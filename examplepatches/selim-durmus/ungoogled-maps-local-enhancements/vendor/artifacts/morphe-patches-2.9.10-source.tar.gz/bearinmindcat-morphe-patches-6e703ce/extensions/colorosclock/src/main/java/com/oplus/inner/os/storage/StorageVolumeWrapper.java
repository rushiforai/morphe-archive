package com.oplus.inner.os.storage;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Clock uses, answering "absent" off ColorOS (no OPPO code). */
public class StorageVolumeWrapper {
    public static int getFatVolumeId(android.os.storage.StorageVolume p0) {
        return 0;
    }
    public static java.lang.String getPath(android.os.storage.StorageVolume p0) {
        return "";
    }
    public static int getReadOnlyType(android.os.storage.StorageVolume p0) {
        return 0;
    }
}
