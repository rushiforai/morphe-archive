package com.oplus.media;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Clock uses, answering "absent" off ColorOS (no OPPO code). */
public class OplusHeifConverter {
    public static class HeifDecodedFrame {
    }
}
