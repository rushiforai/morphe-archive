package android.content.res;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Clock uses, answering "absent" off ColorOS (no OPPO code). */
public class OplusBaseConfiguration {
    public oplus.content.res.OplusExtraConfiguration mOplusExtraConfiguration;
    public oplus.content.res.OplusExtraConfiguration getOplusExtraConfiguration() {
        return null;
    }
}
