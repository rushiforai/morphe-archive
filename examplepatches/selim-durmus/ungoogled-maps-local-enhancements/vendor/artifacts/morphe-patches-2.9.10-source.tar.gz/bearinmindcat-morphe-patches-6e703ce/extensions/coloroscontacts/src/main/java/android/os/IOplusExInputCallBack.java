package android.os;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Contacts uses, answering "absent" off ColorOS (no OPPO code). */
public interface IOplusExInputCallBack {
    public static abstract class Stub extends android.os.Binder implements android.os.IOplusExInputCallBack {
        public Stub() {
        }
    }
}
