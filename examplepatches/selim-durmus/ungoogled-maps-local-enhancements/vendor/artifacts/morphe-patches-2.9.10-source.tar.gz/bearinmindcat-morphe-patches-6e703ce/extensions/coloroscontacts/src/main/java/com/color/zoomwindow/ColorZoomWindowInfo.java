package com.color.zoomwindow;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Contacts uses, answering "absent" off ColorOS (no OPPO code). */
public class ColorZoomWindowInfo {
    public boolean inputShow;
    public java.lang.String lockPkg;
    public int lockUserId;
    public int rotation;
    public boolean windowShown;
    public java.lang.String zoomPkg;
    public android.graphics.Rect zoomRect;
    public int zoomUserId;
}
