package com.color.oshare;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Contacts uses, answering "absent" off ColorOS (no OPPO code). */
public class ColorOshareDevice {
    public boolean equals(java.lang.Object p0) {
        return false;
    }
    public java.lang.String toString() {
        return "";
    }
}
