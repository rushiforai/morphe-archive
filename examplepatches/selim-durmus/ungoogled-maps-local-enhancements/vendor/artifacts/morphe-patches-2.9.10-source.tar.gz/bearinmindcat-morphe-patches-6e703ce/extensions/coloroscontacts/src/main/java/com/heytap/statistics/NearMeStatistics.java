package com.heytap.statistics;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Contacts uses, answering "absent" off ColorOS (no OPPO code). */
public class NearMeStatistics {
    public static boolean isSwitchOn(android.content.Context p0) {
        return false;
    }
    public static void onBaseEvent(android.content.Context p0, int p1, com.heytap.statistics.event.BaseEvent p2) {
    }
}
