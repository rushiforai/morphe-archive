package com.color.inner.content.res;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Clock uses, answering "absent" off ColorOS (no OPPO code). */
public class ResourcesWrapper {
    public static float getCompatApplicationScale(android.content.res.Resources p0) {
        return 0f;
    }
    public static boolean getThemeChanged(android.content.res.Resources p0) {
        return false;
    }
    public static void setIsThemeChanged(android.content.res.Resources p0, boolean p1) {
    }
}
