package com.coloros.eventhub.sdk.aidl;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Contacts uses, answering "absent" off ColorOS (no OPPO code). */
public class DeviceEvent {
    public DeviceEvent(android.os.Parcel p0) {
    }
}
