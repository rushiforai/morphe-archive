package com.color.inner.os;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Contacts uses, answering "absent" off ColorOS (no OPPO code). */
public class UserHandleWrapper {
    public static android.os.UserHandle CURRENT = android.os.Process.myUserHandle();
    public static android.os.UserHandle OWNER = android.os.UserHandle.getUserHandleForUid(0);
    public static int myUserId() {
        return android.os.Process.myUserHandle().hashCode();
    }
}
