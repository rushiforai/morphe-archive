package com.color.inner.telephony;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Contacts uses, answering "absent" off ColorOS (no OPPO code). */
public class CarrierConfigManagerWrapper {
    public static android.os.PersistableBundle getDefaultConfig() {
        return null;
    }
}
