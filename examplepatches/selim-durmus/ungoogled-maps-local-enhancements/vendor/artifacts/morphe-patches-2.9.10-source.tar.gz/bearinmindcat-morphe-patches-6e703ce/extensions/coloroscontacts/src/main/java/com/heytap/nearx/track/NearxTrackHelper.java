package com.heytap.nearx.track;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Contacts uses, answering "absent" off ColorOS (no OPPO code). */
public class NearxTrackHelper {
    public static boolean hasInit;
}
