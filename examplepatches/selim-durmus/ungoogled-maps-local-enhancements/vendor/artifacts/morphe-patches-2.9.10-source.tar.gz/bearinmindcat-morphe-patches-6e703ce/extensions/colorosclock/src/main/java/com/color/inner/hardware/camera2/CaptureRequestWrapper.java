package com.color.inner.hardware.camera2;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Clock uses, answering "absent" off ColorOS (no OPPO code). */
public class CaptureRequestWrapper {
    public static android.hardware.camera2.CaptureRequest.Key captureRequestKey(java.lang.String p0, java.lang.Class p1) {
        return null;
    }
    public static android.hardware.camera2.CaptureRequest.Key captureRequestKey(java.lang.String p0, java.lang.Class p1, long p2) {
        return null;
    }
}
