package oplus.content.res;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Calculator uses, answering "absent" off ColorOS (no OPPO code). */
public class OplusExtraConfiguration {
    public long mMaterialColor;
    public long mThemeChangedFlags;
    public int mUserId;
}
