package com.heytap.baselib.utils;

/** Generated stand-in (.github/scripts/coloros-standins): names and signatures OnePlus Contacts uses, answering "absent" off ColorOS (no OPPO code). */
public class ClientIdUtils {
    public static com.heytap.baselib.utils.ClientIdUtils INSTANCE;
    public java.lang.String getClientId(android.content.Context p0) {
        return "";
    }
}
