.class public final Ladxz;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Loyh;

.field public c:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Loyh;)V
    .locals 0

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    iput-object p1, p0, Ladxz;->a:Landroid/content/Context;

    .line 9
    iput-object p2, p0, Ladxz;->b:Loyh;

    .line 11
    return-void
.end method
