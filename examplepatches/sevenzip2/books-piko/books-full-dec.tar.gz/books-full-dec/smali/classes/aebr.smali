.class public final Laebr;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laebr;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laebr;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laebr;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laebr;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laebr;->e:Lbeye;

    .line 14
    return-void
.end method


# virtual methods
.method public final a()Laebq;
    .locals 4

    .line 1
    iget-object v0, p0, Laebr;->a:Lbeye;

    .line 3
    check-cast v0, Lpwn;

    .line 5
    invoke-virtual {v0}, Lpwn;->a()Landroid/accounts/Account;

    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Laebr;->b:Lbeye;

    .line 11
    check-cast v1, Lakws;

    .line 13
    invoke-virtual {v1}, Lakws;->a()Lakwr;

    .line 16
    move-result-object v1

    .line 17
    iget-object v2, p0, Laebr;->c:Lbeye;

    .line 19
    invoke-interface {v2}, Lbeye;->b()Ljava/lang/Object;

    .line 22
    move-result-object v2

    .line 23
    check-cast v2, Laebm;

    .line 25
    iget-object v2, p0, Laebr;->d:Lbeye;

    .line 27
    check-cast v2, Loxv;

    .line 29
    invoke-virtual {v2}, Loxv;->a()Loxu;

    .line 32
    move-result-object v2

    .line 33
    iget-object p0, p0, Laebr;->e:Lbeye;

    .line 35
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 38
    move-result-object p0

    .line 39
    check-cast p0, Lalog;

    .line 41
    new-instance v3, Laebq;

    .line 43
    invoke-direct {v3, v0, v1, v2, p0}, Laebq;-><init>(Landroid/accounts/Account;Lakwr;Loxu;Lalog;)V

    .line 46
    return-object v3
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Laebr;->a()Laebq;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
