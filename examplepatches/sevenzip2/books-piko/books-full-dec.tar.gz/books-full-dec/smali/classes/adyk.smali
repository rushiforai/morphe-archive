.class public final synthetic Ladyk;
.super Ljava/lang/Object;
.source "PG"