.class public final synthetic Lacfc;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwq;


# instance fields
.field public final synthetic a:Lacfk;

.field public final synthetic b:Ljava/util/Collection;


# direct methods
.method public synthetic constructor <init>(Lacfk;Ljava/util/Collection;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacfc;->a:Lacfk;

    .line 6
    iput-object p2, p0, Lacfc;->b:Ljava/util/Collection;

    .line 8
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lacfc;->a:Lacfk;

    .line 3
    iget-object v0, v0, Lacfk;->b:Lmld;

    .line 5
    check-cast p1, Lmsi;

    .line 7
    iget-object p0, p0, Lacfc;->b:Ljava/util/Collection;

    .line 9
    invoke-virtual {v0, p1, p0}, Lmld;->d(Lmsi;Ljava/lang/Iterable;)V

    .line 12
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 14
    return-object p0
.end method
