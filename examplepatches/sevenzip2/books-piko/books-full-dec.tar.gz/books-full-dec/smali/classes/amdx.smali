.class public interface abstract Lamdx;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract a(Landroidx/work/WorkerParameters;)Lneo;
.end method
