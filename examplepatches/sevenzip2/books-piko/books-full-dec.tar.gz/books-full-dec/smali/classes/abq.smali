.class public final Labq;
.super Ljava/lang/Object;
.source "PG"


# static fields
.field private static final a:I = -0x19000001

.field private static final b:I = -0x7fe4e4e5

.field private static c:Laby;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 1
    return-void
.end method

.method public static synthetic a(Labl;)V
    .locals 8

    .line 1
    new-instance v0, Lacl;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance v2, Lacm;

    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-direct {v2, v1, v1, v0}, Lacm;-><init>(IILbhwq;)V

    .line 12
    sget v0, Labq;->a:I

    .line 14
    sget v1, Labq;->b:I

    .line 16
    new-instance v3, Lacl;

    .line 18
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 21
    move-object v4, v3

    .line 22
    new-instance v3, Lacm;

    .line 24
    invoke-direct {v3, v0, v1, v4}, Lacm;-><init>(IILbhwq;)V

    .line 27
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 34
    move-result-object v5

    .line 35
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 38
    sget-object v0, Labq;->c:Laby;

    .line 40
    if-nez v0, :cond_5

    .line 42
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 44
    const/16 v1, 0x23

    .line 46
    if-lt v0, v1, :cond_0

    .line 48
    new-instance v0, Labw;

    .line 50
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 53
    goto :goto_0

    .line 54
    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 56
    const/16 v1, 0x1e

    .line 58
    if-lt v0, v1, :cond_1

    .line 60
    new-instance v0, Labv;

    .line 62
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 65
    goto :goto_0

    .line 66
    :cond_1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 68
    const/16 v1, 0x1d

    .line 70
    if-lt v0, v1, :cond_2

    .line 72
    new-instance v0, Labu;

    .line 74
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 77
    goto :goto_0

    .line 78
    :cond_2
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 80
    const/16 v1, 0x1c

    .line 82
    if-lt v0, v1, :cond_3

    .line 84
    new-instance v0, Labt;

    .line 86
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 89
    goto :goto_0

    .line 90
    :cond_3
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 92
    const/16 v1, 0x1a

    .line 94
    if-lt v0, v1, :cond_4

    .line 96
    new-instance v0, Labs;

    .line 98
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 101
    goto :goto_0

    .line 102
    :cond_4
    new-instance v0, Labr;

    .line 104
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 107
    :goto_0
    sput-object v0, Labq;->c:Laby;

    .line 109
    :cond_5
    move-object v1, v0

    .line 110
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    .line 113
    move-result-object v4

    .line 114
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 117
    iget-object v0, v2, Lacm;->b:Lbhwq;

    .line 119
    invoke-virtual {v5}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 122
    move-result-object v6

    .line 123
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 126
    invoke-interface {v0, v6}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 129
    move-result-object v0

    .line 130
    check-cast v0, Ljava/lang/Boolean;

    .line 132
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 135
    move-result v6

    .line 136
    iget-object v0, v3, Lacm;->b:Lbhwq;

    .line 138
    invoke-virtual {v5}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 141
    move-result-object v7

    .line 142
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 145
    invoke-interface {v0, v7}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 148
    move-result-object v0

    .line 149
    check-cast v0, Ljava/lang/Boolean;

    .line 151
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 154
    move-result v7

    .line 155
    invoke-interface/range {v1 .. v7}, Laby;->a(Lacm;Lacm;Landroid/view/Window;Landroid/view/View;ZZ)V

    .line 158
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    .line 161
    move-result-object p0

    .line 162
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 165
    invoke-interface {v1, p0}, Laby;->b(Landroid/view/Window;)V

    .line 168
    return-void
.end method
