.class public final Laain;
.super Ljava/lang/Object;
.source "PG"


# static fields
.field public static final a:Laaio;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Laaio;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    sput-object v0, Laain;->a:Laaio;

    .line 8
    return-void
.end method
