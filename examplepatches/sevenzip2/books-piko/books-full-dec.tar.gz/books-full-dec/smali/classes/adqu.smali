.class public final Ladqu;
.super Lajdj;
.source "PG"

# interfaces
.implements Ladqs;


# static fields
.field private static final a:Layxl;

.field private static final b:Ljava/util/Set;


# instance fields
.field private final c:Lahjo;

.field private final d:Landroid/accounts/Account;

.field private final e:Lahjj;

.field private final f:Ladrb;

.field private final g:Luxd;

.field private final h:Lppr;

.field private final i:Z

.field private final j:Layhy;

.field private final k:Lahjy;

.field private final l:Loxu;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-string v0, "com/google/android/apps/play/books/ebook/server/EBookServerImpl"

    .line 3
    invoke-static {v0}, Layxl;->i(Ljava/lang/String;)Layxl;

    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Ladqu;->a:Layxl;

    .line 9
    new-instance v0, Ljava/util/HashSet;

    .line 11
    const/4 v1, 0x2

    .line 12
    invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(I)V

    .line 15
    sput-object v0, Ladqu;->b:Ljava/util/Set;

    .line 17
    const-string v1, "text/css"

    .line 19
    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 22
    const-string v1, "smil"

    .line 24
    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 27
    return-void
.end method

.method public constructor <init>(Lahjo;Landroid/accounts/Account;Lahjj;Ladrb;Luxd;Lwon;Lppr;Layhy;Loxu;Lahka;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lajdj;-><init>(Lahjo;Landroid/accounts/Account;)V

    .line 4
    iput-object p1, p0, Ladqu;->c:Lahjo;

    .line 6
    iput-object p2, p0, Ladqu;->d:Landroid/accounts/Account;

    .line 8
    iput-object p3, p0, Ladqu;->e:Lahjj;

    .line 10
    iput-object p4, p0, Ladqu;->f:Ladrb;

    .line 12
    iput-object p5, p0, Ladqu;->g:Luxd;

    .line 14
    iput-object p7, p0, Ladqu;->h:Lppr;

    .line 16
    sget-object p1, Lwoq;->C:Lwoq;

    .line 18
    invoke-virtual {p1, p6}, Lwoq;->g(Lwon;)Z

    .line 21
    move-result p1

    .line 22
    iput-boolean p1, p0, Ladqu;->i:Z

    .line 24
    iput-object p8, p0, Ladqu;->j:Layhy;

    .line 26
    iput-object p9, p0, Ladqu;->l:Loxu;

    .line 28
    sget-object p1, Ladqu;->a:Layxl;

    .line 30
    invoke-virtual {p10, p1}, Lahka;->a(Layxl;)Lahjy;

    .line 33
    move-result-object p1

    .line 34
    iput-object p1, p0, Ladqu;->k:Lahjy;

    .line 36
    return-void
.end method

.method private final l(Lacps;Lorg/apache/http/HttpEntity;Lajej;)Lacpi;
    .locals 5

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "EbookServer"

    .line 4
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 7
    move-result v0

    .line 8
    invoke-virtual {p1}, Lacps;->d()Ljava/lang/String;

    .line 11
    move-result-object p1

    .line 12
    if-eqz v0, :cond_0

    .line 14
    const-string v2, "Parsing "

    .line 16
    const-string v3, " resource response"

    .line 18
    invoke-static {p1, v2, v3}, La;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 21
    move-result-object v2

    .line 22
    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 25
    :cond_0
    const-string v2, "text/css"

    .line 27
    invoke-static {p1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 30
    move-result v2

    .line 31
    const/4 v3, 0x0

    .line 32
    if-eqz v2, :cond_2

    .line 34
    invoke-interface {p2}, Lorg/apache/http/HttpEntity;->getContent()Ljava/io/InputStream;

    .line 37
    move-result-object p1

    .line 38
    invoke-static {p1}, Lakve;->h(Ljava/io/InputStream;)[B

    .line 41
    move-result-object p1

    .line 42
    invoke-static {}, Lbdsj;->a()Lbdsj;

    .line 45
    move-result-object v0

    .line 46
    sget-object v2, Lbccy;->a:Lbccy;

    .line 48
    invoke-static {v2, p1, v0}, Lbdtb;->parseFrom(Lbdtb;[BLbdsj;)Lbdtb;

    .line 51
    move-result-object p1

    .line 52
    check-cast p1, Lbccy;

    .line 54
    invoke-static {p1}, Ladqu;->n(Lbccy;)Ljava/util/List;

    .line 57
    move-result-object v0

    .line 58
    iget-object p1, p1, Lbccy;->f:Ljava/lang/String;

    .line 60
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    .line 63
    move-result-object p1

    .line 64
    new-instance v2, Ljava/lang/String;

    .line 66
    invoke-direct {v2, p1}, Ljava/lang/String;-><init>([B)V

    .line 69
    invoke-static {v2}, Lalnd;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 72
    move-result-object p1

    .line 73
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    .line 76
    move-result-object p1

    .line 77
    :try_start_0
    iget-object v2, p3, Lajej;->a:Lajek;

    .line 79
    iget-object v4, v2, Lajek;->c:[B

    .line 81
    iget-object v2, v2, Lajek;->b:Ljava/lang/String;

    .line 83
    invoke-static {p1, v4, v2}, Laloa;->g([B[BLjava/lang/String;)[B

    .line 86
    move-result-object p1

    .line 87
    new-instance v2, Lajdh;

    .line 89
    new-instance v4, Ljava/io/ByteArrayInputStream;

    .line 91
    invoke-direct {v4, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    .line 94
    invoke-direct {v2, v3, v4, p3}, Lajdh;-><init>(Lorg/apache/http/HttpEntity;Ljava/io/InputStream;Lajej;)V

    .line 97
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 98
    :catch_0
    move-exception p3

    .line 99
    new-instance v2, Lajdh;

    .line 101
    new-instance v4, Ljava/io/ByteArrayInputStream;

    .line 103
    invoke-direct {v4, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    .line 106
    invoke-direct {v2, v3, v4, v3}, Lajdh;-><init>(Lorg/apache/http/HttpEntity;Ljava/io/InputStream;Lajej;)V

    .line 109
    const/4 p1, 0x6

    .line 110
    invoke-static {v1, p1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 113
    move-result p1

    .line 114
    if-eqz p1, :cond_1

    .line 116
    const-string p1, "Error encrypting CSS content locally"

    .line 118
    invoke-static {v1, p1, p3}, Lakvo;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 121
    :cond_1
    iget-object p0, p0, Ladqu;->h:Lppr;

    .line 123
    const-string p1, "ERROR_ENCRYPTING_CSS"

    .line 125
    invoke-virtual {p0, p1}, Lppr;->d(Ljava/lang/String;)V

    .line 128
    :goto_0
    invoke-static {p2}, Lahio;->f(Lorg/apache/http/HttpEntity;)V

    .line 131
    move-object v3, v0

    .line 132
    goto/16 :goto_2

    .line 134
    :cond_2
    const-string p0, "image/svg+xml"

    .line 136
    invoke-static {p1, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 139
    move-result p0

    .line 140
    if-eqz p0, :cond_3

    .line 142
    invoke-interface {p2}, Lorg/apache/http/HttpEntity;->getContent()Ljava/io/InputStream;

    .line 145
    move-result-object p0

    .line 146
    invoke-static {p0}, Lakve;->h(Ljava/io/InputStream;)[B

    .line 149
    move-result-object p0

    .line 150
    invoke-static {}, Lbdsj;->a()Lbdsj;

    .line 153
    move-result-object p1

    .line 154
    sget-object v0, Lbccy;->a:Lbccy;

    .line 156
    invoke-static {v0, p0, p1}, Lbdtb;->parseFrom(Lbdtb;[BLbdsj;)Lbdtb;

    .line 159
    move-result-object p0

    .line 160
    check-cast p0, Lbccy;

    .line 162
    invoke-static {p0}, Ladqu;->n(Lbccy;)Ljava/util/List;

    .line 165
    move-result-object p1

    .line 166
    new-instance v2, Lajdh;

    .line 168
    iget-object p0, p0, Lbccy;->d:Lbdrs;

    .line 170
    invoke-virtual {p0}, Lbdrs;->h()Ljava/io/InputStream;

    .line 173
    move-result-object p0

    .line 174
    invoke-direct {v2, v3, p0, p3}, Lajdh;-><init>(Lorg/apache/http/HttpEntity;Ljava/io/InputStream;Lajej;)V

    .line 177
    invoke-static {p2}, Lahio;->f(Lorg/apache/http/HttpEntity;)V

    .line 180
    :goto_1
    move-object v3, p1

    .line 181
    goto :goto_2

    .line 182
    :cond_3
    const-string p0, "smil"

    .line 184
    invoke-static {p1, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 187
    move-result p0

    .line 188
    if-eqz p0, :cond_5

    .line 190
    invoke-interface {p2}, Lorg/apache/http/HttpEntity;->getContent()Ljava/io/InputStream;

    .line 193
    move-result-object p0

    .line 194
    invoke-static {p0}, Lakve;->h(Ljava/io/InputStream;)[B

    .line 197
    move-result-object p0

    .line 198
    invoke-static {}, Lbdsj;->a()Lbdsj;

    .line 201
    move-result-object p1

    .line 202
    sget-object v2, Lbccy;->a:Lbccy;

    .line 204
    invoke-static {v2, p0, p1}, Lbdtb;->parseFrom(Lbdtb;[BLbdsj;)Lbdtb;

    .line 207
    move-result-object p0

    .line 208
    check-cast p0, Lbccy;

    .line 210
    if-eqz v0, :cond_4

    .line 212
    iget-object p1, p0, Lbccy;->h:Lbdts;

    .line 214
    invoke-interface {p1}, Lbdts;->size()I

    .line 217
    move-result p1

    .line 218
    new-instance v0, Ljava/lang/StringBuilder;

    .line 220
    const-string v2, "found "

    .line 222
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 225
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 228
    const-string p1, " audio resources in SMIL resource"

    .line 230
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 233
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 236
    move-result-object p1

    .line 237
    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 240
    :cond_4
    invoke-static {p0}, Ladqu;->n(Lbccy;)Ljava/util/List;

    .line 243
    move-result-object p1

    .line 244
    new-instance v2, Lajdh;

    .line 246
    iget-object p0, p0, Lbccy;->d:Lbdrs;

    .line 248
    invoke-virtual {p0}, Lbdrs;->h()Ljava/io/InputStream;

    .line 251
    move-result-object p0

    .line 252
    invoke-direct {v2, v3, p0, p3}, Lajdh;-><init>(Lorg/apache/http/HttpEntity;Ljava/io/InputStream;Lajej;)V

    .line 255
    invoke-static {p2}, Lahio;->f(Lorg/apache/http/HttpEntity;)V

    .line 258
    goto :goto_1

    .line 259
    :cond_5
    invoke-static {p1}, Lacps;->i(Ljava/lang/String;)Z

    .line 262
    move-result p0

    .line 263
    if-nez p0, :cond_6

    .line 265
    const-string p0, "audio"

    .line 267
    invoke-static {p1, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 270
    move-result p0

    .line 271
    if-eqz p0, :cond_7

    .line 273
    :cond_6
    move-object p3, v3

    .line 274
    :cond_7
    new-instance v2, Lajdh;

    .line 276
    invoke-direct {v2, p2, p3}, Lajdh;-><init>(Lorg/apache/http/HttpEntity;Lajej;)V

    .line 279
    :goto_2
    new-instance p0, Lacpj;

    .line 281
    invoke-direct {p0, v2, v3}, Lacpj;-><init>(Lajeh;Ljava/util/List;)V

    .line 284
    return-object p0
.end method

.method private static final m(Lbccy;Ljava/util/Set;)Ljava/util/List;
    .locals 6

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 6
    iget-object p0, p0, Lbccy;->h:Lbdts;

    .line 8
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 11
    move-result-object p0

    .line 12
    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_2

    .line 18
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Lbcdy;

    .line 24
    iget v2, v1, Lbcdy;->b:I

    .line 26
    and-int/lit8 v2, v2, 0x2

    .line 28
    if-eqz v2, :cond_0

    .line 30
    if-eqz p1, :cond_1

    .line 32
    iget-object v2, v1, Lbcdy;->d:Ljava/lang/String;

    .line 34
    invoke-interface {p1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 37
    move-result v2

    .line 38
    if-nez v2, :cond_0

    .line 40
    :cond_1
    invoke-static {}, Lacps;->j()Lacpa;

    .line 43
    move-result-object v2

    .line 44
    iget-object v3, v1, Lbcdy;->c:Ljava/lang/String;

    .line 46
    const-string v4, "&amp;"

    .line 48
    const-string v5, "&"

    .line 50
    invoke-virtual {v3, v4, v5}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 53
    move-result-object v3

    .line 54
    const/4 v4, 0x0

    .line 55
    const/4 v5, 0x0

    .line 56
    invoke-static {v3, v5, v4, v5}, Lacpt;->a(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)Ljava/lang/String;

    .line 59
    move-result-object v4

    .line 60
    iput-object v4, v2, Lacpa;->a:Ljava/lang/String;

    .line 62
    iput-object v3, v2, Lacpa;->b:Ljava/lang/String;

    .line 64
    iget-object v1, v1, Lbcdy;->d:Ljava/lang/String;

    .line 66
    iput-object v1, v2, Lacpa;->c:Ljava/lang/String;

    .line 68
    invoke-virtual {v2}, Lacpa;->a()Lacps;

    .line 71
    move-result-object v1

    .line 72
    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 75
    goto :goto_0

    .line 76
    :cond_2
    return-object v0
.end method

.method private static final n(Lbccy;)Ljava/util/List;
    .locals 1

    .line 1
    invoke-static {p0}, Lalmy;->a(Lbccy;)V

    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-static {p0, v0}, Ladqu;->m(Lbccy;Ljava/util/Set;)Ljava/util/List;

    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method


# virtual methods
.method public final a(Ljava/lang/String;Lacps;Lacpo;Lajej;)Lacpi;
    .locals 10

    .line 1
    const-string v0, "getResourceContent"

    .line 3
    const-string v1, "com/google/android/apps/play/books/ebook/server/EBookServerImpl"

    .line 5
    const-string v2, "Server returned \'image not available\' gif for "

    .line 7
    invoke-virtual {p2}, Lacps;->f()Ljava/lang/String;

    .line 10
    move-result-object v3

    .line 11
    invoke-virtual {p2}, Lacps;->d()Ljava/lang/String;

    .line 14
    move-result-object v4

    .line 15
    invoke-static {v3}, Lacpt;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 18
    move-result-object v5

    .line 19
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    const-string v6, "EBookServerImpl.java"

    .line 24
    const/4 v7, 0x3

    .line 25
    const-string v8, "EbookServer"

    .line 27
    invoke-static {v8, v7}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 30
    move-result v7

    .line 31
    if-eqz v7, :cond_0

    .line 33
    invoke-static {v5}, Lakww;->c(Ljava/lang/String;)Ljava/lang/String;

    .line 36
    move-result-object v5

    .line 37
    new-instance v7, Ljava/lang/StringBuilder;

    .line 39
    const-string v9, "Fetching volume "

    .line 41
    invoke-direct {v7, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 44
    invoke-virtual {v7, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 47
    const-string p1, ", resource ID "

    .line 49
    invoke-virtual {v7, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 52
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 58
    move-result-object p1

    .line 59
    invoke-static {v8, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 62
    :cond_0
    if-eqz v3, :cond_1

    .line 64
    const-string p1, "&hk=1"

    .line 66
    const-string v5, ""

    .line 68
    invoke-virtual {v3, p1, v5}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 71
    move-result-object v3

    .line 72
    :cond_1
    iget-object p1, p0, Ladqu;->e:Lahjj;

    .line 74
    iget-object v5, p4, Lajej;->a:Lajek;

    .line 76
    invoke-static {p1, v3, v5}, Lwva;->b(Lahjj;Ljava/lang/String;Lajek;)Landroid/net/Uri$Builder;

    .line 79
    move-result-object p1

    .line 80
    const-string v7, "text/css"

    .line 82
    invoke-static {v4, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 85
    move-result v7

    .line 86
    if-nez v7, :cond_2

    .line 88
    const-string v7, "smil"

    .line 90
    invoke-static {v4, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 93
    move-result v7

    .line 94
    if-nez v7, :cond_2

    .line 96
    const-string v7, "image/svg+xml"

    .line 98
    invoke-static {v4, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 101
    move-result v7

    .line 102
    if-eqz v7, :cond_3

    .line 104
    :cond_2
    const-string v7, "alt"

    .line 106
    const-string v8, "proto"

    .line 108
    invoke-virtual {p1, v7, v8}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 111
    :cond_3
    if-eqz p3, :cond_4

    .line 113
    iget-object p3, p3, Lacpo;->a:Ljava/lang/String;

    .line 115
    const-string v7, "lsess"

    .line 117
    invoke-virtual {p1, v7, p3}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 120
    :cond_4
    const-string p3, "audio"

    .line 122
    invoke-virtual {p3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 125
    move-result p3

    .line 126
    if-eqz p3, :cond_5

    .line 128
    sget-object p3, Lahis;->a:Layys;

    .line 130
    const-string p3, "container"

    .line 132
    const-string v4, "mpg"

    .line 134
    invoke-virtual {p1, p3, v4}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 137
    :cond_5
    invoke-virtual {p1}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 140
    move-result-object p1

    .line 141
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 144
    move-result-object p1

    .line 145
    const/4 p3, 0x0

    .line 146
    :try_start_0
    invoke-static {}, Lbfxi;->f()Z

    .line 149
    move-result v4

    .line 150
    if-eqz v4, :cond_6

    .line 152
    sget-object v4, Ladqu;->a:Layxl;

    .line 154
    invoke-virtual {v4}, Layxb;->d()Layxz;

    .line 157
    move-result-object v4

    .line 158
    check-cast v4, Layxi;

    .line 160
    const/16 v7, 0x11d

    .line 162
    invoke-interface {v4, v1, v0, v7, v6}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 165
    move-result-object v4

    .line 166
    check-cast v4, Layxi;

    .line 168
    const-string v7, "RPCEvent[getResourceContent]"

    .line 170
    invoke-interface {v4, v7}, Layxi;->s(Ljava/lang/String;)V

    .line 173
    :cond_6
    iget-object v4, p0, Ladqu;->c:Lahjo;

    .line 175
    iget-object v7, p0, Ladqu;->d:Landroid/accounts/Account;

    .line 177
    invoke-interface {v4, p1, v7}, Lahjo;->d(Ljava/lang/String;Landroid/accounts/Account;)Lorg/apache/http/HttpResponse;

    .line 180
    move-result-object p1

    .line 181
    invoke-interface {p1}, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;

    .line 184
    move-result-object p3

    .line 185
    invoke-interface {p3}, Lorg/apache/http/HttpEntity;->getContentType()Lorg/apache/http/Header;

    .line 188
    move-result-object p1

    .line 189
    invoke-interface {p1}, Lorg/apache/http/Header;->getValue()Ljava/lang/String;

    .line 192
    move-result-object p1

    .line 193
    const-string v4, "image/gif"

    .line 195
    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 198
    move-result p1

    .line 199
    if-nez p1, :cond_7

    .line 201
    invoke-direct {p0, p2, p3, p4}, Ladqu;->l(Lacps;Lorg/apache/http/HttpEntity;Lajej;)Lacpi;

    .line 204
    move-result-object p0

    .line 205
    return-object p0

    .line 206
    :cond_7
    new-instance p0, Lcom/google/android/apps/play/books/net/HttpHelper$ServerIoException;

    .line 208
    iget-object p1, v5, Lajek;->b:Ljava/lang/String;

    .line 210
    new-instance p2, Ljava/lang/StringBuilder;

    .line 212
    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 215
    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 218
    const-string p4, " and key "

    .line 220
    invoke-virtual {p2, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 223
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 226
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 229
    move-result-object p1

    .line 230
    invoke-direct {p0, p1}, Lcom/google/android/apps/play/books/net/HttpHelper$ServerIoException;-><init>(Ljava/lang/String;)V

    .line 233
    throw p0

    .line 234
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Lcom/google/android/gms/auth/GoogleAuthException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    move-exception p0

    .line 235
    goto :goto_1

    .line 236
    :catch_0
    move-exception p0

    .line 237
    goto :goto_0

    .line 238
    :catch_1
    move-exception p0

    .line 239
    :goto_0
    :try_start_1
    sget-object p1, Ladqu;->a:Layxl;

    .line 241
    invoke-virtual {p1}, Layxb;->c()Layxz;

    .line 244
    move-result-object p1

    .line 245
    check-cast p1, Layxi;

    .line 247
    invoke-interface {p1, p0}, Layxi;->i(Ljava/lang/Throwable;)Layxz;

    .line 250
    move-result-object p1

    .line 251
    check-cast p1, Layxi;

    .line 253
    const/16 p2, 0x132

    .line 255
    invoke-interface {p1, v1, v0, p2, v6}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 258
    move-result-object p1

    .line 259
    check-cast p1, Layxi;

    .line 261
    const-string p2, "RPCError[getResourceContent]"

    .line 263
    invoke-interface {p1, p2}, Layxi;->s(Ljava/lang/String;)V

    .line 266
    throw p0

    .line 267
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_1
    invoke-static {p3}, Lahio;->f(Lorg/apache/http/HttpEntity;)V

    .line 270
    throw p0
.end method

.method public final b(Ljava/lang/String;Ladqx;)Lacpk;
    .locals 30

    .line 1
    move-object/from16 v1, p0

    .line 3
    move-object/from16 v2, p1

    .line 5
    move-object/from16 v3, p2

    .line 7
    const-string v4, "time_background"

    .line 9
    const-string v5, "insufficient fast book open data for volume: "

    .line 11
    iget-boolean v0, v3, Ladqx;->b:Z

    .line 13
    const-string v6, "com/google/android/apps/play/books/ebook/server/EBookServerImpl"

    .line 15
    const-string v7, "getFastBookOpenData"

    .line 17
    const/4 v8, 0x1

    .line 18
    const-string v9, "EBookServerImpl.java"

    .line 20
    if-eqz v0, :cond_1

    .line 22
    :try_start_0
    iget-object v0, v1, Ladqu;->e:Lahjj;

    .line 24
    invoke-virtual {v0}, Lahjj;->e()Landroid/net/Uri;

    .line 27
    move-result-object v0

    .line 28
    sget-object v10, Lbazj;->a:Lbazj;

    .line 30
    invoke-virtual {v10}, Lbdtb;->createBuilder()Lbdst;

    .line 33
    move-result-object v10

    .line 34
    check-cast v10, Lbazi;

    .line 36
    sget-object v11, Lbaxk;->a:Lbaxk;

    .line 38
    invoke-virtual {v11}, Lbdtb;->createBuilder()Lbdst;

    .line 41
    move-result-object v11

    .line 42
    check-cast v11, Lbaxj;

    .line 44
    iget-object v12, v1, Ladqu;->j:Layhy;

    .line 46
    invoke-virtual {v12}, Layhy;->g()Z

    .line 49
    move-result v13

    .line 50
    if-eqz v13, :cond_0

    .line 52
    iget-boolean v13, v3, Ladqx;->c:Z

    .line 54
    if-eqz v13, :cond_0

    .line 56
    invoke-virtual {v12}, Layhy;->c()Ljava/lang/Object;

    .line 59
    move-result-object v12

    .line 60
    check-cast v12, Ljava/lang/Long;

    .line 62
    invoke-virtual {v12}, Ljava/lang/Long;->longValue()J

    .line 65
    move-result-wide v12

    .line 66
    invoke-virtual {v11}, Lbdst;->u()V

    .line 69
    iget-object v14, v11, Lbaxj;->b:Lbdtb;

    .line 71
    check-cast v14, Lbaxk;

    .line 73
    iput-wide v12, v14, Lbaxk;->f:J

    .line 75
    :cond_0
    invoke-virtual {v10}, Lbdst;->u()V

    .line 78
    iget-object v12, v10, Lbazi;->b:Lbdtb;

    .line 80
    check-cast v12, Lbazj;

    .line 82
    invoke-virtual {v11}, Lbdst;->q()Lbdtb;

    .line 85
    move-result-object v11

    .line 86
    check-cast v11, Lbaxk;

    .line 88
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 91
    iput-object v11, v12, Lbazj;->c:Lbaxk;

    .line 93
    iget v11, v12, Lbazj;->b:I

    .line 95
    or-int/2addr v11, v8

    .line 96
    iput v11, v12, Lbazj;->b:I

    .line 98
    invoke-virtual {v10}, Lbdst;->u()V

    .line 101
    iget-object v11, v10, Lbazi;->b:Lbdtb;

    .line 103
    check-cast v11, Lbazj;

    .line 105
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 108
    iput-object v2, v11, Lbazj;->d:Ljava/lang/String;

    .line 110
    invoke-virtual {v10}, Lbdst;->q()Lbdtb;

    .line 113
    move-result-object v10

    .line 114
    check-cast v10, Lbazj;

    .line 116
    sget-object v11, Lbazl;->a:Lbazl;

    .line 118
    const-class v11, Lbazl;

    .line 120
    invoke-static {v11}, Lbdtb;->getParserForClass(Ljava/lang/Class;)Lbduo;

    .line 123
    move-result-object v11

    .line 124
    invoke-virtual {v1, v0, v10, v11}, Lajdj;->j(Landroid/net/Uri;Lbdui;Lbduo;)Lbdui;

    .line 127
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Lcom/google/android/gms/auth/GoogleAuthException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    .line 128
    :catch_0
    move-exception v0

    .line 129
    goto :goto_0

    .line 130
    :catch_1
    move-exception v0

    .line 131
    :goto_0
    sget-object v10, Ladqu;->a:Layxl;

    .line 133
    invoke-virtual {v10}, Layxb;->c()Layxz;

    .line 136
    move-result-object v10

    .line 137
    check-cast v10, Layxi;

    .line 139
    invoke-interface {v10, v0}, Layxi;->i(Ljava/lang/Throwable;)Layxz;

    .line 142
    move-result-object v0

    .line 143
    check-cast v0, Layxi;

    .line 145
    const/16 v10, 0x271

    .line 147
    invoke-interface {v0, v6, v7, v10, v9}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 150
    move-result-object v0

    .line 151
    check-cast v0, Layxi;

    .line 153
    const-string v10, "Error during add to lib FBO %s"

    .line 155
    invoke-interface {v0, v10, v2}, Layxi;->v(Ljava/lang/String;Ljava/lang/Object;)V

    .line 158
    :cond_1
    :goto_1
    iget-object v0, v1, Ladqu;->e:Lahjj;

    .line 160
    iget-boolean v10, v3, Ladqx;->a:Z

    .line 162
    iget-boolean v11, v1, Ladqu;->i:Z

    .line 164
    iget-boolean v12, v3, Ladqx;->c:Z

    .line 166
    if-eqz v12, :cond_2

    .line 168
    iget-object v12, v1, Ladqu;->j:Layhy;

    .line 170
    invoke-virtual {v12}, Layhy;->g()Z

    .line 173
    move-result v14

    .line 174
    if-eqz v14, :cond_2

    .line 176
    invoke-virtual {v12}, Layhy;->c()Ljava/lang/Object;

    .line 179
    move-result-object v12

    .line 180
    check-cast v12, Ljava/lang/Long;

    .line 182
    goto :goto_2

    .line 183
    :cond_2
    const/4 v12, 0x0

    .line 184
    :goto_2
    invoke-virtual {v0}, Lahjj;->a()Landroid/net/Uri$Builder;

    .line 187
    move-result-object v14

    .line 188
    const-string v15, "books"

    .line 190
    invoke-virtual {v14, v15}, Landroid/net/Uri$Builder;->appendEncodedPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 193
    move-result-object v14

    .line 194
    const-string v15, "content"

    .line 196
    invoke-virtual {v14, v15}, Landroid/net/Uri$Builder;->appendEncodedPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 199
    move-result-object v14

    .line 200
    const-string v15, "volumes"

    .line 202
    invoke-virtual {v14, v15}, Landroid/net/Uri$Builder;->appendEncodedPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 205
    move-result-object v14

    .line 206
    invoke-virtual {v14, v2}, Landroid/net/Uri$Builder;->appendEncodedPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 209
    move-result-object v14

    .line 210
    const-string v15, "manifest2"

    .line 212
    invoke-virtual {v14, v15}, Landroid/net/Uri$Builder;->appendEncodedPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 215
    move-result-object v14

    .line 216
    const-string v15, "alt"

    .line 218
    const-string v13, "proto"

    .line 220
    invoke-virtual {v14, v15, v13}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 223
    move-result-object v13

    .line 224
    const-string v14, "1"

    .line 226
    if-eq v8, v10, :cond_3

    .line 228
    const-string v15, "0"

    .line 230
    goto :goto_3

    .line 231
    :cond_3
    move-object v15, v14

    .line 232
    :goto_3
    move/from16 v16, v8

    .line 234
    const-string v8, "overview"

    .line 236
    invoke-virtual {v13, v8, v15}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 239
    move-result-object v8

    .line 240
    const-string v13, "bbevo"

    .line 242
    invoke-virtual {v8, v13, v14}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 245
    move-result-object v8

    .line 246
    if-eqz v12, :cond_4

    .line 248
    invoke-virtual {v12}, Ljava/lang/Long;->longValue()J

    .line 251
    move-result-wide v12

    .line 252
    invoke-static {v12, v13}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    .line 255
    move-result-object v12

    .line 256
    const-string v13, "android_id"

    .line 258
    invoke-virtual {v8, v13, v12}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 261
    :cond_4
    const-string v12, ""

    .line 263
    if-eqz v11, :cond_5

    .line 265
    const-string v11, "lsess"

    .line 267
    invoke-virtual {v8, v11, v12}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 270
    :cond_5
    const-string v11, "hk"

    .line 272
    invoke-virtual {v8, v11, v14}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 275
    const-string v11, "ev"

    .line 277
    const-string v13, "3a"

    .line 279
    invoke-virtual {v8, v11, v13}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 282
    const-string v11, "ef"

    .line 284
    const-string v13, "4"

    .line 286
    invoke-virtual {v8, v11, v13}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 289
    const-string v11, "ftc"

    .line 291
    invoke-virtual {v8, v11, v14}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 294
    const-string v11, "oos"

    .line 296
    invoke-virtual {v8, v11, v14}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 299
    const-string v11, "multi_toc"

    .line 301
    invoke-virtual {v8, v11, v14}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 304
    const-string v11, "av"

    .line 306
    const-string v13, "2"

    .line 308
    invoke-virtual {v8, v11, v13}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 311
    const-string v11, "svg"

    .line 313
    invoke-virtual {v8, v11, v13}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 316
    const-string v11, "math"

    .line 318
    invoke-virtual {v8, v11, v14}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 321
    const-string v11, "flvers"

    .line 323
    invoke-virtual {v8, v11, v14}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 326
    const-string v11, "vert"

    .line 328
    invoke-virtual {v8, v11, v14}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 331
    const-string v11, "spread_regions"

    .line 333
    invoke-virtual {v8, v11, v14}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 336
    const-string v11, "npdf"

    .line 338
    invoke-virtual {v8, v11, v14}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 341
    invoke-virtual {v8}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 344
    move-result-object v8

    .line 345
    invoke-virtual {v8}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 348
    move-result-object v8

    .line 349
    invoke-virtual {v0, v8}, Lahjj;->h(Ljava/lang/String;)Landroid/net/Uri;

    .line 352
    move-result-object v0

    .line 353
    invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 356
    move-result-object v0

    .line 357
    const-string v8, "EbookServer"

    .line 359
    const/4 v11, 0x3

    .line 360
    invoke-static {v8, v11}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 363
    move-result v13

    .line 364
    if-eqz v13, :cond_6

    .line 366
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 369
    move-result-object v13

    .line 370
    const-string v14, "Fast Book Open Fetch URL = "

    .line 372
    invoke-virtual {v14, v13}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 375
    move-result-object v13

    .line 376
    invoke-static {v8, v13}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 379
    :cond_6
    new-instance v13, Lorg/apache/http/client/methods/HttpGet;

    .line 381
    invoke-direct {v13, v0}, Lorg/apache/http/client/methods/HttpGet;-><init>(Ljava/lang/String;)V

    .line 384
    const-string v0, "Accept"

    .line 386
    const-string v14, "application/xml,application/xhtml+xml,text/xml,image/svg+xml"

    .line 388
    invoke-virtual {v13, v0, v14}, Lorg/apache/http/client/methods/HttpGet;->setHeader(Ljava/lang/String;Ljava/lang/String;)V

    .line 391
    const-string v0, "Accept-Charset"

    .line 393
    const-string v14, "utf-8"

    .line 395
    invoke-virtual {v13, v0, v14}, Lorg/apache/http/client/methods/HttpGet;->setHeader(Ljava/lang/String;Ljava/lang/String;)V

    .line 398
    const-string v0, "accept-encoding"

    .line 400
    const-string v14, "gzip"

    .line 402
    invoke-virtual {v13, v0, v14}, Lorg/apache/http/client/methods/HttpGet;->setHeader(Ljava/lang/String;Ljava/lang/String;)V

    .line 405
    new-instance v14, Lalsf;

    .line 407
    invoke-direct {v14}, Lalsf;-><init>()V

    .line 410
    :try_start_1
    invoke-static {}, Lbfxi;->f()Z

    .line 413
    move-result v0

    .line 414
    if-eqz v0, :cond_7

    .line 416
    sget-object v0, Ladqu;->a:Layxl;

    .line 418
    invoke-virtual {v0}, Layxb;->d()Layxz;

    .line 421
    move-result-object v0

    .line 422
    check-cast v0, Layxi;

    .line 424
    const/16 v15, 0x289

    .line 426
    invoke-interface {v0, v6, v7, v15, v9}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 429
    move-result-object v0

    .line 430
    check-cast v0, Layxi;

    .line 432
    const-string v15, "RPCEvent[getFastBookData]"

    .line 434
    invoke-interface {v0, v15}, Layxi;->s(Ljava/lang/String;)V

    .line 437
    :try_end_1
    .catch Lcom/google/android/apps/play/books/net/HttpHelper$ServerStatusErrorException; {:try_start_1 .. :try_end_1} :catch_b
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_a
    .catch Lcom/google/android/gms/auth/GoogleAuthException; {:try_start_1 .. :try_end_1} :catch_9
    .catchall {:try_start_1 .. :try_end_1} :catchall_19

    :cond_7
    :try_start_2
    iget-object v0, v1, Ladqu;->c:Lahjo;

    .line 439
    iget-object v15, v1, Ladqu;->d:Landroid/accounts/Account;

    .line 441
    invoke-interface {v0, v13, v15}, Lahjo;->c(Lorg/apache/http/client/methods/HttpUriRequest;Landroid/accounts/Account;)Lorg/apache/http/HttpResponse;

    .line 444
    move-result-object v0

    .line 445
    invoke-interface {v0}, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;

    .line 448
    move-result-object v13

    .line 449
    :try_end_2
    .catch Lcom/google/android/apps/play/books/net/HttpHelper$ServerStatusErrorException; {:try_start_2 .. :try_end_2} :catch_8
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_a
    .catch Lcom/google/android/gms/auth/GoogleAuthException; {:try_start_2 .. :try_end_2} :catch_9
    .catchall {:try_start_2 .. :try_end_2} :catchall_19

    :try_start_3
    invoke-interface {v13}, Lorg/apache/http/HttpEntity;->getContent()Ljava/io/InputStream;

    .line 452
    move-result-object v15

    .line 453
    new-instance v11, Ljava/util/zip/GZIPInputStream;

    .line 455
    invoke-direct {v11, v15}, Ljava/util/zip/GZIPInputStream;-><init>(Ljava/io/InputStream;)V

    .line 458
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_18

    move/from16 v17, v10

    .line 460
    const/16 v18, 0x2

    .line 462
    :try_start_4
    invoke-static {v11}, Lakve;->h(Ljava/io/InputStream;)[B

    .line 465
    move-result-object v10

    .line 466
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_16

    move-object/from16 v20, v11

    .line 468
    :try_start_5
    invoke-static {}, Lbdsj;->a()Lbdsj;

    .line 471
    move-result-object v11

    .line 472
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_15

    move-object/from16 v21, v13

    .line 474
    :try_start_6
    sget-object v13, Lovj;->a:Lovj;

    .line 476
    invoke-static {v13, v10, v11}, Lbdtb;->parseFrom(Lbdtb;[BLbdsj;)Lbdtb;

    .line 479
    move-result-object v10

    .line 480
    check-cast v10, Lovj;

    .line 482
    iget v11, v10, Lovj;->b:I

    .line 484
    and-int/lit8 v13, v11, 0x2

    .line 486
    if-eqz v13, :cond_8

    .line 488
    const/16 v22, 0x0

    .line 490
    goto :goto_4

    .line 491
    :cond_8
    move/from16 v22, v16

    .line 493
    :goto_4
    if-eqz v13, :cond_67

    .line 495
    if-eqz v17, :cond_a

    .line 497
    and-int/lit8 v13, v11, 0x1

    .line 499
    if-eqz v13, :cond_9

    .line 501
    goto :goto_5

    .line 502
    :cond_9
    move/from16 v10, v16

    .line 504
    goto/16 :goto_31

    .line 506
    :cond_a
    :goto_5
    const/4 v0, 0x3

    .line 507
    invoke-static {v8, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 510
    move-result v0

    .line 511
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_14

    if-eqz v0, :cond_b

    .line 513
    :try_start_7
    const-string v0, "FastBookOpenData has overview and manifest!"

    .line 515
    invoke-static {v8, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 518
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    goto :goto_8

    .line 519
    :catchall_0
    move-exception v0

    .line 520
    move-object v3, v4

    .line 521
    move-object/from16 v25, v6

    .line 523
    move-object/from16 v27, v7

    .line 525
    move-object/from16 v26, v9

    .line 527
    move-object/from16 v23, v14

    .line 529
    :goto_6
    move-object/from16 v24, v15

    .line 531
    :goto_7
    move/from16 v2, v18

    .line 533
    goto/16 :goto_38

    .line 535
    :cond_b
    :goto_8
    :try_start_8
    iget v0, v10, Lovj;->b:I

    .line 537
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_14

    and-int/lit8 v0, v0, 0x1

    .line 539
    if-eqz v0, :cond_d

    .line 541
    :try_start_9
    iget-object v0, v10, Lovj;->c:Loxj;

    .line 543
    if-nez v0, :cond_c

    .line 545
    sget-object v0, Loxj;->a:Loxj;

    .line 547
    :cond_c
    iget-object v2, v1, Ladqu;->g:Luxd;

    .line 549
    invoke-virtual {v2, v0}, Luxd;->a(Loxj;)Luxg;

    .line 552
    move-result-object v0

    .line 553
    move-object v2, v0

    .line 554
    check-cast v2, Luva;

    .line 556
    iget-object v2, v2, Luva;->a:Luws;

    .line 558
    check-cast v0, Luva;

    .line 560
    iget-object v0, v0, Luva;->b:Luxk;

    .line 562
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_0

    goto :goto_9

    .line 563
    :cond_d
    const/4 v0, 0x0

    .line 564
    const/4 v2, 0x0

    .line 565
    :goto_9
    :try_start_a
    iget-object v5, v10, Lovj;->d:Lovh;

    .line 567
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_14

    if-nez v5, :cond_e

    .line 569
    :try_start_b
    sget-object v5, Lovh;->b:Lovh;

    .line 571
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_0

    :cond_e
    :try_start_c
    sget-object v8, Lacqi;->a:Ljava/util/Map;

    .line 573
    invoke-static {}, Lacqg;->z()Lacqf;

    .line 576
    move-result-object v8

    .line 577
    iget v11, v5, Lovh;->c:I

    .line 579
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_14

    and-int/lit8 v11, v11, 0x2

    .line 581
    if-eqz v11, :cond_12

    .line 583
    :try_start_d
    iget-object v11, v5, Lovh;->d:Ljava/lang/String;

    .line 585
    invoke-virtual {v8, v11}, Lacqf;->c(Ljava/lang/String;)V

    .line 588
    new-instance v11, Lbdtl;

    .line 590
    iget-object v13, v5, Lovh;->f:Lbdtj;

    .line 592
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_2

    move-object/from16 v23, v14

    .line 594
    :try_start_e
    sget-object v14, Lovh;->a:Lbdtk;

    .line 596
    invoke-direct {v11, v13, v14}, Lbdtl;-><init>(Lbdtj;Lbdtk;)V

    .line 599
    invoke-interface {v11}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 602
    move-result-object v11

    .line 603
    const/4 v13, 0x0

    .line 604
    const/4 v14, 0x0

    .line 605
    :goto_a
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 608
    move-result v17

    .line 609
    if-eqz v17, :cond_11

    .line 611
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 614
    move-result-object v17

    .line 615
    move-object/from16 p1, v11

    .line 617
    move-object/from16 v11, v17

    .line 619
    check-cast v11, Louy;

    .line 621
    move/from16 v17, v13

    .line 623
    sget-object v13, Louy;->b:Louy;

    .line 625
    if-ne v13, v11, :cond_f

    .line 627
    move-object/from16 v11, p1

    .line 629
    move/from16 v13, v16

    .line 631
    goto :goto_a

    .line 632
    :cond_f
    sget-object v13, Louy;->c:Louy;

    .line 634
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_1

    if-ne v13, v11, :cond_10

    .line 636
    move-object/from16 v11, p1

    .line 638
    move/from16 v14, v16

    .line 640
    goto :goto_b

    .line 641
    :cond_10
    move-object/from16 v11, p1

    .line 643
    :goto_b
    move/from16 v13, v17

    .line 645
    goto :goto_a

    .line 646
    :cond_11
    move/from16 v17, v13

    .line 648
    move/from16 v11, v17

    .line 650
    goto :goto_d

    .line 651
    :catchall_1
    move-exception v0

    .line 652
    goto :goto_c

    .line 653
    :catchall_2
    move-exception v0

    .line 654
    move-object/from16 v23, v14

    .line 656
    :goto_c
    move-object v3, v4

    .line 657
    move-object/from16 v25, v6

    .line 659
    move-object/from16 v27, v7

    .line 661
    move-object/from16 v26, v9

    .line 663
    goto/16 :goto_6

    .line 665
    :cond_12
    move-object/from16 v23, v14

    .line 667
    const/4 v11, 0x0

    .line 668
    const/4 v14, 0x0

    .line 669
    :goto_d
    :try_start_f
    invoke-virtual {v8, v11}, Lacqf;->f(Z)V

    .line 672
    invoke-virtual {v8, v14}, Lacqf;->i(Z)V

    .line 675
    iget v11, v5, Lovh;->c:I

    .line 677
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_12

    const/4 v13, 0x4

    .line 678
    and-int/2addr v11, v13

    .line 679
    if-eqz v11, :cond_14

    .line 681
    :try_start_10
    sget-object v11, Lacqi;->a:Ljava/util/Map;

    .line 683
    iget v14, v5, Lovh;->e:I

    .line 685
    invoke-static {v14}, Louy;->b(I)Louy;

    .line 688
    move-result-object v14

    .line 689
    if-nez v14, :cond_13

    .line 691
    sget-object v14, Louy;->a:Louy;

    .line 693
    :cond_13
    iget v14, v14, Louy;->e:I

    .line 695
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 698
    move-result-object v14

    .line 699
    invoke-interface {v11, v14}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 702
    move-result-object v11

    .line 703
    check-cast v11, Lahge;

    .line 705
    move-object v14, v8

    .line 706
    check-cast v14, Lacpe;

    .line 708
    iput-object v11, v14, Lacpe;->a:Lahge;

    .line 710
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_1

    :cond_14
    :try_start_11
    iget v11, v5, Lovh;->c:I

    .line 712
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_12

    and-int/lit8 v11, v11, 0x8

    .line 714
    if-eqz v11, :cond_15

    .line 716
    :try_start_12
    iget v11, v5, Lovh;->g:I

    .line 718
    invoke-virtual {v8, v11}, Lacqf;->d(I)V

    .line 721
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_1

    :cond_15
    :try_start_13
    iget v11, v5, Lovh;->c:I

    .line 723
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_12

    and-int/lit16 v11, v11, 0x80

    .line 725
    if-eqz v11, :cond_16

    .line 727
    :try_start_14
    iget-boolean v11, v5, Lovh;->j:Z

    .line 729
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_1

    if-eqz v11, :cond_16

    .line 731
    move/from16 v11, v16

    .line 733
    goto :goto_e

    .line 734
    :cond_16
    const/4 v11, 0x0

    .line 735
    :goto_e
    :try_start_15
    invoke-virtual {v8, v11}, Lacqf;->j(Z)V

    .line 738
    iget v11, v5, Lovh;->c:I

    .line 740
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_12

    and-int/lit16 v11, v11, 0x400

    .line 742
    if-eqz v11, :cond_17

    .line 744
    :try_start_16
    iget-object v11, v5, Lovh;->l:Ljava/lang/String;

    .line 746
    :try_end_16
    .catchall {:try_start_16 .. :try_end_16} :catchall_1

    goto :goto_f

    .line 747
    :cond_17
    const/4 v11, 0x0

    .line 748
    :goto_f
    :try_start_17
    const-string v14, "-epub-media-overlay-active media-overlay-active"

    .line 750
    if-nez v11, :cond_18

    .line 752
    move-object v11, v14

    .line 753
    :cond_18
    invoke-static {v11}, Lalnd;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 756
    move-result-object v11

    .line 757
    move-object v14, v8

    .line 758
    check-cast v14, Lacpe;

    .line 760
    iput-object v11, v14, Lacpe;->b:Ljava/lang/String;

    .line 762
    iget v11, v5, Lovh;->c:I

    .line 764
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_12

    and-int/lit16 v14, v11, 0x200

    .line 766
    if-eqz v14, :cond_19

    .line 768
    :try_start_18
    iget-object v14, v5, Lovh;->k:Ljava/lang/String;

    .line 770
    move-object v13, v8

    .line 771
    check-cast v13, Lacpe;

    .line 773
    iput-object v14, v13, Lacpe;->c:Ljava/lang/String;

    .line 775
    :cond_19
    and-int/lit16 v13, v11, 0x1000

    .line 777
    if-eqz v13, :cond_1a

    .line 779
    iget-object v13, v5, Lovh;->m:Ljava/lang/String;

    .line 781
    move-object v14, v8

    .line 782
    check-cast v14, Lacpe;

    .line 784
    iput-object v13, v14, Lacpe;->d:Ljava/lang/String;

    .line 786
    :cond_1a
    and-int/lit16 v11, v11, 0x2000

    .line 788
    if-eqz v11, :cond_1b

    .line 790
    iget-object v11, v5, Lovh;->n:Ljava/lang/String;

    .line 792
    move-object v13, v8

    .line 793
    check-cast v13, Lacpe;

    .line 795
    iput-object v11, v13, Lacpe;->e:Ljava/lang/String;

    .line 797
    :try_end_18
    .catchall {:try_start_18 .. :try_end_18} :catchall_1

    :cond_1b
    :try_start_19
    iget-object v11, v5, Lovh;->h:Lous;

    .line 799
    :try_end_19
    .catchall {:try_start_19 .. :try_end_19} :catchall_12

    if-nez v11, :cond_1c

    .line 801
    :try_start_1a
    sget-object v11, Lous;->a:Lous;

    .line 803
    :try_end_1a
    .catchall {:try_start_1a .. :try_end_1a} :catchall_1

    :cond_1c
    :try_start_1b
    iget-object v11, v11, Lous;->b:Ljava/lang/String;

    .line 805
    invoke-static {v11}, Layia;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 808
    move-result-object v11

    .line 809
    iget-object v13, v5, Lovh;->h:Lous;

    .line 811
    :try_end_1b
    .catchall {:try_start_1b .. :try_end_1b} :catchall_12

    if-nez v13, :cond_1d

    .line 813
    :try_start_1c
    sget-object v13, Lous;->a:Lous;

    .line 815
    :try_end_1c
    .catchall {:try_start_1c .. :try_end_1c} :catchall_1

    :cond_1d
    :try_start_1d
    iget-object v13, v13, Lous;->c:Ljava/lang/String;

    .line 817
    invoke-static {v13}, Layia;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 820
    move-result-object v13

    .line 821
    if-nez v11, :cond_1e

    .line 823
    if-eqz v13, :cond_1f

    .line 825
    :cond_1e
    new-instance v14, Lacox;

    .line 827
    invoke-direct {v14, v11, v13}, Lacox;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 830
    move-object v11, v8

    .line 831
    check-cast v11, Lacpe;

    .line 833
    iput-object v14, v11, Lacpe;->f:Lacph;

    .line 835
    :cond_1f
    iget-object v11, v5, Lovh;->i:Lous;

    .line 837
    :try_end_1d
    .catchall {:try_start_1d .. :try_end_1d} :catchall_12

    if-nez v11, :cond_20

    .line 839
    :try_start_1e
    sget-object v13, Lous;->a:Lous;

    .line 841
    :try_end_1e
    .catchall {:try_start_1e .. :try_end_1e} :catchall_1

    goto :goto_10

    .line 842
    :cond_20
    move-object v13, v11

    .line 843
    :goto_10
    :try_start_1f
    iget-object v13, v13, Lous;->b:Ljava/lang/String;

    .line 845
    invoke-static {v13}, Layia;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 848
    move-result-object v13

    .line 849
    :try_end_1f
    .catchall {:try_start_1f .. :try_end_1f} :catchall_12

    if-nez v11, :cond_21

    .line 851
    :try_start_20
    sget-object v11, Lous;->a:Lous;

    .line 853
    :try_end_20
    .catchall {:try_start_20 .. :try_end_20} :catchall_1

    :cond_21
    :try_start_21
    iget-object v11, v11, Lous;->c:Ljava/lang/String;

    .line 855
    invoke-static {v11}, Layia;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 858
    move-result-object v11

    .line 859
    if-nez v13, :cond_22

    .line 861
    if-eqz v11, :cond_23

    .line 863
    :cond_22
    new-instance v14, Lacox;

    .line 865
    invoke-direct {v14, v13, v11}, Lacox;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 868
    move-object v11, v8

    .line 869
    check-cast v11, Lacpe;

    .line 871
    iput-object v14, v11, Lacpe;->g:Lacph;

    .line 873
    :cond_23
    iget v11, v5, Lovh;->c:I

    .line 875
    :try_end_21
    .catchall {:try_start_21 .. :try_end_21} :catchall_12

    const/high16 v13, 0x10000

    .line 877
    and-int/2addr v11, v13

    .line 878
    if-eqz v11, :cond_2d

    .line 880
    :try_start_22
    iget-object v11, v5, Lovh;->t:Lbebe;

    .line 882
    :try_end_22
    .catchall {:try_start_22 .. :try_end_22} :catchall_3

    if-nez v11, :cond_24

    .line 884
    :try_start_23
    sget-object v11, Lbebe;->a:Lbebe;

    .line 886
    :try_end_23
    .catchall {:try_start_23 .. :try_end_23} :catchall_1

    :cond_24
    :try_start_24
    iget v13, v11, Lbebe;->b:I

    .line 888
    :try_end_24
    .catchall {:try_start_24 .. :try_end_24} :catchall_3

    and-int/lit8 v14, v13, 0x4

    .line 890
    if-eqz v14, :cond_25

    .line 892
    :try_start_25
    iget-object v14, v11, Lbebe;->e:Ljava/lang/String;

    .line 894
    goto :goto_11

    .line 895
    :cond_25
    move-object v14, v12

    .line 896
    :goto_11
    and-int/lit8 v13, v13, 0x8

    .line 898
    if-eqz v13, :cond_26

    .line 900
    iget-object v13, v11, Lbebe;->f:Ljava/lang/String;

    .line 902
    :try_end_25
    .catchall {:try_start_25 .. :try_end_25} :catchall_1

    goto :goto_12

    .line 903
    :cond_26
    move-object v13, v12

    .line 904
    :goto_12
    :try_start_26
    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    .line 907
    move-result v17

    .line 908
    :try_end_26
    .catchall {:try_start_26 .. :try_end_26} :catchall_3

    if-eqz v17, :cond_28

    .line 910
    :try_start_27
    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    .line 913
    move-result v17

    .line 914
    :try_end_27
    .catchall {:try_start_27 .. :try_end_27} :catchall_1

    if-nez v17, :cond_27

    .line 916
    goto :goto_13

    .line 917
    :cond_27
    move-object/from16 v24, v15

    .line 919
    goto :goto_15

    .line 920
    :cond_28
    :goto_13
    move-object/from16 v24, v15

    .line 922
    :try_start_28
    new-instance v15, Ljava/lang/StringBuilder;

    .line 924
    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    .line 927
    invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 930
    move-object/from16 v17, v14

    .line 932
    const-string v14, "#"

    .line 934
    invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 937
    invoke-virtual {v15, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 940
    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 943
    move-result-object v14

    .line 944
    move-object v15, v8

    .line 945
    check-cast v15, Lacpe;

    .line 947
    iput-object v14, v15, Lacpe;->h:Ljava/lang/String;

    .line 949
    invoke-virtual/range {v17 .. v17}, Ljava/lang/String;->isEmpty()Z

    .line 952
    move-result v14

    .line 953
    move/from16 v15, v16

    .line 955
    if-ne v15, v14, :cond_29

    .line 957
    const/4 v14, 0x0

    .line 958
    goto :goto_14

    .line 959
    :cond_29
    move-object/from16 v14, v17

    .line 961
    :goto_14
    move-object v15, v8

    .line 962
    check-cast v15, Lacpe;

    .line 964
    iput-object v14, v15, Lacpe;->i:Ljava/lang/String;

    .line 966
    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    .line 969
    move-result v14

    .line 970
    const/4 v15, 0x1

    .line 971
    if-ne v15, v14, :cond_2a

    .line 973
    const/4 v13, 0x0

    .line 974
    :cond_2a
    move-object v14, v8

    .line 975
    check-cast v14, Lacpe;

    .line 977
    iput-object v13, v14, Lacpe;->j:Ljava/lang/String;

    .line 979
    :goto_15
    iget v13, v11, Lbebe;->b:I

    .line 981
    and-int/lit8 v14, v13, 0x1

    .line 983
    if-eqz v14, :cond_2b

    .line 985
    iget-boolean v14, v11, Lbebe;->c:Z

    .line 987
    if-eqz v14, :cond_2b

    .line 989
    const/4 v14, 0x1

    .line 990
    goto :goto_16

    .line 991
    :cond_2b
    const/4 v14, 0x0

    .line 992
    :goto_16
    and-int/lit8 v13, v13, 0x2

    .line 994
    if-eqz v13, :cond_2c

    .line 996
    iget-boolean v11, v11, Lbebe;->d:Z

    .line 998
    :try_end_28
    .catchall {:try_start_28 .. :try_end_28} :catchall_4

    if-eqz v11, :cond_2c

    .line 1000
    const/4 v11, 0x1

    .line 1001
    goto :goto_18

    .line 1002
    :cond_2c
    const/4 v11, 0x0

    .line 1003
    goto :goto_18

    .line 1004
    :catchall_3
    move-exception v0

    .line 1005
    move-object/from16 v24, v15

    .line 1007
    :goto_17
    move-object v3, v4

    .line 1008
    move-object/from16 v25, v6

    .line 1010
    move-object/from16 v27, v7

    .line 1012
    move-object/from16 v26, v9

    .line 1014
    goto/16 :goto_7

    .line 1016
    :cond_2d
    move-object/from16 v24, v15

    .line 1018
    const/4 v11, 0x0

    .line 1019
    const/4 v14, 0x0

    .line 1020
    :goto_18
    :try_start_29
    invoke-virtual {v8, v14}, Lacqf;->e(Z)V

    .line 1023
    invoke-virtual {v8, v11}, Lacqf;->g(Z)V

    .line 1026
    new-instance v11, Layoy;

    .line 1028
    const/4 v13, 0x4

    .line 1029
    invoke-direct {v11, v13}, Layoy;-><init>(I)V

    .line 1032
    iget-object v13, v5, Lovh;->o:Lbdts;

    .line 1034
    invoke-interface {v13}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 1037
    move-result-object v13

    .line 1038
    const/4 v14, 0x0

    .line 1039
    :goto_19
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    .line 1042
    move-result v15

    .line 1043
    :try_end_29
    .catchall {:try_start_29 .. :try_end_29} :catchall_11

    if-eqz v15, :cond_33

    .line 1045
    :try_start_2a
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1048
    move-result-object v15

    .line 1049
    check-cast v15, Louq;

    .line 1051
    add-int/lit8 v17, v14, 0x1

    .line 1053
    move-object/from16 v22, v13

    .line 1055
    invoke-static {}, Lacpg;->f()Lacov;

    .line 1058
    move-result-object v13

    .line 1059
    invoke-static {v14}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 1062
    move-result-object v14

    .line 1063
    iput-object v14, v13, Lacov;->a:Ljava/lang/String;

    .line 1065
    iget v14, v15, Louq;->b:I

    .line 1067
    and-int/lit8 v25, v14, 0x1

    .line 1069
    if-eqz v25, :cond_2e

    .line 1071
    move/from16 v25, v14

    .line 1073
    iget-object v14, v15, Louq;->c:Ljava/lang/String;

    .line 1075
    iput-object v14, v13, Lacov;->b:Ljava/lang/String;

    .line 1077
    goto :goto_1a

    .line 1078
    :cond_2e
    move/from16 v25, v14

    .line 1080
    :goto_1a
    and-int/lit8 v14, v25, 0x2

    .line 1082
    if-eqz v14, :cond_2f

    .line 1084
    iget v14, v15, Louq;->d:I

    .line 1086
    invoke-virtual {v13, v14}, Lacov;->d(I)V

    .line 1089
    :cond_2f
    iget v14, v15, Louq;->b:I

    .line 1091
    const/16 v25, 0x4

    .line 1093
    and-int/lit8 v14, v14, 0x4

    .line 1095
    if-eqz v14, :cond_30

    .line 1097
    iget v14, v15, Louq;->e:I

    .line 1099
    invoke-virtual {v13, v14}, Lacov;->c(I)V

    .line 1102
    :cond_30
    iget v14, v15, Louq;->b:I

    .line 1104
    and-int/lit8 v14, v14, 0x8

    .line 1106
    if-eqz v14, :cond_31

    .line 1108
    iget v14, v15, Louq;->f:I

    .line 1110
    invoke-virtual {v13, v14}, Lacov;->b(I)V

    .line 1113
    :cond_31
    iget v14, v15, Louq;->b:I

    .line 1115
    and-int/lit8 v14, v14, 0x10

    .line 1117
    if-eqz v14, :cond_32

    .line 1119
    iget-object v14, v15, Louq;->g:Ljava/lang/String;

    .line 1121
    iput-object v14, v13, Lacov;->c:Ljava/lang/String;

    .line 1123
    :cond_32
    invoke-virtual {v13}, Lacov;->a()Lacpg;

    .line 1126
    move-result-object v13

    .line 1127
    invoke-virtual {v11, v13}, Layoy;->h(Ljava/lang/Object;)V

    .line 1130
    :try_end_2a
    .catchall {:try_start_2a .. :try_end_2a} :catchall_4

    move/from16 v14, v17

    .line 1132
    move-object/from16 v13, v22

    .line 1134
    goto :goto_19

    .line 1135
    :catchall_4
    move-exception v0

    .line 1136
    goto/16 :goto_17

    .line 1138
    :cond_33
    :try_start_2b
    invoke-virtual {v11}, Layoy;->g()Laypd;

    .line 1141
    move-result-object v11

    .line 1142
    invoke-virtual {v8, v11}, Lacqf;->b(Laypd;)V

    .line 1145
    sget-object v11, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1147
    new-instance v13, Lakvb;

    .line 1149
    invoke-direct {v13, v11}, Lakvb;-><init>(Ljava/lang/Object;)V

    .line 1152
    new-instance v11, Ljava/util/ArrayList;

    .line 1154
    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    .line 1157
    new-instance v14, Layoy;

    .line 1159
    const/4 v15, 0x4

    .line 1160
    invoke-direct {v14, v15}, Layoy;-><init>(I)V

    .line 1163
    iget-object v15, v5, Lovh;->q:Lbdts;

    .line 1165
    invoke-interface {v15}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 1168
    move-result-object v15

    .line 1169
    :goto_1b
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    .line 1172
    move-result v17

    .line 1173
    :try_end_2b
    .catchall {:try_start_2b .. :try_end_2b} :catchall_11

    if-eqz v17, :cond_3c

    .line 1175
    :try_start_2c
    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1178
    move-result-object v17

    .line 1179
    move-object/from16 v22, v15

    .line 1181
    move-object/from16 v15, v17

    .line 1183
    check-cast v15, Lova;

    .line 1185
    :try_end_2c
    .catchall {:try_start_2c .. :try_end_2c} :catchall_9

    move-object/from16 v25, v6

    .line 1187
    :try_start_2d
    invoke-static {}, Lacps;->j()Lacpa;

    .line 1190
    move-result-object v6

    .line 1191
    :try_end_2d
    .catchall {:try_start_2d .. :try_end_2d} :catchall_8

    move-object/from16 v26, v9

    .line 1193
    :try_start_2e
    iget v9, v15, Lova;->b:I

    .line 1195
    :try_end_2e
    .catchall {:try_start_2e .. :try_end_2e} :catchall_7

    and-int/lit8 v17, v9, 0x8

    .line 1197
    if-eqz v17, :cond_34

    .line 1199
    :try_start_2f
    iget-object v3, v15, Lova;->d:Ljava/lang/String;

    .line 1201
    iput-object v3, v6, Lacpa;->b:Ljava/lang/String;

    .line 1203
    goto :goto_1c

    .line 1204
    :catchall_5
    move-exception v0

    .line 1205
    move-object v3, v4

    .line 1206
    move-object/from16 v27, v7

    .line 1208
    goto/16 :goto_7

    .line 1210
    :cond_34
    :goto_1c
    and-int/lit8 v3, v9, 0x2

    .line 1212
    if-eqz v3, :cond_35

    .line 1214
    iget-object v3, v15, Lova;->c:Ljava/lang/String;

    .line 1216
    iput-object v3, v6, Lacpa;->c:Ljava/lang/String;

    .line 1218
    :cond_35
    and-int/lit16 v3, v9, 0x100

    .line 1220
    if-eqz v3, :cond_36

    .line 1222
    iget-object v3, v15, Lova;->i:Ljava/lang/String;

    .line 1224
    iput-object v3, v6, Lacpa;->d:Ljava/lang/String;

    .line 1226
    :cond_36
    and-int/lit8 v3, v9, 0x10

    .line 1228
    if-eqz v3, :cond_37

    .line 1230
    iget-object v3, v15, Lova;->e:Ljava/lang/String;

    .line 1232
    iput-object v3, v6, Lacpa;->e:Ljava/lang/String;

    .line 1234
    :cond_37
    and-int/lit8 v3, v9, 0x20

    .line 1236
    if-eqz v3, :cond_38

    .line 1238
    iget-boolean v3, v15, Lova;->f:Z

    .line 1240
    invoke-virtual {v6, v3}, Lacpa;->d(Z)V

    .line 1243
    :try_end_2f
    .catchall {:try_start_2f .. :try_end_2f} :catchall_5

    :cond_38
    :try_start_30
    iget v3, v15, Lova;->b:I

    .line 1245
    :try_end_30
    .catchall {:try_start_30 .. :try_end_30} :catchall_7

    and-int/lit8 v3, v3, 0x40

    .line 1247
    if-eqz v3, :cond_39

    .line 1249
    :try_start_31
    iget-boolean v3, v15, Lova;->g:Z

    .line 1251
    invoke-virtual {v6, v3}, Lacpa;->c(Z)V

    .line 1254
    :try_end_31
    .catchall {:try_start_31 .. :try_end_31} :catchall_5

    :cond_39
    :try_start_32
    iget v3, v15, Lova;->b:I

    .line 1256
    :try_end_32
    .catchall {:try_start_32 .. :try_end_32} :catchall_7

    and-int/lit16 v3, v3, 0x80

    .line 1258
    if-eqz v3, :cond_3a

    .line 1260
    :try_start_33
    iget-object v3, v15, Lova;->h:Ljava/lang/String;

    .line 1262
    iput-object v3, v6, Lacpa;->f:Ljava/lang/String;

    .line 1264
    :try_end_33
    .catchall {:try_start_33 .. :try_end_33} :catchall_5

    :cond_3a
    :try_start_34
    iget-object v3, v15, Lova;->c:Ljava/lang/String;

    .line 1266
    const-string v9, "smil"

    .line 1268
    invoke-static {v3, v9}, Lj$/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1271
    move-result v3

    .line 1272
    :try_end_34
    .catchall {:try_start_34 .. :try_end_34} :catchall_7

    if-eqz v3, :cond_3b

    .line 1274
    :try_start_35
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 1276
    iput-object v3, v13, Lakvb;->a:Ljava/lang/Object;

    .line 1278
    :try_end_35
    .catchall {:try_start_35 .. :try_end_35} :catchall_5

    :cond_3b
    :try_start_36
    iget-object v3, v15, Lova;->d:Ljava/lang/String;

    .line 1280
    iget-object v9, v15, Lova;->i:Ljava/lang/String;

    .line 1282
    :try_end_36
    .catchall {:try_start_36 .. :try_end_36} :catchall_7

    move-object/from16 v27, v7

    .line 1284
    :try_start_37
    iget-boolean v7, v15, Lova;->f:Z

    .line 1286
    iget-object v15, v15, Lova;->h:Ljava/lang/String;

    .line 1288
    invoke-static {v3, v9, v7, v15}, Lacpt;->a(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)Ljava/lang/String;

    .line 1291
    move-result-object v3

    .line 1292
    iput-object v3, v6, Lacpa;->a:Ljava/lang/String;

    .line 1294
    invoke-virtual {v6}, Lacpa;->a()Lacps;

    .line 1297
    move-result-object v3

    .line 1298
    invoke-interface {v11, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1301
    :try_end_37
    .catchall {:try_start_37 .. :try_end_37} :catchall_6

    move-object/from16 v3, p2

    .line 1303
    move-object/from16 v15, v22

    .line 1305
    move-object/from16 v6, v25

    .line 1307
    move-object/from16 v9, v26

    .line 1309
    move-object/from16 v7, v27

    .line 1311
    goto/16 :goto_1b

    .line 1313
    :catchall_6
    move-exception v0

    .line 1314
    goto :goto_1e

    .line 1315
    :catchall_7
    move-exception v0

    .line 1316
    move-object/from16 v27, v7

    .line 1318
    goto :goto_1e

    .line 1319
    :catchall_8
    move-exception v0

    .line 1320
    goto :goto_1d

    .line 1321
    :catchall_9
    move-exception v0

    .line 1322
    move-object/from16 v25, v6

    .line 1324
    :goto_1d
    move-object/from16 v27, v7

    .line 1326
    move-object/from16 v26, v9

    .line 1328
    :goto_1e
    move-object v3, v4

    .line 1329
    goto/16 :goto_7

    .line 1331
    :cond_3c
    move-object/from16 v25, v6

    .line 1333
    move-object/from16 v27, v7

    .line 1335
    move-object/from16 v26, v9

    .line 1337
    :try_start_38
    iget-object v3, v5, Lovh;->q:Lbdts;

    .line 1339
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 1342
    move-result-object v3

    .line 1343
    :cond_3d
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1346
    move-result v6

    .line 1347
    :try_end_38
    .catchall {:try_start_38 .. :try_end_38} :catchall_10

    if-eqz v6, :cond_40

    .line 1349
    :try_start_39
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1352
    move-result-object v6

    .line 1353
    check-cast v6, Lova;

    .line 1355
    iget-object v7, v6, Lova;->j:Lbdts;

    .line 1357
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 1360
    move-result-object v7

    .line 1361
    :cond_3e
    :goto_1f
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 1364
    move-result v9

    .line 1365
    if-eqz v9, :cond_3d

    .line 1367
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1370
    move-result-object v9

    .line 1371
    check-cast v9, Lovc;

    .line 1373
    iget v15, v9, Lovc;->b:I

    .line 1375
    const/16 v16, 0x1

    .line 1377
    and-int/lit8 v15, v15, 0x1

    .line 1379
    if-eqz v15, :cond_3e

    .line 1381
    iget v15, v9, Lovc;->c:I

    .line 1383
    move-object/from16 v17, v3

    .line 1385
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 1388
    move-result v3

    .line 1389
    if-ge v15, v3, :cond_3f

    .line 1391
    iget v3, v9, Lovc;->c:I

    .line 1393
    invoke-interface {v11, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1396
    move-result-object v3

    .line 1397
    check-cast v3, Lacps;

    .line 1399
    invoke-virtual {v3}, Lacps;->R()Ljava/lang/String;

    .line 1402
    move-result-object v3

    .line 1403
    iget-object v9, v6, Lova;->d:Ljava/lang/String;

    .line 1405
    iget-object v15, v6, Lova;->i:Ljava/lang/String;

    .line 1407
    move-object/from16 v22, v7

    .line 1409
    iget-boolean v7, v6, Lova;->f:Z

    .line 1411
    :try_end_39
    .catchall {:try_start_39 .. :try_end_39} :catchall_a

    move-object/from16 v28, v4

    .line 1413
    :try_start_3a
    iget-object v4, v6, Lova;->h:Ljava/lang/String;

    .line 1415
    invoke-static {v9, v15, v7, v4}, Lacpt;->a(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)Ljava/lang/String;

    .line 1418
    move-result-object v4

    .line 1419
    new-instance v7, Lacpm;

    .line 1421
    invoke-direct {v7, v4, v3}, Lacpm;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 1424
    invoke-virtual {v14, v7}, Layoy;->h(Ljava/lang/Object;)V

    .line 1427
    :try_end_3a
    .catchall {:try_start_3a .. :try_end_3a} :catchall_b

    move-object/from16 v3, v17

    .line 1429
    move-object/from16 v7, v22

    .line 1431
    move-object/from16 v4, v28

    .line 1433
    goto :goto_1f

    .line 1434
    :cond_3f
    move-object/from16 v3, v17

    .line 1436
    goto :goto_1f

    .line 1437
    :catchall_a
    move-exception v0

    .line 1438
    move-object/from16 v28, v4

    .line 1440
    :goto_20
    move/from16 v2, v18

    .line 1442
    move-object/from16 v3, v28

    .line 1444
    goto/16 :goto_38

    .line 1446
    :cond_40
    move-object/from16 v28, v4

    .line 1448
    :try_start_3b
    sget-object v3, Lbfwk;->a:Lbfwk;

    .line 1450
    invoke-virtual {v3}, Lbfwk;->b()Lbfwl;

    .line 1453
    move-result-object v3

    .line 1454
    invoke-interface {v3}, Lbfwl;->a()Z

    .line 1457
    move-result v3

    .line 1458
    :try_end_3b
    .catchall {:try_start_3b .. :try_end_3b} :catchall_f

    if-eqz v3, :cond_43

    .line 1460
    :try_start_3c
    invoke-static {}, Lbfwk;->c()Z

    .line 1463
    move-result v3

    .line 1464
    if-eqz v3, :cond_41

    .line 1466
    goto :goto_21

    .line 1467
    :cond_41
    iget v3, v5, Lovh;->c:I

    .line 1469
    const v4, 0x8000

    .line 1472
    and-int/2addr v3, v4

    .line 1473
    if-eqz v3, :cond_43

    .line 1475
    iget-object v3, v5, Lovh;->s:Louw;

    .line 1477
    if-nez v3, :cond_42

    .line 1479
    sget-object v3, Louw;->a:Louw;

    .line 1481
    :cond_42
    iget v4, v3, Louw;->b:I

    .line 1483
    const/16 v16, 0x1

    .line 1485
    and-int/lit8 v4, v4, 0x1

    .line 1487
    if-eqz v4, :cond_43

    .line 1489
    iget-object v3, v3, Louw;->c:Ljava/lang/String;

    .line 1491
    invoke-virtual {v8, v3}, Lacqf;->l(Ljava/lang/String;)V

    .line 1494
    const/4 v4, 0x0

    .line 1495
    invoke-static {v3, v12, v4, v12}, Lacpt;->a(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)Ljava/lang/String;

    .line 1498
    move-result-object v6

    .line 1499
    invoke-static {}, Lacps;->j()Lacpa;

    .line 1502
    move-result-object v4

    .line 1503
    iput-object v3, v4, Lacpa;->b:Ljava/lang/String;

    .line 1505
    iput-object v6, v4, Lacpa;->a:Ljava/lang/String;

    .line 1507
    sget-object v3, Lahge;->c:Lahge;

    .line 1509
    invoke-virtual {v4, v3}, Lacpa;->b(Lahge;)V

    .line 1512
    invoke-virtual {v4}, Lacpa;->a()Lacps;

    .line 1515
    move-result-object v3

    .line 1516
    invoke-interface {v11, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1519
    :try_end_3c
    .catchall {:try_start_3c .. :try_end_3c} :catchall_b

    goto :goto_21

    .line 1520
    :catchall_b
    move-exception v0

    .line 1521
    goto :goto_20

    .line 1522
    :cond_43
    :goto_21
    :try_start_3d
    invoke-virtual {v8, v11}, Lacqf;->r(Ljava/util/List;)V

    .line 1525
    invoke-virtual {v14}, Layoy;->g()Laypd;

    .line 1528
    move-result-object v3

    .line 1529
    invoke-virtual {v8, v3}, Lacqf;->m(Layos;)V

    .line 1532
    iget-object v3, v13, Lakvb;->a:Ljava/lang/Object;

    .line 1534
    check-cast v3, Ljava/lang/Boolean;

    .line 1536
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1539
    move-result v3

    .line 1540
    invoke-virtual {v8, v3}, Lacqf;->h(Z)V

    .line 1543
    new-instance v3, Ljava/util/ArrayList;

    .line 1545
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 1548
    new-instance v4, Layoy;

    .line 1550
    const/4 v13, 0x4

    .line 1551
    invoke-direct {v4, v13}, Layoy;-><init>(I)V

    .line 1554
    iget-object v6, v5, Lovh;->p:Lbdts;

    .line 1556
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 1559
    move-result-object v6

    .line 1560
    :goto_22
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 1563
    move-result v7

    .line 1564
    :try_end_3d
    .catchall {:try_start_3d .. :try_end_3d} :catchall_f

    if-eqz v7, :cond_5c

    .line 1566
    :try_start_3e
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1569
    move-result-object v7

    .line 1570
    check-cast v7, Love;

    .line 1572
    invoke-static {}, Lacpu;->p()Lacpc;

    .line 1575
    move-result-object v13

    .line 1576
    iget v14, v7, Love;->b:I

    .line 1578
    and-int/lit8 v15, v14, 0x4

    .line 1580
    if-eqz v15, :cond_44

    .line 1582
    iget-object v15, v7, Love;->d:Ljava/lang/String;

    .line 1584
    iput-object v15, v13, Lacpc;->a:Ljava/lang/String;

    .line 1586
    :cond_44
    and-int/lit8 v15, v14, 0x10

    .line 1588
    if-eqz v15, :cond_45

    .line 1590
    iget-object v15, v7, Love;->f:Ljava/lang/String;

    .line 1592
    iput-object v15, v13, Lacpc;->b:Ljava/lang/String;

    .line 1594
    :cond_45
    and-int/lit8 v14, v14, 0x20

    .line 1596
    if-eqz v14, :cond_46

    .line 1598
    iget v14, v7, Love;->g:I

    .line 1600
    invoke-virtual {v13, v14}, Lacpc;->e(I)V

    .line 1603
    :cond_46
    iget v14, v7, Love;->b:I

    .line 1605
    and-int/lit16 v15, v14, 0x400

    .line 1607
    if-eqz v15, :cond_47

    .line 1609
    iget-boolean v15, v7, Love;->l:Z

    .line 1611
    goto :goto_23

    .line 1612
    :cond_47
    const/4 v15, 0x0

    .line 1613
    :goto_23
    and-int/lit8 v14, v14, 0x8

    .line 1615
    if-eqz v14, :cond_48

    .line 1617
    iget-object v14, v7, Love;->e:Ljava/lang/String;

    .line 1619
    invoke-static {v14}, Lalnd;->b(Ljava/lang/CharSequence;)Z

    .line 1622
    move-result v14

    .line 1623
    if-nez v14, :cond_48

    .line 1625
    iget-object v14, v7, Love;->e:Ljava/lang/String;

    .line 1627
    invoke-static {v14}, Lalsw;->a(Ljava/lang/String;)Landroid/net/Uri;

    .line 1630
    move-result-object v14

    .line 1631
    invoke-virtual {v14}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 1634
    move-result-object v14

    .line 1635
    iput-object v14, v13, Lacpc;->c:Ljava/lang/String;

    .line 1637
    goto :goto_24

    .line 1638
    :cond_48
    iput-object v12, v13, Lacpc;->c:Ljava/lang/String;

    .line 1640
    const/4 v15, 0x1

    .line 1641
    :goto_24
    xor-int/lit8 v14, v15, 0x1

    .line 1643
    invoke-virtual {v13, v14}, Lacpc;->g(Z)V

    .line 1646
    iget v14, v7, Love;->b:I

    .line 1648
    and-int/lit8 v14, v14, 0x40

    .line 1650
    if-eqz v14, :cond_49

    .line 1652
    iget v14, v7, Love;->h:I

    .line 1654
    invoke-virtual {v13, v14}, Lacpc;->b(I)V

    .line 1657
    :cond_49
    iget-object v14, v7, Love;->i:Lbefd;

    .line 1659
    if-nez v14, :cond_4a

    .line 1661
    sget-object v14, Lbefd;->a:Lbefd;

    .line 1663
    :cond_4a
    iget v14, v14, Lbefd;->b:I

    .line 1665
    const/16 v16, 0x1

    .line 1667
    and-int/lit8 v14, v14, 0x1

    .line 1669
    if-eqz v14, :cond_4f

    .line 1671
    iget-object v14, v7, Love;->i:Lbefd;

    .line 1673
    if-nez v14, :cond_4b

    .line 1675
    sget-object v14, Lbefd;->a:Lbefd;

    .line 1677
    :cond_4b
    iget-object v14, v14, Lbefd;->c:Lbefc;

    .line 1679
    if-nez v14, :cond_4c

    .line 1681
    sget-object v14, Lbefc;->a:Lbefc;

    .line 1683
    :cond_4c
    iget v9, v14, Lbefc;->b:I

    .line 1685
    and-int/lit8 v9, v9, 0x2

    .line 1687
    move-object/from16 v22, v6

    .line 1689
    const/4 v6, -0x2

    .line 1690
    if-eqz v9, :cond_4d

    .line 1692
    iget-object v9, v14, Lbefc;->d:Ljava/lang/String;

    .line 1694
    invoke-static {v9, v6}, Lacqi;->a(Ljava/lang/String;I)I

    .line 1697
    move-result v6

    .line 1698
    :cond_4d
    iget v9, v14, Lbefc;->b:I

    .line 1700
    const/16 v16, 0x1

    .line 1702
    and-int/lit8 v9, v9, 0x1

    .line 1704
    if-eqz v9, :cond_4e

    .line 1706
    iget-object v9, v14, Lbefc;->c:Ljava/lang/String;

    .line 1708
    const/4 v14, -0x1

    .line 1709
    invoke-static {v9, v14}, Lacqi;->a(Ljava/lang/String;I)I

    .line 1712
    move-result v9

    .line 1713
    goto :goto_25

    .line 1714
    :cond_4e
    const/4 v9, -0x1

    .line 1715
    :goto_25
    invoke-virtual {v13, v6}, Lacpc;->c(I)V

    .line 1718
    invoke-virtual {v13, v9}, Lacpc;->d(I)V

    .line 1721
    goto :goto_26

    .line 1722
    :cond_4f
    move-object/from16 v22, v6

    .line 1724
    :goto_26
    iget v6, v7, Love;->b:I

    .line 1726
    and-int/lit8 v6, v6, 0x2

    .line 1728
    if-eqz v6, :cond_50

    .line 1730
    iget-object v6, v7, Love;->c:Ljava/lang/String;

    .line 1732
    iput-object v6, v13, Lacpc;->d:Ljava/lang/String;

    .line 1734
    :cond_50
    iget-object v6, v7, Love;->j:Loug;

    .line 1736
    if-nez v6, :cond_51

    .line 1738
    sget-object v6, Loug;->a:Loug;

    .line 1740
    :cond_51
    iget-object v6, v6, Loug;->b:Lbebi;

    .line 1742
    if-nez v6, :cond_52

    .line 1744
    sget-object v6, Lbebi;->a:Lbebi;

    .line 1746
    :cond_52
    iget v6, v6, Lbebi;->b:I

    .line 1748
    const/16 v16, 0x1

    .line 1750
    and-int/lit8 v6, v6, 0x1

    .line 1752
    if-eqz v6, :cond_56

    .line 1754
    iget-object v6, v7, Love;->j:Loug;

    .line 1756
    if-nez v6, :cond_53

    .line 1758
    sget-object v6, Loug;->a:Loug;

    .line 1760
    :cond_53
    iget-object v6, v6, Loug;->b:Lbebi;

    .line 1762
    if-nez v6, :cond_54

    .line 1764
    sget-object v6, Lbebi;->a:Lbebi;

    .line 1766
    :cond_54
    iget v6, v6, Lbebi;->c:I

    .line 1768
    invoke-static {v6}, Lbebh;->a(I)I

    .line 1771
    move-result v6

    .line 1772
    if-nez v6, :cond_55

    .line 1774
    const/4 v6, 0x1

    .line 1775
    :cond_55
    const/16 v17, -0x1

    .line 1777
    add-int/lit8 v6, v6, -0x1

    .line 1779
    invoke-virtual {v13, v6}, Lacpc;->f(I)V

    .line 1782
    :cond_56
    if-nez v15, :cond_5b

    .line 1784
    iget-object v6, v7, Love;->k:Lbdts;

    .line 1786
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 1789
    move-result-object v6

    .line 1790
    :cond_57
    :goto_27
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 1793
    move-result v9

    .line 1794
    if-eqz v9, :cond_5b

    .line 1796
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1799
    move-result-object v9

    .line 1800
    check-cast v9, Lovc;

    .line 1802
    iget v14, v9, Lovc;->b:I

    .line 1804
    const/16 v16, 0x1

    .line 1806
    and-int/lit8 v14, v14, 0x1

    .line 1808
    if-eqz v14, :cond_57

    .line 1810
    iget v14, v9, Lovc;->c:I

    .line 1812
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 1815
    move-result v15

    .line 1816
    if-ge v14, v15, :cond_57

    .line 1818
    iget v14, v9, Lovc;->c:I

    .line 1820
    invoke-interface {v11, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1823
    move-result-object v14

    .line 1824
    check-cast v14, Lacps;

    .line 1826
    invoke-virtual {v14}, Lacps;->R()Ljava/lang/String;

    .line 1829
    move-result-object v14

    .line 1830
    iget v15, v7, Love;->b:I

    .line 1832
    const/16 v17, 0x4

    .line 1834
    and-int/lit8 v15, v15, 0x4

    .line 1836
    if-eqz v15, :cond_58

    .line 1838
    iget-object v15, v7, Love;->d:Ljava/lang/String;

    .line 1840
    goto :goto_28

    .line 1841
    :cond_58
    const/4 v15, 0x0

    .line 1842
    :goto_28
    move-object/from16 v17, v6

    .line 1844
    iget v6, v9, Lovc;->b:I

    .line 1846
    and-int/lit8 v29, v6, 0x2

    .line 1848
    if-eqz v29, :cond_59

    .line 1850
    move/from16 v29, v6

    .line 1852
    iget-object v6, v9, Lovc;->d:Ljava/lang/String;

    .line 1854
    goto :goto_29

    .line 1855
    :cond_59
    move/from16 v29, v6

    .line 1857
    const/4 v6, 0x0

    .line 1858
    :goto_29
    and-int/lit8 v29, v29, 0x4

    .line 1860
    if-eqz v29, :cond_5a

    .line 1862
    iget-object v9, v9, Lovc;->e:Ljava/lang/String;

    .line 1864
    goto :goto_2a

    .line 1865
    :cond_5a
    const/4 v9, 0x0

    .line 1866
    :goto_2a
    move-object/from16 v29, v7

    .line 1868
    new-instance v7, Lacpn;

    .line 1870
    invoke-direct {v7, v15, v14, v6, v9}, Lacpn;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1873
    invoke-virtual {v4, v7}, Layoy;->h(Ljava/lang/Object;)V

    .line 1876
    move-object/from16 v6, v17

    .line 1878
    move-object/from16 v7, v29

    .line 1880
    goto :goto_27

    .line 1881
    :cond_5b
    invoke-virtual {v13}, Lacpc;->a()Lacpu;

    .line 1884
    move-result-object v6

    .line 1885
    invoke-interface {v3, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1888
    :try_end_3e
    .catchall {:try_start_3e .. :try_end_3e} :catchall_b

    move-object/from16 v6, v22

    .line 1890
    goto/16 :goto_22

    .line 1892
    :cond_5c
    :try_start_3f
    invoke-virtual {v8, v3}, Lacqf;->s(Ljava/util/List;)V

    .line 1895
    invoke-virtual {v4}, Layoy;->g()Laypd;

    .line 1898
    move-result-object v3

    .line 1899
    invoke-virtual {v8, v3}, Lacqf;->o(Layos;)V

    .line 1902
    new-instance v3, Ljava/util/ArrayList;

    .line 1904
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 1907
    iget-object v4, v5, Lovh;->r:Lbdts;

    .line 1909
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 1912
    move-result-object v4

    .line 1913
    :goto_2b
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 1916
    move-result v5

    .line 1917
    :try_end_3f
    .catchall {:try_start_3f .. :try_end_3f} :catchall_f

    if-eqz v5, :cond_65

    .line 1919
    :try_start_40
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1922
    move-result-object v5

    .line 1923
    check-cast v5, Louu;

    .line 1925
    invoke-static {}, Lacpq;->f()Lacoy;

    .line 1928
    move-result-object v6

    .line 1929
    iget v7, v5, Louu;->b:I

    .line 1931
    :try_end_40
    .catchall {:try_start_40 .. :try_end_40} :catchall_b

    and-int/lit8 v7, v7, 0x8

    .line 1933
    if-eqz v7, :cond_5e

    .line 1935
    :try_start_41
    iget v7, v5, Louu;->f:I

    .line 1937
    :try_end_41
    .catchall {:try_start_41 .. :try_end_41} :catchall_c

    and-int/lit8 v7, v7, 0x10

    .line 1939
    if-eqz v7, :cond_5d

    .line 1941
    const/16 v16, 0x1

    .line 1943
    goto :goto_2c

    .line 1944
    :cond_5d
    const/16 v16, 0x0

    .line 1946
    :goto_2c
    const/4 v15, 0x1

    .line 1947
    xor-int/lit8 v7, v16, 0x1

    .line 1949
    :try_start_42
    invoke-virtual {v6, v7}, Lacoy;->d(Z)V

    .line 1952
    goto :goto_2d

    .line 1953
    :catchall_c
    move-exception v0

    .line 1954
    const/4 v15, 0x1

    .line 1955
    goto/16 :goto_20

    .line 1957
    :cond_5e
    const/4 v15, 0x1

    .line 1958
    invoke-virtual {v6, v15}, Lacoy;->d(Z)V

    .line 1961
    :goto_2d
    iget v7, v5, Louu;->b:I

    .line 1963
    const/4 v13, 0x4

    .line 1964
    and-int/2addr v7, v13

    .line 1965
    if-eqz v7, :cond_5f

    .line 1967
    iget-object v7, v5, Louu;->e:Ljava/lang/String;

    .line 1969
    invoke-virtual {v6, v7}, Lacoy;->c(Ljava/lang/String;)V

    .line 1972
    :cond_5f
    iget v7, v5, Louu;->b:I

    .line 1974
    and-int/lit8 v7, v7, 0x2

    .line 1976
    if-eqz v7, :cond_60

    .line 1978
    iget-object v7, v5, Louu;->d:Ljava/lang/String;

    .line 1980
    invoke-static {v7}, Lalnd;->b(Ljava/lang/CharSequence;)Z

    .line 1983
    move-result v9

    .line 1984
    if-nez v9, :cond_60

    .line 1986
    invoke-static {v7}, Lalsw;->a(Ljava/lang/String;)Landroid/net/Uri;

    .line 1989
    move-result-object v7

    .line 1990
    invoke-virtual {v7}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 1993
    move-result-object v7

    .line 1994
    iput-object v7, v6, Lacoy;->b:Ljava/lang/String;

    .line 1996
    :cond_60
    iget v7, v5, Louu;->b:I

    .line 1998
    and-int/lit8 v9, v7, 0x1

    .line 2000
    if-eqz v9, :cond_61

    .line 2002
    iget-object v9, v5, Louu;->c:Ljava/lang/String;

    .line 2004
    iput-object v9, v6, Lacoy;->a:Ljava/lang/String;

    .line 2006
    :cond_61
    and-int/lit8 v7, v7, 0x20

    .line 2008
    if-eqz v7, :cond_64

    .line 2010
    iget-object v5, v5, Louu;->g:Lbebi;

    .line 2012
    if-nez v5, :cond_62

    .line 2014
    sget-object v5, Lbebi;->a:Lbebi;

    .line 2016
    :cond_62
    iget v7, v5, Lbebi;->b:I

    .line 2018
    const/16 v16, 0x1

    .line 2020
    and-int/lit8 v7, v7, 0x1

    .line 2022
    if-eqz v7, :cond_64

    .line 2024
    iget v5, v5, Lbebi;->c:I

    .line 2026
    invoke-static {v5}, Lbebh;->a(I)I

    .line 2029
    move-result v5

    .line 2030
    if-nez v5, :cond_63

    .line 2032
    const/4 v5, 0x1

    .line 2033
    :cond_63
    const/16 v17, -0x1

    .line 2035
    add-int/lit8 v5, v5, -0x1

    .line 2037
    invoke-virtual {v6, v5}, Lacoy;->b(I)V

    .line 2040
    goto :goto_2e

    .line 2041
    :cond_64
    const/16 v17, -0x1

    .line 2043
    :goto_2e
    invoke-virtual {v6}, Lacoy;->a()Lacpq;

    .line 2046
    move-result-object v5

    .line 2047
    invoke-interface {v3, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2050
    :try_end_42
    .catchall {:try_start_42 .. :try_end_42} :catchall_b

    goto/16 :goto_2b

    .line 2052
    :cond_65
    :try_start_43
    invoke-virtual {v8, v3}, Lacqf;->q(Ljava/util/List;)V

    .line 2055
    invoke-virtual {v8}, Lacqf;->a()Lacqg;

    .line 2058
    move-result-object v3

    .line 2059
    iget v4, v10, Lovj;->b:I

    .line 2061
    :try_end_43
    .catchall {:try_start_43 .. :try_end_43} :catchall_f

    const/4 v13, 0x4

    .line 2062
    and-int/2addr v4, v13

    .line 2063
    if-eqz v4, :cond_66

    .line 2065
    :try_start_44
    new-instance v13, Lacpo;

    .line 2067
    iget-object v4, v10, Lovj;->e:Ljava/lang/String;

    .line 2069
    invoke-direct {v13, v4}, Lacpo;-><init>(Ljava/lang/String;)V

    .line 2072
    :try_end_44
    .catchall {:try_start_44 .. :try_end_44} :catchall_b

    goto :goto_2f

    .line 2073
    :cond_66
    const/4 v13, 0x0

    .line 2074
    :goto_2f
    :try_start_45
    new-instance v4, Lacpk;

    .line 2076
    invoke-direct {v4, v2, v3, v0, v13}, Lacpk;-><init>(Luws;Lacqg;Luxk;Lacpo;)V

    .line 2079
    :try_end_45
    .catchall {:try_start_45 .. :try_end_45} :catchall_f

    move/from16 v2, v18

    .line 2081
    :try_start_46
    new-array v0, v2, [Ljava/io/Closeable;

    .line 2083
    const/16 v19, 0x0

    .line 2085
    aput-object v24, v0, v19

    .line 2087
    const/16 v16, 0x1

    .line 2089
    aput-object v20, v0, v16

    .line 2091
    invoke-static {v0}, Lakve;->f([Ljava/io/Closeable;)V

    .line 2094
    :try_end_46
    .catchall {:try_start_46 .. :try_end_46} :catchall_e

    :try_start_47
    invoke-static/range {v21 .. v21}, Lahio;->f(Lorg/apache/http/HttpEntity;)V

    .line 2097
    :try_end_47
    .catch Lcom/google/android/apps/play/books/net/HttpHelper$ServerStatusErrorException; {:try_start_47 .. :try_end_47} :catch_4
    .catch Ljava/io/IOException; {:try_start_47 .. :try_end_47} :catch_3
    .catch Lcom/google/android/gms/auth/GoogleAuthException; {:try_start_47 .. :try_end_47} :catch_2
    .catchall {:try_start_47 .. :try_end_47} :catchall_d

    iget-object v0, v1, Ladqu;->h:Lppr;

    .line 2099
    invoke-virtual/range {v23 .. v23}, Lalsf;->a()J

    .line 2102
    move-object/from16 v3, v28

    .line 2104
    invoke-virtual {v0, v3}, Lppr;->a(Ljava/lang/String;)V

    .line 2107
    return-object v4

    .line 2108
    :catchall_d
    move-exception v0

    .line 2109
    move-object/from16 v3, v28

    .line 2111
    goto/16 :goto_3e

    .line 2113
    :catch_2
    move-exception v0

    .line 2114
    goto :goto_30

    .line 2115
    :catch_3
    move-exception v0

    .line 2116
    :goto_30
    move-object/from16 v3, v28

    .line 2118
    goto/16 :goto_3c

    .line 2120
    :catch_4
    move-exception v0

    .line 2121
    move-object/from16 v3, v28

    .line 2123
    goto/16 :goto_3a

    .line 2125
    :catchall_e
    move-exception v0

    .line 2126
    move-object/from16 v3, v28

    .line 2128
    goto/16 :goto_39

    .line 2130
    :catchall_f
    move-exception v0

    .line 2131
    move-object/from16 v3, v28

    .line 2133
    goto/16 :goto_37

    .line 2135
    :catchall_10
    move-exception v0

    .line 2136
    move-object v3, v4

    .line 2137
    goto/16 :goto_37

    .line 2139
    :catchall_11
    move-exception v0

    .line 2140
    move-object v3, v4

    .line 2141
    move-object/from16 v25, v6

    .line 2143
    move-object/from16 v27, v7

    .line 2145
    move-object/from16 v26, v9

    .line 2147
    goto/16 :goto_37

    .line 2149
    :catchall_12
    move-exception v0

    .line 2150
    move-object v3, v4

    .line 2151
    move-object/from16 v25, v6

    .line 2153
    move-object/from16 v27, v7

    .line 2155
    move-object/from16 v26, v9

    .line 2157
    goto/16 :goto_36

    .line 2159
    :cond_67
    move/from16 v10, v17

    .line 2161
    :goto_31
    move-object v3, v4

    .line 2162
    move-object/from16 v25, v6

    .line 2164
    move-object/from16 v27, v7

    .line 2166
    move-object/from16 v26, v9

    .line 2168
    move-object/from16 v23, v14

    .line 2170
    move-object/from16 v24, v15

    .line 2172
    :try_start_48
    new-instance v0, Ljava/io/IOException;

    .line 2174
    const/16 v16, 0x1

    .line 2176
    xor-int/lit8 v4, v22, 0x1

    .line 2178
    if-eqz v10, :cond_69

    .line 2180
    and-int/lit8 v6, v11, 0x1

    .line 2182
    if-eqz v6, :cond_68

    .line 2184
    goto :goto_32

    .line 2185
    :cond_68
    const/4 v15, 0x0

    .line 2186
    goto :goto_33

    .line 2187
    :cond_69
    :goto_32
    const/4 v15, 0x1

    .line 2188
    :goto_33
    new-instance v6, Ljava/lang/StringBuilder;

    .line 2190
    invoke-direct {v6, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 2193
    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2196
    const-string v2, " has manifest: "

    .line 2198
    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2201
    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 2204
    const-string v2, " has overview if requested: "

    .line 2206
    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2209
    invoke-virtual {v6, v15}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 2212
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 2215
    move-result-object v2

    .line 2216
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 2219
    throw v0

    .line 2220
    :try_end_48
    .catchall {:try_start_48 .. :try_end_48} :catchall_13

    :catchall_13
    move-exception v0

    .line 2221
    goto :goto_37

    .line 2222
    :catchall_14
    move-exception v0

    .line 2223
    move-object v3, v4

    .line 2224
    move-object/from16 v25, v6

    .line 2226
    move-object/from16 v27, v7

    .line 2228
    move-object/from16 v26, v9

    .line 2230
    goto :goto_35

    .line 2231
    :catchall_15
    move-exception v0

    .line 2232
    move-object v3, v4

    .line 2233
    move-object/from16 v25, v6

    .line 2235
    move-object/from16 v27, v7

    .line 2237
    move-object/from16 v26, v9

    .line 2239
    goto :goto_34

    .line 2240
    :catchall_16
    move-exception v0

    .line 2241
    move-object v3, v4

    .line 2242
    move-object/from16 v25, v6

    .line 2244
    move-object/from16 v27, v7

    .line 2246
    move-object/from16 v26, v9

    .line 2248
    move-object/from16 v20, v11

    .line 2250
    :goto_34
    move-object/from16 v21, v13

    .line 2252
    :goto_35
    move-object/from16 v23, v14

    .line 2254
    :goto_36
    move-object/from16 v24, v15

    .line 2256
    :goto_37
    const/4 v2, 0x2

    .line 2257
    :goto_38
    :try_start_49
    new-array v2, v2, [Ljava/io/Closeable;

    .line 2259
    const/16 v19, 0x0

    .line 2261
    aput-object v24, v2, v19

    .line 2263
    const/16 v16, 0x1

    .line 2265
    aput-object v20, v2, v16

    .line 2267
    invoke-static {v2}, Lakve;->f([Ljava/io/Closeable;)V

    .line 2270
    throw v0

    .line 2271
    :try_end_49
    .catchall {:try_start_49 .. :try_end_49} :catchall_17

    :catchall_17
    move-exception v0

    .line 2272
    goto :goto_39

    .line 2273
    :catchall_18
    move-exception v0

    .line 2274
    move-object v3, v4

    .line 2275
    move-object/from16 v25, v6

    .line 2277
    move-object/from16 v27, v7

    .line 2279
    move-object/from16 v26, v9

    .line 2281
    move-object/from16 v21, v13

    .line 2283
    move-object/from16 v23, v14

    .line 2285
    :goto_39
    :try_start_4a
    invoke-static/range {v21 .. v21}, Lahio;->f(Lorg/apache/http/HttpEntity;)V

    .line 2288
    throw v0

    .line 2289
    :try_end_4a
    .catch Lcom/google/android/apps/play/books/net/HttpHelper$ServerStatusErrorException; {:try_start_4a .. :try_end_4a} :catch_7
    .catch Ljava/io/IOException; {:try_start_4a .. :try_end_4a} :catch_6
    .catch Lcom/google/android/gms/auth/GoogleAuthException; {:try_start_4a .. :try_end_4a} :catch_5
    .catchall {:try_start_4a .. :try_end_4a} :catchall_1a

    :catch_5
    move-exception v0

    .line 2290
    goto :goto_3c

    .line 2291
    :catch_6
    move-exception v0

    .line 2292
    goto :goto_3c

    .line 2293
    :catch_7
    move-exception v0

    .line 2294
    goto :goto_3a

    .line 2295
    :catch_8
    move-exception v0

    .line 2296
    move-object v3, v4

    .line 2297
    move-object/from16 v25, v6

    .line 2299
    move-object/from16 v27, v7

    .line 2301
    move-object/from16 v26, v9

    .line 2303
    move-object/from16 v23, v14

    .line 2305
    :goto_3a
    move-object/from16 v6, v27

    .line 2307
    goto :goto_3d

    .line 2308
    :catchall_19
    move-exception v0

    .line 2309
    move-object v3, v4

    .line 2310
    move-object/from16 v23, v14

    .line 2312
    goto/16 :goto_3e

    .line 2314
    :catch_9
    move-exception v0

    .line 2315
    goto :goto_3b

    .line 2316
    :catch_a
    move-exception v0

    .line 2317
    :goto_3b
    move-object v3, v4

    .line 2318
    move-object/from16 v27, v7

    .line 2320
    move-object/from16 v23, v14

    .line 2322
    :goto_3c
    :try_start_4b
    iget-object v2, v1, Ladqu;->k:Lahjy;

    .line 2324
    const/16 v4, 0x194

    .line 2326
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2329
    move-result-object v4

    .line 2330
    new-instance v5, Layvt;

    .line 2332
    invoke-direct {v5, v4}, Layvt;-><init>(Ljava/lang/Object;)V

    .line 2335
    move-object/from16 v6, v27

    .line 2337
    invoke-interface {v2, v0, v6, v5}, Lahjy;->a(Ljava/lang/Exception;Ljava/lang/String;Ljava/util/Set;)V

    .line 2340
    move-object/from16 v5, p2

    .line 2342
    iget-boolean v5, v5, Ladqx;->a:Z

    .line 2344
    if-eqz v5, :cond_6a

    .line 2346
    const-string v5, "fboWithOverview=1"

    .line 2348
    new-instance v6, Layvt;

    .line 2350
    invoke-direct {v6, v4}, Layvt;-><init>(Ljava/lang/Object;)V

    .line 2353
    invoke-interface {v2, v0, v5, v6}, Lahjy;->a(Ljava/lang/Exception;Ljava/lang/String;Ljava/util/Set;)V

    .line 2356
    :cond_6a
    throw v0

    .line 2357
    :catch_b
    move-exception v0

    .line 2358
    move-object v3, v4

    .line 2359
    move-object/from16 v25, v6

    .line 2361
    move-object v6, v7

    .line 2362
    move-object/from16 v26, v9

    .line 2364
    move-object/from16 v23, v14

    .line 2366
    :goto_3d
    iget v2, v0, Lcom/google/android/apps/play/books/net/HttpHelper$ServerStatusErrorException;->a:I

    .line 2368
    const/16 v4, 0x1f4

    .line 2370
    if-ne v2, v4, :cond_6b

    .line 2372
    iget-object v2, v1, Ladqu;->l:Loxu;

    .line 2374
    iget-object v4, v1, Ladqu;->d:Landroid/accounts/Account;

    .line 2376
    invoke-virtual {v2, v4}, Loxu;->a(Landroid/accounts/Account;)Z

    .line 2379
    move-result v2

    .line 2380
    if-eqz v2, :cond_6b

    .line 2382
    sget-object v2, Ladqu;->a:Layxl;

    .line 2384
    invoke-virtual {v2}, Layxb;->c()Layxz;

    .line 2387
    move-result-object v2

    .line 2388
    check-cast v2, Layxi;

    .line 2390
    invoke-interface {v2, v0}, Layxi;->i(Ljava/lang/Throwable;)Layxz;

    .line 2393
    move-result-object v2

    .line 2394
    check-cast v2, Layxi;

    .line 2396
    const/16 v4, 0x2c2

    .line 2398
    move-object/from16 v5, v25

    .line 2400
    move-object/from16 v7, v26

    .line 2402
    invoke-interface {v2, v5, v6, v4, v7}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 2405
    move-result-object v2

    .line 2406
    check-cast v2, Layxi;

    .line 2408
    const-string v4, "ServerStatusError[getFastBookOpenData] for disabled account"

    .line 2410
    invoke-interface {v2, v4}, Layxi;->s(Ljava/lang/String;)V

    .line 2413
    new-instance v2, Lcom/google/android/apps/play/books/net/HttpHelper$AccountAuthException;

    .line 2415
    invoke-virtual {v0}, Lcom/google/android/apps/play/books/net/HttpHelper$ServerStatusErrorException;->getMessage()Ljava/lang/String;

    .line 2418
    move-result-object v4

    .line 2419
    invoke-direct {v2, v4, v0}, Lcom/google/android/apps/play/books/net/HttpHelper$AccountAuthException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 2422
    throw v2

    .line 2423
    :cond_6b
    move-object/from16 v5, v25

    .line 2425
    move-object/from16 v7, v26

    .line 2427
    sget-object v2, Ladqu;->a:Layxl;

    .line 2429
    invoke-virtual {v2}, Layxb;->c()Layxz;

    .line 2432
    move-result-object v2

    .line 2433
    check-cast v2, Layxi;

    .line 2435
    invoke-interface {v2, v0}, Layxi;->i(Ljava/lang/Throwable;)Layxz;

    .line 2438
    move-result-object v2

    .line 2439
    check-cast v2, Layxi;

    .line 2441
    const/16 v4, 0x2c7

    .line 2443
    invoke-interface {v2, v5, v6, v4, v7}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 2446
    move-result-object v2

    .line 2447
    check-cast v2, Layxi;

    .line 2449
    const-string v4, "ServerStatusError[getFastBookOpenData]"

    .line 2451
    invoke-interface {v2, v4}, Layxi;->s(Ljava/lang/String;)V

    .line 2454
    throw v0

    .line 2455
    :try_end_4b
    .catchall {:try_start_4b .. :try_end_4b} :catchall_1a

    :catchall_1a
    move-exception v0

    .line 2456
    :goto_3e
    iget-object v1, v1, Ladqu;->h:Lppr;

    .line 2458
    invoke-virtual/range {v23 .. v23}, Lalsf;->a()J

    .line 2461
    invoke-virtual {v1, v3}, Lppr;->a(Ljava/lang/String;)V

    .line 2464
    throw v0
.end method

.method public final c(Ljava/lang/String;Lacpq;Lajej;)Lajeh;
    .locals 4

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "EbookServer"

    .line 4
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 10
    invoke-virtual {p2}, Lacpq;->R()Ljava/lang/String;

    .line 13
    move-result-object v0

    .line 14
    new-instance v2, Ljava/lang/StringBuilder;

    .line 16
    const-string v3, "Fetching volume "

    .line 18
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 21
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 24
    const-string p1, ", page ID "

    .line 26
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 35
    move-result-object p1

    .line 36
    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 39
    :cond_0
    invoke-virtual {p2}, Lacpq;->b()Ljava/lang/String;

    .line 42
    move-result-object p1

    .line 43
    iget-object p2, p0, Ladqu;->e:Lahjj;

    .line 45
    iget-object v0, p3, Lajej;->a:Lajek;

    .line 47
    invoke-static {p2, p1, v0}, Lwva;->b(Lahjj;Ljava/lang/String;Lajek;)Landroid/net/Uri$Builder;

    .line 50
    move-result-object p1

    .line 51
    iget-object p2, p0, Ladqu;->f:Ladrb;

    .line 53
    iget-object v0, p2, Ladrb;->b:Ljava/lang/String;

    .line 55
    const-string v0, "w"

    .line 57
    iget-object p2, p2, Ladrb;->a:Ljava/lang/String;

    .line 59
    invoke-virtual {p1, v0, p2}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 62
    invoke-virtual {p1}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 65
    move-result-object p1

    .line 66
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 69
    move-result-object p1

    .line 70
    invoke-static {}, Lbfxi;->f()Z

    .line 73
    move-result p2

    .line 74
    const-string v0, "retrieveImageEntity"

    .line 76
    const-string v1, "com/google/android/apps/play/books/ebook/server/EBookServerImpl"

    .line 78
    const-string v2, "EBookServerImpl.java"

    .line 80
    if-eqz p2, :cond_1

    .line 82
    sget-object p2, Ladqu;->a:Layxl;

    .line 84
    invoke-virtual {p2}, Layxb;->d()Layxz;

    .line 87
    move-result-object p2

    .line 88
    check-cast p2, Layxi;

    .line 90
    const/16 v3, 0xd2

    .line 92
    invoke-interface {p2, v1, v0, v3, v2}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 95
    move-result-object p2

    .line 96
    check-cast p2, Layxi;

    .line 98
    const-string v3, "RPCEvent[retrieveImageEntity]: SUL %s"

    .line 100
    invoke-interface {p2, v3, p1}, Layxi;->v(Ljava/lang/String;Ljava/lang/Object;)V

    .line 103
    :cond_1
    :try_start_0
    iget-object p2, p0, Ladqu;->c:Lahjo;

    .line 105
    iget-object p0, p0, Ladqu;->d:Landroid/accounts/Account;

    .line 107
    invoke-interface {p2, p1, p0}, Lahjo;->d(Ljava/lang/String;Landroid/accounts/Account;)Lorg/apache/http/HttpResponse;

    .line 110
    move-result-object p0

    .line 111
    invoke-interface {p0}, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;

    .line 114
    move-result-object p0

    .line 115
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Lcom/google/android/gms/auth/GoogleAuthException; {:try_start_0 .. :try_end_0} :catch_0

    new-instance p1, Ladqt;

    .line 117
    invoke-direct {p1, p0, p3, p0, p3}, Ladqt;-><init>(Lorg/apache/http/HttpEntity;Lajej;Lorg/apache/http/HttpEntity;Lajej;)V

    .line 120
    return-object p1

    .line 121
    :catch_0
    move-exception p0

    .line 122
    goto :goto_0

    .line 123
    :catch_1
    move-exception p0

    .line 124
    :goto_0
    sget-object p2, Ladqu;->a:Layxl;

    .line 126
    invoke-virtual {p2}, Layxb;->c()Layxz;

    .line 129
    move-result-object p2

    .line 130
    check-cast p2, Layxi;

    .line 132
    invoke-interface {p2, p0}, Layxi;->i(Ljava/lang/Throwable;)Layxz;

    .line 135
    move-result-object p2

    .line 136
    check-cast p2, Layxi;

    .line 138
    const/16 p3, 0xd7

    .line 140
    invoke-interface {p2, v1, v0, p3, v2}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 143
    move-result-object p2

    .line 144
    check-cast p2, Layxi;

    .line 146
    const-string p3, "RPCError[retrieveImageEntity]: SUL %s"

    .line 148
    invoke-interface {p2, p3, p1}, Layxi;->v(Ljava/lang/String;Ljava/lang/Object;)V

    .line 151
    throw p0
.end method

.method public final d(Ljava/lang/String;Ljava/lang/String;Lajej;)Lajeh;
    .locals 7

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "EbookServer"

    .line 4
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 10
    const-string v0, "Fetching structure for volume "

    .line 12
    const-string v2, ", page ID "

    .line 14
    invoke-static {p2, p1, v0, v2}, La;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 17
    move-result-object v0

    .line 18
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 21
    :cond_0
    iget-object v0, p0, Ladqu;->e:Lahjj;

    .line 23
    invoke-virtual {v0, p1, p2}, Lahjj;->d(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    .line 26
    move-result-object p1

    .line 27
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 30
    move-result-object p1

    .line 31
    iget-object p2, p3, Lajej;->a:Lajek;

    .line 33
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    iget-object p2, p2, Lajek;->b:Ljava/lang/String;

    .line 41
    invoke-static {v0, p1, p2}, Lwva;->c(Lahjj;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 44
    move-result-object p1

    .line 45
    const-string p2, "alt"

    .line 47
    const-string v0, "proto"

    .line 49
    invoke-virtual {p1, p2, v0}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 52
    const-string p2, "ps"

    .line 54
    const-string v0, "1"

    .line 56
    invoke-virtual {p1, p2, v0}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 59
    const-string p2, "enc_all"

    .line 61
    invoke-virtual {p1, p2, v0}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 64
    invoke-virtual {p1}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 67
    move-result-object p1

    .line 68
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 71
    move-result-object p1

    .line 72
    const-string v5, "EBookServerImpl.java"

    .line 74
    :try_start_0
    invoke-static {}, Lbfxi;->f()Z

    .line 77
    move-result p2

    .line 78
    if-eqz p2, :cond_1

    .line 80
    sget-object p2, Ladqu;->a:Layxl;

    .line 82
    invoke-virtual {p2}, Layxb;->d()Layxz;

    .line 85
    move-result-object p2

    .line 86
    check-cast p2, Layxi;

    .line 88
    const-string v0, "com/google/android/apps/play/books/ebook/server/EBookServerImpl"

    .line 90
    const-string v1, "retrieveStructureEntity"

    .line 92
    const/16 v2, 0x248

    .line 94
    invoke-interface {p2, v0, v1, v2, v5}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 97
    move-result-object p2

    .line 98
    check-cast p2, Layxi;

    .line 100
    const-string v0, "RPCEvent[retrieveStructureEntity]"

    .line 102
    invoke-interface {p2, v0}, Layxi;->s(Ljava/lang/String;)V

    .line 105
    :cond_1
    iget-object p2, p0, Ladqu;->c:Lahjo;

    .line 107
    iget-object p0, p0, Ladqu;->d:Landroid/accounts/Account;

    .line 109
    invoke-interface {p2, p1, p0}, Lahjo;->d(Ljava/lang/String;Landroid/accounts/Account;)Lorg/apache/http/HttpResponse;

    .line 112
    move-result-object p0

    .line 113
    invoke-interface {p0}, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;

    .line 116
    move-result-object p0

    .line 117
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Lcom/google/android/gms/auth/GoogleAuthException; {:try_start_0 .. :try_end_0} :catch_0

    new-instance p1, Lajdh;

    .line 119
    invoke-direct {p1, p0, p3}, Lajdh;-><init>(Lorg/apache/http/HttpEntity;Lajej;)V

    .line 122
    return-object p1

    .line 123
    :catch_0
    move-exception v0

    .line 124
    goto :goto_0

    .line 125
    :catch_1
    move-exception v0

    .line 126
    :goto_0
    move-object p0, v0

    .line 127
    move-object v6, p0

    .line 128
    sget-object p0, Ladqu;->a:Layxl;

    .line 130
    invoke-virtual {p0}, Layxb;->c()Layxz;

    .line 133
    move-result-object v0

    .line 134
    const-string v3, "retrieveStructureEntity"

    .line 136
    const/16 v4, 0x24c

    .line 138
    const-string v1, "RPCError[retrieveStructureEntity]"

    .line 140
    const-string v2, "com/google/android/apps/play/books/ebook/server/EBookServerImpl"

    .line 142
    invoke-static/range {v0 .. v6}, La;->A(Layxz;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;CLjava/lang/String;Ljava/lang/Throwable;)V

    .line 145
    throw v6
.end method

.method public final e(Ljava/lang/String;)Ljava/io/InputStream;
    .locals 7

    .line 1
    const-string v5, "EBookServerImpl.java"

    .line 3
    :try_start_0
    invoke-static {}, Lbfxi;->f()Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 9
    sget-object v0, Ladqu;->a:Layxl;

    .line 11
    invoke-virtual {v0}, Layxb;->d()Layxz;

    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Layxi;

    .line 17
    const-string v1, "com/google/android/apps/play/books/ebook/server/EBookServerImpl"

    .line 19
    const-string v2, "getAudioResourceContent"

    .line 21
    const/16 v3, 0x1ac

    .line 23
    invoke-interface {v0, v1, v2, v3, v5}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Layxi;

    .line 29
    const-string v1, "RPCEvent[getAudioResourceContent]"

    .line 31
    invoke-interface {v0, v1}, Layxi;->s(Ljava/lang/String;)V

    .line 34
    :cond_0
    iget-object v0, p0, Ladqu;->c:Lahjo;

    .line 36
    iget-object p0, p0, Ladqu;->d:Landroid/accounts/Account;

    .line 38
    invoke-interface {v0, p1, p0}, Lahjo;->d(Ljava/lang/String;Landroid/accounts/Account;)Lorg/apache/http/HttpResponse;

    .line 41
    move-result-object p0

    .line 42
    invoke-interface {p0}, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;

    .line 45
    move-result-object p0

    .line 46
    invoke-interface {p0}, Lorg/apache/http/HttpEntity;->getContent()Ljava/io/InputStream;

    .line 49
    move-result-object p0

    .line 50
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Lcom/google/android/gms/auth/GoogleAuthException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    .line 51
    :catch_0
    move-exception v0

    .line 52
    goto :goto_0

    .line 53
    :catch_1
    move-exception v0

    .line 54
    :goto_0
    move-object p0, v0

    .line 55
    move-object v6, p0

    .line 56
    sget-object p0, Ladqu;->a:Layxl;

    .line 58
    invoke-virtual {p0}, Layxb;->c()Layxz;

    .line 61
    move-result-object v0

    .line 62
    const-string v3, "getAudioResourceContent"

    .line 64
    const/16 v4, 0x1b1

    .line 66
    const-string v1, "RPCError[getAudioResourceContent]"

    .line 68
    const-string v2, "com/google/android/apps/play/books/ebook/server/EBookServerImpl"

    .line 70
    invoke-static/range {v0 .. v6}, La;->A(Layxz;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;CLjava/lang/String;Ljava/lang/Throwable;)V

    .line 73
    throw v6
.end method

.method public final f(Ljava/lang/String;)Ljava/io/InputStream;
    .locals 9

    .line 1
    iget-object v0, p0, Ladqu;->e:Lahjj;

    .line 3
    invoke-virtual {v0, p1}, Lahjj;->h(Ljava/lang/String;)Landroid/net/Uri;

    .line 6
    move-result-object p1

    .line 7
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 10
    move-result-object p1

    .line 11
    new-instance v0, Lorg/apache/http/client/methods/HttpGet;

    .line 13
    invoke-direct {v0, p1}, Lorg/apache/http/client/methods/HttpGet;-><init>(Ljava/lang/String;)V

    .line 16
    const-string p1, "Accept-Charset"

    .line 18
    const-string v1, "utf-8"

    .line 20
    invoke-virtual {v0, p1, v1}, Lorg/apache/http/client/methods/HttpGet;->setHeader(Ljava/lang/String;Ljava/lang/String;)V

    .line 23
    const-string v7, "EBookServerImpl.java"

    .line 25
    :try_start_0
    invoke-static {}, Lbfxi;->f()Z

    .line 28
    move-result p1

    .line 29
    if-eqz p1, :cond_0

    .line 31
    sget-object p1, Ladqu;->a:Layxl;

    .line 33
    invoke-virtual {p1}, Layxb;->d()Layxz;

    .line 36
    move-result-object p1

    .line 37
    check-cast p1, Layxi;

    .line 39
    const-string v1, "com/google/android/apps/play/books/ebook/server/EBookServerImpl"

    .line 41
    const-string v2, "getSharedFontContent"

    .line 43
    const/16 v3, 0xe5

    .line 45
    invoke-interface {p1, v1, v2, v3, v7}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 48
    move-result-object p1

    .line 49
    check-cast p1, Layxi;

    .line 51
    const-string v1, "RPCEvent[getSharedFontContent]"

    .line 53
    invoke-interface {p1, v1}, Layxi;->s(Ljava/lang/String;)V

    .line 56
    :cond_0
    iget-object p1, p0, Ladqu;->c:Lahjo;

    .line 58
    iget-object p0, p0, Ladqu;->d:Landroid/accounts/Account;

    .line 60
    invoke-interface {p1, v0, p0}, Lahjo;->c(Lorg/apache/http/client/methods/HttpUriRequest;Landroid/accounts/Account;)Lorg/apache/http/HttpResponse;

    .line 63
    move-result-object p0

    .line 64
    invoke-interface {p0}, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;

    .line 67
    move-result-object p0

    .line 68
    invoke-interface {p0}, Lorg/apache/http/HttpEntity;->getContent()Ljava/io/InputStream;

    .line 71
    move-result-object p0

    .line 72
    new-instance p1, Lahix;

    .line 74
    invoke-direct {p1, p0}, Laltm;-><init>(Ljava/io/InputStream;)V

    .line 77
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Lcom/google/android/gms/auth/GoogleAuthException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    .line 78
    :catch_0
    move-exception v0

    .line 79
    goto :goto_0

    .line 80
    :catch_1
    move-exception v0

    .line 81
    :goto_0
    move-object p0, v0

    .line 82
    move-object v8, p0

    .line 83
    sget-object p0, Ladqu;->a:Layxl;

    .line 85
    invoke-virtual {p0}, Layxb;->c()Layxz;

    .line 88
    move-result-object v2

    .line 89
    const-string v5, "getSharedFontContent"

    .line 91
    const/16 v6, 0xea

    .line 93
    const-string v3, "RPCError[getSharedFontContent]"

    .line 95
    const-string v4, "com/google/android/apps/play/books/ebook/server/EBookServerImpl"

    .line 97
    invoke-static/range {v2 .. v8}, La;->A(Layxz;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;CLjava/lang/String;Ljava/lang/Throwable;)V

    .line 100
    throw v8
.end method

.method public final g(Ljava/lang/String;Lacpu;Lacpo;Lajej;Ljava/lang/String;Z)Ladrd;
    .locals 14

    .line 1
    move-object/from16 v0, p3

    .line 3
    move-object/from16 v1, p4

    .line 5
    const-string v2, "getSegmentContent"

    .line 7
    const-string v3, "com/google/android/apps/play/books/ebook/server/EBookServerImpl"

    .line 9
    const-string v4, "Unhandled inline CSS: "

    .line 11
    const-string v5, "Unsupported session key version: "

    .line 13
    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    invoke-virtual/range {p2 .. p2}, Lacpu;->R()Ljava/lang/String;

    .line 19
    move-result-object v6

    .line 20
    invoke-virtual/range {p2 .. p2}, Lacpu;->i()Ljava/lang/String;

    .line 23
    move-result-object v7

    .line 24
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    const-string v8, "EBookServerImpl.java"

    .line 32
    const/4 v9, 0x3

    .line 33
    const-string v10, "EbookServer"

    .line 35
    invoke-static {v10, v9}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 38
    move-result v9

    .line 39
    if-eqz v9, :cond_0

    .line 41
    const-string v9, "Fetching volume "

    .line 43
    const-string v11, ", segment ID "

    .line 45
    invoke-static {v6, p1, v9, v11}, La;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 48
    move-result-object v6

    .line 49
    invoke-static {v10, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 52
    :cond_0
    iget-object v6, p0, Ladqu;->e:Lahjj;

    .line 54
    iget-object v9, v1, Lajej;->a:Lajek;

    .line 56
    invoke-static {v6, v7, v9}, Lwva;->b(Lahjj;Ljava/lang/String;Lajek;)Landroid/net/Uri$Builder;

    .line 59
    move-result-object v6

    .line 60
    const-string v7, "w"

    .line 62
    move-object/from16 v9, p5

    .line 64
    invoke-virtual {v6, v7, v9}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 67
    const-string v7, "alt"

    .line 69
    const-string v9, "proto"

    .line 71
    invoke-virtual {v6, v7, v9}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 74
    const-string v7, "inline"

    .line 76
    const-string v9, "0"

    .line 78
    invoke-virtual {v6, v7, v9}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 81
    if-eqz v0, :cond_1

    .line 83
    iget-object v0, v0, Lacpo;->a:Ljava/lang/String;

    .line 85
    const-string v7, "lsess"

    .line 87
    invoke-virtual {v6, v7, v0}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 90
    :cond_1
    invoke-virtual {v6}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 93
    move-result-object v0

    .line 94
    invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 97
    move-result-object v6

    .line 98
    const/4 v7, 0x0

    .line 99
    :try_start_0
    invoke-static {}, Lbfxi;->f()Z

    .line 102
    move-result v0

    .line 103
    if-eqz v0, :cond_2

    .line 105
    sget-object v0, Ladqu;->a:Layxl;

    .line 107
    invoke-virtual {v0}, Layxb;->d()Layxz;

    .line 110
    move-result-object v0

    .line 111
    check-cast v0, Layxi;

    .line 113
    const/16 v9, 0x1db

    .line 115
    invoke-interface {v0, v3, v2, v9, v8}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 118
    move-result-object v0

    .line 119
    check-cast v0, Layxi;

    .line 121
    const-string v9, "RPCEvent[getSegmentContent]"

    .line 123
    invoke-interface {v0, v9}, Layxi;->s(Ljava/lang/String;)V

    .line 126
    :cond_2
    iget-object v0, p0, Ladqu;->c:Lahjo;

    .line 128
    iget-object p0, p0, Ladqu;->d:Landroid/accounts/Account;

    .line 130
    invoke-interface {v0, v6, p0}, Lahjo;->d(Ljava/lang/String;Landroid/accounts/Account;)Lorg/apache/http/HttpResponse;

    .line 133
    move-result-object p0

    .line 134
    invoke-interface {p0}, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;

    .line 137
    move-result-object p0

    .line 138
    :try_end_0
    .catch Lcom/google/android/apps/play/books/net/HttpHelper$KeyExpiredException; {:try_start_0 .. :try_end_0} :catch_5
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Lcom/google/android/gms/auth/GoogleAuthException; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    invoke-interface {p0}, Lorg/apache/http/HttpEntity;->getContent()Ljava/io/InputStream;

    .line 141
    move-result-object v0

    .line 142
    invoke-static {v0}, Lakve;->h(Ljava/io/InputStream;)[B

    .line 145
    move-result-object v0

    .line 146
    invoke-static {}, Lbdsj;->a()Lbdsj;

    .line 149
    move-result-object v9

    .line 150
    sget-object v11, Lbccy;->a:Lbccy;

    .line 152
    invoke-static {v11, v0, v9}, Lbdtb;->parseFrom(Lbdtb;[BLbdsj;)Lbdtb;

    .line 155
    move-result-object v0

    .line 156
    check-cast v0, Lbccy;

    .line 158
    invoke-static {v0}, Lalmy;->a(Lbccy;)V

    .line 161
    if-eqz p6, :cond_3

    .line 163
    sget-object v9, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 165
    goto :goto_0

    .line 166
    :cond_3
    sget-object v9, Ladqu;->b:Ljava/util/Set;

    .line 168
    invoke-static {v0, v9}, Ladqu;->m(Lbccy;Ljava/util/Set;)Ljava/util/List;

    .line 171
    move-result-object v9

    .line 172
    :goto_0
    iget v11, v0, Lbccy;->b:I

    .line 174
    and-int/lit16 v11, v11, 0x80

    .line 176
    const/4 v12, 0x2

    .line 177
    if-eqz v11, :cond_4

    .line 179
    iget-object v11, v0, Lbccy;->f:Ljava/lang/String;

    .line 181
    invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z

    .line 184
    move-result v13

    .line 185
    if-nez v13, :cond_4

    .line 187
    invoke-static {v10, v12}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 190
    move-result v13

    .line 191
    if-eqz v13, :cond_4

    .line 193
    invoke-virtual {v11}, Ljava/lang/String;->length()I

    .line 196
    move-result v11

    .line 197
    new-instance v13, Ljava/lang/StringBuilder;

    .line 199
    invoke-direct {v13, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 202
    invoke-virtual {v13, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 205
    const-string v4, " bytes"

    .line 207
    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 210
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 213
    move-result-object v4

    .line 214
    invoke-static {v10, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 217
    :cond_4
    iget-object v4, v0, Lbccy;->d:Lbdrs;

    .line 219
    invoke-virtual {v4}, Lbdrs;->E()Z

    .line 222
    move-result v10

    .line 223
    if-nez v10, :cond_8

    .line 225
    invoke-virtual {v4}, Lbdrs;->h()Ljava/io/InputStream;

    .line 228
    move-result-object v4

    .line 229
    new-instance v10, Lajdh;

    .line 231
    invoke-direct {v10, p0, v4, v1}, Lajdh;-><init>(Lorg/apache/http/HttpEntity;Ljava/io/InputStream;Lajej;)V

    .line 234
    iget v4, v0, Lbccy;->b:I

    .line 236
    and-int/lit16 v4, v4, 0x100

    .line 238
    if-eqz v4, :cond_7

    .line 240
    iget-object v0, v0, Lbccy;->g:Lbccq;

    .line 242
    if-nez v0, :cond_5

    .line 244
    sget-object v0, Lbccq;->a:Lbccq;

    .line 246
    :cond_5
    iget v4, v0, Lbccq;->b:I

    .line 248
    and-int/2addr v4, v12

    .line 249
    if-eqz v4, :cond_7

    .line 251
    iget-object v0, v0, Lbccq;->c:Lbcco;

    .line 253
    if-nez v0, :cond_6

    .line 255
    sget-object v0, Lbcco;->a:Lbcco;

    .line 257
    :cond_6
    iget-object v7, v0, Lbcco;->b:Lbdts;

    .line 259
    :cond_7
    new-instance v0, Ladrd;

    .line 261
    invoke-direct {v0, v10, v9, v7}, Ladrd;-><init>(Lajeh;Ljava/util/List;Ljava/util/List;)V

    .line 264
    :try_end_1
    .catch Lcom/google/android/apps/play/books/net/HttpHelper$KeyExpiredException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Lcom/google/android/gms/auth/GoogleAuthException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-static {p0}, Lahio;->f(Lorg/apache/http/HttpEntity;)V

    .line 267
    return-object v0

    .line 268
    :cond_8
    :try_start_2
    new-instance v0, Lcom/google/android/apps/play/books/util/EmptySegmentContentException;

    .line 270
    const-string v4, "Empty segment"

    .line 272
    invoke-direct {v0, v4}, Lcom/google/android/apps/play/books/util/EmptySegmentContentException;-><init>(Ljava/lang/String;)V

    .line 275
    throw v0

    .line 276
    :try_end_2
    .catch Lcom/google/android/apps/play/books/net/HttpHelper$KeyExpiredException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Lcom/google/android/gms/auth/GoogleAuthException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :catchall_0
    move-exception v0

    .line 277
    move-object v7, p0

    .line 278
    goto :goto_5

    .line 279
    :catch_0
    move-exception v0

    .line 280
    goto :goto_1

    .line 281
    :catch_1
    move-exception v0

    .line 282
    :goto_1
    move-object v7, p0

    .line 283
    goto :goto_3

    .line 284
    :catch_2
    move-exception v0

    .line 285
    move-object v7, p0

    .line 286
    goto :goto_4

    .line 287
    :catchall_1
    move-exception v0

    .line 288
    move-object p0, v0

    .line 289
    move-object v0, p0

    .line 290
    goto :goto_5

    .line 291
    :catch_3
    move-exception v0

    .line 292
    goto :goto_2

    .line 293
    :catch_4
    move-exception v0

    .line 294
    :goto_2
    move-object p0, v0

    .line 295
    move-object v0, p0

    .line 296
    :goto_3
    :try_start_3
    sget-object p0, Ladqu;->a:Layxl;

    .line 298
    invoke-virtual {p0}, Layxb;->c()Layxz;

    .line 301
    move-result-object p0

    .line 302
    check-cast p0, Layxi;

    .line 304
    invoke-interface {p0, v0}, Layxi;->i(Ljava/lang/Throwable;)Layxz;

    .line 307
    move-result-object p0

    .line 308
    check-cast p0, Layxi;

    .line 310
    const/16 v1, 0x1e5

    .line 312
    invoke-interface {p0, v3, v2, v1, v8}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 315
    move-result-object p0

    .line 316
    check-cast p0, Layxi;

    .line 318
    const-string v1, "RPCError[getSegmentContent] %s"

    .line 320
    invoke-interface {p0, v1, v6}, Layxi;->v(Ljava/lang/String;Ljava/lang/Object;)V

    .line 323
    throw v0

    .line 324
    :catchall_2
    move-exception v0

    .line 325
    move-object p0, v0

    .line 326
    goto :goto_5

    .line 327
    :catch_5
    move-exception v0

    .line 328
    move-object p0, v0

    .line 329
    move-object v0, p0

    .line 330
    :goto_4
    new-instance p0, Lcom/google/android/apps/play/books/util/SessionKeyExpiredException;

    .line 332
    iget-object v1, v1, Lajej;->a:Lajek;

    .line 334
    iget-object v1, v1, Lajek;->b:Ljava/lang/String;

    .line 336
    new-instance v2, Ljava/lang/StringBuilder;

    .line 338
    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 341
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 344
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 347
    move-result-object v1

    .line 348
    invoke-direct {p0, v1, v0}, Lcom/google/android/apps/play/books/util/SessionKeyExpiredException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 351
    throw p0

    .line 352
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :goto_5
    invoke-static {v7}, Lahio;->f(Lorg/apache/http/HttpEntity;)V

    .line 355
    throw v0
.end method
