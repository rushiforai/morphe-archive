.class public final Laanj;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;

.field private final g:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laanj;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laanj;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laanj;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laanj;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laanj;->e:Lbeye;

    .line 14
    iput-object p6, p0, Laanj;->f:Lbeye;

    .line 16
    iput-object p7, p0, Laanj;->g:Lbeye;

    .line 18
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 10

    .line 1
    iget-object v0, p0, Laanj;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v2

    .line 9
    invoke-static {}, Lzvs;->a()Lalyv;

    .line 12
    move-result-object v3

    .line 13
    iget-object v0, p0, Laanj;->b:Lbeye;

    .line 15
    check-cast v0, Lzvr;

    .line 17
    invoke-virtual {v0}, Lzvr;->a()Lalyv;

    .line 20
    move-result-object v4

    .line 21
    iget-object v0, p0, Laanj;->d:Lbeye;

    .line 23
    check-cast v0, Labxb;

    .line 25
    invoke-virtual {v0}, Labxb;->a()Labxa;

    .line 28
    move-result-object v6

    .line 29
    iget-object v0, p0, Laanj;->e:Lbeye;

    .line 31
    check-cast v0, Laclw;

    .line 33
    invoke-virtual {v0}, Laclw;->a()Lacli;

    .line 36
    move-result-object v7

    .line 37
    iget-object v0, p0, Laanj;->f:Lbeye;

    .line 39
    check-cast v0, Labjc;

    .line 41
    invoke-virtual {v0}, Labjc;->a()Labjb;

    .line 44
    move-result-object v8

    .line 45
    iget-object v0, p0, Laanj;->g:Lbeye;

    .line 47
    check-cast v0, Lackk;

    .line 49
    invoke-virtual {v0}, Lackk;->a()Lackj;

    .line 52
    move-result-object v9

    .line 53
    iget-object v5, p0, Laanj;->c:Lbeye;

    .line 55
    new-instance v1, Laani;

    .line 57
    invoke-direct/range {v1 .. v9}, Laani;-><init>(Ldw;Lalyv;Lalyv;Lbhpa;Labxa;Lacli;Labjb;Lackj;)V

    .line 60
    return-object v1
.end method
