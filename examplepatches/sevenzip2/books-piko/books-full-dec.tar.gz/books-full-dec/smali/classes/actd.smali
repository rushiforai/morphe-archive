.class public final Lactd;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lactd;->a:Lbeye;

    .line 6
    iput-object p2, p0, Lactd;->b:Lbeye;

    .line 8
    iput-object p3, p0, Lactd;->c:Lbeye;

    .line 10
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, Lactd;->a:Lbeye;

    .line 3
    check-cast v0, Lacuy;

    .line 5
    invoke-virtual {v0}, Lacuy;->a()Lacux;

    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Lactd;->b:Lbeye;

    .line 11
    check-cast v1, Lacxj;

    .line 13
    invoke-virtual {v1}, Lacxj;->a()Lacwy;

    .line 16
    move-result-object v1

    .line 17
    iget-object p0, p0, Lactd;->c:Lbeye;

    .line 19
    check-cast p0, Lacsz;

    .line 21
    invoke-virtual {p0}, Lacsz;->a()Lacsu;

    .line 24
    move-result-object p0

    .line 25
    new-instance v2, Lactc;

    .line 27
    invoke-direct {v2, v0, v1, p0}, Lactc;-><init>(Lacux;Lacwy;Lacsu;)V

    .line 30
    return-object v2
.end method
