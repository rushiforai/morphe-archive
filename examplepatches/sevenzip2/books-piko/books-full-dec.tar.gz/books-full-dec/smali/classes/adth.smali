.class public final Ladth;
.super Ladti;
.source "PG"


# instance fields
.field public final a:Lavkn;

.field public final b:Lbesg;


# direct methods
.method public constructor <init>(Lavkn;Lbesg;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ladti;-><init>()V

    .line 4
    iput-object p1, p0, Ladth;->a:Lavkn;

    .line 6
    iput-object p2, p0, Ladth;->b:Lbesg;

    .line 8
    return-void
.end method
