.class final Ladxn;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:I

.field final synthetic b:Ladxt;


# direct methods
.method public constructor <init>(Ladxt;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ladxn;->b:Ladxt;

    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, Lbhuu;-><init>(ILbhtu;)V

    .line 7
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Ladxn;

    .line 13
    invoke-virtual {p0, p1}, Ladxn;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Ladxn;->a:I

    .line 5
    const/4 v2, 0x1

    .line 6
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 9
    if-eqz v1, :cond_0

    .line 11
    if-eq v1, v2, :cond_1

    .line 13
    goto :goto_1

    .line 14
    :cond_0
    sget-wide v3, Ladxt;->a:J

    .line 16
    iput v2, p0, Ladxn;->a:I

    .line 18
    invoke-static {v3, v4}, Lbifu;->a(J)J

    .line 21
    move-result-wide v3

    .line 22
    invoke-static {v3, v4, p0}, Lbifu;->c(JLbhtu;)Ljava/lang/Object;

    .line 25
    move-result-object p1

    .line 26
    if-ne p1, v0, :cond_1

    .line 28
    goto :goto_0

    .line 29
    :cond_1
    iget-object p1, p0, Ladxn;->b:Ladxt;

    .line 31
    const/4 v1, 0x2

    .line 32
    iput v1, p0, Ladxn;->a:I

    .line 34
    invoke-static {p1, p0}, Ladxt;->a(Ladxt;Lbhtu;)Ljava/lang/Object;

    .line 37
    move-result-object p1

    .line 38
    if-ne p1, v0, :cond_2

    .line 40
    :goto_0
    return-object v0

    .line 41
    :cond_2
    :goto_1
    if-eqz p1, :cond_3

    .line 43
    goto :goto_2

    .line 44
    :cond_3
    const/4 v2, 0x0

    .line 45
    :goto_2
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 48
    move-result-object p0

    .line 49
    return-object p0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 0

    .line 1
    new-instance p1, Ladxn;

    .line 3
    iget-object p0, p0, Ladxn;->b:Ladxt;

    .line 5
    invoke-direct {p1, p0, p2}, Ladxn;-><init>(Ladxt;Lbhtu;)V

    .line 8
    return-object p1
.end method
