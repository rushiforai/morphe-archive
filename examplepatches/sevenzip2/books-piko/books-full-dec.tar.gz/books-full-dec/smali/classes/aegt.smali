.class public final Laegt;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:I

.field final synthetic b:Landroid/accounts/AccountManager;

.field private synthetic c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/accounts/AccountManager;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laegt;->b:Landroid/accounts/AccountManager;

    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, Lbhuu;-><init>(ILbhtu;)V

    .line 7
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbiko;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Laegt;

    .line 13
    invoke-virtual {p0, p1}, Laegt;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Laegt;->a:I

    .line 5
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 8
    if-eqz v1, :cond_0

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object p1, p0, Laegt;->c:Ljava/lang/Object;

    .line 13
    check-cast p1, Lbiko;

    .line 15
    new-instance v1, Laegr;

    .line 17
    invoke-direct {v1, p1}, Laegr;-><init>(Lbiko;)V

    .line 20
    iget-object v2, p0, Laegt;->b:Landroid/accounts/AccountManager;

    .line 22
    const/4 v3, 0x0

    .line 23
    const/4 v4, 0x1

    .line 24
    invoke-virtual {v2, v1, v3, v4}, Landroid/accounts/AccountManager;->addOnAccountsUpdatedListener(Landroid/accounts/OnAccountsUpdateListener;Landroid/os/Handler;Z)V

    .line 27
    new-instance v3, Laegs;

    .line 29
    invoke-direct {v3, v2, v1}, Laegs;-><init>(Landroid/accounts/AccountManager;Landroid/accounts/OnAccountsUpdateListener;)V

    .line 32
    iput v4, p0, Laegt;->a:I

    .line 34
    invoke-static {p1, v3, p0}, Lbikn;->a(Lbiko;Lbhwf;Lbhtu;)Ljava/lang/Object;

    .line 37
    move-result-object p0

    .line 38
    if-ne p0, v0, :cond_1

    .line 40
    return-object v0

    .line 41
    :cond_1
    :goto_0
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 43
    return-object p0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 1

    .line 1
    new-instance v0, Laegt;

    .line 3
    iget-object p0, p0, Laegt;->b:Landroid/accounts/AccountManager;

    .line 5
    invoke-direct {v0, p0, p2}, Laegt;-><init>(Landroid/accounts/AccountManager;Lbhtu;)V

    .line 8
    iput-object p1, v0, Laegt;->c:Ljava/lang/Object;

    .line 10
    return-object v0
.end method
