.class public final Laclw;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laclw;->a:Lbeye;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()Lacli;
    .locals 0

    .line 1
    iget-object p0, p0, Laclw;->a:Lbeye;

    .line 3
    check-cast p0, Laclj;

    .line 5
    invoke-virtual {p0}, Laclj;->a()Lacli;

    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Laclw;->a()Lacli;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
