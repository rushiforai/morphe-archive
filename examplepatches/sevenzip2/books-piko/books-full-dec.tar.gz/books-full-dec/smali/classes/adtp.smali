.class public final Ladtp;
.super Ljava/lang/Object;
.source "PG"


# static fields
.field public static final a:Ladtq;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Ladtq;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    sput-object v0, Ladtp;->a:Ladtq;

    .line 8
    return-void
.end method
