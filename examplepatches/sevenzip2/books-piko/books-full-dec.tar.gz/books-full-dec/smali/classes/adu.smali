.class public interface abstract Ladu;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract a(Ljava/lang/Object;)V
.end method
