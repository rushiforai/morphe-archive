.class public final Laehd;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:I

.field final synthetic b:Lbhwq;

.field final synthetic c:Lbilb;

.field private synthetic d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lbhwq;Lbilb;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laehd;->b:Lbhwq;

    .line 3
    iput-object p2, p0, Laehd;->c:Lbilb;

    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, Lbhuu;-><init>(ILbhtu;)V

    .line 9
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbilc;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Laehd;

    .line 13
    invoke-virtual {p0, p1}, Laehd;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Laehd;->a:I

    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v1, :cond_1

    .line 8
    if-eq v1, v2, :cond_0

    .line 10
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 13
    goto :goto_1

    .line 14
    :cond_0
    iget-object v1, p0, Laehd;->d:Ljava/lang/Object;

    .line 16
    check-cast v1, Lbilc;

    .line 18
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 21
    goto :goto_0

    .line 22
    :cond_1
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 25
    iget-object p1, p0, Laehd;->d:Ljava/lang/Object;

    .line 27
    move-object v1, p1

    .line 28
    check-cast v1, Lbilc;

    .line 30
    iget-object p1, p0, Laehd;->b:Lbhwq;

    .line 32
    iput-object v1, p0, Laehd;->d:Ljava/lang/Object;

    .line 34
    iput v2, p0, Laehd;->a:I

    .line 36
    invoke-interface {p1, p0}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    move-result-object p1

    .line 40
    if-eq p1, v0, :cond_3

    .line 42
    :goto_0
    iget-object v2, p0, Laehd;->c:Lbilb;

    .line 44
    new-instance v3, Laehc;

    .line 46
    const/4 v4, 0x0

    .line 47
    invoke-direct {v3, p1, v4}, Laehc;-><init>(Ljava/lang/Object;Lbhtu;)V

    .line 50
    new-instance p1, Lbimu;

    .line 52
    invoke-direct {p1, v2, v3}, Lbimu;-><init>(Lbilb;Lbhwu;)V

    .line 55
    invoke-static {p1}, Lbimd;->a(Lbilb;)Lbilb;

    .line 58
    move-result-object p1

    .line 59
    iput-object v4, p0, Laehd;->d:Ljava/lang/Object;

    .line 61
    const/4 v2, 0x2

    .line 62
    iput v2, p0, Laehd;->a:I

    .line 64
    invoke-static {v1}, Lbimj;->b(Lbilc;)V

    .line 67
    invoke-interface {p1, v1, p0}, Lbilb;->gv(Lbilc;Lbhtu;)Ljava/lang/Object;

    .line 70
    move-result-object p0

    .line 71
    if-ne p0, v0, :cond_2

    .line 73
    goto :goto_2

    .line 74
    :cond_2
    :goto_1
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 76
    return-object p0

    .line 77
    :cond_3
    :goto_2
    return-object v0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 2

    .line 1
    new-instance v0, Laehd;

    .line 3
    iget-object v1, p0, Laehd;->b:Lbhwq;

    .line 5
    iget-object p0, p0, Laehd;->c:Lbilb;

    .line 7
    invoke-direct {v0, v1, p0, p2}, Laehd;-><init>(Lbhwq;Lbilb;Lbhtu;)V

    .line 10
    iput-object p1, v0, Laehd;->d:Ljava/lang/Object;

    .line 12
    return-object v0
.end method
