.class public final Ladwk;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladwk;->a:Lbeye;

    .line 6
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Ladwk;->a:Lbeye;

    .line 3
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/util/concurrent/Executor;

    .line 9
    invoke-static {p0}, Lbigt;->b(Ljava/util/concurrent/Executor;)Lbifb;

    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method
