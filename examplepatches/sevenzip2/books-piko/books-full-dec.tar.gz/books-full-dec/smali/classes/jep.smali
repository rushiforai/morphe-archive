.class public interface abstract Ljep;
.super Ljava/lang/Object;
.source "PG"