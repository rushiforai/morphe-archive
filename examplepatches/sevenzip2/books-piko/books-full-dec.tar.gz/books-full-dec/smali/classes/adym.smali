.class public final Ladym;
.super Ljava/lang/Object;
.source "PG"