.class public final Laakb;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;

.field private final g:Lbeye;

.field private final h:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laakb;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laakb;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laakb;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laakb;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laakb;->e:Lbeye;

    .line 14
    iput-object p6, p0, Laakb;->f:Lbeye;

    .line 16
    iput-object p7, p0, Laakb;->g:Lbeye;

    .line 18
    iput-object p8, p0, Laakb;->h:Lbeye;

    .line 20
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 9

    .line 1
    iget-object v0, p0, Laakb;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v2

    .line 9
    iget-object v0, p0, Laakb;->b:Lbeye;

    .line 11
    check-cast v0, Laake;

    .line 13
    invoke-virtual {v0}, Laake;->a()Laakd;

    .line 16
    move-result-object v3

    .line 17
    iget-object v0, p0, Laakb;->c:Lbeye;

    .line 19
    check-cast v0, Labvc;

    .line 21
    invoke-virtual {v0}, Labvc;->a()Labvb;

    .line 24
    move-result-object v4

    .line 25
    iget-object v0, p0, Laakb;->d:Lbeye;

    .line 27
    check-cast v0, Lalmd;

    .line 29
    invoke-virtual {v0}, Lalmd;->a()Lalmc;

    .line 32
    iget-object v0, p0, Laakb;->e:Lbeye;

    .line 34
    check-cast v0, Labkc;

    .line 36
    invoke-virtual {v0}, Labkc;->a()Labkb;

    .line 39
    move-result-object v5

    .line 40
    iget-object v0, p0, Laakb;->f:Lbeye;

    .line 42
    invoke-static {v0}, Lbexu;->a(Lbeye;)Lbexl;

    .line 45
    move-result-object v6

    .line 46
    iget-object v0, p0, Laakb;->g:Lbeye;

    .line 48
    check-cast v0, Labxb;

    .line 50
    invoke-virtual {v0}, Labxb;->a()Labxa;

    .line 53
    move-result-object v7

    .line 54
    iget-object p0, p0, Laakb;->h:Lbeye;

    .line 56
    check-cast p0, Lzvr;

    .line 58
    invoke-virtual {p0}, Lzvr;->a()Lalyv;

    .line 61
    move-result-object v8

    .line 62
    new-instance v1, Laaka;

    .line 64
    invoke-direct/range {v1 .. v8}, Laaka;-><init>(Ldw;Laakd;Labvb;Labkb;Lbexl;Labxa;Lalyv;)V

    .line 67
    return-object v1
.end method
