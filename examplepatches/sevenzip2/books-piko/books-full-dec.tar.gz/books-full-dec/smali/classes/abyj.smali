.class public final Labyj;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field private final a:Lbhpa;


# direct methods
.method public constructor <init>(Lbhpa;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    iput-object p1, p0, Labyj;->a:Lbhpa;

    .line 9
    return-void
.end method


# virtual methods
.method public final a(Lakuc;)Labyi;
    .locals 1

    .line 1
    iget-object p0, p0, Labyj;->a:Lbhpa;

    .line 3
    new-instance v0, Labyi;

    .line 5
    invoke-interface {p0}, Lbhpa;->b()Ljava/lang/Object;

    .line 8
    move-result-object p0

    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    check-cast p0, Labyw;

    .line 14
    invoke-direct {v0, p0, p1}, Labyi;-><init>(Labyw;Lakuc;)V

    .line 17
    return-object v0
.end method
