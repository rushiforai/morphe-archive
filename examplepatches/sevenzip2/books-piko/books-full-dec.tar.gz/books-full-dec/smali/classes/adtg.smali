.class public final Ladtg;
.super Ladti;
.source "PG"


# instance fields
.field public final a:Lavgy;

.field public final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lavgy;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ladti;-><init>()V

    .line 4
    iput-object p1, p0, Ladtg;->a:Lavgy;

    .line 6
    iput-object p2, p0, Ladtg;->b:Ljava/lang/String;

    .line 8
    return-void
.end method
