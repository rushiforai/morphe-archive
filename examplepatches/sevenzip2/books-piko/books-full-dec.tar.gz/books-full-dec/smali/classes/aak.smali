.class public final Laak;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field final a:Laaj;

.field final b:Laai;


# direct methods
.method public constructor <init>(Laaj;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laak;->a:Laaj;

    .line 6
    new-instance p1, Laai;

    .line 8
    invoke-direct {p1}, Laai;-><init>()V

    .line 11
    iput-object p1, p0, Laak;->b:Laai;

    .line 13
    return-void
.end method


# virtual methods
.method public final a(IIII)Landroid/view/View;
    .locals 9

    .line 1
    iget-object v0, p0, Laak;->a:Laaj;

    .line 3
    invoke-interface {v0}, Laaj;->d()I

    .line 6
    move-result v1

    .line 7
    invoke-interface {v0}, Laaj;->c()I

    .line 10
    move-result v2

    .line 11
    const/4 v3, 0x0

    .line 12
    move v4, p1

    .line 13
    :goto_0
    if-eq v4, p2, :cond_3

    .line 15
    invoke-interface {v0, v4}, Laaj;->e(I)Landroid/view/View;

    .line 18
    move-result-object v5

    .line 19
    invoke-interface {v0, v5}, Laaj;->b(Landroid/view/View;)I

    .line 22
    move-result v6

    .line 23
    invoke-interface {v0, v5}, Laaj;->a(Landroid/view/View;)I

    .line 26
    move-result v7

    .line 27
    iget-object v8, p0, Laak;->b:Laai;

    .line 29
    invoke-virtual {v8, v1, v2, v6, v7}, Laai;->c(IIII)V

    .line 32
    invoke-virtual {v8}, Laai;->b()V

    .line 35
    invoke-virtual {v8, p3}, Laai;->a(I)V

    .line 38
    invoke-virtual {v8}, Laai;->d()Z

    .line 41
    move-result v6

    .line 42
    if-eqz v6, :cond_0

    .line 44
    return-object v5

    .line 45
    :cond_0
    if-eqz p4, :cond_1

    .line 47
    invoke-virtual {v8}, Laai;->b()V

    .line 50
    invoke-virtual {v8, p4}, Laai;->a(I)V

    .line 53
    invoke-virtual {v8}, Laai;->d()Z

    .line 56
    move-result v6

    .line 57
    if-eqz v6, :cond_1

    .line 59
    move-object v3, v5

    .line 60
    :cond_1
    if-le p2, p1, :cond_2

    .line 62
    const/4 v5, 0x1

    .line 63
    goto :goto_1

    .line 64
    :cond_2
    const/4 v5, -0x1

    .line 65
    :goto_1
    add-int/2addr v4, v5

    .line 66
    goto :goto_0

    .line 67
    :cond_3
    return-object v3
.end method

.method final b(Landroid/view/View;)Z
    .locals 4

    .line 1
    iget-object v0, p0, Laak;->b:Laai;

    .line 3
    iget-object p0, p0, Laak;->a:Laaj;

    .line 5
    invoke-interface {p0}, Laaj;->d()I

    .line 8
    move-result v1

    .line 9
    invoke-interface {p0}, Laaj;->c()I

    .line 12
    move-result v2

    .line 13
    invoke-interface {p0, p1}, Laaj;->b(Landroid/view/View;)I

    .line 16
    move-result v3

    .line 17
    invoke-interface {p0, p1}, Laaj;->a(Landroid/view/View;)I

    .line 20
    move-result p0

    .line 21
    invoke-virtual {v0, v1, v2, v3, p0}, Laai;->c(IIII)V

    .line 24
    invoke-virtual {v0}, Laai;->b()V

    .line 27
    const/16 p0, 0x6003

    .line 29
    invoke-virtual {v0, p0}, Laai;->a(I)V

    .line 32
    invoke-virtual {v0}, Laai;->d()Z

    .line 35
    move-result p0

    .line 36
    return p0
.end method
