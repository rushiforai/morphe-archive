.class public final Lacfx;
.super Lbhuq;
.source "PG"


# instance fields
.field public synthetic a:Ljava/lang/Object;

.field final synthetic b:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

.field public c:I

.field public d:Lbivq;


# direct methods
.method public constructor <init>(Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lacfx;->b:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 3
    invoke-direct {p0, p2}, Lbhuq;-><init>(Lbhtu;)V

    .line 6
    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lacfx;->a:Ljava/lang/Object;

    .line 3
    iget p1, p0, Lacfx;->c:I

    .line 5
    const/high16 v0, -0x80000000

    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lacfx;->c:I

    .line 10
    iget-object p1, p0, Lacfx;->b:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 12
    invoke-virtual {p1, p0}, Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;->c(Lbhtu;)Ljava/lang/Object;

    .line 15
    move-result-object p0

    .line 16
    return-object p0
.end method
