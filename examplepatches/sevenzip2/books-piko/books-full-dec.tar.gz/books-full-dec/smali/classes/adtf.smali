.class public final Ladtf;
.super Lbdtb;
.source "PG"

# interfaces
.implements Lbduj;


# static fields
.field public static final a:Ladtf;


# instance fields
.field public b:I

.field public c:Ljava/lang/String;

.field public d:Lbdvh;

.field public e:Lbdvh;

.field public f:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ladtf;

    .line 3
    invoke-direct {v0}, Ladtf;-><init>()V

    .line 6
    sput-object v0, Ladtf;->a:Ladtf;

    .line 8
    const-class v1, Ladtf;

    .line 10
    invoke-static {v1, v0}, Lbdtb;->registerDefaultInstance(Ljava/lang/Class;Lbdtb;)V

    .line 13
    return-void
.end method

.method private constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Lbdtb;-><init>()V

    .line 4
    const-string v0, ""

    .line 6
    iput-object v0, p0, Ladtf;->c:Ljava/lang/String;

    .line 8
    const/4 v0, 0x1

    .line 9
    iput v0, p0, Ladtf;->f:I

    .line 11
    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lbdta;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    invoke-virtual {p1}, Lbdta;->ordinal()I

    .line 4
    move-result p0

    .line 5
    const/4 p1, 0x6

    .line 6
    const/4 p2, 0x5

    .line 7
    const/4 p3, 0x4

    .line 8
    const/4 v0, 0x3

    .line 9
    const/4 v1, 0x2

    .line 10
    if-eq p0, v1, :cond_4

    .line 12
    if-eq p0, v0, :cond_3

    .line 14
    if-eq p0, p3, :cond_2

    .line 16
    if-eq p0, p2, :cond_1

    .line 18
    if-eq p0, p1, :cond_0

    .line 20
    const/4 p0, 0x0

    .line 21
    return-object p0

    .line 22
    :cond_0
    const-class p0, Ladtf;

    .line 24
    invoke-static {p0}, Lbdtb;->getParserForClass(Ljava/lang/Class;)Lbduo;

    .line 27
    move-result-object p0

    .line 28
    return-object p0

    .line 29
    :cond_1
    sget-object p0, Ladtf;->a:Ladtf;

    .line 31
    return-object p0

    .line 32
    :cond_2
    new-instance p0, Ladte;

    .line 34
    invoke-direct {p0}, Ladte;-><init>()V

    .line 37
    return-object p0

    .line 38
    :cond_3
    new-instance p0, Ladtf;

    .line 40
    invoke-direct {p0}, Ladtf;-><init>()V

    .line 43
    return-object p0

    .line 44
    :cond_4
    new-array p0, p1, [Ljava/lang/Object;

    .line 46
    const-string p1, "b"

    .line 48
    const/4 v2, 0x0

    .line 49
    aput-object p1, p0, v2

    .line 51
    const-string p1, "c"

    .line 53
    const/4 v2, 0x1

    .line 54
    aput-object p1, p0, v2

    .line 56
    const-string p1, "d"

    .line 58
    aput-object p1, p0, v1

    .line 60
    const-string p1, "e"

    .line 62
    aput-object p1, p0, v0

    .line 64
    const-string p1, "f"

    .line 66
    aput-object p1, p0, p3

    .line 68
    sget-object p1, Ladta;->a:Lbdth;

    .line 70
    aput-object p1, p0, p2

    .line 72
    sget-object p1, Ladtf;->a:Ladtf;

    .line 74
    const-string p2, "\u0004\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u1008\u0000\u0002\u1009\u0001\u0003\u1009\u0002\u0004\u180c\u0003"

    .line 76
    invoke-static {p1, p2, p0}, Ladtf;->newMessageInfo(Lbdui;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 79
    move-result-object p0

    .line 80
    return-object p0
.end method
