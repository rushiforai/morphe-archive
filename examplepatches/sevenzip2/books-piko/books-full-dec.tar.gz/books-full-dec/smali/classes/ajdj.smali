.class public Lajdj;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field private final a:Lahjo;

.field private final b:Landroid/accounts/Account;


# direct methods
.method public constructor <init>(Lahjo;Landroid/accounts/Account;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lajdj;->a:Lahjo;

    .line 6
    iput-object p2, p0, Lajdj;->b:Landroid/accounts/Account;

    .line 8
    return-void
.end method


# virtual methods
.method public final h(Lorg/apache/http/client/methods/HttpUriRequest;Lbduo;)Lbdui;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lajdj;->k(Lorg/apache/http/client/methods/HttpUriRequest;)Ljava/io/InputStream;

    .line 4
    move-result-object p0

    .line 5
    :try_start_0
    invoke-static {}, Lbdsj;->a()Lbdsj;

    .line 8
    move-result-object p1

    .line 9
    invoke-interface {p2, p0, p1}, Lbduo;->h(Ljava/io/InputStream;Lbdsj;)Ljava/lang/Object;

    .line 12
    move-result-object p1

    .line 13
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    .line 16
    return-object p1

    .line 17
    :catchall_0
    move-exception p1

    .line 18
    :try_start_1
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    .line 21
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_0

    .line 22
    :catchall_1
    move-exception p0

    .line 23
    invoke-virtual {p1, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 26
    :goto_0
    throw p1
.end method

.method public final i(Landroid/net/Uri;Lbduo;)Lbdui;
    .locals 1

    .line 1
    new-instance v0, Lorg/apache/http/client/methods/HttpGet;

    .line 3
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 6
    move-result-object p1

    .line 7
    invoke-direct {v0, p1}, Lorg/apache/http/client/methods/HttpGet;-><init>(Ljava/lang/String;)V

    .line 10
    invoke-virtual {p0, v0, p2}, Lajdj;->h(Lorg/apache/http/client/methods/HttpUriRequest;Lbduo;)Lbdui;

    .line 13
    move-result-object p0

    .line 14
    return-object p0
.end method

.method public final j(Landroid/net/Uri;Lbdui;Lbduo;)Lbdui;
    .locals 1

    .line 1
    new-instance v0, Lorg/apache/http/client/methods/HttpPost;

    .line 3
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 6
    move-result-object p1

    .line 7
    invoke-direct {v0, p1}, Lorg/apache/http/client/methods/HttpPost;-><init>(Ljava/lang/String;)V

    .line 10
    new-instance p1, Lorg/apache/http/entity/ByteArrayEntity;

    .line 12
    invoke-interface {p2}, Lbdui;->toByteArray()[B

    .line 15
    move-result-object p2

    .line 16
    invoke-direct {p1, p2}, Lorg/apache/http/entity/ByteArrayEntity;-><init>([B)V

    .line 19
    invoke-virtual {v0, p1}, Lorg/apache/http/client/methods/HttpPost;->setEntity(Lorg/apache/http/HttpEntity;)V

    .line 22
    invoke-virtual {p0, v0, p3}, Lajdj;->h(Lorg/apache/http/client/methods/HttpUriRequest;Lbduo;)Lbdui;

    .line 25
    move-result-object p0

    .line 26
    return-object p0
.end method

.method protected final k(Lorg/apache/http/client/methods/HttpUriRequest;)Ljava/io/InputStream;
    .locals 2

    .line 1
    sget-object v0, Lbftm;->a:Lbftm;

    .line 3
    invoke-virtual {v0}, Lbftm;->b()Lbftn;

    .line 6
    move-result-object v0

    .line 7
    invoke-interface {v0}, Lbftn;->a()Z

    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 13
    const-string v0, "accept-encoding"

    .line 15
    const-string v1, "gzip"

    .line 17
    invoke-interface {p1, v0, v1}, Lorg/apache/http/client/methods/HttpUriRequest;->setHeader(Ljava/lang/String;Ljava/lang/String;)V

    .line 20
    :cond_0
    const-string v0, "content-type"

    .line 22
    const-string v1, "application/x-protobuf"

    .line 24
    invoke-interface {p1, v0, v1}, Lorg/apache/http/client/methods/HttpUriRequest;->addHeader(Ljava/lang/String;Ljava/lang/String;)V

    .line 27
    iget-object v0, p0, Lajdj;->a:Lahjo;

    .line 29
    iget-object p0, p0, Lajdj;->b:Landroid/accounts/Account;

    .line 31
    invoke-interface {v0, p1, p0}, Lahjo;->c(Lorg/apache/http/client/methods/HttpUriRequest;Landroid/accounts/Account;)Lorg/apache/http/HttpResponse;

    .line 34
    move-result-object p0

    .line 35
    invoke-interface {p0}, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;

    .line 38
    move-result-object p0

    .line 39
    new-instance p1, Lajdi;

    .line 41
    invoke-static {p0}, Lakub;->a(Lorg/apache/http/HttpEntity;)Ljava/io/InputStream;

    .line 44
    move-result-object v0

    .line 45
    invoke-direct {p1, v0, p0}, Lajdi;-><init>(Ljava/io/InputStream;Lorg/apache/http/HttpEntity;)V

    .line 48
    return-object p1
.end method
