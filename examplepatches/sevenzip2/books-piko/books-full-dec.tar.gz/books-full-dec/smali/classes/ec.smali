.class public Lec;
.super Labl;
.source "PG"

# interfaces
.implements Ljch;


# instance fields
.field final a:Lei;

.field final b:Lkct;

.field c:Z

.field d:Z

.field e:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Labl;-><init>()V

    .line 4
    new-instance v0, Leb;

    .line 6
    invoke-direct {v0, p0}, Leb;-><init>(Lec;)V

    .line 9
    new-instance v1, Lei;

    .line 11
    invoke-direct {v1, v0}, Lei;-><init>(Lek;)V

    .line 14
    iput-object v1, p0, Lec;->a:Lei;

    .line 16
    new-instance v0, Lkct;

    .line 18
    const/4 v1, 0x1

    .line 19
    invoke-direct {v0, p0, v1}, Lkct;-><init>(Lkcm;Z)V

    .line 22
    iput-object v0, p0, Lec;->b:Lkct;

    .line 24
    iput-boolean v1, p0, Lec;->e:Z

    .line 26
    invoke-virtual {p0}, Labl;->S()Lmqs;

    .line 29
    move-result-object v0

    .line 30
    new-instance v1, Ldx;

    .line 32
    invoke-direct {v1, p0}, Ldx;-><init>(Lec;)V

    .line 35
    const-string v2, "android:support:lifecycle"

    .line 37
    invoke-virtual {v0, v2, v1}, Lmqs;->c(Ljava/lang/String;Lmqr;)V

    .line 40
    new-instance v0, Ldy;

    .line 42
    invoke-direct {v0, p0}, Ldy;-><init>(Lec;)V

    .line 45
    invoke-virtual {p0, v0}, Labl;->e(Ljkb;)V

    .line 48
    new-instance v0, Ldz;

    .line 50
    invoke-direct {v0, p0}, Ldz;-><init>(Lec;)V

    .line 53
    iget-object v1, p0, Labl;->k:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 55
    invoke-virtual {v1, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 58
    new-instance v0, Lea;

    .line 60
    invoke-direct {v0, p0}, Lea;-><init>(Lec;)V

    .line 63
    invoke-virtual {p0, v0}, Labl;->r(Lads;)V

    .line 66
    return-void
.end method

.method private static fc(Lfm;Lkbz;)Z
    .locals 5

    .line 1
    invoke-virtual {p0}, Lfm;->l()Ljava/util/List;

    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 8
    move-result-object p0

    .line 9
    const/4 v0, 0x0

    .line 10
    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_4

    .line 16
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    move-result-object v1

    .line 20
    check-cast v1, Ldw;

    .line 22
    if-eqz v1, :cond_0

    .line 24
    iget-object v2, v1, Ldw;->G:Lek;

    .line 26
    if-nez v2, :cond_1

    .line 28
    const/4 v2, 0x0

    .line 29
    goto :goto_1

    .line 30
    :cond_1
    check-cast v2, Leb;

    .line 32
    iget-object v2, v2, Leb;->a:Lec;

    .line 34
    :goto_1
    if-eqz v2, :cond_2

    .line 36
    invoke-virtual {v1}, Ldw;->F()Lfm;

    .line 39
    move-result-object v2

    .line 40
    invoke-static {v2, p1}, Lec;->fc(Lfm;Lkbz;)Z

    .line 43
    move-result v2

    .line 44
    or-int/2addr v0, v2

    .line 45
    :cond_2
    iget-object v2, v1, Ldw;->af:Lgm;

    .line 47
    const/4 v3, 0x1

    .line 48
    if-eqz v2, :cond_3

    .line 50
    invoke-virtual {v2}, Lgm;->N()Lkcb;

    .line 53
    move-result-object v2

    .line 54
    check-cast v2, Lkct;

    .line 56
    iget-object v2, v2, Lkct;->e:Lkbz;

    .line 58
    sget-object v4, Lkbz;->d:Lkbz;

    .line 60
    invoke-virtual {v2, v4}, Lkbz;->a(Lkbz;)Z

    .line 63
    move-result v2

    .line 64
    if-eqz v2, :cond_3

    .line 66
    iget-object v0, v1, Ldw;->af:Lgm;

    .line 68
    iget-object v0, v0, Lgm;->a:Lkct;

    .line 70
    invoke-virtual {v0, p1}, Lkct;->f(Lkbz;)V

    .line 73
    move v0, v3

    .line 74
    :cond_3
    iget-object v2, v1, Ldw;->ad:Lkct;

    .line 76
    iget-object v2, v2, Lkct;->e:Lkbz;

    .line 78
    sget-object v4, Lkbz;->d:Lkbz;

    .line 80
    invoke-virtual {v2, v4}, Lkbz;->a(Lkbz;)Z

    .line 83
    move-result v2

    .line 84
    if-eqz v2, :cond_0

    .line 86
    iget-object v0, v1, Ldw;->ad:Lkct;

    .line 88
    invoke-virtual {v0, p1}, Lkct;->f(Lkbz;)V

    .line 91
    move v0, v3

    .line 92
    goto :goto_0

    .line 93
    :cond_4
    return v0
.end method


# virtual methods
.method public final a()Lfm;
    .locals 0

    .line 1
    iget-object p0, p0, Lec;->a:Lei;

    .line 3
    invoke-virtual {p0}, Lei;->a()Lfm;

    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method final b(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 0

    .line 1
    iget-object p0, p0, Lec;->a:Lei;

    .line 3
    iget-object p0, p0, Lei;->a:Lek;

    .line 5
    iget-object p0, p0, Lek;->e:Lfm;

    .line 7
    iget-object p0, p0, Lfm;->d:Lem;

    .line 9
    invoke-interface {p0, p1, p2, p3, p4}, Landroid/view/LayoutInflater$Factory2;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public final dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .locals 2

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Labl;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    .line 4
    if-eqz p4, :cond_2

    .line 6
    array-length v0, p4

    .line 7
    if-nez v0, :cond_0

    .line 9
    goto :goto_2

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    aget-object v0, p4, v0

    .line 13
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 16
    move-result v1

    .line 17
    sparse-switch v1, :sswitch_data_0

    .line 20
    goto :goto_2

    .line 21
    :sswitch_0    # 0x56b9c952
    const-string v1, "--autofill"

    .line 23
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_2

    .line 29
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 31
    const/16 v1, 0x1a

    .line 33
    if-lt v0, v1, :cond_2

    .line 35
    goto :goto_1

    .line 36
    :sswitch_1    # 0x4519f64d
    const-string v1, "--contentcapture"

    .line 38
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_2

    .line 44
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 46
    const/16 v1, 0x1d

    .line 48
    if-lt v0, v1, :cond_2

    .line 50
    goto :goto_1

    .line 51
    :sswitch_2    # 0x1c2b8816
    const-string v1, "--list-dumpables"

    .line 53
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 56
    move-result v0

    .line 57
    if-eqz v0, :cond_2

    .line 59
    goto :goto_0

    .line 60
    :sswitch_3    # 0x5fd0f67
    const-string v1, "--dump-dumpable"

    .line 62
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 65
    move-result v0

    .line 66
    if-nez v0, :cond_1

    .line 68
    goto :goto_2

    .line 69
    :cond_1
    :goto_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 71
    const/16 v1, 0x21

    .line 73
    if-lt v0, v1, :cond_2

    .line 75
    goto :goto_1

    .line 76
    :sswitch_4    # -0x2673d6ef
    const-string v1, "--translation"

    .line 78
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 81
    move-result v0

    .line 82
    if-eqz v0, :cond_2

    .line 84
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 86
    const/16 v1, 0x1f

    .line 88
    if-lt v0, v1, :cond_2

    .line 90
    :goto_1
    return-void

    .line 91
    :cond_2
    :goto_2
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 94
    const-string v0, "Local FragmentActivity "

    .line 96
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 99
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 102
    move-result v0

    .line 103
    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 106
    move-result-object v0

    .line 107
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 110
    const-string v0, " State:"

    .line 112
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 115
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 118
    move-result-object v0

    .line 119
    const-string v1, "  "

    .line 121
    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 124
    move-result-object v0

    .line 125
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 128
    const-string v1, "mCreated="

    .line 130
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 133
    iget-boolean v1, p0, Lec;->c:Z

    .line 135
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Z)V

    .line 138
    const-string v1, " mResumed="

    .line 140
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 143
    iget-boolean v1, p0, Lec;->d:Z

    .line 145
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Z)V

    .line 148
    const-string v1, " mStopped="

    .line 150
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 153
    iget-boolean v1, p0, Lec;->e:Z

    .line 155
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Z)V

    .line 158
    invoke-virtual {p0}, Lec;->getApplication()Landroid/app/Application;

    .line 161
    move-result-object v1

    .line 162
    if-eqz v1, :cond_3

    .line 164
    invoke-static {p0}, Lkgv;->a(Lkcm;)Lkgv;

    .line 167
    move-result-object v1

    .line 168
    invoke-virtual {v1, v0, p3}, Lkgv;->b(Ljava/lang/String;Ljava/io/PrintWriter;)V

    .line 171
    :cond_3
    iget-object p0, p0, Lec;->a:Lei;

    .line 173
    invoke-virtual {p0}, Lei;->a()Lfm;

    .line 176
    move-result-object p0

    .line 177
    invoke-virtual {p0, p1, p2, p3, p4}, Lfm;->H(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    .line 180
    return-void

    .line 181
    :sswitch_data_0
    .sparse-switch
        -0x2673d6ef -> :sswitch_4
        0x5fd0f67 -> :sswitch_3
        0x1c2b8816 -> :sswitch_2
        0x4519f64d -> :sswitch_1
        0x56b9c952 -> :sswitch_0

    .end sparse-switch
.end method

.method final f()V
    .locals 2

    .line 1
    :cond_0
    invoke-virtual {p0}, Lec;->a()Lfm;

    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Lkbz;->c:Lkbz;

    .line 7
    invoke-static {v0, v1}, Lec;->fc(Lfm;Lkbz;)Z

    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_0

    .line 13
    return-void
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lec;->a:Lei;

    .line 3
    invoke-virtual {v0}, Lei;->b()V

    .line 6
    invoke-super {p0, p1, p2, p3}, Labl;->onActivityResult(IILandroid/content/Intent;)V

    .line 9
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Labl;->onCreate(Landroid/os/Bundle;)V

    .line 4
    iget-object p1, p0, Lec;->b:Lkct;

    .line 6
    sget-object v0, Lkby;->ON_CREATE:Lkby;

    .line 8
    invoke-virtual {p1, v0}, Lkct;->e(Lkby;)V

    .line 11
    iget-object p0, p0, Lec;->a:Lei;

    .line 13
    iget-object p0, p0, Lei;->a:Lek;

    .line 15
    iget-object p0, p0, Lek;->e:Lfm;

    .line 17
    invoke-virtual {p0}, Lfm;->u()V

    .line 20
    return-void
.end method

.method public final onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 1

    .line 14
    invoke-virtual {p0, p1, p2, p3, p4}, Lec;->b(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    .line 15
    invoke-super {p0, p1, p2, p3, p4}, Labl;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_0
    return-object v0
.end method

.method public final onCreateView(Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0, p1, p2, p3}, Lec;->b(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    .line 5
    move-result-object v0

    .line 6
    if-nez v0, :cond_0

    .line 8
    invoke-super {p0, p1, p2, p3}, Labl;->onCreateView(Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    .line 11
    move-result-object p0

    .line 12
    return-object p0

    .line 13
    :cond_0
    return-object v0
.end method

.method protected onDestroy()V
    .locals 1

    .line 1
    invoke-super {p0}, Labl;->onDestroy()V

    .line 4
    iget-object v0, p0, Lec;->a:Lei;

    .line 6
    iget-object v0, v0, Lei;->a:Lek;

    .line 8
    iget-object v0, v0, Lek;->e:Lfm;

    .line 10
    invoke-virtual {v0}, Lfm;->v()V

    .line 13
    iget-object p0, p0, Lec;->b:Lkct;

    .line 15
    sget-object v0, Lkby;->ON_DESTROY:Lkby;

    .line 17
    invoke-virtual {p0, v0}, Lkct;->e(Lkby;)V

    .line 20
    return-void
.end method

.method public onMenuItemSelected(ILandroid/view/MenuItem;)Z
    .locals 1

    .line 1
    invoke-super {p0, p1, p2}, Labl;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    const/4 p0, 0x1

    .line 8
    return p0

    .line 9
    :cond_0
    const/4 v0, 0x6

    .line 10
    if-ne p1, v0, :cond_1

    .line 12
    iget-object p0, p0, Lec;->a:Lei;

    .line 14
    iget-object p0, p0, Lei;->a:Lek;

    .line 16
    iget-object p0, p0, Lek;->e:Lfm;

    .line 18
    invoke-virtual {p0, p2}, Lfm;->Z(Landroid/view/MenuItem;)Z

    .line 21
    move-result p0

    .line 22
    return p0

    .line 23
    :cond_1
    const/4 p0, 0x0

    .line 24
    return p0
.end method

.method protected onPause()V
    .locals 1

    .line 1
    invoke-super {p0}, Labl;->onPause()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lec;->d:Z

    .line 7
    iget-object v0, p0, Lec;->a:Lei;

    .line 9
    iget-object v0, v0, Lei;->a:Lek;

    .line 11
    iget-object v0, v0, Lek;->e:Lfm;

    .line 13
    invoke-virtual {v0}, Lfm;->B()V

    .line 16
    iget-object p0, p0, Lec;->b:Lkct;

    .line 18
    sget-object v0, Lkby;->ON_PAUSE:Lkby;

    .line 20
    invoke-virtual {p0, v0}, Lkct;->e(Lkby;)V

    .line 23
    return-void
.end method

.method protected onPostResume()V
    .locals 2

    .line 1
    invoke-super {p0}, Labl;->onPostResume()V

    .line 4
    iget-object v0, p0, Lec;->b:Lkct;

    .line 6
    sget-object v1, Lkby;->ON_RESUME:Lkby;

    .line 8
    invoke-virtual {v0, v1}, Lkct;->e(Lkby;)V

    .line 11
    iget-object p0, p0, Lec;->a:Lei;

    .line 13
    iget-object p0, p0, Lei;->a:Lek;

    .line 15
    iget-object p0, p0, Lek;->e:Lfm;

    .line 17
    invoke-virtual {p0}, Lfm;->D()V

    .line 20
    return-void
.end method

.method public final onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lec;->a:Lei;

    .line 3
    invoke-virtual {v0}, Lei;->b()V

    .line 6
    invoke-super {p0, p1, p2, p3}, Labl;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    .line 9
    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 1
    iget-object v0, p0, Lec;->a:Lei;

    .line 3
    invoke-virtual {v0}, Lei;->b()V

    .line 6
    invoke-super {p0}, Labl;->onResume()V

    .line 9
    const/4 v1, 0x1

    .line 10
    iput-boolean v1, p0, Lec;->d:Z

    .line 12
    invoke-virtual {v0}, Lei;->c()V

    .line 15
    return-void
.end method

.method protected onStart()V
    .locals 2

    .line 1
    iget-object v0, p0, Lec;->a:Lei;

    .line 3
    invoke-virtual {v0}, Lei;->b()V

    .line 6
    invoke-super {p0}, Labl;->onStart()V

    .line 9
    const/4 v1, 0x0

    .line 10
    iput-boolean v1, p0, Lec;->e:Z

    .line 12
    iget-boolean v1, p0, Lec;->c:Z

    .line 14
    if-nez v1, :cond_0

    .line 16
    const/4 v1, 0x1

    .line 17
    iput-boolean v1, p0, Lec;->c:Z

    .line 19
    iget-object v1, v0, Lei;->a:Lek;

    .line 21
    iget-object v1, v1, Lek;->e:Lfm;

    .line 23
    invoke-virtual {v1}, Lfm;->s()V

    .line 26
    :cond_0
    invoke-virtual {v0}, Lei;->c()V

    .line 29
    iget-object p0, p0, Lec;->b:Lkct;

    .line 31
    sget-object v1, Lkby;->ON_START:Lkby;

    .line 33
    invoke-virtual {p0, v1}, Lkct;->e(Lkby;)V

    .line 36
    iget-object p0, v0, Lei;->a:Lek;

    .line 38
    iget-object p0, p0, Lek;->e:Lfm;

    .line 40
    invoke-virtual {p0}, Lfm;->E()V

    .line 43
    return-void
.end method

.method public final onStateNotSaved()V
    .locals 0

    .line 1
    iget-object p0, p0, Lec;->a:Lei;

    .line 3
    invoke-virtual {p0}, Lei;->b()V

    .line 6
    return-void
.end method

.method protected onStop()V
    .locals 1

    .line 1
    invoke-super {p0}, Labl;->onStop()V

    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Lec;->e:Z

    .line 7
    invoke-virtual {p0}, Lec;->f()V

    .line 10
    iget-object v0, p0, Lec;->a:Lei;

    .line 12
    iget-object v0, v0, Lei;->a:Lek;

    .line 14
    iget-object v0, v0, Lek;->e:Lfm;

    .line 16
    invoke-virtual {v0}, Lfm;->G()V

    .line 19
    iget-object p0, p0, Lec;->b:Lkct;

    .line 21
    sget-object v0, Lkby;->ON_STOP:Lkby;

    .line 23
    invoke-virtual {p0, v0}, Lkct;->e(Lkby;)V

    .line 26
    return-void
.end method
