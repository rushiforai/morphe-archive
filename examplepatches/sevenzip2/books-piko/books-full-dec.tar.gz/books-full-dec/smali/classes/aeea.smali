.class public final Laeea;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const v0, 0x7f1306b7

    .line 7
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 10
    move-result-object v0

    .line 11
    iput-object v0, p0, Laeea;->a:Ljava/lang/String;

    .line 13
    const v0, 0x7f1307a9

    .line 16
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 19
    move-result-object p1

    .line 20
    iput-object p1, p0, Laeea;->b:Ljava/lang/String;

    .line 22
    return-void
.end method

.method public static final e(Landroid/content/res/AssetFileDescriptor;Ljava/lang/String;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    sput-boolean v0, Laedn;->b:Z

    .line 4
    sput-object p0, Laedn;->c:Landroid/content/res/AssetFileDescriptor;

    .line 6
    sput-object p1, Laedn;->d:Ljava/lang/String;

    .line 8
    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 2

    .line 1
    new-instance v0, Landroid/content/Intent;

    .line 3
    sget-object v1, Laeel;->a:Laeel;

    .line 5
    invoke-virtual {p0, v1}, Laeea;->b(Laeel;)Landroid/net/Uri;

    .line 8
    move-result-object p0

    .line 9
    const-string v1, "android.intent.action.VIEW"

    .line 11
    invoke-direct {v0, v1, p0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 14
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 17
    move-result-object p0

    .line 18
    invoke-virtual {v0, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 21
    const-string p0, "authAccount"

    .line 23
    invoke-virtual {v0, p0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 26
    const p0, 0x1000c000

    .line 29
    invoke-virtual {v0, p0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 32
    return-object v0
.end method

.method public final b(Laeel;)Landroid/net/Uri;
    .locals 2

    .line 1
    invoke-virtual {p1}, Laeel;->ordinal()I

    .line 4
    move-result p1

    .line 5
    if-eqz p1, :cond_3

    .line 7
    const/4 v0, 0x1

    .line 8
    const-string v1, "https://play.google.com/books"

    .line 10
    if-eq p1, v0, :cond_2

    .line 12
    const/4 v0, 0x2

    .line 13
    if-eq p1, v0, :cond_1

    .line 15
    const/4 v0, 0x3

    .line 16
    if-ne p1, v0, :cond_0

    .line 18
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 21
    move-result-object p1

    .line 22
    invoke-virtual {p1}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    .line 25
    move-result-object p1

    .line 26
    iget-object p0, p0, Laeea;->b:Ljava/lang/String;

    .line 28
    invoke-virtual {p1, p0}, Landroid/net/Uri$Builder;->path(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 31
    move-result-object p0

    .line 32
    invoke-virtual {p0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 35
    move-result-object p0

    .line 36
    return-object p0

    .line 37
    :cond_0
    new-instance p0, Ljava/lang/RuntimeException;

    .line 39
    const/4 p1, 0x0

    .line 40
    invoke-direct {p0, p1, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 43
    throw p0

    .line 44
    :cond_1
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 47
    move-result-object p1

    .line 48
    invoke-virtual {p1}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    .line 51
    move-result-object p1

    .line 52
    iget-object p0, p0, Laeea;->a:Ljava/lang/String;

    .line 54
    invoke-virtual {p1, p0}, Landroid/net/Uri$Builder;->path(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 57
    move-result-object p0

    .line 58
    invoke-virtual {p0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 61
    move-result-object p0

    .line 62
    return-object p0

    .line 63
    :cond_2
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 66
    move-result-object p0

    .line 67
    return-object p0

    .line 68
    :cond_3
    const-string p0, "https://play.google.com/books#ReadNow"

    .line 70
    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 73
    move-result-object p0

    .line 74
    return-object p0
.end method

.method public final c(Landroid/app/Activity;Laeel;)V
    .locals 1

    .line 1
    sget-object v0, Landroid/os/Bundle;->EMPTY:Landroid/os/Bundle;

    .line 3
    invoke-virtual {p0, p1, p2, v0}, Laeea;->d(Landroid/app/Activity;Laeel;Landroid/os/Bundle;)V

    .line 6
    return-void
.end method

.method public final d(Landroid/app/Activity;Laeel;Landroid/os/Bundle;)V
    .locals 2

    .line 1
    const-class v0, Lcom/google/android/apps/play/books/home/HomeActivity;

    .line 3
    new-instance v1, Landroid/content/Intent;

    .line 5
    invoke-direct {v1, p1, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 8
    invoke-virtual {p0, p2}, Laeea;->b(Laeel;)Landroid/net/Uri;

    .line 11
    move-result-object p0

    .line 12
    invoke-virtual {v1, p0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 15
    invoke-virtual {v1, p3}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    .line 18
    invoke-virtual {p1, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 21
    return-void
.end method
