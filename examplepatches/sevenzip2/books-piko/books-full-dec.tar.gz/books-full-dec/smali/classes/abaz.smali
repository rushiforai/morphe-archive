.class public final Labaz;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labaz;->a:Lbeye;

    .line 6
    iput-object p2, p0, Labaz;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final a()Labax;
    .locals 2

    .line 1
    iget-object v0, p0, Labaz;->b:Lbeye;

    .line 3
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lbifb;

    .line 9
    new-instance v1, Labax;

    .line 11
    iget-object p0, p0, Labaz;->a:Lbeye;

    .line 13
    invoke-direct {v1, p0, v0}, Labax;-><init>(Lbhpa;Lbifb;)V

    .line 16
    return-object v1
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Labaz;->a()Labax;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
