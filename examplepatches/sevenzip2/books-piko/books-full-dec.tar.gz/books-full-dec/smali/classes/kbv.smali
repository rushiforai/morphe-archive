.class public interface abstract Lkbv;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract P()Lkez;
.end method

.method public abstract R()Lkgj;
.end method
