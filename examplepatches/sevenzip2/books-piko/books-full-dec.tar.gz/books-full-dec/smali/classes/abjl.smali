.class public final Labjl;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labjl;->a:Lbeye;

    .line 6
    return-void
.end method


# virtual methods
.method public final synthetic b()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object p0, p0, Labjl;->a:Lbeye;

    .line 3
    check-cast p0, Lqgk;

    .line 5
    invoke-virtual {p0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object p0

    .line 9
    invoke-static {}, Labjw;->a()Lalyv;

    .line 12
    move-result-object v0

    .line 13
    new-instance v1, Labjk;

    .line 15
    invoke-direct {v1, p0, v0}, Labjk;-><init>(Ldw;Lalyv;)V

    .line 18
    return-object v1
.end method
