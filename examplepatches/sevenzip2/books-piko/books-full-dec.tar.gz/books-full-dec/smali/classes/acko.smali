.class public final Lacko;
.super Ljava/lang/Object;
.source "PG"