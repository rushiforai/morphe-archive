.class public final synthetic Laede;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lkdh;


# instance fields
.field public final synthetic a:Laktt;


# direct methods
.method public synthetic constructor <init>(Laktt;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laede;->a:Laktt;

    .line 6
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .locals 0

    .line 1
    iget-object p0, p0, Laede;->a:Laktt;

    .line 3
    check-cast p1, Lakur;

    .line 5
    invoke-interface {p0, p1}, Lakuc;->fu(Ljava/lang/Object;)V

    .line 8
    return-void
.end method
