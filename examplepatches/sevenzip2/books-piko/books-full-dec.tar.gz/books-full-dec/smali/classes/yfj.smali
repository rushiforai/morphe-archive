.class public interface abstract Lyfj;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract a()V
.end method
