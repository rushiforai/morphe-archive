.class public final Lachq;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lvet;
.implements Lachb;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lvet;",
        "Lachb;"
    }
.end annotation


# instance fields
.field public final a:Lylv;

.field public final b:Lakxb;

.field public final c:Lalnh;

.field private final d:Ljava/util/Map;

.field private final e:Lacgz;


# direct methods
.method public constructor <init>(Lacgz;Lylv;Lalpu;Lakxb;Lalnh;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/HashMap;

    .line 6
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 9
    iput-object v0, p0, Lachq;->d:Ljava/util/Map;

    .line 11
    iput-object p1, p0, Lachq;->e:Lacgz;

    .line 13
    iput-object p2, p0, Lachq;->a:Lylv;

    .line 15
    iput-object p4, p0, Lachq;->b:Lakxb;

    .line 17
    iput-object p5, p0, Lachq;->c:Lalnh;

    .line 19
    new-instance p1, Lachn;

    .line 21
    invoke-direct {p1, p0}, Lachn;-><init>(Lachq;)V

    .line 24
    invoke-interface {p3, p1}, Lalpu;->c(Lakuc;)V

    .line 27
    return-void
.end method


# virtual methods
.method public final a(Luws;)Lacgo;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lves;->a(Lvet;Luws;)Lveu;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final declared-synchronized b(Ljava/lang/String;)Lacgo;
    .locals 14

    .line 1
    move-object v12, p1

    .line 2
    monitor-enter p0

    .line 3
    :try_start_0
    iget-object v0, p0, Lachq;->d:Ljava/util/Map;

    .line 5
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    move-result-object v1

    .line 9
    check-cast v1, Lacgo;

    .line 11
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v1, :cond_0

    .line 13
    monitor-exit p0

    .line 14
    return-object v1

    .line 15
    :cond_0
    :try_start_1
    iget-object v1, p0, Lachq;->e:Lacgz;

    .line 17
    iget-object v2, v1, Lacgz;->a:Lbhpa;

    .line 19
    new-instance v3, Lacgy;

    .line 21
    invoke-interface {v2}, Lbhpa;->b()Ljava/lang/Object;

    .line 24
    move-result-object v2

    .line 25
    check-cast v2, Lachl;

    .line 27
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    iget-object v4, v1, Lacgz;->b:Lbhpa;

    .line 32
    invoke-interface {v4}, Lbhpa;->b()Ljava/lang/Object;

    .line 35
    move-result-object v4

    .line 36
    check-cast v4, Lvef;

    .line 38
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    iget-object v5, v1, Lacgz;->c:Lbhpa;

    .line 43
    check-cast v5, Lpzv;

    .line 45
    invoke-virtual {v5}, Lpzv;->a()Landroid/content/ContentResolver;

    .line 48
    move-result-object v5

    .line 49
    iget-object v6, v1, Lacgz;->d:Lbhpa;

    .line 51
    check-cast v6, Lpwn;

    .line 53
    invoke-virtual {v6}, Lpwn;->a()Landroid/accounts/Account;

    .line 56
    move-result-object v6

    .line 57
    iget-object v7, v1, Lacgz;->e:Lbhpa;

    .line 59
    invoke-interface {v7}, Lbhpa;->b()Ljava/lang/Object;

    .line 62
    move-result-object v7

    .line 63
    check-cast v7, Lacjx;

    .line 65
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 68
    iget-object v8, v1, Lacgz;->f:Lbhpa;

    .line 70
    invoke-interface {v8}, Lbhpa;->b()Ljava/lang/Object;

    .line 73
    move-result-object v8

    .line 74
    check-cast v8, Lylv;

    .line 76
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 79
    iget-object v9, v1, Lacgz;->g:Lbhpa;

    .line 81
    check-cast v9, Ladri;

    .line 83
    invoke-virtual {v9}, Ladri;->a()Ladrh;

    .line 86
    move-result-object v9

    .line 87
    iget-object v10, v1, Lacgz;->h:Lbhpa;

    .line 89
    invoke-interface {v10}, Lbhpa;->b()Ljava/lang/Object;

    .line 92
    move-result-object v10

    .line 93
    check-cast v10, Lyek;

    .line 95
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 98
    iget-object v11, v1, Lacgz;->i:Lbhpa;

    .line 100
    check-cast v11, Lupn;

    .line 102
    invoke-virtual {v11}, Lupn;->a()Luqx;

    .line 105
    move-result-object v11

    .line 106
    iget-object v1, v1, Lacgz;->j:Lbhpa;

    .line 108
    check-cast v1, Lahvr;

    .line 110
    invoke-virtual {v1}, Lahvr;->a()Lahvq;

    .line 113
    move-result-object v1

    .line 114
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 117
    move-object v13, v11

    .line 118
    move-object v11, v1

    .line 119
    move-object v1, v3

    .line 120
    move-object v3, v4

    .line 121
    move-object v4, v5

    .line 122
    move-object v5, v6

    .line 123
    move-object v6, v7

    .line 124
    move-object v7, v8

    .line 125
    move-object v8, v9

    .line 126
    move-object v9, v10

    .line 127
    move-object v10, v13

    .line 128
    invoke-direct/range {v1 .. v12}, Lacgy;-><init>(Lachl;Lvef;Landroid/content/ContentResolver;Landroid/accounts/Account;Lacjx;Lylv;Ladrh;Lyek;Luqx;Lahvq;Ljava/lang/String;)V

    .line 131
    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 134
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    .line 135
    return-object v1

    .line 136
    :catchall_0
    move-exception v0

    .line 137
    :try_start_2
    monitor-exit p0

    .line 138
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0
.end method

.method public final bridge synthetic d(Ljava/lang/String;)Lveu;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lachq;->b(Ljava/lang/String;)Lacgo;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final e(Luws;)Lajvi;
    .locals 1

    .line 1
    invoke-static {p0, p1}, Lves;->a(Lvet;Luws;)Lveu;

    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0}, Lacgo;->h()V

    .line 8
    sget-object p0, Lajvi;->e:Lajvi;

    .line 10
    new-instance p0, Lajue;

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 15
    const/4 p1, 0x1

    .line 16
    invoke-virtual {p0, p1}, Lajue;->c(Z)V

    .line 19
    const/4 v0, 0x0

    .line 20
    invoke-virtual {p0, v0}, Lajue;->b(Z)V

    .line 23
    invoke-virtual {p0, p1}, Lajue;->e(Z)V

    .line 26
    invoke-virtual {p0, p1}, Lajue;->d(Z)V

    .line 29
    invoke-virtual {p0}, Lajue;->a()Lajvi;

    .line 32
    move-result-object p0

    .line 33
    return-object p0
.end method

.method public final f()V
    .locals 2

    .line 1
    iget-object p0, p0, Lachq;->d:Ljava/util/Map;

    .line 3
    invoke-interface {p0}, Ljava/util/Map;->values()Ljava/util/Collection;

    .line 6
    move-result-object v0

    .line 7
    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 10
    move-result-object v0

    .line 11
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    move-result v1

    .line 15
    if-eqz v1, :cond_0

    .line 17
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    move-result-object v1

    .line 21
    check-cast v1, Lacgo;

    .line 23
    invoke-interface {v1}, Lacgo;->f()V

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    invoke-interface {p0}, Ljava/util/Map;->clear()V

    .line 30
    return-void
.end method

.method public final j(Luws;Lver;)Luwv;
    .locals 0

    .line 1
    new-instance p0, Lachp;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    invoke-interface {p2, p0}, Lver;->a(Ljava/util/function/Function;)Ljava/lang/Object;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Luwv;

    .line 12
    return-object p0
.end method
