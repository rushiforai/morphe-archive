.class public final Ladls;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladls;->a:Lbeye;

    .line 6
    iput-object p2, p0, Ladls;->b:Lbeye;

    .line 8
    iput-object p3, p0, Ladls;->c:Lbeye;

    .line 10
    iput-object p4, p0, Ladls;->d:Lbeye;

    .line 12
    iput-object p5, p0, Ladls;->e:Lbeye;

    .line 14
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 7

    .line 1
    iget-object v0, p0, Ladls;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v2

    .line 9
    iget-object v0, p0, Ladls;->b:Lbeye;

    .line 11
    check-cast v0, Labth;

    .line 13
    invoke-virtual {v0}, Labth;->a()Labtg;

    .line 16
    move-result-object v3

    .line 17
    iget-object v0, p0, Ladls;->c:Lbeye;

    .line 19
    check-cast v0, Labxb;

    .line 21
    invoke-virtual {v0}, Labxb;->a()Labxa;

    .line 24
    move-result-object v4

    .line 25
    iget-object v0, p0, Ladls;->d:Lbeye;

    .line 27
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 30
    move-result-object v0

    .line 31
    move-object v5, v0

    .line 32
    check-cast v5, Lbifb;

    .line 34
    iget-object p0, p0, Ladls;->e:Lbeye;

    .line 36
    check-cast p0, Labex;

    .line 38
    invoke-virtual {p0}, Labex;->a()Labew;

    .line 41
    move-result-object v6

    .line 42
    new-instance v1, Ladlr;

    .line 44
    invoke-direct/range {v1 .. v6}, Ladlr;-><init>(Ldw;Labtg;Labxa;Lbifb;Labew;)V

    .line 47
    return-object v1
.end method
