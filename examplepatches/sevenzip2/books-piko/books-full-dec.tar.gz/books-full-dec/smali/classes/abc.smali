.class public final synthetic Labc;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwf;


# instance fields
.field public final synthetic a:Labl;


# direct methods
.method public synthetic constructor <init>(Labl;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labc;->a:Labl;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object p0, p0, Labc;->a:Labl;

    .line 3
    new-instance v0, Lkek;

    .line 5
    invoke-virtual {p0}, Labl;->getApplication()Landroid/app/Application;

    .line 8
    move-result-object v1

    .line 9
    invoke-virtual {p0}, Labl;->fP()Landroid/os/Bundle;

    .line 12
    move-result-object v2

    .line 13
    invoke-direct {v0, v1, p0, v2}, Lkek;-><init>(Landroid/app/Application;Lmqw;Landroid/os/Bundle;)V

    .line 16
    return-object v0
.end method
