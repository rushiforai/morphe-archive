.class public final Ladki;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladki;->a:Lbeye;

    .line 6
    iput-object p2, p0, Ladki;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Ladki;->a:Lbeye;

    .line 3
    check-cast v0, Lpwn;

    .line 5
    invoke-virtual {v0}, Lpwn;->a()Landroid/accounts/Account;

    .line 8
    move-result-object v0

    .line 9
    iget-object p0, p0, Ladki;->b:Lbeye;

    .line 11
    check-cast p0, Lajvr;

    .line 13
    invoke-virtual {p0}, Lajvr;->a()Lajvq;

    .line 16
    move-result-object p0

    .line 17
    new-instance v1, Ladkh;

    .line 19
    invoke-direct {v1, v0, p0}, Ladkh;-><init>(Landroid/accounts/Account;Lajvq;)V

    .line 22
    return-object v1
.end method
