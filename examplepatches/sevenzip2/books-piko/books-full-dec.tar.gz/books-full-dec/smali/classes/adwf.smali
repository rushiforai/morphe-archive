.class public final synthetic Ladwf;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwq;


# instance fields
.field public final synthetic a:Landroid/graphics/RectF;

.field public final synthetic b:Landroid/view/ViewGroup;


# direct methods
.method public synthetic constructor <init>(Landroid/graphics/RectF;Landroid/view/ViewGroup;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladwf;->a:Landroid/graphics/RectF;

    .line 6
    iput-object p2, p0, Ladwf;->b:Landroid/view/ViewGroup;

    .line 8
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, Lcom/google/android/apps/play/books/educampaign/ui/viewvisibility/RectFWithView;

    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    iget-object v0, p0, Ladwf;->a:Landroid/graphics/RectF;

    .line 8
    if-eqz v0, :cond_0

    .line 10
    invoke-virtual {p1, v0}, Lcom/google/android/apps/play/books/educampaign/ui/viewvisibility/RectFWithView;->intersect(Landroid/graphics/RectF;)Z

    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 16
    const/4 p0, 0x1

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    iget-object p0, p0, Ladwf;->b:Landroid/view/ViewGroup;

    .line 20
    invoke-static {p0, p1}, Ladwa;->b(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 23
    const/4 p0, 0x0

    .line 24
    :goto_0
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 27
    move-result-object p0

    .line 28
    return-object p0
.end method
