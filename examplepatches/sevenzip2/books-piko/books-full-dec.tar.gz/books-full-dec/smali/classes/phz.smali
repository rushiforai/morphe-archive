.class public interface abstract Lphz;
.super Ljava/lang/Object;
.source "PG"