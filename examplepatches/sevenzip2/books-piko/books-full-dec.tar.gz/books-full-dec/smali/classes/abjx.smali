.class public final Labjx;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# virtual methods
.method public final synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {}, Labjw;->a()Lalyv;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
