.class public interface abstract Laxja;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract t(Landroid/view/MenuItem;)Z
.end method
