.class public interface abstract Laecl;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract M()Loza;
.end method
