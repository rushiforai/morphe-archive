.class public Lakvc;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lakvn;


# instance fields
.field public final a:Lakxo;

.field public final b:Lahu;


# direct methods
.method public constructor <init>(I)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Lakxo;

    .line 6
    invoke-direct {v0}, Lakxo;-><init>()V

    .line 9
    iput-object v0, p0, Lakvc;->a:Lakxo;

    .line 11
    new-instance v0, Lahu;

    .line 13
    invoke-direct {v0, p1}, Lahu;-><init>(I)V

    .line 16
    iput-object v0, p0, Lakvc;->b:Lahu;

    .line 18
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Lbhwf;)Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0, p1}, Lakvc;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    if-nez v0, :cond_0

    .line 7
    invoke-interface {p2}, Lbhwf;->a()Ljava/lang/Object;

    .line 10
    move-result-object p2

    .line 11
    invoke-virtual {p0, p1, p2}, Lakvc;->d(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 14
    return-object p2

    .line 15
    :cond_0
    return-object v0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    iget-object v0, p0, Lakvc;->b:Lahu;

    .line 6
    invoke-virtual {v0, p1}, Lahu;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    move-result-object v0

    .line 10
    if-nez v0, :cond_0

    .line 12
    iget-object p0, p0, Lakvc;->a:Lakxo;

    .line 14
    invoke-virtual {p0, p1}, Lakxo;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    move-result-object p0

    .line 18
    return-object p0

    .line 19
    :cond_0
    return-object v0
.end method

.method public final c()V
    .locals 1

    .line 1
    iget-object v0, p0, Lakvc;->a:Lakxo;

    .line 3
    invoke-virtual {v0}, Lakxo;->c()V

    .line 6
    iget-object p0, p0, Lakvc;->b:Lahu;

    .line 8
    const/4 v0, -0x1

    .line 9
    invoke-virtual {p0, v0}, Lahu;->f(I)V

    .line 12
    return-void
.end method

.method public final d(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    iget-object v0, p0, Lakvc;->a:Lakxo;

    .line 9
    invoke-virtual {v0, p1, p2}, Lakxo;->d(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 12
    iget-object p0, p0, Lakvc;->b:Lahu;

    .line 14
    invoke-virtual {p0, p1, p2}, Lahu;->c(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    return-void
.end method

.method public final e(Lcom/google/common/base/Predicate;)V
    .locals 4

    .line 1
    iget-object v0, p0, Lakvc;->a:Lakxo;

    .line 3
    invoke-virtual {v0}, Lakxo;->a()V

    .line 6
    iget-object v0, v0, Lakxo;->a:Ljava/util/concurrent/ConcurrentMap;

    .line 8
    invoke-interface {v0}, Ljava/util/concurrent/ConcurrentMap;->keySet()Ljava/util/Set;

    .line 11
    move-result-object v0

    .line 12
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 15
    move-result-object v0

    .line 16
    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_1

    .line 22
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 25
    move-result-object v1

    .line 26
    invoke-interface {p1, v1}, Lcom/google/common/base/Predicate;->apply(Ljava/lang/Object;)Z

    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_0

    .line 32
    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    .line 35
    goto :goto_0

    .line 36
    :cond_1
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 38
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 41
    iget-object p0, p0, Lakvc;->b:Lahu;

    .line 43
    invoke-virtual {p0}, Lahu;->e()Ljava/util/Map;

    .line 46
    move-result-object v1

    .line 47
    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 50
    move-result-object v1

    .line 51
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 54
    move-result-object v1

    .line 55
    :cond_2
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 58
    move-result v2

    .line 59
    if-eqz v2, :cond_3

    .line 61
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 64
    move-result-object v2

    .line 65
    invoke-interface {p1, v2}, Lcom/google/common/base/Predicate;->apply(Ljava/lang/Object;)Z

    .line 68
    move-result v3

    .line 69
    if-eqz v3, :cond_2

    .line 71
    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 74
    goto :goto_1

    .line 75
    :cond_3
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 78
    move-result-object p1

    .line 79
    :goto_2
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 82
    move-result v0

    .line 83
    if-eqz v0, :cond_4

    .line 85
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 88
    move-result-object v0

    .line 89
    invoke-virtual {p0, v0}, Lahu;->d(Ljava/lang/Object;)Ljava/lang/Object;

    .line 92
    goto :goto_2

    .line 93
    :cond_4
    return-void
.end method
