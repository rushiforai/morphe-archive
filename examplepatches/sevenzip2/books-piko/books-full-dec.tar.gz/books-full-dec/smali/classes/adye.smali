.class final Ladye;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:Ljava/lang/Object;

.field b:I

.field final synthetic c:Lbihc;

.field final synthetic d:Ladyl;

.field final synthetic e:Lavnw;

.field final synthetic f:Lcom/google/android/libraries/play/logging/ulex/LogId;

.field final synthetic g:Ladyh;

.field final synthetic h:Lbien;

.field final synthetic i:Ladxz;

.field private synthetic j:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lbihc;Ladyl;Lavnw;Lcom/google/android/libraries/play/logging/ulex/LogId;Ladyh;Lbien;Ladxz;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ladye;->c:Lbihc;

    .line 3
    iput-object p2, p0, Ladye;->d:Ladyl;

    .line 5
    iput-object p3, p0, Ladye;->e:Lavnw;

    .line 7
    iput-object p4, p0, Ladye;->f:Lcom/google/android/libraries/play/logging/ulex/LogId;

    .line 9
    iput-object p5, p0, Ladye;->g:Ladyh;

    .line 11
    iput-object p6, p0, Ladye;->h:Lbien;

    .line 13
    iput-object p7, p0, Ladye;->i:Ladxz;

    .line 15
    const/4 p1, 0x2

    .line 16
    invoke-direct {p0, p1, p8}, Lbhuu;-><init>(ILbhtu;)V

    .line 19
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Ladye;

    .line 13
    invoke-virtual {p0, p1}, Ladye;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Ladye;->b:I

    .line 5
    const/4 v2, 0x3

    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x1

    .line 8
    const/4 v5, 0x0

    .line 9
    if-eqz v1, :cond_1

    .line 11
    if-eq v1, v4, :cond_0

    .line 13
    iget-object v0, p0, Ladye;->j:Ljava/lang/Object;

    .line 15
    check-cast v0, Lbien;

    .line 17
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 20
    goto :goto_2

    .line 21
    :cond_0
    iget-object v1, p0, Ladye;->a:Ljava/lang/Object;

    .line 23
    iget-object v6, p0, Ladye;->j:Ljava/lang/Object;

    .line 25
    check-cast v6, Lbifi;

    .line 27
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 30
    goto :goto_0

    .line 31
    :cond_1
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 34
    iget-object p1, p0, Ladye;->j:Ljava/lang/Object;

    .line 36
    move-object v6, p1

    .line 37
    check-cast v6, Lbifi;

    .line 39
    new-instance p1, Ladyd;

    .line 41
    invoke-direct {p1, v5}, Ladyd;-><init>(Lbhtu;)V

    .line 44
    invoke-static {v6, v5, v3, p1, v2}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 47
    move-result-object v1

    .line 48
    iget-object p1, p0, Ladye;->c:Lbihc;

    .line 50
    iput-object v6, p0, Ladye;->j:Ljava/lang/Object;

    .line 52
    iput-object v1, p0, Ladye;->a:Ljava/lang/Object;

    .line 54
    iput v4, p0, Ladye;->b:I

    .line 56
    invoke-interface {p1, p0}, Lbihc;->n(Lbhtu;)Ljava/lang/Object;

    .line 59
    move-result-object p1

    .line 60
    if-eq p1, v0, :cond_6

    .line 62
    :goto_0
    iget-object p1, p0, Ladye;->d:Ladyl;

    .line 64
    invoke-interface {v1}, Lbihc;->y()Z

    .line 67
    move-result v7

    .line 68
    if-eqz p1, :cond_2

    .line 70
    iget-object p1, p0, Ladye;->h:Lbien;

    .line 72
    new-instance v8, Ladyc;

    .line 74
    invoke-direct {v8, v1, p1, v5}, Ladyc;-><init>(Lbihc;Lbien;Lbhtu;)V

    .line 77
    invoke-static {v6, v5, v3, v8, v2}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 80
    :cond_2
    iget-object p1, p0, Ladye;->e:Lavnw;

    .line 82
    iget-object v1, p0, Ladye;->f:Lcom/google/android/libraries/play/logging/ulex/LogId;

    .line 84
    invoke-interface {p1, v1}, Lavnw;->g(Lcom/google/android/libraries/play/logging/ulex/LogId;)Lavoa;

    .line 87
    move-result-object p1

    .line 88
    if-eqz v7, :cond_3

    .line 90
    sget-object v1, Lbesp;->w:Lbesp;

    .line 92
    goto :goto_1

    .line 93
    :cond_3
    sget-object v1, Lbesp;->v:Lbesp;

    .line 95
    :goto_1
    invoke-interface {p1, v1}, Lavoa;->e(Ljava/lang/Enum;)Ljava/lang/Object;

    .line 98
    move-result-object p1

    .line 99
    check-cast p1, Lavro;

    .line 101
    invoke-virtual {p1}, Lavro;->n()Ljava/lang/Object;

    .line 104
    iget-object p1, p0, Ladye;->g:Ladyh;

    .line 106
    iget-object v1, p0, Ladye;->h:Lbien;

    .line 108
    iget-object p1, p1, Ladyh;->b:Lbien;

    .line 110
    iput-object p1, p0, Ladye;->j:Ljava/lang/Object;

    .line 112
    iput-object v5, p0, Ladye;->a:Ljava/lang/Object;

    .line 114
    const/4 v2, 0x2

    .line 115
    iput v2, p0, Ladye;->b:I

    .line 117
    invoke-virtual {v1, p0}, Lbihp;->go(Lbhtu;)Ljava/lang/Object;

    .line 120
    move-result-object v1

    .line 121
    if-ne v1, v0, :cond_4

    .line 123
    goto :goto_3

    .line 124
    :cond_4
    move-object v0, p1

    .line 125
    move-object p1, v1

    .line 126
    :goto_2
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 128
    invoke-static {p1, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 131
    move-result p1

    .line 132
    if-eqz p1, :cond_5

    .line 134
    iget-object p1, p0, Ladye;->d:Ladyl;

    .line 136
    sget-object v1, Ladyl;->b:Ladyl;

    .line 138
    if-ne p1, v1, :cond_5

    .line 140
    move v3, v4

    .line 141
    :cond_5
    new-instance p1, Ladyf;

    .line 143
    invoke-direct {p1, v3}, Ladyf;-><init>(Z)V

    .line 146
    invoke-virtual {v0, p1}, Lbihp;->R(Ljava/lang/Object;)Z

    .line 149
    iget-object p0, p0, Ladye;->i:Ladxz;

    .line 151
    iput-boolean v4, p0, Ladxz;->c:Z

    .line 153
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 155
    return-object p0

    .line 156
    :cond_6
    :goto_3
    return-object v0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 9

    .line 1
    new-instance v0, Ladye;

    .line 3
    iget-object v1, p0, Ladye;->c:Lbihc;

    .line 5
    iget-object v2, p0, Ladye;->d:Ladyl;

    .line 7
    iget-object v3, p0, Ladye;->e:Lavnw;

    .line 9
    iget-object v4, p0, Ladye;->f:Lcom/google/android/libraries/play/logging/ulex/LogId;

    .line 11
    iget-object v5, p0, Ladye;->g:Ladyh;

    .line 13
    iget-object v6, p0, Ladye;->h:Lbien;

    .line 15
    iget-object v7, p0, Ladye;->i:Ladxz;

    .line 17
    move-object v8, p2

    .line 18
    invoke-direct/range {v0 .. v8}, Ladye;-><init>(Lbihc;Ladyl;Lavnw;Lcom/google/android/libraries/play/logging/ulex/LogId;Ladyh;Lbien;Ladxz;Lbhtu;)V

    .line 21
    iput-object p1, v0, Ladye;->j:Ljava/lang/Object;

    .line 23
    return-object v0
.end method
