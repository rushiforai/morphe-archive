.class public final Laece;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# virtual methods
.method public final synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    new-instance p0, Laecc;

    .line 3
    invoke-direct {p0}, Laecc;-><init>()V

    .line 6
    return-object p0
.end method
