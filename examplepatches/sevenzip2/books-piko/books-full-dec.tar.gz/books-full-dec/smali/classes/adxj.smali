.class public final Ladxj;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public volatile a:Z

.field public final b:Lkdg;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Lkdg;

    .line 6
    invoke-direct {v0}, Lkdb;-><init>()V

    .line 9
    iput-object v0, p0, Ladxj;->b:Lkdg;

    .line 11
    return-void
.end method


# virtual methods
.method public final a(Luws;)Z
    .locals 5

    .line 1
    iget-boolean p0, p0, Ladxj;->a:Z

    .line 3
    const/4 v0, 0x1

    .line 4
    if-nez p0, :cond_0

    .line 6
    return v0

    .line 7
    :cond_0
    const/4 p0, 0x0

    .line 8
    if-nez p1, :cond_1

    .line 10
    const-string p1, "ContentFilteringManager"

    .line 12
    const-string v0, "null VolumeData passed to isVolumeAllowed"

    .line 14
    invoke-static {p1, v0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;)I

    .line 17
    return p0

    .line 18
    :cond_1
    invoke-virtual {p1}, Luws;->f()J

    .line 21
    move-result-wide v1

    .line 22
    const-wide/16 v3, 0x1

    .line 24
    and-long/2addr v1, v3

    .line 25
    const-wide/16 v3, 0x0

    .line 27
    cmp-long p1, v1, v3

    .line 29
    if-eqz p1, :cond_2

    .line 31
    return v0

    .line 32
    :cond_2
    return p0
.end method
