.class public interface abstract Lkcj;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lkcl;


# virtual methods
.method public abstract a(Lkcm;Lkby;)V
.end method
