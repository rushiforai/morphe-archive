.class public Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.super Landroid/view/ViewGroup;
.source "PG"

# interfaces
.implements Ljlm;
.implements Ljln;


# static fields
.field public static final a:Ljava/lang/String;

.field public static final b:[Ljava/lang/Class;

.field public static final c:Ljava/lang/ThreadLocal;

.field static final d:Ljava/util/Comparator;

.field public static final synthetic i:I

.field private static final y:Ljke;


# instance fields
.field public final e:Ljaa;

.field public f:Ljox;

.field public g:Z

.field public h:Landroid/view/ViewGroup$OnHierarchyChangeListener;

.field private final j:Ljava/util/List;

.field private final k:Ljava/util/List;

.field private final l:[I

.field private final m:[I

.field private final n:[I

.field private o:Z

.field private p:Z

.field private q:[I

.field private r:Landroid/view/View;

.field private s:Landroid/view/View;

.field private t:Lizx;

.field private u:Z

.field private v:Landroid/graphics/drawable/Drawable;

.field private w:Ljlp;

.field private final x:Ljlo;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    const-class v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Class;->getPackage()Ljava/lang/Package;

    .line 6
    move-result-object v0

    .line 7
    if-eqz v0, :cond_0

    .line 9
    invoke-virtual {v0}, Ljava/lang/Package;->getName()Ljava/lang/String;

    .line 12
    move-result-object v0

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    :goto_0
    sput-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a:Ljava/lang/String;

    .line 17
    new-instance v0, Lizz;

    .line 19
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 22
    sput-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->d:Ljava/util/Comparator;

    .line 24
    const/4 v0, 0x2

    .line 25
    new-array v0, v0, [Ljava/lang/Class;

    .line 27
    const-class v1, Landroid/content/Context;

    .line 29
    const/4 v2, 0x0

    .line 30
    aput-object v1, v0, v2

    .line 32
    const-class v1, Landroid/util/AttributeSet;

    .line 34
    const/4 v2, 0x1

    .line 35
    aput-object v1, v0, v2

    .line 37
    sput-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->b:[Ljava/lang/Class;

    .line 39
    new-instance v0, Ljava/lang/ThreadLocal;

    .line 41
    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    .line 44
    sput-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->c:Ljava/lang/ThreadLocal;

    .line 46
    new-instance v0, Ljkf;

    .line 48
    const/16 v1, 0xc

    .line 50
    invoke-direct {v0, v1}, Ljkf;-><init>(I)V

    .line 53
    sput-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->y:Ljke;

    .line 55
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    const/4 v0, 0x0

    .line 157
    invoke-direct {p0, p1, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    const v0, 0x7f04026b

    .line 156
    invoke-direct {p0, p1, p2, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 8

    .line 1
    invoke-direct/range {p0 .. p3}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 4
    new-instance v2, Ljava/util/ArrayList;

    .line 6
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 9
    iput-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->j:Ljava/util/List;

    .line 11
    new-instance v2, Ljaa;

    .line 13
    invoke-direct {v2}, Ljaa;-><init>()V

    .line 16
    iput-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->e:Ljaa;

    .line 18
    new-instance v2, Ljava/util/ArrayList;

    .line 20
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 23
    iput-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->k:Ljava/util/List;

    .line 25
    const/4 v2, 0x2

    .line 26
    new-array v4, v2, [I

    .line 28
    iput-object v4, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l:[I

    .line 30
    new-array v4, v2, [I

    .line 32
    iput-object v4, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->m:[I

    .line 34
    new-array v2, v2, [I

    .line 36
    iput-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n:[I

    .line 38
    new-instance v2, Ljlo;

    .line 40
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 43
    iput-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->x:Ljlo;

    .line 45
    const/4 v7, 0x0

    .line 46
    if-nez p3, :cond_0

    .line 48
    sget-object v2, Lizq;->a:[I

    .line 50
    const v4, 0x7f140dfd

    .line 53
    invoke-virtual {p1, p2, v2, v7, v4}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 56
    move-result-object v4

    .line 57
    sget-object v2, Lizq;->a:[I

    .line 59
    const/4 v5, 0x0

    .line 60
    const v6, 0x7f140dfd

    .line 63
    move-object v0, p0

    .line 64
    move-object v1, p1

    .line 65
    move-object v3, p2

    .line 66
    invoke-static/range {v0 .. v6}, Ljmy;->o(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V

    .line 69
    goto :goto_0

    .line 70
    :cond_0
    sget-object v0, Lizq;->a:[I

    .line 72
    invoke-virtual {p1, p2, v0, p3, v7}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 75
    move-result-object v4

    .line 76
    sget-object v2, Lizq;->a:[I

    .line 78
    const/4 v6, 0x0

    .line 79
    move-object v0, p0

    .line 80
    move-object v1, p1

    .line 81
    move-object v3, p2

    .line 82
    move v5, p3

    .line 83
    invoke-static/range {v0 .. v6}, Ljmy;->o(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V

    .line 86
    :goto_0
    invoke-virtual {v4, v7, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 89
    move-result v1

    .line 90
    if-eqz v1, :cond_1

    .line 92
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 95
    move-result-object v2

    .line 96
    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getIntArray(I)[I

    .line 99
    move-result-object v1

    .line 100
    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->q:[I

    .line 102
    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 105
    move-result-object v1

    .line 106
    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    .line 108
    iget-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->q:[I

    .line 110
    array-length v2, v2

    .line 111
    :goto_1
    if-ge v7, v2, :cond_1

    .line 113
    iget-object v3, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->q:[I

    .line 115
    aget v5, v3, v7

    .line 117
    int-to-float v5, v5

    .line 118
    mul-float/2addr v5, v1

    .line 119
    float-to-int v5, v5

    .line 120
    aput v5, v3, v7

    .line 122
    add-int/lit8 v7, v7, 0x1

    .line 124
    goto :goto_1

    .line 125
    :cond_1
    const/4 v1, 0x1

    .line 126
    invoke-virtual {v4, v1}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 129
    move-result-object v2

    .line 130
    iput-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 132
    invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V

    .line 135
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->y()V

    .line 138
    new-instance v2, Lizv;

    .line 140
    invoke-direct {v2, p0}, Lizv;-><init>(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V

    .line 143
    invoke-super {p0, v2}, Landroid/view/ViewGroup;->setOnHierarchyChangeListener(Landroid/view/ViewGroup$OnHierarchyChangeListener;)V

    .line 146
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getImportantForAccessibility()I

    .line 149
    move-result v2

    .line 150
    if-nez v2, :cond_2

    .line 152
    invoke-virtual {p0, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->setImportantForAccessibility(I)V

    .line 155
    :cond_2
    return-void
.end method

.method private final A(Lizt;Landroid/view/View;Landroid/view/MotionEvent;I)Z
    .locals 0

    .line 1
    if-eqz p4, :cond_0

    .line 3
    invoke-virtual {p1, p0, p2, p3}, Lizt;->g(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 6
    move-result p0

    .line 7
    return p0

    .line 8
    :cond_0
    invoke-virtual {p1, p0, p2, p3}, Lizt;->d(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 11
    move-result p0

    .line 12
    return p0
.end method

.method private final B(Landroid/view/MotionEvent;I)Z
    .locals 11

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->k:Ljava/util/List;

    .line 7
    invoke-interface {v1}, Ljava/util/List;->clear()V

    .line 10
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->isChildrenDrawingOrderEnabled()Z

    .line 13
    move-result v2

    .line 14
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 17
    move-result v3

    .line 18
    add-int/lit8 v4, v3, -0x1

    .line 20
    :goto_0
    if-ltz v4, :cond_1

    .line 22
    if-eqz v2, :cond_0

    .line 24
    invoke-virtual {p0, v3, v4}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildDrawingOrder(II)I

    .line 27
    move-result v5

    .line 28
    goto :goto_1

    .line 29
    :cond_0
    move v5, v4

    .line 30
    :goto_1
    invoke-virtual {p0, v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 33
    move-result-object v5

    .line 34
    invoke-interface {v1, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 37
    add-int/lit8 v4, v4, -0x1

    .line 39
    goto :goto_0

    .line 40
    :cond_1
    sget-object v2, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->d:Ljava/util/Comparator;

    .line 42
    if-eqz v2, :cond_2

    .line 44
    invoke-static {v1, v2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 47
    :cond_2
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 50
    move-result v2

    .line 51
    const/4 v3, 0x0

    .line 52
    const/4 v4, 0x0

    .line 53
    move v5, v3

    .line 54
    move v6, v5

    .line 55
    :goto_2
    if-ge v5, v2, :cond_a

    .line 57
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 60
    move-result-object v7

    .line 61
    check-cast v7, Landroid/view/View;

    .line 63
    invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 66
    move-result-object v8

    .line 67
    check-cast v8, Lizw;

    .line 69
    iget-object v9, v8, Lizw;->a:Lizt;

    .line 71
    if-nez v6, :cond_5

    .line 73
    if-eqz v9, :cond_7

    .line 75
    invoke-direct {p0, v9, v7, p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->A(Lizt;Landroid/view/View;Landroid/view/MotionEvent;I)Z

    .line 78
    move-result v6

    .line 79
    if-eqz v6, :cond_7

    .line 81
    iput-object v7, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/view/View;

    .line 83
    const/4 v7, 0x3

    .line 84
    if-eq v0, v7, :cond_7

    .line 86
    const/4 v7, 0x1

    .line 87
    if-eq v0, v7, :cond_7

    .line 89
    move v7, v3

    .line 90
    :goto_3
    if-ge v7, v5, :cond_7

    .line 92
    invoke-interface {v1, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 95
    move-result-object v9

    .line 96
    check-cast v9, Landroid/view/View;

    .line 98
    invoke-virtual {v9}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 101
    move-result-object v10

    .line 102
    check-cast v10, Lizw;

    .line 104
    iget-object v10, v10, Lizw;->a:Lizt;

    .line 106
    if-eqz v10, :cond_4

    .line 108
    if-nez v4, :cond_3

    .line 110
    invoke-static {p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->D(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    .line 113
    move-result-object v4

    .line 114
    :cond_3
    invoke-direct {p0, v10, v9, v4, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->A(Lizt;Landroid/view/View;Landroid/view/MotionEvent;I)Z

    .line 117
    :cond_4
    add-int/lit8 v7, v7, 0x1

    .line 119
    goto :goto_3

    .line 120
    :cond_5
    if-eqz v0, :cond_7

    .line 122
    if-eqz v9, :cond_9

    .line 124
    if-nez v4, :cond_6

    .line 126
    invoke-static {p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->D(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    .line 129
    move-result-object v4

    .line 130
    :cond_6
    invoke-direct {p0, v9, v7, v4, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->A(Lizt;Landroid/view/View;Landroid/view/MotionEvent;I)Z

    .line 133
    goto :goto_4

    .line 134
    :cond_7
    iget-object v7, v8, Lizw;->a:Lizt;

    .line 136
    if-nez v7, :cond_8

    .line 138
    iput-boolean v3, v8, Lizw;->m:Z

    .line 140
    :cond_8
    iget-boolean v7, v8, Lizw;->m:Z

    .line 142
    :cond_9
    :goto_4
    add-int/lit8 v5, v5, 0x1

    .line 144
    goto :goto_2

    .line 145
    :cond_a
    invoke-interface {v1}, Ljava/util/List;->clear()V

    .line 148
    if-eqz v4, :cond_b

    .line 150
    invoke-virtual {v4}, Landroid/view/MotionEvent;->recycle()V

    .line 153
    :cond_b
    return v6
.end method

.method private static final C(ILandroid/graphics/Rect;Landroid/graphics/Rect;Lizw;II)V
    .locals 6

    .line 1
    iget v0, p3, Lizw;->c:I

    .line 3
    if-nez v0, :cond_0

    .line 5
    const/16 v0, 0x11

    .line 7
    :cond_0
    invoke-static {v0, p0}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 10
    move-result v0

    .line 11
    iget p3, p3, Lizw;->d:I

    .line 13
    invoke-static {p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->s(I)I

    .line 16
    move-result p3

    .line 17
    and-int/lit8 v1, v0, 0x7

    .line 19
    and-int/lit8 v0, v0, 0x70

    .line 21
    invoke-static {p3, p0}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 24
    move-result p0

    .line 25
    and-int/lit8 p3, p0, 0x7

    .line 27
    and-int/lit8 p0, p0, 0x70

    .line 29
    const/4 v2, 0x5

    .line 30
    const/4 v3, 0x1

    .line 31
    if-eq p3, v3, :cond_2

    .line 33
    if-eq p3, v2, :cond_1

    .line 35
    iget p3, p1, Landroid/graphics/Rect;->left:I

    .line 37
    goto :goto_0

    .line 38
    :cond_1
    iget p3, p1, Landroid/graphics/Rect;->right:I

    .line 40
    goto :goto_0

    .line 41
    :cond_2
    iget p3, p1, Landroid/graphics/Rect;->left:I

    .line 43
    invoke-virtual {p1}, Landroid/graphics/Rect;->width()I

    .line 46
    move-result v4

    .line 47
    div-int/lit8 v4, v4, 0x2

    .line 49
    add-int/2addr p3, v4

    .line 50
    :goto_0
    const/16 v4, 0x50

    .line 52
    const/16 v5, 0x10

    .line 54
    if-eq p0, v5, :cond_4

    .line 56
    if-eq p0, v4, :cond_3

    .line 58
    iget p0, p1, Landroid/graphics/Rect;->top:I

    .line 60
    goto :goto_1

    .line 61
    :cond_3
    iget p0, p1, Landroid/graphics/Rect;->bottom:I

    .line 63
    goto :goto_1

    .line 64
    :cond_4
    iget p0, p1, Landroid/graphics/Rect;->top:I

    .line 66
    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    .line 69
    move-result p1

    .line 70
    div-int/lit8 p1, p1, 0x2

    .line 72
    add-int/2addr p0, p1

    .line 73
    :goto_1
    if-eq v1, v3, :cond_5

    .line 75
    if-eq v1, v2, :cond_6

    .line 77
    sub-int/2addr p3, p4

    .line 78
    goto :goto_2

    .line 79
    :cond_5
    div-int/lit8 p1, p4, 0x2

    .line 81
    sub-int/2addr p3, p1

    .line 82
    :cond_6
    :goto_2
    if-eq v0, v5, :cond_7

    .line 84
    if-eq v0, v4, :cond_8

    .line 86
    sub-int/2addr p0, p5

    .line 87
    goto :goto_3

    .line 88
    :cond_7
    div-int/lit8 p1, p5, 0x2

    .line 90
    sub-int/2addr p0, p1

    .line 91
    :cond_8
    :goto_3
    add-int/2addr p4, p3

    .line 92
    add-int/2addr p5, p0

    .line 93
    invoke-virtual {p2, p3, p0, p4, p5}, Landroid/graphics/Rect;->set(IIII)V

    .line 96
    return-void
.end method

.method private static final D(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
    .locals 1

    .line 1
    invoke-static {p0}, Landroid/view/MotionEvent;->obtain(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    .line 4
    move-result-object p0

    .line 5
    const/4 v0, 0x3

    .line 6
    invoke-virtual {p0, v0}, Landroid/view/MotionEvent;->setAction(I)V

    .line 9
    return-object p0
.end method

.method private static final E(Landroid/view/View;I)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Lizw;

    .line 7
    iget v1, v0, Lizw;->i:I

    .line 9
    if-eq v1, p1, :cond_0

    .line 11
    sget v2, Ljmy;->a:I

    .line 13
    sub-int v1, p1, v1

    .line 15
    invoke-virtual {p0, v1}, Landroid/view/View;->offsetLeftAndRight(I)V

    .line 18
    iput p1, v0, Lizw;->i:I

    .line 20
    :cond_0
    return-void
.end method

.method private static final F(Landroid/view/View;I)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Lizw;

    .line 7
    iget v1, v0, Lizw;->j:I

    .line 9
    if-eq v1, p1, :cond_0

    .line 11
    sget v2, Ljmy;->a:I

    .line 13
    sub-int v1, p1, v1

    .line 15
    invoke-virtual {p0, v1}, Landroid/view/View;->offsetTopAndBottom(I)V

    .line 18
    iput p1, v0, Lizw;->j:I

    .line 20
    :cond_0
    return-void
.end method

.method static final l(Landroid/view/View;)Lizw;
    .locals 6

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Lizw;

    .line 7
    iget-boolean v1, v0, Lizw;->b:Z

    .line 9
    if-nez v1, :cond_4

    .line 11
    instance-of v1, p0, Lizs;

    .line 13
    const-string v2, "CoordinatorLayout"

    .line 15
    const/4 v3, 0x1

    .line 16
    if-eqz v1, :cond_1

    .line 18
    check-cast p0, Lizs;

    .line 20
    invoke-interface {p0}, Lizs;->getBehavior()Lizt;

    .line 23
    move-result-object p0

    .line 24
    if-nez p0, :cond_0

    .line 26
    const-string v1, "Attached behavior class is null"

    .line 28
    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 31
    :cond_0
    invoke-virtual {v0, p0}, Lizw;->b(Lizt;)V

    .line 34
    iput-boolean v3, v0, Lizw;->b:Z

    .line 36
    return-object v0

    .line 37
    :cond_1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    move-result-object p0

    .line 41
    const/4 v1, 0x0

    .line 42
    move-object v4, v1

    .line 43
    :goto_0
    if-eqz p0, :cond_2

    .line 45
    const-class v4, Lizu;

    .line 47
    invoke-virtual {p0, v4}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    .line 50
    move-result-object v4

    .line 51
    check-cast v4, Lizu;

    .line 53
    if-nez v4, :cond_2

    .line 55
    invoke-virtual {p0}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    .line 58
    move-result-object p0

    .line 59
    goto :goto_0

    .line 60
    :cond_2
    if-eqz v4, :cond_3

    .line 62
    :try_start_0
    invoke-interface {v4}, Lizu;->a()Ljava/lang/Class;

    .line 65
    move-result-object p0

    .line 66
    invoke-virtual {p0, v1}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 69
    move-result-object p0

    .line 70
    invoke-virtual {p0, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 73
    move-result-object p0

    .line 74
    check-cast p0, Lizt;

    .line 76
    invoke-virtual {v0, p0}, Lizw;->b(Lizt;)V

    .line 79
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    .line 80
    :catch_0
    move-exception p0

    .line 81
    new-instance v1, Ljava/lang/StringBuilder;

    .line 83
    const-string v5, "Default behavior class "

    .line 85
    invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 88
    invoke-interface {v4}, Lizu;->a()Ljava/lang/Class;

    .line 91
    move-result-object v4

    .line 92
    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 95
    move-result-object v4

    .line 96
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    const-string v4, " could not be instantiated. Did you forget a default constructor?"

    .line 101
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 104
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 107
    move-result-object v1

    .line 108
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 111
    :cond_3
    :goto_1
    iput-boolean v3, v0, Lizw;->b:Z

    .line 113
    :cond_4
    return-object v0
.end method

.method private final n()I
    .locals 1

    .line 1
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->o()I

    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getHeight()I

    .line 8
    move-result p0

    .line 9
    sub-int/2addr v0, p0

    .line 10
    return v0
.end method

.method private final o()I
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    move v1, v0

    .line 3
    :goto_0
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 6
    move-result v2

    .line 7
    if-ge v0, v2, :cond_0

    .line 9
    invoke-virtual {p0, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 12
    move-result-object v2

    .line 13
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 16
    move-result-object v3

    .line 17
    check-cast v3, Lizw;

    .line 19
    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    .line 22
    move-result v2

    .line 23
    iget v4, v3, Lizw;->topMargin:I

    .line 25
    add-int/2addr v2, v4

    .line 26
    iget v3, v3, Lizw;->bottomMargin:I

    .line 28
    add-int/2addr v2, v3

    .line 29
    add-int/2addr v1, v2

    .line 30
    add-int/lit8 v0, v0, 0x1

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    return v1
.end method

.method private final q(I)I
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->q:[I

    .line 3
    const/4 v1, 0x0

    .line 4
    const-string v2, "CoordinatorLayout"

    .line 6
    if-nez v0, :cond_0

    .line 8
    new-instance v0, Ljava/lang/StringBuilder;

    .line 10
    const-string v3, "No keylines defined for "

    .line 12
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 15
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 18
    const-string p0, " - attempted index lookup "

    .line 20
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 26
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    move-result-object p0

    .line 30
    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 33
    return v1

    .line 34
    :cond_0
    if-ltz p1, :cond_2

    .line 36
    array-length v3, v0

    .line 37
    if-lt p1, v3, :cond_1

    .line 39
    goto :goto_0

    .line 40
    :cond_1
    aget p0, v0, p1

    .line 42
    return p0

    .line 43
    :cond_2
    :goto_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 45
    const-string v3, "Keyline index "

    .line 47
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 50
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 53
    const-string p1, " out of range for "

    .line 55
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 61
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 64
    move-result-object p0

    .line 65
    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 68
    return v1
.end method

.method private final r()I
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getHeight()I

    .line 4
    move-result p0

    .line 5
    int-to-float p0, p0

    .line 6
    const v0, 0x3e4ccccd    # 0.2f

    .line 9
    mul-float/2addr p0, v0

    .line 10
    float-to-int p0, p0

    .line 11
    return p0
.end method

.method private static s(I)I
    .locals 1

    .line 1
    and-int/lit8 v0, p0, 0x7

    .line 3
    if-nez v0, :cond_0

    .line 5
    const v0, 0x800003

    .line 8
    or-int/2addr p0, v0

    .line 9
    :cond_0
    and-int/lit8 v0, p0, 0x70

    .line 11
    if-nez v0, :cond_1

    .line 13
    or-int/lit8 p0, p0, 0x30

    .line 15
    :cond_1
    return p0
.end method

.method private static t(I)I
    .locals 0

    .line 1
    if-nez p0, :cond_0

    .line 3
    const p0, 0x800035

    .line 6
    :cond_0
    return p0
.end method

.method private static u()Landroid/graphics/Rect;
    .locals 1

    .line 1
    sget-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->y:Ljke;

    .line 3
    invoke-virtual {v0}, Ljke;->a()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/graphics/Rect;

    .line 9
    if-nez v0, :cond_0

    .line 11
    new-instance v0, Landroid/graphics/Rect;

    .line 13
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 16
    :cond_0
    return-object v0
.end method

.method private final v(Lizw;Landroid/graphics/Rect;II)V
    .locals 5

    .line 1
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getWidth()I

    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getHeight()I

    .line 8
    move-result v1

    .line 9
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingLeft()I

    .line 12
    move-result v2

    .line 13
    iget v3, p1, Lizw;->leftMargin:I

    .line 15
    add-int/2addr v2, v3

    .line 16
    iget v3, p2, Landroid/graphics/Rect;->left:I

    .line 18
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingRight()I

    .line 21
    move-result v4

    .line 22
    sub-int/2addr v0, v4

    .line 23
    sub-int/2addr v0, p3

    .line 24
    iget v4, p1, Lizw;->rightMargin:I

    .line 26
    sub-int/2addr v0, v4

    .line 27
    invoke-static {v3, v0}, Ljava/lang/Math;->min(II)I

    .line 30
    move-result v0

    .line 31
    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    .line 34
    move-result v0

    .line 35
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingTop()I

    .line 38
    move-result v2

    .line 39
    iget v3, p1, Lizw;->topMargin:I

    .line 41
    add-int/2addr v2, v3

    .line 42
    iget v3, p2, Landroid/graphics/Rect;->top:I

    .line 44
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingBottom()I

    .line 47
    move-result p0

    .line 48
    sub-int/2addr v1, p0

    .line 49
    sub-int/2addr v1, p4

    .line 50
    iget p0, p1, Lizw;->bottomMargin:I

    .line 52
    sub-int/2addr v1, p0

    .line 53
    invoke-static {v3, v1}, Ljava/lang/Math;->min(II)I

    .line 56
    move-result p0

    .line 57
    invoke-static {v2, p0}, Ljava/lang/Math;->max(II)I

    .line 60
    move-result p0

    .line 61
    add-int/2addr p3, v0

    .line 62
    add-int/2addr p4, p0

    .line 63
    invoke-virtual {p2, v0, p0, p3, p4}, Landroid/graphics/Rect;->set(IIII)V

    .line 66
    return-void
.end method

.method private static w(Landroid/graphics/Rect;)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/graphics/Rect;->setEmpty()V

    .line 4
    sget-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->y:Ljke;

    .line 6
    invoke-virtual {v0, p0}, Ljke;->b(Ljava/lang/Object;)Z

    .line 9
    return-void
.end method

.method private final x()V
    .locals 9

    .line 1
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/view/View;

    .line 3
    if-eqz v0, :cond_1

    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Lizw;

    .line 11
    iget-object v0, v0, Lizw;->a:Lizt;

    .line 13
    if-eqz v0, :cond_0

    .line 15
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 18
    move-result-wide v1

    .line 19
    const/4 v7, 0x0

    .line 20
    const/4 v8, 0x0

    .line 21
    const/4 v5, 0x3

    .line 22
    const/4 v6, 0x0

    .line 23
    move-wide v3, v1

    .line 24
    invoke-static/range {v1 .. v8}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    .line 27
    move-result-object v1

    .line 28
    iget-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/view/View;

    .line 30
    invoke-virtual {v0, p0, v2, v1}, Lizt;->g(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 33
    invoke-virtual {v1}, Landroid/view/MotionEvent;->recycle()V

    .line 36
    :cond_0
    const/4 v0, 0x0

    .line 37
    iput-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/view/View;

    .line 39
    :cond_1
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 42
    move-result v0

    .line 43
    const/4 v1, 0x0

    .line 44
    move v2, v1

    .line 45
    :goto_0
    if-ge v2, v0, :cond_2

    .line 47
    invoke-virtual {p0, v2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 50
    move-result-object v3

    .line 51
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 54
    move-result-object v3

    .line 55
    check-cast v3, Lizw;

    .line 57
    iput-boolean v1, v3, Lizw;->m:Z

    .line 59
    add-int/lit8 v2, v2, 0x1

    .line 61
    goto :goto_0

    .line 62
    :cond_2
    iput-boolean v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->o:Z

    .line 64
    return-void
.end method

.method private final y()V
    .locals 1

    .line 1
    sget v0, Ljmy;->a:I

    .line 3
    invoke-virtual {p0}, Landroid/view/View;->getFitsSystemWindows()Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_1

    .line 9
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->w:Ljlp;

    .line 11
    if-nez v0, :cond_0

    .line 13
    new-instance v0, Lizr;

    .line 15
    invoke-direct {v0, p0}, Lizr;-><init>(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V

    .line 18
    iput-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->w:Ljlp;

    .line 20
    :cond_0
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->w:Ljlp;

    .line 22
    invoke-static {p0, v0}, Ljmo;->c(Landroid/view/View;Ljlp;)V

    .line 25
    const/16 v0, 0x500

    .line 27
    invoke-virtual {p0, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->setSystemUiVisibility(I)V

    .line 30
    return-void

    .line 31
    :cond_1
    const/4 v0, 0x0

    .line 32
    invoke-static {p0, v0}, Ljmo;->c(Landroid/view/View;Ljlp;)V

    .line 35
    return-void
.end method

.method private final z(I)Z
    .locals 10

    .line 1
    move-object v0, p0

    .line 2
    :goto_0
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_2

    .line 5
    invoke-virtual {v0}, Landroid/view/View;->isFocused()Z

    .line 8
    move-result v2

    .line 9
    if-nez v2, :cond_1

    .line 11
    instance-of v2, v0, Landroid/view/ViewGroup;

    .line 13
    if-eqz v2, :cond_0

    .line 15
    check-cast v0, Landroid/view/ViewGroup;

    .line 17
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getFocusedChild()Landroid/view/View;

    .line 20
    move-result-object v0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    move-object v0, v1

    .line 23
    goto :goto_0

    .line 24
    :cond_1
    move-object v2, v0

    .line 25
    goto :goto_1

    .line 26
    :cond_2
    move-object v2, v1

    .line 27
    :goto_1
    const/4 v0, 0x2

    .line 28
    const/4 v9, 0x1

    .line 29
    invoke-virtual {p0, p0, v2, v0, v9}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p(Landroid/view/View;Landroid/view/View;II)Z

    .line 32
    iget-object v5, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n:[I

    .line 34
    const/4 v3, 0x0

    .line 35
    const/4 v6, 0x1

    .line 36
    move-object v1, p0

    .line 37
    move v4, p1

    .line 38
    invoke-virtual/range {v1 .. v6}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->d(Landroid/view/View;II[II)V

    .line 41
    aget p0, v5, v9

    .line 43
    const/4 p1, 0x0

    .line 44
    aput p1, v5, p1

    .line 46
    aput p1, v5, v9

    .line 48
    move-object v8, v5

    .line 49
    const/4 v5, 0x0

    .line 50
    const/4 v7, 0x1

    .line 51
    move v6, v4

    .line 52
    move v4, p0

    .line 53
    invoke-virtual/range {v1 .. v8}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f(Landroid/view/View;IIIII[I)V

    .line 56
    move-object v5, v8

    .line 57
    invoke-virtual {v1, v2, v9}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->h(Landroid/view/View;I)V

    .line 60
    aget p0, v5, v9

    .line 62
    if-lez p0, :cond_3

    .line 64
    return v9

    .line 65
    :cond_3
    return p1
.end method


# virtual methods
.method public final a(Landroid/view/View;)Ljava/util/List;
    .locals 4

    .line 1
    iget-object p0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->e:Ljaa;

    .line 3
    iget-object p0, p0, Ljaa;->a:Lajm;

    .line 5
    iget v0, p0, Lajm;->f:I

    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x0

    .line 9
    :goto_0
    if-ge v1, v0, :cond_2

    .line 11
    invoke-virtual {p0, v1}, Lajm;->g(I)Ljava/lang/Object;

    .line 14
    move-result-object v3

    .line 15
    check-cast v3, Ljava/util/ArrayList;

    .line 17
    if-eqz v3, :cond_1

    .line 19
    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 22
    move-result v3

    .line 23
    if-eqz v3, :cond_1

    .line 25
    if-nez v2, :cond_0

    .line 27
    new-instance v2, Ljava/util/ArrayList;

    .line 29
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 32
    :cond_0
    invoke-virtual {p0, v1}, Lajm;->d(I)Ljava/lang/Object;

    .line 35
    move-result-object v3

    .line 36
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 39
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 41
    goto :goto_0

    .line 42
    :cond_2
    if-nez v2, :cond_3

    .line 44
    sget-object p0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 46
    return-object p0

    .line 47
    :cond_3
    return-object v2
.end method

.method public final b(Landroid/view/View;)V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->e:Ljaa;

    .line 3
    invoke-virtual {v0, p1}, Ljaa;->a(Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 6
    move-result-object v0

    .line 7
    if-eqz v0, :cond_1

    .line 9
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 12
    move-result v1

    .line 13
    if-nez v1, :cond_1

    .line 15
    const/4 v1, 0x0

    .line 16
    :goto_0
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 19
    move-result v2

    .line 20
    if-ge v1, v2, :cond_1

    .line 22
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 25
    move-result-object v2

    .line 26
    check-cast v2, Landroid/view/View;

    .line 28
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 31
    move-result-object v3

    .line 32
    check-cast v3, Lizw;

    .line 34
    iget-object v3, v3, Lizw;->a:Lizt;

    .line 36
    if-eqz v3, :cond_0

    .line 38
    invoke-virtual {v3, p0, v2, p1}, Lizt;->i(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)V

    .line 41
    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 43
    goto :goto_0

    .line 44
    :cond_1
    return-void
.end method

.method final c(Landroid/view/View;ZLandroid/graphics/Rect;)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->isLayoutRequested()Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_2

    .line 7
    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    .line 10
    move-result v0

    .line 11
    const/16 v1, 0x8

    .line 13
    if-ne v0, v1, :cond_0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    if-eqz p2, :cond_1

    .line 18
    sget p2, Ljab;->a:I

    .line 20
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    .line 23
    move-result p2

    .line 24
    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    .line 27
    move-result v0

    .line 28
    const/4 v1, 0x0

    .line 29
    invoke-virtual {p3, v1, v1, p2, v0}, Landroid/graphics/Rect;->set(IIII)V

    .line 32
    invoke-static {p0, p1, p3}, Ljab;->a(Landroid/view/ViewGroup;Landroid/view/View;Landroid/graphics/Rect;)V

    .line 35
    return-void

    .line 36
    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    .line 39
    move-result p0

    .line 40
    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    .line 43
    move-result p2

    .line 44
    invoke-virtual {p1}, Landroid/view/View;->getRight()I

    .line 47
    move-result v0

    .line 48
    invoke-virtual {p1}, Landroid/view/View;->getBottom()I

    .line 51
    move-result p1

    .line 52
    invoke-virtual {p3, p0, p2, v0, p1}, Landroid/graphics/Rect;->set(IIII)V

    .line 55
    return-void

    .line 56
    :cond_2
    :goto_0
    invoke-virtual {p3}, Landroid/graphics/Rect;->setEmpty()V

    .line 59
    return-void
.end method

.method protected final checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 1

    .line 1
    instance-of v0, p1, Lizw;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    .line 8
    move-result p0

    .line 9
    if-eqz p0, :cond_0

    .line 11
    const/4 p0, 0x1

    .line 12
    return p0

    .line 13
    :cond_0
    const/4 p0, 0x0

    .line 14
    return p0
.end method

.method public final d(Landroid/view/View;II[II)V
    .locals 13

    .line 1
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 4
    move-result v7

    .line 5
    const/4 v8, 0x0

    .line 6
    move v0, v8

    .line 7
    move v9, v0

    .line 8
    move v10, v9

    .line 9
    move v11, v10

    .line 10
    :goto_0
    const/4 v12, 0x1

    .line 11
    if-ge v9, v7, :cond_3

    .line 13
    invoke-virtual {p0, v9}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 16
    move-result-object v2

    .line 17
    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    .line 20
    move-result v3

    .line 21
    const/16 v4, 0x8

    .line 23
    if-eq v3, v4, :cond_2

    .line 25
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 28
    move-result-object v3

    .line 29
    check-cast v3, Lizw;

    .line 31
    move/from16 v6, p5

    .line 33
    invoke-virtual {v3, v6}, Lizw;->d(I)Z

    .line 36
    move-result v4

    .line 37
    if-eqz v4, :cond_2

    .line 39
    iget-object v3, v3, Lizw;->a:Lizt;

    .line 41
    if-eqz v3, :cond_2

    .line 43
    iget-object v5, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l:[I

    .line 45
    aput v8, v5, v8

    .line 47
    aput v8, v5, v12

    .line 49
    move-object v1, p0

    .line 50
    move/from16 v4, p3

    .line 52
    move-object v0, v3

    .line 53
    move-object v3, p1

    .line 54
    invoke-virtual/range {v0 .. v6}, Lizt;->m(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;I[II)V

    .line 57
    if-lez p2, :cond_0

    .line 59
    aget v0, v5, v8

    .line 61
    invoke-static {v10, v0}, Ljava/lang/Math;->max(II)I

    .line 64
    move-result v0

    .line 65
    goto :goto_1

    .line 66
    :cond_0
    aget v0, v5, v8

    .line 68
    invoke-static {v10, v0}, Ljava/lang/Math;->min(II)I

    .line 71
    move-result v0

    .line 72
    :goto_1
    move v10, v0

    .line 73
    if-lez p3, :cond_1

    .line 75
    aget v0, v5, v12

    .line 77
    invoke-static {v11, v0}, Ljava/lang/Math;->max(II)I

    .line 80
    move-result v0

    .line 81
    goto :goto_2

    .line 82
    :cond_1
    aget v0, v5, v12

    .line 84
    invoke-static {v11, v0}, Ljava/lang/Math;->min(II)I

    .line 87
    move-result v0

    .line 88
    :goto_2
    move v11, v0

    .line 89
    move v0, v12

    .line 90
    :cond_2
    add-int/lit8 v9, v9, 0x1

    .line 92
    goto :goto_0

    .line 93
    :cond_3
    aput v10, p4, v8

    .line 95
    aput v11, p4, v12

    .line 97
    if-eqz v0, :cond_4

    .line 99
    invoke-virtual {p0, v12}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->i(I)V

    .line 102
    :cond_4
    return-void
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 3

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_a

    .line 7
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 10
    move-result v1

    .line 11
    if-nez v1, :cond_a

    .line 13
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 16
    move-result v1

    .line 17
    const/16 v2, 0x13

    .line 19
    if-eq v1, v2, :cond_8

    .line 21
    const/16 v2, 0x14

    .line 23
    if-eq v1, v2, :cond_6

    .line 25
    const/16 v2, 0x3e

    .line 27
    if-eq v1, v2, :cond_4

    .line 29
    const/16 p1, 0x5c

    .line 31
    if-eq v1, p1, :cond_3

    .line 33
    const/16 p1, 0x5d

    .line 35
    if-eq v1, p1, :cond_2

    .line 37
    const/16 p1, 0x7a

    .line 39
    if-eq v1, p1, :cond_1

    .line 41
    const/16 p1, 0x7b

    .line 43
    if-eq v1, p1, :cond_0

    .line 45
    goto :goto_0

    .line 46
    :cond_0
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n()I

    .line 49
    move-result p1

    .line 50
    invoke-direct {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z(I)Z

    .line 53
    move-result p0

    .line 54
    return p0

    .line 55
    :cond_1
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->o()I

    .line 58
    move-result p1

    .line 59
    neg-int p1, p1

    .line 60
    invoke-direct {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z(I)Z

    .line 63
    move-result p0

    .line 64
    return p0

    .line 65
    :cond_2
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getHeight()I

    .line 68
    move-result p1

    .line 69
    invoke-direct {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z(I)Z

    .line 72
    move-result p0

    .line 73
    return p0

    .line 74
    :cond_3
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getHeight()I

    .line 77
    move-result p1

    .line 78
    neg-int p1, p1

    .line 79
    invoke-direct {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z(I)Z

    .line 82
    move-result p0

    .line 83
    return p0

    .line 84
    :cond_4
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isShiftPressed()Z

    .line 87
    move-result p1

    .line 88
    if-eqz p1, :cond_5

    .line 90
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->o()I

    .line 93
    move-result p1

    .line 94
    neg-int p1, p1

    .line 95
    invoke-direct {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z(I)Z

    .line 98
    move-result p0

    .line 99
    return p0

    .line 100
    :cond_5
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n()I

    .line 103
    move-result p1

    .line 104
    invoke-direct {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z(I)Z

    .line 107
    move-result p0

    .line 108
    return p0

    .line 109
    :cond_6
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isAltPressed()Z

    .line 112
    move-result p1

    .line 113
    if-eqz p1, :cond_7

    .line 115
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getHeight()I

    .line 118
    move-result p1

    .line 119
    invoke-direct {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z(I)Z

    .line 122
    move-result p0

    .line 123
    return p0

    .line 124
    :cond_7
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r()I

    .line 127
    move-result p1

    .line 128
    invoke-direct {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z(I)Z

    .line 131
    move-result p0

    .line 132
    return p0

    .line 133
    :cond_8
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isAltPressed()Z

    .line 136
    move-result p1

    .line 137
    if-eqz p1, :cond_9

    .line 139
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getHeight()I

    .line 142
    move-result p1

    .line 143
    neg-int p1, p1

    .line 144
    invoke-direct {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z(I)Z

    .line 147
    move-result p0

    .line 148
    return p0

    .line 149
    :cond_9
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r()I

    .line 152
    move-result p1

    .line 153
    neg-int p1, p1

    .line 154
    invoke-direct {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z(I)Z

    .line 157
    move-result p0

    .line 158
    return p0

    .line 159
    :cond_a
    :goto_0
    return v0
.end method

.method protected final drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z
    .locals 1

    .line 1
    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Lizw;

    .line 7
    iget-object v0, v0, Lizw;->a:Lizt;

    .line 9
    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/ViewGroup;->drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z

    .line 12
    move-result p0

    .line 13
    return p0
.end method

.method protected final drawableStateChanged()V
    .locals 3

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->drawableStateChanged()V

    .line 4
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getDrawableState()[I

    .line 7
    move-result-object v0

    .line 8
    iget-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 10
    if-eqz v1, :cond_0

    .line 12
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    .line 15
    move-result v2

    .line 16
    if-eqz v2, :cond_0

    .line 18
    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_0

    .line 24
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->invalidate()V

    .line 27
    :cond_0
    return-void
.end method

.method public final e(Landroid/view/View;IIIII)V
    .locals 8

    .line 1
    const/4 v6, 0x0

    .line 2
    iget-object v7, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->m:[I

    .line 4
    move-object v0, p0

    .line 5
    move-object v1, p1

    .line 6
    move v2, p2

    .line 7
    move v3, p3

    .line 8
    move v4, p4

    .line 9
    move v5, p5

    .line 10
    invoke-virtual/range {v0 .. v7}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f(Landroid/view/View;IIIII[I)V

    .line 13
    return-void
.end method

.method public final f(Landroid/view/View;IIIII[I)V
    .locals 14

    .line 1
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 4
    move-result p1

    .line 5
    const/4 v0, 0x0

    .line 6
    move v1, v0

    .line 7
    move v2, v1

    .line 8
    move v3, v2

    .line 9
    move v4, v3

    .line 10
    :goto_0
    const/4 v5, 0x1

    .line 11
    if-ge v1, p1, :cond_4

    .line 13
    invoke-virtual {p0, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 16
    move-result-object v8

    .line 17
    invoke-virtual {v8}, Landroid/view/View;->getVisibility()I

    .line 20
    move-result v6

    .line 21
    const/16 v7, 0x8

    .line 23
    if-eq v6, v7, :cond_2

    .line 25
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 28
    move-result-object v6

    .line 29
    check-cast v6, Lizw;

    .line 31
    move/from16 v13, p6

    .line 33
    invoke-virtual {v6, v13}, Lizw;->d(I)Z

    .line 36
    move-result v7

    .line 37
    if-eqz v7, :cond_3

    .line 39
    iget-object v6, v6, Lizw;->a:Lizt;

    .line 41
    if-eqz v6, :cond_3

    .line 43
    iget-object v12, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l:[I

    .line 45
    aput v0, v12, v0

    .line 47
    aput v0, v12, v5

    .line 49
    move-object v7, p0

    .line 50
    move/from16 v9, p3

    .line 52
    move/from16 v10, p4

    .line 54
    move/from16 v11, p5

    .line 56
    invoke-virtual/range {v6 .. v12}, Lizt;->n(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III[I)V

    .line 59
    if-lez p4, :cond_0

    .line 61
    aget v4, v12, v0

    .line 63
    invoke-static {v2, v4}, Ljava/lang/Math;->max(II)I

    .line 66
    move-result v2

    .line 67
    goto :goto_1

    .line 68
    :cond_0
    aget v4, v12, v0

    .line 70
    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    .line 73
    move-result v2

    .line 74
    :goto_1
    if-lez p5, :cond_1

    .line 76
    aget v4, v12, v5

    .line 78
    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    .line 81
    move-result v3

    .line 82
    goto :goto_2

    .line 83
    :cond_1
    aget v4, v12, v5

    .line 85
    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    .line 88
    move-result v3

    .line 89
    :goto_2
    move v4, v5

    .line 90
    goto :goto_3

    .line 91
    :cond_2
    move/from16 v13, p6

    .line 93
    :cond_3
    :goto_3
    add-int/lit8 v1, v1, 0x1

    .line 95
    goto :goto_0

    .line 96
    :cond_4
    aget p1, p7, v0

    .line 98
    add-int/2addr p1, v2

    .line 99
    aput p1, p7, v0

    .line 101
    aget p1, p7, v5

    .line 103
    add-int/2addr p1, v3

    .line 104
    aput p1, p7, v5

    .line 106
    if-eqz v4, :cond_5

    .line 108
    invoke-virtual {p0, v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->i(I)V

    .line 111
    :cond_5
    return-void
.end method

.method public final g(Landroid/view/View;Landroid/view/View;II)V
    .locals 1

    .line 1
    iget-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->x:Ljlo;

    .line 3
    invoke-virtual {p1, p3, p4}, Ljlo;->b(II)V

    .line 6
    iput-object p2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->s:Landroid/view/View;

    .line 8
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 11
    move-result p1

    .line 12
    const/4 p2, 0x0

    .line 13
    :goto_0
    if-ge p2, p1, :cond_1

    .line 15
    invoke-virtual {p0, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 18
    move-result-object p3

    .line 19
    invoke-virtual {p3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 22
    move-result-object p3

    .line 23
    check-cast p3, Lizw;

    .line 25
    invoke-virtual {p3, p4}, Lizw;->d(I)Z

    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_0

    .line 31
    iget-object p3, p3, Lizw;->a:Lizt;

    .line 33
    :cond_0
    add-int/lit8 p2, p2, 0x1

    .line 35
    goto :goto_0

    .line 36
    :cond_1
    return-void
.end method

.method protected final synthetic generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 0

    .line 1
    new-instance p0, Lizw;

    .line 3
    invoke-direct {p0}, Lizw;-><init>()V

    .line 6
    return-object p0
.end method

.method public final bridge synthetic generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    .line 31
    new-instance v0, Lizw;

    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-direct {v0, p0, p1}, Lizw;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method

.method protected final bridge synthetic generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 0

    .line 1
    instance-of p0, p1, Lizw;

    .line 3
    if-eqz p0, :cond_0

    .line 5
    new-instance p0, Lizw;

    .line 7
    check-cast p1, Lizw;

    .line 9
    invoke-direct {p0, p1}, Lizw;-><init>(Lizw;)V

    .line 12
    return-object p0

    .line 13
    :cond_0
    instance-of p0, p1, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 15
    if-eqz p0, :cond_1

    .line 17
    new-instance p0, Lizw;

    .line 19
    check-cast p1, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 21
    invoke-direct {p0, p1}, Lizw;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    .line 24
    return-object p0

    .line 25
    :cond_1
    new-instance p0, Lizw;

    .line 27
    invoke-direct {p0, p1}, Lizw;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    .line 30
    return-object p0
.end method

.method public final getLastWindowInsets()Ljox;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljox;

    .line 3
    return-object p0
.end method

.method public getNestedScrollAxes()I
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->x:Ljlo;

    .line 3
    invoke-virtual {p0}, Ljlo;->a()I

    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public getStatusBarBackground()Landroid/graphics/drawable/Drawable;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 3
    return-object p0
.end method

.method protected getSuggestedMinimumHeight()I
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->getSuggestedMinimumHeight()I

    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingTop()I

    .line 8
    move-result v1

    .line 9
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingBottom()I

    .line 12
    move-result p0

    .line 13
    add-int/2addr v1, p0

    .line 14
    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    .line 17
    move-result p0

    .line 18
    return p0
.end method

.method protected getSuggestedMinimumWidth()I
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->getSuggestedMinimumWidth()I

    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingLeft()I

    .line 8
    move-result v1

    .line 9
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingRight()I

    .line 12
    move-result p0

    .line 13
    add-int/2addr v1, p0

    .line 14
    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    .line 17
    move-result p0

    .line 18
    return p0
.end method

.method public final h(Landroid/view/View;I)V
    .locals 6

    .line 1
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->x:Ljlo;

    .line 3
    invoke-virtual {v0, p2}, Ljlo;->c(I)V

    .line 6
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 9
    move-result v0

    .line 10
    const/4 v1, 0x0

    .line 11
    move v2, v1

    .line 12
    :goto_0
    if-ge v2, v0, :cond_2

    .line 14
    invoke-virtual {p0, v2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 17
    move-result-object v3

    .line 18
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 21
    move-result-object v4

    .line 22
    check-cast v4, Lizw;

    .line 24
    invoke-virtual {v4, p2}, Lizw;->d(I)Z

    .line 27
    move-result v5

    .line 28
    if-nez v5, :cond_0

    .line 30
    goto :goto_1

    .line 31
    :cond_0
    iget-object v5, v4, Lizw;->a:Lizt;

    .line 33
    if-eqz v5, :cond_1

    .line 35
    invoke-virtual {v5, p0, v3, p1, p2}, Lizt;->c(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;I)V

    .line 38
    :cond_1
    invoke-virtual {v4, p2, v1}, Lizw;->c(IZ)V

    .line 41
    invoke-virtual {v4}, Lizw;->a()V

    .line 44
    :goto_1
    add-int/lit8 v2, v2, 0x1

    .line 46
    goto :goto_0

    .line 47
    :cond_2
    const/4 p1, 0x0

    .line 48
    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->s:Landroid/view/View;

    .line 50
    return-void
.end method

.method public final i(I)V
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 3
    move/from16 v1, p1

    .line 5
    iget-object v2, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->j:Ljava/util/List;

    .line 7
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getLayoutDirection()I

    .line 10
    move-result v3

    .line 11
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 14
    move-result v9

    .line 15
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u()Landroid/graphics/Rect;

    .line 18
    move-result-object v10

    .line 19
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u()Landroid/graphics/Rect;

    .line 22
    move-result-object v11

    .line 23
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u()Landroid/graphics/Rect;

    .line 26
    move-result-object v12

    .line 27
    const/4 v14, 0x0

    .line 28
    :goto_0
    if-ge v14, v9, :cond_1e

    .line 30
    invoke-interface {v2, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 33
    move-result-object v4

    .line 34
    move-object v15, v4

    .line 35
    check-cast v15, Landroid/view/View;

    .line 37
    invoke-virtual {v15}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 40
    move-result-object v4

    .line 41
    check-cast v4, Lizw;

    .line 43
    if-nez v1, :cond_0

    .line 45
    invoke-virtual {v15}, Landroid/view/View;->getVisibility()I

    .line 48
    move-result v5

    .line 49
    const/16 v6, 0x8

    .line 51
    if-ne v5, v6, :cond_0

    .line 53
    move-object v4, v2

    .line 54
    move/from16 v21, v14

    .line 56
    const/4 v7, 0x0

    .line 57
    goto/16 :goto_12

    .line 59
    :cond_0
    const/4 v5, 0x0

    .line 60
    :goto_1
    if-ge v5, v14, :cond_7

    .line 62
    invoke-interface {v2, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 65
    move-result-object v7

    .line 66
    check-cast v7, Landroid/view/View;

    .line 68
    iget-object v8, v4, Lizw;->l:Landroid/view/View;

    .line 70
    if-ne v8, v7, :cond_6

    .line 72
    invoke-virtual {v15}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 75
    move-result-object v7

    .line 76
    check-cast v7, Lizw;

    .line 78
    iget-object v8, v7, Lizw;->k:Landroid/view/View;

    .line 80
    if-eqz v8, :cond_6

    .line 82
    move-object v8, v4

    .line 83
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u()Landroid/graphics/Rect;

    .line 86
    move-result-object v4

    .line 87
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u()Landroid/graphics/Rect;

    .line 90
    move-result-object v13

    .line 91
    move/from16 v16, v5

    .line 93
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u()Landroid/graphics/Rect;

    .line 96
    move-result-object v5

    .line 97
    iget-object v6, v7, Lizw;->k:Landroid/view/View;

    .line 99
    sget v18, Ljab;->a:I

    .line 101
    move/from16 v18, v3

    .line 103
    invoke-virtual {v6}, Landroid/view/View;->getWidth()I

    .line 106
    move-result v3

    .line 107
    move-object/from16 v19, v5

    .line 109
    invoke-virtual {v6}, Landroid/view/View;->getHeight()I

    .line 112
    move-result v5

    .line 113
    move-object/from16 v20, v7

    .line 115
    const/4 v7, 0x0

    .line 116
    invoke-virtual {v4, v7, v7, v3, v5}, Landroid/graphics/Rect;->set(IIII)V

    .line 119
    invoke-static {v0, v6, v4}, Ljab;->a(Landroid/view/ViewGroup;Landroid/view/View;Landroid/graphics/Rect;)V

    .line 122
    invoke-virtual {v0, v15, v7, v13}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->c(Landroid/view/View;ZLandroid/graphics/Rect;)V

    .line 125
    invoke-virtual {v15}, Landroid/view/View;->getMeasuredWidth()I

    .line 128
    move-result v7

    .line 129
    move-object v3, v8

    .line 130
    invoke-virtual {v15}, Landroid/view/View;->getMeasuredHeight()I

    .line 133
    move-result v8

    .line 134
    move-object/from16 v22, v3

    .line 136
    move/from16 v21, v14

    .line 138
    move/from16 v3, v18

    .line 140
    move-object/from16 v5, v19

    .line 142
    move-object/from16 v6, v20

    .line 144
    const/4 v14, 0x1

    .line 145
    invoke-static/range {v3 .. v8}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->C(ILandroid/graphics/Rect;Landroid/graphics/Rect;Lizw;II)V

    .line 148
    iget v14, v5, Landroid/graphics/Rect;->left:I

    .line 150
    move-object/from16 v18, v2

    .line 152
    iget v2, v13, Landroid/graphics/Rect;->left:I

    .line 154
    if-ne v14, v2, :cond_2

    .line 156
    iget v2, v5, Landroid/graphics/Rect;->top:I

    .line 158
    iget v14, v13, Landroid/graphics/Rect;->top:I

    .line 160
    if-eq v2, v14, :cond_1

    .line 162
    goto :goto_2

    .line 163
    :cond_1
    const/16 v17, 0x0

    .line 165
    goto :goto_3

    .line 166
    :cond_2
    :goto_2
    const/16 v17, 0x1

    .line 168
    :goto_3
    invoke-direct {v0, v6, v5, v7, v8}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v(Lizw;Landroid/graphics/Rect;II)V

    .line 171
    iget v2, v5, Landroid/graphics/Rect;->left:I

    .line 173
    iget v7, v13, Landroid/graphics/Rect;->left:I

    .line 175
    sub-int/2addr v2, v7

    .line 176
    iget v7, v5, Landroid/graphics/Rect;->top:I

    .line 178
    iget v8, v13, Landroid/graphics/Rect;->top:I

    .line 180
    sub-int/2addr v7, v8

    .line 181
    if-eqz v2, :cond_3

    .line 183
    sget v8, Ljmy;->a:I

    .line 185
    invoke-virtual {v15, v2}, Landroid/view/View;->offsetLeftAndRight(I)V

    .line 188
    :cond_3
    if-eqz v7, :cond_4

    .line 190
    sget v2, Ljmy;->a:I

    .line 192
    invoke-virtual {v15, v7}, Landroid/view/View;->offsetTopAndBottom(I)V

    .line 195
    :cond_4
    if-eqz v17, :cond_5

    .line 197
    iget-object v2, v6, Lizw;->a:Lizt;

    .line 199
    if-eqz v2, :cond_5

    .line 201
    iget-object v6, v6, Lizw;->k:Landroid/view/View;

    .line 203
    invoke-virtual {v2, v0, v15, v6}, Lizt;->i(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)V

    .line 206
    :cond_5
    invoke-virtual {v4}, Landroid/graphics/Rect;->setEmpty()V

    .line 209
    sget-object v2, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->y:Ljke;

    .line 211
    invoke-virtual {v2, v4}, Ljke;->b(Ljava/lang/Object;)Z

    .line 214
    invoke-virtual {v13}, Landroid/graphics/Rect;->setEmpty()V

    .line 217
    invoke-virtual {v2, v13}, Ljke;->b(Ljava/lang/Object;)Z

    .line 220
    invoke-virtual {v5}, Landroid/graphics/Rect;->setEmpty()V

    .line 223
    invoke-virtual {v2, v5}, Ljke;->b(Ljava/lang/Object;)Z

    .line 226
    goto :goto_4

    .line 227
    :cond_6
    move-object/from16 v18, v2

    .line 229
    move-object/from16 v22, v4

    .line 231
    move/from16 v16, v5

    .line 233
    move/from16 v21, v14

    .line 235
    :goto_4
    add-int/lit8 v5, v16, 0x1

    .line 237
    move-object/from16 v2, v18

    .line 239
    move/from16 v14, v21

    .line 241
    move-object/from16 v4, v22

    .line 243
    goto/16 :goto_1

    .line 245
    :cond_7
    move-object/from16 v18, v2

    .line 247
    move-object/from16 v22, v4

    .line 249
    move/from16 v21, v14

    .line 251
    const/4 v14, 0x1

    .line 252
    invoke-virtual {v0, v15, v14, v11}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->c(Landroid/view/View;ZLandroid/graphics/Rect;)V

    .line 255
    move-object/from16 v8, v22

    .line 257
    iget v2, v8, Lizw;->g:I

    .line 259
    const/4 v4, 0x5

    .line 260
    const/4 v5, 0x3

    .line 261
    const/16 v6, 0x50

    .line 263
    const/16 v7, 0x30

    .line 265
    if-eqz v2, :cond_c

    .line 267
    invoke-virtual {v11}, Landroid/graphics/Rect;->isEmpty()Z

    .line 270
    move-result v2

    .line 271
    if-nez v2, :cond_c

    .line 273
    iget v2, v8, Lizw;->g:I

    .line 275
    invoke-static {v2, v3}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 278
    move-result v2

    .line 279
    and-int/lit8 v13, v2, 0x70

    .line 281
    if-eq v13, v7, :cond_9

    .line 283
    if-eq v13, v6, :cond_8

    .line 285
    goto :goto_5

    .line 286
    :cond_8
    iget v13, v10, Landroid/graphics/Rect;->bottom:I

    .line 288
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getHeight()I

    .line 291
    move-result v14

    .line 292
    iget v6, v11, Landroid/graphics/Rect;->top:I

    .line 294
    sub-int/2addr v14, v6

    .line 295
    invoke-static {v13, v14}, Ljava/lang/Math;->max(II)I

    .line 298
    move-result v6

    .line 299
    iput v6, v10, Landroid/graphics/Rect;->bottom:I

    .line 301
    goto :goto_5

    .line 302
    :cond_9
    iget v6, v10, Landroid/graphics/Rect;->top:I

    .line 304
    iget v13, v11, Landroid/graphics/Rect;->bottom:I

    .line 306
    invoke-static {v6, v13}, Ljava/lang/Math;->max(II)I

    .line 309
    move-result v6

    .line 310
    iput v6, v10, Landroid/graphics/Rect;->top:I

    .line 312
    :goto_5
    and-int/lit8 v2, v2, 0x7

    .line 314
    if-eq v2, v5, :cond_b

    .line 316
    if-eq v2, v4, :cond_a

    .line 318
    goto :goto_6

    .line 319
    :cond_a
    iget v2, v10, Landroid/graphics/Rect;->right:I

    .line 321
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getWidth()I

    .line 324
    move-result v6

    .line 325
    iget v13, v11, Landroid/graphics/Rect;->left:I

    .line 327
    sub-int/2addr v6, v13

    .line 328
    invoke-static {v2, v6}, Ljava/lang/Math;->max(II)I

    .line 331
    move-result v2

    .line 332
    iput v2, v10, Landroid/graphics/Rect;->right:I

    .line 334
    goto :goto_6

    .line 335
    :cond_b
    iget v2, v10, Landroid/graphics/Rect;->left:I

    .line 337
    iget v6, v11, Landroid/graphics/Rect;->right:I

    .line 339
    invoke-static {v2, v6}, Ljava/lang/Math;->max(II)I

    .line 342
    move-result v2

    .line 343
    iput v2, v10, Landroid/graphics/Rect;->left:I

    .line 345
    :cond_c
    :goto_6
    iget v2, v8, Lizw;->h:I

    .line 347
    if-eqz v2, :cond_17

    .line 349
    invoke-virtual {v15}, Landroid/view/View;->getVisibility()I

    .line 352
    move-result v2

    .line 353
    if-nez v2, :cond_17

    .line 355
    invoke-virtual {v15}, Landroid/view/View;->isLaidOut()Z

    .line 358
    move-result v2

    .line 359
    if-nez v2, :cond_d

    .line 361
    goto/16 :goto_c

    .line 363
    :cond_d
    invoke-virtual {v15}, Landroid/view/View;->getWidth()I

    .line 366
    move-result v2

    .line 367
    if-lez v2, :cond_17

    .line 369
    invoke-virtual {v15}, Landroid/view/View;->getHeight()I

    .line 372
    move-result v2

    .line 373
    if-lez v2, :cond_17

    .line 375
    invoke-virtual {v15}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 378
    move-result-object v2

    .line 379
    check-cast v2, Lizw;

    .line 381
    iget-object v6, v2, Lizw;->a:Lizt;

    .line 383
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u()Landroid/graphics/Rect;

    .line 386
    move-result-object v8

    .line 387
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u()Landroid/graphics/Rect;

    .line 390
    move-result-object v13

    .line 391
    invoke-virtual {v15}, Landroid/view/View;->getLeft()I

    .line 394
    move-result v14

    .line 395
    invoke-virtual {v15}, Landroid/view/View;->getTop()I

    .line 398
    move-result v4

    .line 399
    invoke-virtual {v15}, Landroid/view/View;->getRight()I

    .line 402
    move-result v5

    .line 403
    invoke-virtual {v15}, Landroid/view/View;->getBottom()I

    .line 406
    move-result v7

    .line 407
    invoke-virtual {v13, v14, v4, v5, v7}, Landroid/graphics/Rect;->set(IIII)V

    .line 410
    if-eqz v6, :cond_f

    .line 412
    invoke-virtual {v6, v15, v8}, Lizt;->r(Landroid/view/View;Landroid/graphics/Rect;)Z

    .line 415
    move-result v4

    .line 416
    if-eqz v4, :cond_f

    .line 418
    invoke-virtual {v13, v8}, Landroid/graphics/Rect;->contains(Landroid/graphics/Rect;)Z

    .line 421
    move-result v4

    .line 422
    if-eqz v4, :cond_e

    .line 424
    goto :goto_7

    .line 425
    :cond_e
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 427
    new-instance v1, Ljava/lang/StringBuilder;

    .line 429
    const-string v2, "Rect should be within the child\'s bounds. Rect:"

    .line 431
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 434
    invoke-virtual {v8}, Landroid/graphics/Rect;->toShortString()Ljava/lang/String;

    .line 437
    move-result-object v2

    .line 438
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 441
    const-string v2, " | Bounds:"

    .line 443
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 446
    invoke-virtual {v13}, Landroid/graphics/Rect;->toShortString()Ljava/lang/String;

    .line 449
    move-result-object v2

    .line 450
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 453
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 456
    move-result-object v1

    .line 457
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 460
    throw v0

    .line 461
    :cond_f
    invoke-virtual {v8, v13}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 464
    :goto_7
    invoke-virtual {v13}, Landroid/graphics/Rect;->setEmpty()V

    .line 467
    sget-object v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->y:Ljke;

    .line 469
    invoke-virtual {v4, v13}, Ljke;->b(Ljava/lang/Object;)Z

    .line 472
    invoke-virtual {v8}, Landroid/graphics/Rect;->isEmpty()Z

    .line 475
    move-result v5

    .line 476
    if-eqz v5, :cond_10

    .line 478
    invoke-virtual {v8}, Landroid/graphics/Rect;->setEmpty()V

    .line 481
    invoke-virtual {v4, v8}, Ljke;->b(Ljava/lang/Object;)Z

    .line 484
    goto/16 :goto_c

    .line 486
    :cond_10
    iget v5, v2, Lizw;->h:I

    .line 488
    invoke-static {v5, v3}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 491
    move-result v5

    .line 492
    and-int/lit8 v6, v5, 0x30

    .line 494
    const/16 v7, 0x30

    .line 496
    if-ne v6, v7, :cond_11

    .line 498
    iget v6, v8, Landroid/graphics/Rect;->top:I

    .line 500
    iget v7, v2, Lizw;->topMargin:I

    .line 502
    sub-int/2addr v6, v7

    .line 503
    iget v7, v2, Lizw;->j:I

    .line 505
    sub-int/2addr v6, v7

    .line 506
    iget v7, v10, Landroid/graphics/Rect;->top:I

    .line 508
    if-ge v6, v7, :cond_11

    .line 510
    iget v7, v10, Landroid/graphics/Rect;->top:I

    .line 512
    sub-int/2addr v7, v6

    .line 513
    invoke-static {v15, v7}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->F(Landroid/view/View;I)V

    .line 516
    const/4 v6, 0x1

    .line 517
    goto :goto_8

    .line 518
    :cond_11
    const/4 v6, 0x0

    .line 519
    :goto_8
    and-int/lit8 v7, v5, 0x50

    .line 521
    const/16 v13, 0x50

    .line 523
    if-ne v7, v13, :cond_12

    .line 525
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getHeight()I

    .line 528
    move-result v7

    .line 529
    iget v13, v8, Landroid/graphics/Rect;->bottom:I

    .line 531
    sub-int/2addr v7, v13

    .line 532
    iget v13, v2, Lizw;->bottomMargin:I

    .line 534
    sub-int/2addr v7, v13

    .line 535
    iget v13, v2, Lizw;->j:I

    .line 537
    add-int/2addr v7, v13

    .line 538
    iget v13, v10, Landroid/graphics/Rect;->bottom:I

    .line 540
    if-ge v7, v13, :cond_12

    .line 542
    iget v6, v10, Landroid/graphics/Rect;->bottom:I

    .line 544
    sub-int/2addr v7, v6

    .line 545
    invoke-static {v15, v7}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->F(Landroid/view/View;I)V

    .line 548
    goto :goto_9

    .line 549
    :cond_12
    if-nez v6, :cond_13

    .line 551
    const/4 v7, 0x0

    .line 552
    invoke-static {v15, v7}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->F(Landroid/view/View;I)V

    .line 555
    :cond_13
    :goto_9
    and-int/lit8 v6, v5, 0x3

    .line 557
    const/4 v7, 0x3

    .line 558
    if-ne v6, v7, :cond_14

    .line 560
    iget v6, v8, Landroid/graphics/Rect;->left:I

    .line 562
    iget v7, v2, Lizw;->leftMargin:I

    .line 564
    sub-int/2addr v6, v7

    .line 565
    iget v7, v2, Lizw;->i:I

    .line 567
    sub-int/2addr v6, v7

    .line 568
    iget v7, v10, Landroid/graphics/Rect;->left:I

    .line 570
    if-ge v6, v7, :cond_14

    .line 572
    iget v7, v10, Landroid/graphics/Rect;->left:I

    .line 574
    sub-int/2addr v7, v6

    .line 575
    invoke-static {v15, v7}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->E(Landroid/view/View;I)V

    .line 578
    const/4 v6, 0x1

    .line 579
    goto :goto_a

    .line 580
    :cond_14
    const/4 v6, 0x0

    .line 581
    :goto_a
    and-int/lit8 v5, v5, 0x5

    .line 583
    const/4 v7, 0x5

    .line 584
    if-ne v5, v7, :cond_15

    .line 586
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getWidth()I

    .line 589
    move-result v5

    .line 590
    iget v7, v8, Landroid/graphics/Rect;->right:I

    .line 592
    sub-int/2addr v5, v7

    .line 593
    iget v7, v2, Lizw;->rightMargin:I

    .line 595
    sub-int/2addr v5, v7

    .line 596
    iget v2, v2, Lizw;->i:I

    .line 598
    add-int/2addr v5, v2

    .line 599
    iget v2, v10, Landroid/graphics/Rect;->right:I

    .line 601
    if-ge v5, v2, :cond_15

    .line 603
    iget v2, v10, Landroid/graphics/Rect;->right:I

    .line 605
    sub-int/2addr v5, v2

    .line 606
    invoke-static {v15, v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->E(Landroid/view/View;I)V

    .line 609
    const/4 v7, 0x0

    .line 610
    goto :goto_b

    .line 611
    :cond_15
    const/4 v7, 0x0

    .line 612
    if-nez v6, :cond_16

    .line 614
    invoke-static {v15, v7}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->E(Landroid/view/View;I)V

    .line 617
    :cond_16
    :goto_b
    invoke-virtual {v8}, Landroid/graphics/Rect;->setEmpty()V

    .line 620
    invoke-virtual {v4, v8}, Ljke;->b(Ljava/lang/Object;)Z

    .line 623
    goto :goto_d

    .line 624
    :cond_17
    :goto_c
    const/4 v7, 0x0

    .line 625
    :goto_d
    add-int/lit8 v14, v21, 0x1

    .line 627
    const/4 v2, 0x2

    .line 628
    if-eq v1, v2, :cond_18

    .line 630
    invoke-virtual {v15}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 633
    move-result-object v4

    .line 634
    check-cast v4, Lizw;

    .line 636
    iget-object v4, v4, Lizw;->p:Landroid/graphics/Rect;

    .line 638
    invoke-virtual {v12, v4}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 641
    invoke-virtual {v12, v11}, Landroid/graphics/Rect;->equals(Ljava/lang/Object;)Z

    .line 644
    move-result v4

    .line 645
    if-nez v4, :cond_1d

    .line 647
    invoke-virtual {v15}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 650
    move-result-object v4

    .line 651
    check-cast v4, Lizw;

    .line 653
    iget-object v4, v4, Lizw;->p:Landroid/graphics/Rect;

    .line 655
    invoke-virtual {v4, v11}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 658
    :cond_18
    :goto_e
    if-ge v14, v9, :cond_1d

    .line 660
    move-object/from16 v4, v18

    .line 662
    invoke-interface {v4, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 665
    move-result-object v5

    .line 666
    check-cast v5, Landroid/view/View;

    .line 668
    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 671
    move-result-object v6

    .line 672
    check-cast v6, Lizw;

    .line 674
    iget-object v8, v6, Lizw;->a:Lizt;

    .line 676
    if-eqz v8, :cond_1b

    .line 678
    invoke-virtual {v8, v15}, Lizt;->h(Landroid/view/View;)Z

    .line 681
    move-result v13

    .line 682
    if-eqz v13, :cond_1b

    .line 684
    if-nez v1, :cond_19

    .line 686
    iget-boolean v13, v6, Lizw;->o:Z

    .line 688
    if-eqz v13, :cond_19

    .line 690
    invoke-virtual {v6}, Lizw;->a()V

    .line 693
    goto :goto_10

    .line 694
    :cond_19
    if-eq v1, v2, :cond_1a

    .line 696
    invoke-virtual {v8, v0, v5, v15}, Lizt;->i(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)V

    .line 699
    move v5, v7

    .line 700
    goto :goto_f

    .line 701
    :cond_1a
    invoke-virtual {v8, v0, v15}, Lizt;->j(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;)V

    .line 704
    const/4 v5, 0x1

    .line 705
    :goto_f
    const/4 v8, 0x1

    .line 706
    if-ne v1, v8, :cond_1c

    .line 708
    iput-boolean v5, v6, Lizw;->o:Z

    .line 710
    goto :goto_11

    .line 711
    :cond_1b
    :goto_10
    const/4 v8, 0x1

    .line 712
    :cond_1c
    :goto_11
    add-int/lit8 v14, v14, 0x1

    .line 714
    move-object/from16 v18, v4

    .line 716
    goto :goto_e

    .line 717
    :cond_1d
    move-object/from16 v4, v18

    .line 719
    :goto_12
    add-int/lit8 v14, v21, 0x1

    .line 721
    move-object v2, v4

    .line 722
    goto/16 :goto_0

    .line 724
    :cond_1e
    invoke-virtual {v10}, Landroid/graphics/Rect;->setEmpty()V

    .line 727
    sget-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->y:Ljke;

    .line 729
    invoke-virtual {v0, v10}, Ljke;->b(Ljava/lang/Object;)Z

    .line 732
    invoke-virtual {v11}, Landroid/graphics/Rect;->setEmpty()V

    .line 735
    invoke-virtual {v0, v11}, Ljke;->b(Ljava/lang/Object;)Z

    .line 738
    invoke-virtual {v12}, Landroid/graphics/Rect;->setEmpty()V

    .line 741
    invoke-virtual {v0, v12}, Ljke;->b(Ljava/lang/Object;)Z

    .line 744
    return-void
.end method

.method public final j(Landroid/view/View;I)V
    .locals 10

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Lizw;

    .line 7
    iget-object v1, v0, Lizw;->k:Landroid/view/View;

    .line 9
    const/4 v2, 0x0

    .line 10
    if-nez v1, :cond_8

    .line 12
    iget v1, v0, Lizw;->f:I

    .line 14
    const/4 v3, -0x1

    .line 15
    if-ne v1, v3, :cond_7

    .line 17
    iget v0, v0, Lizw;->e:I

    .line 19
    if-ltz v0, :cond_5

    .line 21
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 24
    move-result-object v1

    .line 25
    check-cast v1, Lizw;

    .line 27
    iget v3, v1, Lizw;->c:I

    .line 29
    invoke-static {v3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t(I)I

    .line 32
    move-result v3

    .line 33
    invoke-static {v3, p2}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 36
    move-result v3

    .line 37
    and-int/lit8 v4, v3, 0x7

    .line 39
    and-int/lit8 v3, v3, 0x70

    .line 41
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getWidth()I

    .line 44
    move-result v5

    .line 45
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getHeight()I

    .line 48
    move-result v6

    .line 49
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredWidth()I

    .line 52
    move-result v7

    .line 53
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    .line 56
    move-result v8

    .line 57
    const/4 v9, 0x1

    .line 58
    if-ne p2, v9, :cond_0

    .line 60
    sub-int v0, v5, v0

    .line 62
    :cond_0
    invoke-direct {p0, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->q(I)I

    .line 65
    move-result p2

    .line 66
    sub-int/2addr p2, v7

    .line 67
    if-eq v4, v9, :cond_2

    .line 69
    const/4 v0, 0x5

    .line 70
    if-eq v4, v0, :cond_1

    .line 72
    goto :goto_0

    .line 73
    :cond_1
    add-int/2addr p2, v7

    .line 74
    goto :goto_0

    .line 75
    :cond_2
    div-int/lit8 v0, v7, 0x2

    .line 77
    add-int/2addr p2, v0

    .line 78
    :goto_0
    const/16 v0, 0x10

    .line 80
    if-eq v3, v0, :cond_4

    .line 82
    const/16 v0, 0x50

    .line 84
    if-eq v3, v0, :cond_3

    .line 86
    goto :goto_1

    .line 87
    :cond_3
    move v2, v8

    .line 88
    goto :goto_1

    .line 89
    :cond_4
    div-int/lit8 v2, v8, 0x2

    .line 91
    :goto_1
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingLeft()I

    .line 94
    move-result v0

    .line 95
    iget v3, v1, Lizw;->leftMargin:I

    .line 97
    add-int/2addr v0, v3

    .line 98
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingRight()I

    .line 101
    move-result v3

    .line 102
    sub-int/2addr v5, v3

    .line 103
    sub-int/2addr v5, v7

    .line 104
    iget v3, v1, Lizw;->rightMargin:I

    .line 106
    sub-int/2addr v5, v3

    .line 107
    invoke-static {p2, v5}, Ljava/lang/Math;->min(II)I

    .line 110
    move-result p2

    .line 111
    invoke-static {v0, p2}, Ljava/lang/Math;->max(II)I

    .line 114
    move-result p2

    .line 115
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingTop()I

    .line 118
    move-result v0

    .line 119
    iget v3, v1, Lizw;->topMargin:I

    .line 121
    add-int/2addr v0, v3

    .line 122
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingBottom()I

    .line 125
    move-result p0

    .line 126
    sub-int/2addr v6, p0

    .line 127
    sub-int/2addr v6, v8

    .line 128
    iget p0, v1, Lizw;->bottomMargin:I

    .line 130
    sub-int/2addr v6, p0

    .line 131
    invoke-static {v2, v6}, Ljava/lang/Math;->min(II)I

    .line 134
    move-result p0

    .line 135
    invoke-static {v0, p0}, Ljava/lang/Math;->max(II)I

    .line 138
    move-result p0

    .line 139
    add-int/2addr v7, p2

    .line 140
    add-int/2addr v8, p0

    .line 141
    invoke-virtual {p1, p2, p0, v7, v8}, Landroid/view/View;->layout(IIII)V

    .line 144
    return-void

    .line 145
    :cond_5
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 148
    move-result-object v0

    .line 149
    check-cast v0, Lizw;

    .line 151
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u()Landroid/graphics/Rect;

    .line 154
    move-result-object v4

    .line 155
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingLeft()I

    .line 158
    move-result v1

    .line 159
    iget v2, v0, Lizw;->leftMargin:I

    .line 161
    add-int/2addr v1, v2

    .line 162
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingTop()I

    .line 165
    move-result v2

    .line 166
    iget v3, v0, Lizw;->topMargin:I

    .line 168
    add-int/2addr v2, v3

    .line 169
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getWidth()I

    .line 172
    move-result v3

    .line 173
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingRight()I

    .line 176
    move-result v5

    .line 177
    sub-int/2addr v3, v5

    .line 178
    iget v5, v0, Lizw;->rightMargin:I

    .line 180
    sub-int/2addr v3, v5

    .line 181
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getHeight()I

    .line 184
    move-result v5

    .line 185
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingBottom()I

    .line 188
    move-result v6

    .line 189
    sub-int/2addr v5, v6

    .line 190
    iget v6, v0, Lizw;->bottomMargin:I

    .line 192
    sub-int/2addr v5, v6

    .line 193
    invoke-virtual {v4, v1, v2, v3, v5}, Landroid/graphics/Rect;->set(IIII)V

    .line 196
    iget-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljox;

    .line 198
    if-eqz v1, :cond_6

    .line 200
    sget v1, Ljmy;->a:I

    .line 202
    invoke-virtual {p0}, Landroid/view/View;->getFitsSystemWindows()Z

    .line 205
    move-result v1

    .line 206
    if-eqz v1, :cond_6

    .line 208
    invoke-virtual {p1}, Landroid/view/View;->getFitsSystemWindows()Z

    .line 211
    move-result v1

    .line 212
    if-nez v1, :cond_6

    .line 214
    iget v1, v4, Landroid/graphics/Rect;->left:I

    .line 216
    iget-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljox;

    .line 218
    invoke-virtual {v2}, Ljox;->b()I

    .line 221
    move-result v2

    .line 222
    add-int/2addr v1, v2

    .line 223
    iput v1, v4, Landroid/graphics/Rect;->left:I

    .line 225
    iget v1, v4, Landroid/graphics/Rect;->top:I

    .line 227
    iget-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljox;

    .line 229
    invoke-virtual {v2}, Ljox;->d()I

    .line 232
    move-result v2

    .line 233
    add-int/2addr v1, v2

    .line 234
    iput v1, v4, Landroid/graphics/Rect;->top:I

    .line 236
    iget v1, v4, Landroid/graphics/Rect;->right:I

    .line 238
    iget-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljox;

    .line 240
    invoke-virtual {v2}, Ljox;->c()I

    .line 243
    move-result v2

    .line 244
    sub-int/2addr v1, v2

    .line 245
    iput v1, v4, Landroid/graphics/Rect;->right:I

    .line 247
    iget v1, v4, Landroid/graphics/Rect;->bottom:I

    .line 249
    iget-object p0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljox;

    .line 251
    invoke-virtual {p0}, Ljox;->a()I

    .line 254
    move-result p0

    .line 255
    sub-int/2addr v1, p0

    .line 256
    iput v1, v4, Landroid/graphics/Rect;->bottom:I

    .line 258
    :cond_6
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u()Landroid/graphics/Rect;

    .line 261
    move-result-object v5

    .line 262
    iget p0, v0, Lizw;->c:I

    .line 264
    invoke-static {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->s(I)I

    .line 267
    move-result v1

    .line 268
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredWidth()I

    .line 271
    move-result v2

    .line 272
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    .line 275
    move-result v3

    .line 276
    move v6, p2

    .line 277
    invoke-static/range {v1 .. v6}, Landroid/view/Gravity;->apply(IIILandroid/graphics/Rect;Landroid/graphics/Rect;I)V

    .line 280
    iget p0, v5, Landroid/graphics/Rect;->left:I

    .line 282
    iget p2, v5, Landroid/graphics/Rect;->top:I

    .line 284
    iget v0, v5, Landroid/graphics/Rect;->right:I

    .line 286
    iget v1, v5, Landroid/graphics/Rect;->bottom:I

    .line 288
    invoke-virtual {p1, p0, p2, v0, v1}, Landroid/view/View;->layout(IIII)V

    .line 291
    invoke-virtual {v4}, Landroid/graphics/Rect;->setEmpty()V

    .line 294
    sget-object p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->y:Ljke;

    .line 296
    invoke-virtual {p0, v4}, Ljke;->b(Ljava/lang/Object;)Z

    .line 299
    invoke-virtual {v5}, Landroid/graphics/Rect;->setEmpty()V

    .line 302
    invoke-virtual {p0, v5}, Ljke;->b(Ljava/lang/Object;)Z

    .line 305
    return-void

    .line 306
    :cond_7
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 308
    const-string p1, "An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete."

    .line 310
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 313
    throw p0

    .line 314
    :cond_8
    move v0, p2

    .line 315
    move-object p2, v1

    .line 316
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u()Landroid/graphics/Rect;

    .line 319
    move-result-object v1

    .line 320
    move v3, v2

    .line 321
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u()Landroid/graphics/Rect;

    .line 324
    move-result-object v2

    .line 325
    :try_start_0
    sget v4, Ljab;->a:I

    .line 327
    invoke-virtual {p2}, Landroid/view/View;->getWidth()I

    .line 330
    move-result v4

    .line 331
    invoke-virtual {p2}, Landroid/view/View;->getHeight()I

    .line 334
    move-result v5

    .line 335
    invoke-virtual {v1, v3, v3, v4, v5}, Landroid/graphics/Rect;->set(IIII)V

    .line 338
    invoke-static {p0, p2, v1}, Ljab;->a(Landroid/view/ViewGroup;Landroid/view/View;Landroid/graphics/Rect;)V

    .line 341
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 344
    move-result-object p2

    .line 345
    move-object v3, p2

    .line 346
    check-cast v3, Lizw;

    .line 348
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredWidth()I

    .line 351
    move-result v4

    .line 352
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    .line 355
    move-result v5

    .line 356
    invoke-static/range {v0 .. v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->C(ILandroid/graphics/Rect;Landroid/graphics/Rect;Lizw;II)V

    .line 359
    invoke-direct {p0, v3, v2, v4, v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v(Lizw;Landroid/graphics/Rect;II)V

    .line 362
    iget p0, v2, Landroid/graphics/Rect;->left:I

    .line 364
    iget p2, v2, Landroid/graphics/Rect;->top:I

    .line 366
    iget v0, v2, Landroid/graphics/Rect;->right:I

    .line 368
    iget v3, v2, Landroid/graphics/Rect;->bottom:I

    .line 370
    invoke-virtual {p1, p0, p2, v0, v3}, Landroid/view/View;->layout(IIII)V

    .line 373
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v1}, Landroid/graphics/Rect;->setEmpty()V

    .line 376
    sget-object p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->y:Ljke;

    .line 378
    invoke-virtual {p0, v1}, Ljke;->b(Ljava/lang/Object;)Z

    .line 381
    invoke-virtual {v2}, Landroid/graphics/Rect;->setEmpty()V

    .line 384
    invoke-virtual {p0, v2}, Ljke;->b(Ljava/lang/Object;)Z

    .line 387
    return-void

    .line 388
    :catchall_0
    move-exception v0

    .line 389
    move-object p0, v0

    .line 390
    invoke-virtual {v1}, Landroid/graphics/Rect;->setEmpty()V

    .line 393
    sget-object p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->y:Ljke;

    .line 395
    invoke-virtual {p1, v1}, Ljke;->b(Ljava/lang/Object;)Z

    .line 398
    invoke-virtual {v2}, Landroid/graphics/Rect;->setEmpty()V

    .line 401
    invoke-virtual {p1, v2}, Ljke;->b(Ljava/lang/Object;)Z

    .line 404
    throw p0
.end method

.method public final k(Landroid/view/View;II)Z
    .locals 4

    .line 1
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u()Landroid/graphics/Rect;

    .line 4
    move-result-object v0

    .line 5
    sget v1, Ljab;->a:I

    .line 7
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    .line 10
    move-result v1

    .line 11
    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    .line 14
    move-result v2

    .line 15
    const/4 v3, 0x0

    .line 16
    invoke-virtual {v0, v3, v3, v1, v2}, Landroid/graphics/Rect;->set(IIII)V

    .line 19
    invoke-static {p0, p1, v0}, Ljab;->a(Landroid/view/ViewGroup;Landroid/view/View;Landroid/graphics/Rect;)V

    .line 22
    :try_start_0
    invoke-virtual {v0, p2, p3}, Landroid/graphics/Rect;->contains(II)Z

    .line 25
    move-result p0

    .line 26
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-static {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->w(Landroid/graphics/Rect;)V

    .line 29
    return p0

    .line 30
    :catchall_0
    move-exception p0

    .line 31
    invoke-static {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->w(Landroid/graphics/Rect;)V

    .line 34
    throw p0
.end method

.method public final m(Landroid/view/View;III)V
    .locals 6

    .line 1
    const/4 v5, 0x0

    .line 2
    move-object v0, p0

    .line 3
    move-object v1, p1

    .line 4
    move v2, p2

    .line 5
    move v3, p3

    .line 6
    move v4, p4

    .line 7
    invoke-virtual/range {v0 .. v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->measureChildWithMargins(Landroid/view/View;IIII)V

    .line 10
    return-void
.end method

.method public final onAttachedToWindow()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onAttachedToWindow()V

    .line 4
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->x()V

    .line 7
    iget-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u:Z

    .line 9
    if-eqz v0, :cond_1

    .line 11
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t:Lizx;

    .line 13
    if-nez v0, :cond_0

    .line 15
    new-instance v0, Lizx;

    .line 17
    invoke-direct {v0, p0}, Lizx;-><init>(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V

    .line 20
    iput-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t:Lizx;

    .line 22
    :cond_0
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 25
    move-result-object v0

    .line 26
    iget-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t:Lizx;

    .line 28
    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 31
    :cond_1
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljox;

    .line 33
    if-nez v0, :cond_2

    .line 35
    sget v0, Ljmy;->a:I

    .line 37
    invoke-virtual {p0}, Landroid/view/View;->getFitsSystemWindows()Z

    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_2

    .line 43
    invoke-virtual {p0}, Landroid/view/View;->requestApplyInsets()V

    .line 46
    :cond_2
    const/4 v0, 0x1

    .line 47
    iput-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Z

    .line 49
    return-void
.end method

.method public final onDetachedFromWindow()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onDetachedFromWindow()V

    .line 4
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->x()V

    .line 7
    iget-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u:Z

    .line 9
    if-eqz v0, :cond_0

    .line 11
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t:Lizx;

    .line 13
    if-eqz v0, :cond_0

    .line 15
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 18
    move-result-object v0

    .line 19
    iget-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t:Lizx;

    .line 21
    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 24
    :cond_0
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->s:Landroid/view/View;

    .line 26
    const/4 v1, 0x0

    .line 27
    if-eqz v0, :cond_1

    .line 29
    invoke-virtual {p0, v0, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->h(Landroid/view/View;I)V

    .line 32
    :cond_1
    iput-boolean v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Z

    .line 34
    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 4

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onDraw(Landroid/graphics/Canvas;)V

    .line 4
    iget-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->g:Z

    .line 6
    if-eqz v0, :cond_1

    .line 8
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 10
    if-eqz v0, :cond_1

    .line 12
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljox;

    .line 14
    const/4 v1, 0x0

    .line 15
    if-eqz v0, :cond_0

    .line 17
    invoke-virtual {v0}, Ljox;->d()I

    .line 20
    move-result v0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    move v0, v1

    .line 23
    :goto_0
    if-lez v0, :cond_1

    .line 25
    iget-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 27
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getWidth()I

    .line 30
    move-result v3

    .line 31
    invoke-virtual {v2, v1, v1, v3, v0}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 34
    iget-object p0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 36
    invoke-virtual {p0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 39
    :cond_1
    return-void
.end method

.method public onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 2

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez v0, :cond_0

    .line 8
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->x()V

    .line 11
    move v0, v1

    .line 12
    :cond_0
    invoke-direct {p0, p1, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->B(Landroid/view/MotionEvent;I)Z

    .line 15
    move-result p1

    .line 16
    const/4 v1, 0x1

    .line 17
    if-eq v0, v1, :cond_2

    .line 19
    const/4 v1, 0x3

    .line 20
    if-ne v0, v1, :cond_1

    .line 22
    goto :goto_0

    .line 23
    :cond_1
    return p1

    .line 24
    :cond_2
    :goto_0
    const/4 v0, 0x0

    .line 25
    iput-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/view/View;

    .line 27
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->x()V

    .line 30
    return p1
.end method

.method protected final onLayout(ZIIII)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getLayoutDirection()I

    .line 4
    move-result p1

    .line 5
    iget-object p2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->j:Ljava/util/List;

    .line 7
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 10
    move-result p3

    .line 11
    const/4 p4, 0x0

    .line 12
    :goto_0
    if-ge p4, p3, :cond_3

    .line 14
    invoke-interface {p2, p4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 17
    move-result-object p5

    .line 18
    check-cast p5, Landroid/view/View;

    .line 20
    invoke-virtual {p5}, Landroid/view/View;->getVisibility()I

    .line 23
    move-result v0

    .line 24
    const/16 v1, 0x8

    .line 26
    if-ne v0, v1, :cond_0

    .line 28
    goto :goto_1

    .line 29
    :cond_0
    invoke-virtual {p5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 32
    move-result-object v0

    .line 33
    check-cast v0, Lizw;

    .line 35
    iget-object v0, v0, Lizw;->a:Lizt;

    .line 37
    if-eqz v0, :cond_1

    .line 39
    invoke-virtual {v0, p0, p5, p1}, Lizt;->e(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z

    .line 42
    move-result v0

    .line 43
    if-nez v0, :cond_2

    .line 45
    :cond_1
    invoke-virtual {p0, p5, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->j(Landroid/view/View;I)V

    .line 48
    :cond_2
    :goto_1
    add-int/lit8 p4, p4, 0x1

    .line 50
    goto :goto_0

    .line 51
    :cond_3
    return-void
.end method

.method protected final onMeasure(II)V
    .locals 26

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v6, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->j:Ljava/util/List;

    .line 5
    invoke-interface {v6}, Ljava/util/List;->clear()V

    .line 8
    iget-object v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->e:Ljaa;

    .line 10
    iget-object v2, v1, Ljaa;->a:Lajm;

    .line 12
    iget v3, v2, Lajm;->f:I

    .line 14
    const/4 v7, 0x0

    .line 15
    move v4, v7

    .line 16
    :goto_0
    if-ge v4, v3, :cond_1

    .line 18
    invoke-virtual {v2, v4}, Lajm;->g(I)Ljava/lang/Object;

    .line 21
    move-result-object v5

    .line 22
    check-cast v5, Ljava/util/ArrayList;

    .line 24
    if-eqz v5, :cond_0

    .line 26
    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    .line 29
    iget-object v8, v1, Ljaa;->d:Ljke;

    .line 31
    invoke-virtual {v8, v5}, Ljke;->b(Ljava/lang/Object;)Z

    .line 34
    :cond_0
    add-int/lit8 v4, v4, 0x1

    .line 36
    goto :goto_0

    .line 37
    :cond_1
    invoke-virtual {v2}, Lajm;->clear()V

    .line 40
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 43
    move-result v3

    .line 44
    move v4, v7

    .line 45
    :goto_1
    if-ge v4, v3, :cond_1a

    .line 47
    invoke-virtual {v0, v4}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 50
    move-result-object v5

    .line 51
    invoke-static {v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l(Landroid/view/View;)Lizw;

    .line 54
    move-result-object v8

    .line 55
    iget v9, v8, Lizw;->f:I

    .line 57
    const/4 v10, -0x1

    .line 58
    const/4 v11, 0x0

    .line 59
    if-ne v9, v10, :cond_2

    .line 61
    iput-object v11, v8, Lizw;->l:Landroid/view/View;

    .line 63
    iput-object v11, v8, Lizw;->k:Landroid/view/View;

    .line 65
    goto/16 :goto_7

    .line 67
    :cond_2
    iget-object v9, v8, Lizw;->k:Landroid/view/View;

    .line 69
    if-eqz v9, :cond_8

    .line 71
    invoke-virtual {v9}, Landroid/view/View;->getId()I

    .line 74
    move-result v9

    .line 75
    iget v10, v8, Lizw;->f:I

    .line 77
    if-eq v9, v10, :cond_3

    .line 79
    goto :goto_4

    .line 80
    :cond_3
    iget-object v9, v8, Lizw;->k:Landroid/view/View;

    .line 82
    invoke-virtual {v9}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 85
    move-result-object v10

    .line 86
    :goto_2
    if-eq v10, v0, :cond_7

    .line 88
    if-eqz v10, :cond_6

    .line 90
    if-ne v10, v5, :cond_4

    .line 92
    goto :goto_3

    .line 93
    :cond_4
    instance-of v12, v10, Landroid/view/View;

    .line 95
    if-eqz v12, :cond_5

    .line 97
    move-object v9, v10

    .line 98
    check-cast v9, Landroid/view/View;

    .line 100
    :cond_5
    invoke-interface {v10}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 103
    move-result-object v10

    .line 104
    goto :goto_2

    .line 105
    :cond_6
    :goto_3
    iput-object v11, v8, Lizw;->l:Landroid/view/View;

    .line 107
    iput-object v11, v8, Lizw;->k:Landroid/view/View;

    .line 109
    goto :goto_4

    .line 110
    :cond_7
    iput-object v9, v8, Lizw;->l:Landroid/view/View;

    .line 112
    goto :goto_6

    .line 113
    :cond_8
    :goto_4
    iget v9, v8, Lizw;->f:I

    .line 115
    invoke-virtual {v0, v9}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->findViewById(I)Landroid/view/View;

    .line 118
    move-result-object v9

    .line 119
    iput-object v9, v8, Lizw;->k:Landroid/view/View;

    .line 121
    iget-object v9, v8, Lizw;->k:Landroid/view/View;

    .line 123
    if-eqz v9, :cond_f

    .line 125
    if-ne v9, v0, :cond_a

    .line 127
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->isInEditMode()Z

    .line 130
    move-result v9

    .line 131
    if-eqz v9, :cond_9

    .line 133
    iput-object v11, v8, Lizw;->l:Landroid/view/View;

    .line 135
    iput-object v11, v8, Lizw;->k:Landroid/view/View;

    .line 137
    goto :goto_6

    .line 138
    :cond_9
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 140
    const-string v1, "View can not be anchored to the the parent CoordinatorLayout"

    .line 142
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 145
    throw v0

    .line 146
    :cond_a
    invoke-virtual {v9}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 149
    move-result-object v10

    .line 150
    :goto_5
    if-eq v10, v0, :cond_e

    .line 152
    if-eqz v10, :cond_e

    .line 154
    if-ne v10, v5, :cond_c

    .line 156
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->isInEditMode()Z

    .line 159
    move-result v9

    .line 160
    if-eqz v9, :cond_b

    .line 162
    iput-object v11, v8, Lizw;->l:Landroid/view/View;

    .line 164
    iput-object v11, v8, Lizw;->k:Landroid/view/View;

    .line 166
    goto :goto_6

    .line 167
    :cond_b
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 169
    const-string v1, "Anchor must not be a descendant of the anchored view"

    .line 171
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 174
    throw v0

    .line 175
    :cond_c
    instance-of v12, v10, Landroid/view/View;

    .line 177
    if-eqz v12, :cond_d

    .line 179
    move-object v9, v10

    .line 180
    check-cast v9, Landroid/view/View;

    .line 182
    :cond_d
    invoke-interface {v10}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 185
    move-result-object v10

    .line 186
    goto :goto_5

    .line 187
    :cond_e
    iput-object v9, v8, Lizw;->l:Landroid/view/View;

    .line 189
    goto :goto_6

    .line 190
    :cond_f
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->isInEditMode()Z

    .line 193
    move-result v9

    .line 194
    if-eqz v9, :cond_19

    .line 196
    iput-object v11, v8, Lizw;->l:Landroid/view/View;

    .line 198
    iput-object v11, v8, Lizw;->k:Landroid/view/View;

    .line 200
    :goto_6
    iget-object v9, v8, Lizw;->k:Landroid/view/View;

    .line 202
    :goto_7
    invoke-virtual {v1, v5}, Ljaa;->b(Ljava/lang/Object;)V

    .line 205
    move v9, v7

    .line 206
    :goto_8
    if-ge v9, v3, :cond_18

    .line 208
    if-ne v9, v4, :cond_10

    .line 210
    goto :goto_a

    .line 211
    :cond_10
    invoke-virtual {v0, v9}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 214
    move-result-object v10

    .line 215
    iget-object v11, v8, Lizw;->l:Landroid/view/View;

    .line 217
    if-eq v10, v11, :cond_12

    .line 219
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getLayoutDirection()I

    .line 222
    move-result v11

    .line 223
    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 226
    move-result-object v12

    .line 227
    check-cast v12, Lizw;

    .line 229
    iget v12, v12, Lizw;->g:I

    .line 231
    invoke-static {v12, v11}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 234
    move-result v12

    .line 235
    if-eqz v12, :cond_11

    .line 237
    iget v13, v8, Lizw;->h:I

    .line 239
    invoke-static {v13, v11}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 242
    move-result v11

    .line 243
    and-int/2addr v11, v12

    .line 244
    if-ne v11, v12, :cond_11

    .line 246
    goto :goto_9

    .line 247
    :cond_11
    iget-object v11, v8, Lizw;->a:Lizt;

    .line 249
    if-eqz v11, :cond_16

    .line 251
    invoke-virtual {v11, v10}, Lizt;->h(Landroid/view/View;)Z

    .line 254
    move-result v11

    .line 255
    if-eqz v11, :cond_16

    .line 257
    :cond_12
    :goto_9
    invoke-virtual {v2, v10}, Lajm;->containsKey(Ljava/lang/Object;)Z

    .line 260
    move-result v11

    .line 261
    if-nez v11, :cond_13

    .line 263
    invoke-virtual {v1, v10}, Ljaa;->b(Ljava/lang/Object;)V

    .line 266
    :cond_13
    invoke-virtual {v2, v10}, Lajm;->containsKey(Ljava/lang/Object;)Z

    .line 269
    move-result v11

    .line 270
    if-eqz v11, :cond_17

    .line 272
    invoke-virtual {v2, v5}, Lajm;->containsKey(Ljava/lang/Object;)Z

    .line 275
    move-result v11

    .line 276
    if-eqz v11, :cond_17

    .line 278
    invoke-virtual {v2, v10}, Lajm;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 281
    move-result-object v11

    .line 282
    check-cast v11, Ljava/util/ArrayList;

    .line 284
    if-nez v11, :cond_15

    .line 286
    iget-object v11, v1, Ljaa;->d:Ljke;

    .line 288
    invoke-virtual {v11}, Ljke;->a()Ljava/lang/Object;

    .line 291
    move-result-object v11

    .line 292
    check-cast v11, Ljava/util/ArrayList;

    .line 294
    if-nez v11, :cond_14

    .line 296
    new-instance v11, Ljava/util/ArrayList;

    .line 298
    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    .line 301
    :cond_14
    invoke-virtual {v2, v10, v11}, Lajm;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 304
    :cond_15
    invoke-virtual {v11, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 307
    :cond_16
    :goto_a
    add-int/lit8 v9, v9, 0x1

    .line 309
    goto :goto_8

    .line 310
    :cond_17
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 312
    const-string v1, "All nodes must be present in the graph before being added as an edge"

    .line 314
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 317
    throw v0

    .line 318
    :cond_18
    add-int/lit8 v4, v4, 0x1

    .line 320
    goto/16 :goto_1

    .line 322
    :cond_19
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 324
    new-instance v2, Ljava/lang/StringBuilder;

    .line 326
    const-string v3, "Could not find CoordinatorLayout descendant view with id "

    .line 328
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 331
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getResources()Landroid/content/res/Resources;

    .line 334
    move-result-object v0

    .line 335
    iget v3, v8, Lizw;->f:I

    .line 337
    invoke-virtual {v0, v3}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    .line 340
    move-result-object v0

    .line 341
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 344
    const-string v0, " to anchor view "

    .line 346
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 349
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 352
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 355
    move-result-object v0

    .line 356
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 359
    throw v1

    .line 360
    :cond_1a
    iget-object v3, v1, Ljaa;->b:Ljava/util/ArrayList;

    .line 362
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 365
    iget-object v4, v1, Ljaa;->c:Ljava/util/HashSet;

    .line 367
    invoke-virtual {v4}, Ljava/util/HashSet;->clear()V

    .line 370
    iget v5, v2, Lajm;->f:I

    .line 372
    move v8, v7

    .line 373
    :goto_b
    if-ge v8, v5, :cond_1b

    .line 375
    invoke-virtual {v2, v8}, Lajm;->d(I)Ljava/lang/Object;

    .line 378
    move-result-object v9

    .line 379
    invoke-virtual {v1, v9, v3, v4}, Ljaa;->c(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/HashSet;)V

    .line 382
    add-int/lit8 v8, v8, 0x1

    .line 384
    goto :goto_b

    .line 385
    :cond_1b
    invoke-interface {v6, v3}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 388
    invoke-static {v6}, Ljava/util/Collections;->reverse(Ljava/util/List;)V

    .line 391
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 394
    move-result v1

    .line 395
    move v3, v7

    .line 396
    :goto_c
    const/4 v8, 0x1

    .line 397
    if-ge v3, v1, :cond_1e

    .line 399
    invoke-virtual {v0, v3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 402
    move-result-object v4

    .line 403
    iget v5, v2, Lajm;->f:I

    .line 405
    move v9, v7

    .line 406
    :goto_d
    if-ge v9, v5, :cond_1d

    .line 408
    invoke-virtual {v2, v9}, Lajm;->g(I)Ljava/lang/Object;

    .line 411
    move-result-object v10

    .line 412
    check-cast v10, Ljava/util/ArrayList;

    .line 414
    if-eqz v10, :cond_1c

    .line 416
    invoke-virtual {v10, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 419
    move-result v10

    .line 420
    if-eqz v10, :cond_1c

    .line 422
    move v1, v8

    .line 423
    goto :goto_e

    .line 424
    :cond_1c
    add-int/lit8 v9, v9, 0x1

    .line 426
    goto :goto_d

    .line 427
    :cond_1d
    add-int/lit8 v3, v3, 0x1

    .line 429
    goto :goto_c

    .line 430
    :cond_1e
    move v1, v7

    .line 431
    :goto_e
    iget-boolean v2, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u:Z

    .line 433
    if-eq v1, v2, :cond_23

    .line 435
    iget-boolean v2, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Z

    .line 437
    if-eqz v1, :cond_21

    .line 439
    if-eqz v2, :cond_20

    .line 441
    iget-object v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t:Lizx;

    .line 443
    if-nez v1, :cond_1f

    .line 445
    new-instance v1, Lizx;

    .line 447
    invoke-direct {v1, v0}, Lizx;-><init>(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V

    .line 450
    iput-object v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t:Lizx;

    .line 452
    :cond_1f
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 455
    move-result-object v1

    .line 456
    iget-object v2, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t:Lizx;

    .line 458
    invoke-virtual {v1, v2}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 461
    :cond_20
    iput-boolean v8, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u:Z

    .line 463
    goto :goto_f

    .line 464
    :cond_21
    if-eqz v2, :cond_22

    .line 466
    iget-object v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t:Lizx;

    .line 468
    if-eqz v1, :cond_22

    .line 470
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 473
    move-result-object v1

    .line 474
    iget-object v2, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t:Lizx;

    .line 476
    invoke-virtual {v1, v2}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 479
    :cond_22
    iput-boolean v7, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u:Z

    .line 481
    :cond_23
    :goto_f
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingLeft()I

    .line 484
    move-result v9

    .line 485
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingTop()I

    .line 488
    move-result v1

    .line 489
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingRight()I

    .line 492
    move-result v10

    .line 493
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getPaddingBottom()I

    .line 496
    move-result v2

    .line 497
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getLayoutDirection()I

    .line 500
    move-result v11

    .line 501
    if-ne v11, v8, :cond_24

    .line 503
    move v12, v8

    .line 504
    goto :goto_10

    .line 505
    :cond_24
    move v12, v7

    .line 506
    :goto_10
    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 509
    move-result v13

    .line 510
    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 513
    move-result v14

    .line 514
    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 517
    move-result v15

    .line 518
    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 521
    move-result v16

    .line 522
    add-int v17, v9, v10

    .line 524
    add-int v18, v1, v2

    .line 526
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getSuggestedMinimumWidth()I

    .line 529
    move-result v1

    .line 530
    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getSuggestedMinimumHeight()I

    .line 533
    move-result v2

    .line 534
    iget-object v3, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljox;

    .line 536
    if-eqz v3, :cond_25

    .line 538
    sget v3, Ljmy;->a:I

    .line 540
    invoke-virtual {v0}, Landroid/view/View;->getFitsSystemWindows()Z

    .line 543
    move-result v3

    .line 544
    if-eqz v3, :cond_25

    .line 546
    move/from16 v19, v8

    .line 548
    goto :goto_11

    .line 549
    :cond_25
    move/from16 v19, v7

    .line 551
    :goto_11
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 554
    move-result v3

    .line 555
    move v4, v7

    .line 556
    move v5, v4

    .line 557
    :goto_12
    if-ge v4, v3, :cond_32

    .line 559
    invoke-interface {v6, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 562
    move-result-object v20

    .line 563
    check-cast v20, Landroid/view/View;

    .line 565
    invoke-virtual/range {v20 .. v20}, Landroid/view/View;->getVisibility()I

    .line 568
    move-result v8

    .line 569
    const/16 v7, 0x8

    .line 571
    if-eq v8, v7, :cond_31

    .line 573
    invoke-virtual/range {v20 .. v20}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 576
    move-result-object v7

    .line 577
    check-cast v7, Lizw;

    .line 579
    iget v8, v7, Lizw;->e:I

    .line 581
    if-ltz v8, :cond_2c

    .line 583
    if-eqz v13, :cond_2c

    .line 585
    invoke-direct {v0, v8}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->q(I)I

    .line 588
    move-result v8

    .line 589
    move/from16 v22, v1

    .line 591
    iget v1, v7, Lizw;->c:I

    .line 593
    invoke-static {v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t(I)I

    .line 596
    move-result v1

    .line 597
    invoke-static {v1, v11}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 600
    move-result v1

    .line 601
    and-int/lit8 v1, v1, 0x7

    .line 603
    move/from16 v23, v2

    .line 605
    const/4 v2, 0x3

    .line 606
    if-ne v1, v2, :cond_26

    .line 608
    if-eqz v12, :cond_27

    .line 610
    move v1, v2

    .line 611
    const/16 v24, 0x1

    .line 613
    goto :goto_13

    .line 614
    :cond_26
    move/from16 v24, v12

    .line 616
    :goto_13
    const/4 v2, 0x5

    .line 617
    if-ne v1, v2, :cond_29

    .line 619
    if-eqz v24, :cond_28

    .line 621
    :cond_27
    sub-int v1, v14, v10

    .line 623
    sub-int/2addr v1, v8

    .line 624
    const/4 v2, 0x0

    .line 625
    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    .line 628
    move-result v1

    .line 629
    move/from16 v25, v2

    .line 631
    move v2, v1

    .line 632
    move/from16 v1, v25

    .line 634
    goto :goto_14

    .line 635
    :cond_28
    move v1, v2

    .line 636
    const/16 v24, 0x0

    .line 638
    :cond_29
    if-ne v1, v2, :cond_2a

    .line 640
    if-eqz v24, :cond_2b

    .line 642
    :cond_2a
    const/4 v2, 0x3

    .line 643
    if-ne v1, v2, :cond_2d

    .line 645
    if-eqz v24, :cond_2d

    .line 647
    :cond_2b
    sub-int/2addr v8, v9

    .line 648
    const/4 v1, 0x0

    .line 649
    invoke-static {v1, v8}, Ljava/lang/Math;->max(II)I

    .line 652
    move-result v2

    .line 653
    goto :goto_14

    .line 654
    :cond_2c
    move/from16 v22, v1

    .line 656
    move/from16 v23, v2

    .line 658
    :cond_2d
    const/4 v1, 0x0

    .line 659
    move v2, v1

    .line 660
    :goto_14
    if-eqz v19, :cond_2e

    .line 662
    sget v8, Ljmy;->a:I

    .line 664
    invoke-virtual/range {v20 .. v20}, Landroid/view/View;->getFitsSystemWindows()Z

    .line 667
    move-result v8

    .line 668
    if-nez v8, :cond_2e

    .line 670
    iget-object v8, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljox;

    .line 672
    invoke-virtual {v8}, Ljox;->b()I

    .line 675
    move-result v8

    .line 676
    iget-object v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljox;

    .line 678
    invoke-virtual {v1}, Ljox;->c()I

    .line 681
    move-result v1

    .line 682
    add-int/2addr v8, v1

    .line 683
    iget-object v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljox;

    .line 685
    invoke-virtual {v1}, Ljox;->d()I

    .line 688
    move-result v1

    .line 689
    move/from16 v24, v1

    .line 691
    iget-object v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljox;

    .line 693
    invoke-virtual {v1}, Ljox;->a()I

    .line 696
    move-result v1

    .line 697
    add-int v1, v24, v1

    .line 699
    sub-int v8, v14, v8

    .line 701
    invoke-static {v8, v13}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 704
    move-result v8

    .line 705
    sub-int v1, v16, v1

    .line 707
    invoke-static {v1, v15}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 710
    move-result v1

    .line 711
    goto :goto_15

    .line 712
    :cond_2e
    move/from16 v8, p1

    .line 714
    move/from16 v1, p2

    .line 716
    :goto_15
    iget-object v0, v7, Lizw;->a:Lizt;

    .line 718
    move/from16 v21, v22

    .line 720
    move-object/from16 v22, v6

    .line 722
    move/from16 v6, v21

    .line 724
    move/from16 v21, v23

    .line 726
    move/from16 v23, v9

    .line 728
    move/from16 v9, v21

    .line 730
    if-eqz v0, :cond_30

    .line 732
    const/16 v24, 0x0

    .line 734
    move/from16 v21, v4

    .line 736
    move v4, v2

    .line 737
    move-object/from16 v2, v20

    .line 739
    move/from16 v20, v3

    .line 741
    move v3, v8

    .line 742
    move v8, v5

    .line 743
    move v5, v1

    .line 744
    move-object/from16 v1, p0

    .line 746
    invoke-virtual/range {v0 .. v5}, Lizt;->k(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III)Z

    .line 749
    move-result v0

    .line 750
    move-object v1, v2

    .line 751
    move v2, v3

    .line 752
    move v3, v4

    .line 753
    move v4, v5

    .line 754
    if-nez v0, :cond_2f

    .line 756
    goto :goto_16

    .line 757
    :cond_2f
    move-object/from16 v0, p0

    .line 759
    goto :goto_17

    .line 760
    :cond_30
    move/from16 v21, v4

    .line 762
    const/16 v24, 0x0

    .line 764
    move v4, v1

    .line 765
    move-object/from16 v1, v20

    .line 767
    move/from16 v20, v3

    .line 769
    move v3, v2

    .line 770
    move v2, v8

    .line 771
    move v8, v5

    .line 772
    :goto_16
    const/4 v5, 0x0

    .line 773
    move-object/from16 v0, p0

    .line 775
    invoke-virtual/range {v0 .. v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->measureChildWithMargins(Landroid/view/View;IIII)V

    .line 778
    :goto_17
    invoke-virtual {v1}, Landroid/view/View;->getMeasuredWidth()I

    .line 781
    move-result v2

    .line 782
    add-int v2, v17, v2

    .line 784
    iget v3, v7, Lizw;->leftMargin:I

    .line 786
    add-int/2addr v2, v3

    .line 787
    iget v3, v7, Lizw;->rightMargin:I

    .line 789
    add-int/2addr v2, v3

    .line 790
    invoke-static {v6, v2}, Ljava/lang/Math;->max(II)I

    .line 793
    move-result v2

    .line 794
    invoke-virtual {v1}, Landroid/view/View;->getMeasuredHeight()I

    .line 797
    move-result v3

    .line 798
    add-int v3, v18, v3

    .line 800
    iget v4, v7, Lizw;->topMargin:I

    .line 802
    add-int/2addr v3, v4

    .line 803
    iget v4, v7, Lizw;->bottomMargin:I

    .line 805
    add-int/2addr v3, v4

    .line 806
    invoke-static {v9, v3}, Ljava/lang/Math;->max(II)I

    .line 809
    move-result v3

    .line 810
    invoke-virtual {v1}, Landroid/view/View;->getMeasuredState()I

    .line 813
    move-result v1

    .line 814
    invoke-static {v8, v1}, Landroid/view/View;->combineMeasuredStates(II)I

    .line 817
    move-result v5

    .line 818
    move v1, v2

    .line 819
    move v2, v3

    .line 820
    goto :goto_18

    .line 821
    :cond_31
    move/from16 v20, v3

    .line 823
    move/from16 v21, v4

    .line 825
    move v8, v5

    .line 826
    move-object/from16 v22, v6

    .line 828
    move/from16 v23, v9

    .line 830
    const/16 v24, 0x0

    .line 832
    move v6, v1

    .line 833
    move v9, v2

    .line 834
    :goto_18
    add-int/lit8 v4, v21, 0x1

    .line 836
    move/from16 v3, v20

    .line 838
    move-object/from16 v6, v22

    .line 840
    move/from16 v9, v23

    .line 842
    move/from16 v7, v24

    .line 844
    const/4 v8, 0x1

    .line 845
    goto/16 :goto_12

    .line 847
    :cond_32
    move v6, v1

    .line 848
    move v9, v2

    .line 849
    move v8, v5

    .line 850
    const/high16 v1, -0x1000000

    .line 852
    and-int/2addr v1, v8

    .line 853
    move/from16 v2, p1

    .line 855
    invoke-static {v6, v2, v1}, Landroid/view/View;->resolveSizeAndState(III)I

    .line 858
    move-result v1

    .line 859
    shl-int/lit8 v2, v8, 0x10

    .line 861
    move/from16 v3, p2

    .line 863
    invoke-static {v9, v3, v2}, Landroid/view/View;->resolveSizeAndState(III)I

    .line 866
    move-result v2

    .line 867
    invoke-virtual {v0, v1, v2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->setMeasuredDimension(II)V

    .line 870
    return-void
.end method

.method public final onNestedFling(Landroid/view/View;FFZ)Z
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 4
    move-result p1

    .line 5
    const/4 p2, 0x0

    .line 6
    move p3, p2

    .line 7
    :goto_0
    if-ge p3, p1, :cond_2

    .line 9
    invoke-virtual {p0, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 12
    move-result-object p4

    .line 13
    invoke-virtual {p4}, Landroid/view/View;->getVisibility()I

    .line 16
    move-result v0

    .line 17
    const/16 v1, 0x8

    .line 19
    if-ne v0, v1, :cond_0

    .line 21
    goto :goto_1

    .line 22
    :cond_0
    invoke-virtual {p4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 25
    move-result-object p4

    .line 26
    check-cast p4, Lizw;

    .line 28
    iget-boolean v0, p4, Lizw;->n:Z

    .line 30
    if-eqz v0, :cond_1

    .line 32
    iget-object p4, p4, Lizw;->a:Lizt;

    .line 34
    :cond_1
    :goto_1
    add-int/lit8 p3, p3, 0x1

    .line 36
    goto :goto_0

    .line 37
    :cond_2
    return p2
.end method

.method public final onNestedPreFling(Landroid/view/View;FF)Z
    .locals 4

    .line 1
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 4
    move-result p2

    .line 5
    const/4 p3, 0x0

    .line 6
    move v0, p3

    .line 7
    :goto_0
    if-ge p3, p2, :cond_1

    .line 9
    invoke-virtual {p0, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 12
    move-result-object v1

    .line 13
    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    .line 16
    move-result v2

    .line 17
    const/16 v3, 0x8

    .line 19
    if-eq v2, v3, :cond_0

    .line 21
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 24
    move-result-object v1

    .line 25
    check-cast v1, Lizw;

    .line 27
    iget-boolean v2, v1, Lizw;->n:Z

    .line 29
    if-eqz v2, :cond_0

    .line 31
    iget-object v1, v1, Lizw;->a:Lizt;

    .line 33
    if-eqz v1, :cond_0

    .line 35
    invoke-virtual {v1, p1}, Lizt;->l(Landroid/view/View;)Z

    .line 38
    move-result v1

    .line 39
    or-int/2addr v0, v1

    .line 40
    :cond_0
    add-int/lit8 p3, p3, 0x1

    .line 42
    goto :goto_0

    .line 43
    :cond_1
    return v0
.end method

.method public final onNestedPreScroll(Landroid/view/View;II[I)V
    .locals 6

    .line 1
    const/4 v5, 0x0

    .line 2
    move-object v0, p0

    .line 3
    move-object v1, p1

    .line 4
    move v2, p2

    .line 5
    move v3, p3

    .line 6
    move-object v4, p4

    .line 7
    invoke-virtual/range {v0 .. v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->d(Landroid/view/View;II[II)V

    .line 10
    return-void
.end method

.method public final onNestedScroll(Landroid/view/View;IIII)V
    .locals 7

    .line 1
    const/4 v6, 0x0

    .line 2
    move-object v0, p0

    .line 3
    move-object v1, p1

    .line 4
    move v2, p2

    .line 5
    move v3, p3

    .line 6
    move v4, p4

    .line 7
    move v5, p5

    .line 8
    invoke-virtual/range {v0 .. v6}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->e(Landroid/view/View;IIIII)V

    .line 11
    return-void
.end method

.method public final onNestedScrollAccepted(Landroid/view/View;Landroid/view/View;I)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->g(Landroid/view/View;Landroid/view/View;II)V

    .line 5
    return-void
.end method

.method protected final onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 6

    .line 1
    instance-of v0, p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$SavedState;

    .line 3
    if-nez v0, :cond_0

    .line 5
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 8
    return-void

    .line 9
    :cond_0
    check-cast p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$SavedState;

    .line 11
    iget-object v0, p1, Landroidx/customview/view/AbsSavedState;->d:Landroid/os/Parcelable;

    .line 13
    invoke-super {p0, v0}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 16
    iget-object p1, p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$SavedState;->a:Landroid/util/SparseArray;

    .line 18
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 21
    move-result v0

    .line 22
    const/4 v1, 0x0

    .line 23
    :goto_0
    if-ge v1, v0, :cond_2

    .line 25
    invoke-virtual {p0, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 28
    move-result-object v2

    .line 29
    invoke-virtual {v2}, Landroid/view/View;->getId()I

    .line 32
    move-result v3

    .line 33
    invoke-static {v2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l(Landroid/view/View;)Lizw;

    .line 36
    move-result-object v4

    .line 37
    iget-object v4, v4, Lizw;->a:Lizt;

    .line 39
    const/4 v5, -0x1

    .line 40
    if-eq v3, v5, :cond_1

    .line 42
    if-eqz v4, :cond_1

    .line 44
    invoke-virtual {p1, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 47
    move-result-object v3

    .line 48
    check-cast v3, Landroid/os/Parcelable;

    .line 50
    if-eqz v3, :cond_1

    .line 52
    invoke-virtual {v4, v2, v3}, Lizt;->o(Landroid/view/View;Landroid/os/Parcelable;)V

    .line 55
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 57
    goto :goto_0

    .line 58
    :cond_2
    return-void
.end method

.method protected final onSaveInstanceState()Landroid/os/Parcelable;
    .locals 8

    .line 1
    new-instance v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$SavedState;

    .line 3
    invoke-super {p0}, Landroid/view/ViewGroup;->onSaveInstanceState()Landroid/os/Parcelable;

    .line 6
    move-result-object v1

    .line 7
    invoke-direct {v0, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$SavedState;-><init>(Landroid/os/Parcelable;)V

    .line 10
    new-instance v1, Landroid/util/SparseArray;

    .line 12
    invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V

    .line 15
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 18
    move-result v2

    .line 19
    const/4 v3, 0x0

    .line 20
    :goto_0
    if-ge v3, v2, :cond_1

    .line 22
    invoke-virtual {p0, v3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 25
    move-result-object v4

    .line 26
    invoke-virtual {v4}, Landroid/view/View;->getId()I

    .line 29
    move-result v5

    .line 30
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 33
    move-result-object v6

    .line 34
    check-cast v6, Lizw;

    .line 36
    iget-object v6, v6, Lizw;->a:Lizt;

    .line 38
    const/4 v7, -0x1

    .line 39
    if-eq v5, v7, :cond_0

    .line 41
    if-eqz v6, :cond_0

    .line 43
    invoke-virtual {v6, v4}, Lizt;->p(Landroid/view/View;)Landroid/os/Parcelable;

    .line 46
    move-result-object v4

    .line 47
    if-eqz v4, :cond_0

    .line 49
    invoke-virtual {v1, v5, v4}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    .line 52
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 54
    goto :goto_0

    .line 55
    :cond_1
    iput-object v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$SavedState;->a:Landroid/util/SparseArray;

    .line 57
    return-object v0
.end method

.method public final onStartNestedScroll(Landroid/view/View;Landroid/view/View;I)Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p(Landroid/view/View;Landroid/view/View;II)Z

    .line 5
    move-result p0

    .line 6
    return p0
.end method

.method public final onStopNestedScroll(Landroid/view/View;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, p1, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->h(Landroid/view/View;I)V

    .line 5
    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 6

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/view/View;

    .line 7
    const/4 v2, 0x1

    .line 8
    const/4 v3, 0x0

    .line 9
    if-eqz v1, :cond_1

    .line 11
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Lizw;

    .line 17
    iget-object v1, v1, Lizw;->a:Lizt;

    .line 19
    if-eqz v1, :cond_0

    .line 21
    iget-object v4, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/view/View;

    .line 23
    invoke-virtual {v1, p0, v4, p1}, Lizt;->g(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 26
    move-result v1

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    move v1, v3

    .line 29
    goto :goto_0

    .line 30
    :cond_1
    invoke-direct {p0, p1, v2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->B(Landroid/view/MotionEvent;I)Z

    .line 33
    move-result v1

    .line 34
    if-eqz v0, :cond_2

    .line 36
    if-eqz v1, :cond_2

    .line 38
    move v3, v2

    .line 39
    :cond_2
    :goto_0
    iget-object v4, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/view/View;

    .line 41
    const/4 v5, 0x3

    .line 42
    if-eqz v4, :cond_4

    .line 44
    if-ne v0, v5, :cond_3

    .line 46
    goto :goto_1

    .line 47
    :cond_3
    if-eqz v3, :cond_5

    .line 49
    invoke-static {p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->D(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    .line 52
    move-result-object p1

    .line 53
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 56
    invoke-virtual {p1}, Landroid/view/MotionEvent;->recycle()V

    .line 59
    goto :goto_2

    .line 60
    :cond_4
    :goto_1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 63
    move-result p1

    .line 64
    or-int/2addr v1, p1

    .line 65
    :cond_5
    :goto_2
    if-eq v0, v2, :cond_7

    .line 67
    if-ne v0, v5, :cond_6

    .line 69
    goto :goto_3

    .line 70
    :cond_6
    return v1

    .line 71
    :cond_7
    :goto_3
    const/4 p1, 0x0

    .line 72
    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/view/View;

    .line 74
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->x()V

    .line 77
    return v1
.end method

.method public final p(Landroid/view/View;Landroid/view/View;II)Z
    .locals 10

    .line 1
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 4
    move-result p2

    .line 5
    const/4 v0, 0x0

    .line 6
    move v1, v0

    .line 7
    move v2, v1

    .line 8
    :goto_0
    if-ge v1, p2, :cond_2

    .line 10
    invoke-virtual {p0, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 13
    move-result-object v5

    .line 14
    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    .line 17
    move-result v3

    .line 18
    const/16 v4, 0x8

    .line 20
    if-eq v3, v4, :cond_1

    .line 22
    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 25
    move-result-object v3

    .line 26
    move-object v9, v3

    .line 27
    check-cast v9, Lizw;

    .line 29
    iget-object v3, v9, Lizw;->a:Lizt;

    .line 31
    if-eqz v3, :cond_0

    .line 33
    move-object v4, p0

    .line 34
    move-object v6, p1

    .line 35
    move v7, p3

    .line 36
    move v8, p4

    .line 37
    invoke-virtual/range {v3 .. v8}, Lizt;->q(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;II)Z

    .line 40
    move-result p0

    .line 41
    or-int/2addr v2, p0

    .line 42
    invoke-virtual {v9, v8, p0}, Lizw;->c(IZ)V

    .line 45
    goto :goto_1

    .line 46
    :cond_0
    move-object v4, p0

    .line 47
    move-object v6, p1

    .line 48
    move v7, p3

    .line 49
    move v8, p4

    .line 50
    invoke-virtual {v9, v8, v0}, Lizw;->c(IZ)V

    .line 53
    goto :goto_1

    .line 54
    :cond_1
    move-object v4, p0

    .line 55
    move-object v6, p1

    .line 56
    move v7, p3

    .line 57
    move v8, p4

    .line 58
    :goto_1
    add-int/lit8 v1, v1, 0x1

    .line 60
    move-object p0, v4

    .line 61
    move-object p1, v6

    .line 62
    move p3, v7

    .line 63
    move p4, v8

    .line 64
    goto :goto_0

    .line 65
    :cond_2
    return v2
.end method

.method public final requestChildRectangleOnScreen(Landroid/view/View;Landroid/graphics/Rect;Z)Z
    .locals 1

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Lizw;

    .line 7
    iget-object v0, v0, Lizw;->a:Lizt;

    .line 9
    if-eqz v0, :cond_0

    .line 11
    invoke-virtual {v0, p0, p1, p2, p3}, Lizt;->f(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/graphics/Rect;Z)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 17
    const/4 p0, 0x1

    .line 18
    return p0

    .line 19
    :cond_0
    invoke-super {p0, p1, p2, p3}, Landroid/view/ViewGroup;->requestChildRectangleOnScreen(Landroid/view/View;Landroid/graphics/Rect;Z)Z

    .line 22
    move-result p0

    .line 23
    return p0
.end method

.method public final requestDisallowInterceptTouchEvent(Z)V
    .locals 12

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->requestDisallowInterceptTouchEvent(Z)V

    .line 4
    if-eqz p1, :cond_4

    .line 6
    iget-boolean p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->o:Z

    .line 8
    if-nez p1, :cond_4

    .line 10
    iget-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/view/View;

    .line 12
    if-nez p1, :cond_3

    .line 14
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildCount()I

    .line 17
    move-result p1

    .line 18
    const/4 v0, 0x0

    .line 19
    const/4 v1, 0x0

    .line 20
    :goto_0
    if-ge v0, p1, :cond_2

    .line 22
    invoke-virtual {p0, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getChildAt(I)Landroid/view/View;

    .line 25
    move-result-object v2

    .line 26
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 29
    move-result-object v3

    .line 30
    check-cast v3, Lizw;

    .line 32
    iget-object v3, v3, Lizw;->a:Lizt;

    .line 34
    if-eqz v3, :cond_1

    .line 36
    if-nez v1, :cond_0

    .line 38
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 41
    move-result-wide v4

    .line 42
    const/4 v10, 0x0

    .line 43
    const/4 v11, 0x0

    .line 44
    const/4 v8, 0x3

    .line 45
    const/4 v9, 0x0

    .line 46
    move-wide v6, v4

    .line 47
    invoke-static/range {v4 .. v11}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    .line 50
    move-result-object v1

    .line 51
    :cond_0
    invoke-virtual {v3, p0, v2, v1}, Lizt;->d(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 54
    :cond_1
    add-int/lit8 v0, v0, 0x1

    .line 56
    goto :goto_0

    .line 57
    :cond_2
    if-eqz v1, :cond_3

    .line 59
    invoke-virtual {v1}, Landroid/view/MotionEvent;->recycle()V

    .line 62
    :cond_3
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->x()V

    .line 65
    const/4 p1, 0x1

    .line 66
    iput-boolean p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->o:Z

    .line 68
    :cond_4
    return-void
.end method

.method public setFitsSystemWindows(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->setFitsSystemWindows(Z)V

    .line 4
    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->y()V

    .line 7
    return-void
.end method

.method public setOnHierarchyChangeListener(Landroid/view/ViewGroup$OnHierarchyChangeListener;)V
    .locals 0

    .line 1
    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->h:Landroid/view/ViewGroup$OnHierarchyChangeListener;

    .line 3
    return-void
.end method

.method public setStatusBarBackground(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eq v0, p1, :cond_5

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 11
    :cond_0
    if-eqz p1, :cond_1

    .line 13
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 16
    move-result-object v1

    .line 17
    :cond_1
    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 19
    if-eqz v1, :cond_4

    .line 21
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    .line 24
    move-result p1

    .line 25
    if-eqz p1, :cond_2

    .line 27
    iget-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 29
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getDrawableState()[I

    .line 32
    move-result-object v0

    .line 33
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 36
    :cond_2
    iget-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 38
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getLayoutDirection()I

    .line 41
    move-result v0

    .line 42
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setLayoutDirection(I)Z

    .line 45
    iget-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 47
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getVisibility()I

    .line 50
    move-result v0

    .line 51
    const/4 v1, 0x0

    .line 52
    if-nez v0, :cond_3

    .line 54
    const/4 v0, 0x1

    .line 55
    goto :goto_0

    .line 56
    :cond_3
    move v0, v1

    .line 57
    :goto_0
    invoke-virtual {p1, v0, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    .line 60
    iget-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 62
    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 65
    :cond_4
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->postInvalidateOnAnimation()V

    .line 68
    :cond_5
    return-void
.end method

.method public setStatusBarBackgroundColor(I)V
    .locals 1

    .line 1
    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    .line 3
    invoke-direct {v0, p1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    .line 6
    invoke-virtual {p0, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->setStatusBarBackground(Landroid/graphics/drawable/Drawable;)V

    .line 9
    return-void
.end method

.method public setStatusBarBackgroundResource(I)V
    .locals 1

    .line 1
    if-eqz p1, :cond_0

    .line 3
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getContext()Landroid/content/Context;

    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0, p1}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 10
    move-result-object p1

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 p1, 0x0

    .line 13
    :goto_0
    invoke-virtual {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->setStatusBarBackground(Landroid/graphics/drawable/Drawable;)V

    .line 16
    return-void
.end method

.method public setVisibility(I)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 4
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 6
    if-eqz v0, :cond_1

    .line 8
    const/4 v1, 0x0

    .line 9
    if-nez p1, :cond_0

    .line 11
    const/4 p1, 0x1

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    move p1, v1

    .line 14
    :goto_0
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    .line 17
    move-result v0

    .line 18
    if-eq v0, p1, :cond_1

    .line 20
    iget-object p0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 22
    invoke-virtual {p0, p1, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    .line 25
    :cond_1
    return-void
.end method

.method protected final verifyDrawable(Landroid/graphics/drawable/Drawable;)Z
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->verifyDrawable(Landroid/graphics/drawable/Drawable;)Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_1

    .line 7
    iget-object p0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Landroid/graphics/drawable/Drawable;

    .line 9
    if-ne p1, p0, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 p0, 0x0

    .line 13
    return p0

    .line 14
    :cond_1
    :goto_0
    const/4 p0, 0x1

    .line 15
    return p0
.end method
