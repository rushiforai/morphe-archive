.class public final Landroidx/compose/ui/platform/ComposeView;
.super Lhjx;
.source "PG"


# instance fields
.field private final a:Lfoc;

.field private b:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 6

    .line 16
    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v0, p0

    move-object v1, p1

    invoke-direct/range {v0 .. v5}, Landroidx/compose/ui/platform/ComposeView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;IILbhxk;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 6

    .line 15
    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v3, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    invoke-direct/range {v0 .. v5}, Landroidx/compose/ui/platform/ComposeView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;IILbhxk;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2, p3}, Lhjx;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 4
    sget-object p1, Lfru;->a:Lfru;

    .line 6
    new-instance p2, Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 8
    const/4 p3, 0x0

    .line 9
    invoke-direct {p2, p3, p1}, Lfrd;-><init>(Ljava/lang/Object;Lfre;)V

    .line 12
    iput-object p2, p0, Landroidx/compose/ui/platform/ComposeView;->a:Lfoc;

    .line 14
    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;IILbhxk;)V
    .locals 0

    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_0

    const/4 p2, 0x0

    :cond_0
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_1

    const/4 p3, 0x0

    .line 17
    :cond_1
    invoke-direct {p0, p1, p2, p3}, Landroidx/compose/ui/platform/ComposeView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method protected static synthetic getShouldCreateCompositionOnAttachedToWindow$annotations()V
    .locals 0

    .line 1
    return-void
.end method


# virtual methods
.method public final b(Lfld;I)V
    .locals 5

    .line 1
    and-int/lit8 v0, p2, 0x6

    .line 3
    const v1, 0x190bf45a

    .line 6
    invoke-interface {p1, v1}, Lfld;->c(I)Lfld;

    .line 9
    move-result-object p1

    .line 10
    const/4 v1, 0x2

    .line 11
    const/4 v2, 0x1

    .line 12
    if-nez v0, :cond_1

    .line 14
    invoke-interface {p1, p0}, Lfld;->E(Ljava/lang/Object;)Z

    .line 17
    move-result v0

    .line 18
    if-eq v2, v0, :cond_0

    .line 20
    move v0, v1

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v0, 0x4

    .line 23
    :goto_0
    or-int/2addr v0, p2

    .line 24
    goto :goto_1

    .line 25
    :cond_1
    move v0, p2

    .line 26
    :goto_1
    and-int/lit8 v3, v0, 0x3

    .line 28
    const/4 v4, 0x0

    .line 29
    if-eq v3, v1, :cond_2

    .line 31
    move v1, v2

    .line 32
    goto :goto_2

    .line 33
    :cond_2
    move v1, v4

    .line 34
    :goto_2
    and-int/2addr v0, v2

    .line 35
    invoke-interface {p1, v1, v0}, Lfld;->I(ZI)Z

    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_4

    .line 41
    iget-object v0, p0, Landroidx/compose/ui/platform/ComposeView;->a:Lfoc;

    .line 43
    invoke-interface {v0}, Lfoc;->dY()Ljava/lang/Object;

    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Lbhwu;

    .line 49
    if-nez v0, :cond_3

    .line 51
    const v0, -0x49d6f281

    .line 54
    invoke-interface {p1, v0}, Lfld;->v(I)V

    .line 57
    goto :goto_3

    .line 58
    :cond_3
    const v1, 0x5e04ac2

    .line 61
    invoke-interface {p1, v1}, Lfld;->v(I)V

    .line 64
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 67
    move-result-object v1

    .line 68
    invoke-interface {v0, p1, v1}, Lbhwu;->a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    :goto_3
    move-object v0, p1

    .line 72
    check-cast v0, Lfmu;

    .line 74
    invoke-virtual {v0, v4}, Lfmu;->X(Z)V

    .line 77
    goto :goto_4

    .line 78
    :cond_4
    invoke-interface {p1}, Lfld;->s()V

    .line 81
    :goto_4
    invoke-interface {p1}, Lfld;->L()Lfpf;

    .line 84
    move-result-object p1

    .line 85
    if-eqz p1, :cond_5

    .line 87
    new-instance v0, Lhow;

    .line 89
    invoke-direct {v0, p0, p2}, Lhow;-><init>(Landroidx/compose/ui/platform/ComposeView;I)V

    .line 92
    iput-object v0, p1, Lfpf;->c:Lbhwu;

    .line 94
    :cond_5
    return-void
.end method

.method public getAccessibilityClassName()Ljava/lang/CharSequence;
    .locals 0

    .line 1
    const-string p0, "androidx.compose.ui.platform.ComposeView"

    .line 3
    return-object p0
.end method

.method protected getShouldCreateCompositionOnAttachedToWindow()Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Landroidx/compose/ui/platform/ComposeView;->b:Z

    .line 3
    return p0
.end method

.method public final setContent(Lbhwu;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lbhwu<",
            "-",
            "Lfld;",
            "-",
            "Ljava/lang/Integer;",
            "Lbhqc;",
            ">;)V"
        }
    .end annotation

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Landroidx/compose/ui/platform/ComposeView;->b:Z

    .line 4
    iget-object v0, p0, Landroidx/compose/ui/platform/ComposeView;->a:Lfoc;

    .line 6
    invoke-interface {v0, p1}, Lfoc;->g(Ljava/lang/Object;)V

    .line 9
    invoke-virtual {p0}, Landroidx/compose/ui/platform/ComposeView;->isAttachedToWindow()Z

    .line 12
    move-result p1

    .line 13
    if-nez p1, :cond_1

    .line 15
    invoke-virtual {p0}, Lhjx;->getComposeViewContext$ui()Lhpe;

    .line 18
    move-result-object p1

    .line 19
    if-eqz p1, :cond_0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    return-void

    .line 23
    :cond_1
    :goto_0
    invoke-virtual {p0}, Lhjx;->d()V

    .line 26
    return-void
.end method
