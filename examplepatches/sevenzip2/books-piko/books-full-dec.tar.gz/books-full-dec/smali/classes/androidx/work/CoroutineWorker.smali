.class public abstract Landroidx/work/CoroutineWorker;
.super Lneo;
.source "PG"


# instance fields
.field private final e:Landroidx/work/WorkerParameters;

.field private final f:Lbifb;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-direct {p0, p1, p2}, Lneo;-><init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V

    .line 10
    iput-object p2, p0, Landroidx/work/CoroutineWorker;->e:Landroidx/work/WorkerParameters;

    .line 12
    sget-object p1, Lndo;->a:Lndo;

    .line 14
    iput-object p1, p0, Landroidx/work/CoroutineWorker;->f:Lbifb;

    .line 16
    return-void
.end method


# virtual methods
.method public final a()Lazuj;
    .locals 3

    .line 1
    new-instance v0, Lbihe;

    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lbihe;-><init>(Lbihc;)V

    .line 7
    iget-object v2, p0, Landroidx/work/CoroutineWorker;->f:Lbifb;

    .line 9
    invoke-virtual {v2, v0}, Lbhto;->plus(Lbhuc;)Lbhuc;

    .line 12
    move-result-object v0

    .line 13
    new-instance v2, Lndp;

    .line 15
    invoke-direct {v2, p0, v1}, Lndp;-><init>(Landroidx/work/CoroutineWorker;Lbhtu;)V

    .line 18
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    new-instance p0, Lnee;

    .line 23
    invoke-direct {p0, v0, v2}, Lnee;-><init>(Lbhuc;Lbhwu;)V

    .line 26
    invoke-static {p0}, Liuh;->a(Liue;)Lazuj;

    .line 29
    move-result-object p0

    .line 30
    return-object p0
.end method

.method public final b()Lazuj;
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/work/CoroutineWorker;->f:Lbifb;

    .line 3
    sget-object v1, Lndo;->a:Lndo;

    .line 5
    invoke-static {v0, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_0

    .line 11
    iget-object v0, p0, Landroidx/work/CoroutineWorker;->e:Landroidx/work/WorkerParameters;

    .line 13
    iget-object v0, v0, Landroidx/work/WorkerParameters;->e:Lbhuc;

    .line 15
    :cond_0
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    new-instance v1, Lbihe;

    .line 20
    const/4 v2, 0x0

    .line 21
    invoke-direct {v1, v2}, Lbihe;-><init>(Lbihc;)V

    .line 24
    invoke-interface {v0, v1}, Lbhuc;->plus(Lbhuc;)Lbhuc;

    .line 27
    move-result-object v0

    .line 28
    new-instance v1, Lndq;

    .line 30
    invoke-direct {v1, p0, v2}, Lndq;-><init>(Landroidx/work/CoroutineWorker;Lbhtu;)V

    .line 33
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    new-instance p0, Lnee;

    .line 38
    invoke-direct {p0, v0, v1}, Lnee;-><init>(Lbhuc;Lbhwu;)V

    .line 41
    invoke-static {p0}, Liuh;->a(Liue;)Lazuj;

    .line 44
    move-result-object p0

    .line 45
    return-object p0
.end method

.method public abstract c(Lbhtu;)Ljava/lang/Object;
.end method
