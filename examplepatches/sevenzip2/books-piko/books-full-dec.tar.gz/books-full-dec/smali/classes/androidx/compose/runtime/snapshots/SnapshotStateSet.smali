.class public final Landroidx/compose/runtime/snapshots/SnapshotStateSet;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Landroid/os/Parcelable;
.implements Ljava/util/Set;
.implements Ljava/util/RandomAccess;
.implements Lgbw;
.implements Lbhyq;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable;",
        "Ljava/util/Set<",
        "TT;>;",
        "Ljava/util/RandomAccess;",
        "Lgbw;",
        "Lbhyq;"
    }
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Landroidx/compose/runtime/snapshots/SnapshotStateSet<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field


# instance fields
.field public a:Lgby;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lgbm;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    sput-object v0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 8
    return-void
.end method

.method public constructor <init>()V
    .locals 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    sget-object v0, Lfwt;->a:Lfwt;

    .line 6
    new-instance v1, Lgca;

    .line 8
    invoke-static {}, Lgaq;->b()Lgac;

    .line 11
    move-result-object v2

    .line 12
    invoke-virtual {v2}, Lgac;->v()J

    .line 15
    move-result-wide v2

    .line 16
    invoke-direct {v1, v2, v3, v0}, Lgca;-><init>(JLfwt;)V

    .line 19
    sget-object v2, Lgaq;->b:Lfxw;

    .line 21
    invoke-virtual {v2}, Lfxw;->a()Ljava/lang/Object;

    .line 24
    move-result-object v2

    .line 25
    if-eqz v2, :cond_0

    .line 27
    new-instance v2, Lgca;

    .line 29
    const-wide/16 v3, 0x1

    .line 31
    invoke-direct {v2, v3, v4, v0}, Lgca;-><init>(JLfwt;)V

    .line 34
    iput-object v2, v1, Lgby;->n:Lgby;

    .line 36
    :cond_0
    iput-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 38
    return-void
.end method


# virtual methods
.method public final a()Lgby;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 3
    return-object p0
.end method

.method public final add(Ljava/lang/Object;)Z
    .locals 9

    .line 1
    :cond_0
    sget-object v0, Lgbn;->a:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    invoke-static {v1, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Lgca;

    .line 15
    iget v2, v1, Lgca;->a:I

    .line 17
    iget-object v1, v1, Lgca;->b:Lfwt;

    .line 19
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit v0

    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    invoke-virtual {v1, p1}, Lfwt;->b(Ljava/lang/Object;)Lfwt;

    .line 26
    move-result-object v3

    .line 27
    invoke-static {v3, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    move-result v1

    .line 31
    const/4 v4, 0x0

    .line 32
    if-eqz v1, :cond_1

    .line 34
    return v4

    .line 35
    :cond_1
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 37
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    sget-object v5, Lgaq;->c:Ljava/lang/Object;

    .line 42
    monitor-enter v5

    .line 43
    :try_start_1
    invoke-static {}, Lgaq;->b()Lgac;

    .line 46
    move-result-object v6

    .line 47
    invoke-static {v1, p0, v6}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 50
    move-result-object v1

    .line 51
    check-cast v1, Lgca;

    .line 53
    monitor-enter v0

    .line 54
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget v7, v1, Lgca;->a:I

    .line 56
    const/4 v8, 0x1

    .line 57
    if-ne v7, v2, :cond_2

    .line 59
    iput-object v3, v1, Lgca;->b:Lfwt;

    .line 61
    add-int/lit8 v7, v7, 0x1

    .line 63
    iput v7, v1, Lgca;->a:I

    .line 65
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move v4, v8

    .line 66
    :cond_2
    :try_start_3
    monitor-exit v0

    .line 67
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit v5

    .line 68
    invoke-static {v6, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 71
    if-eqz v4, :cond_0

    .line 73
    return v8

    .line 74
    :catchall_0
    move-exception p0

    .line 75
    :try_start_4
    monitor-exit v0

    .line 76
    throw p0

    .line 77
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p0

    .line 78
    monitor-exit v5

    .line 79
    throw p0

    .line 80
    :catchall_2
    move-exception p0

    .line 81
    monitor-exit v0

    .line 82
    throw p0
.end method

.method public final addAll(Ljava/util/Collection;)Z
    .locals 9

    .line 1
    :cond_0
    sget-object v0, Lgbn;->a:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    invoke-static {v1, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Lgca;

    .line 15
    iget v2, v1, Lgca;->a:I

    .line 17
    iget-object v1, v1, Lgca;->b:Lfwt;

    .line 19
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit v0

    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    new-instance v3, Lfwu;

    .line 25
    invoke-direct {v3, v1}, Lfwu;-><init>(Lfwt;)V

    .line 28
    invoke-interface {v3, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 31
    invoke-virtual {v3}, Lfwu;->a()Lfwt;

    .line 34
    move-result-object v3

    .line 35
    invoke-static {v3, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 38
    move-result v1

    .line 39
    const/4 v4, 0x0

    .line 40
    if-eqz v1, :cond_1

    .line 42
    return v4

    .line 43
    :cond_1
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 45
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 48
    sget-object v5, Lgaq;->c:Ljava/lang/Object;

    .line 50
    monitor-enter v5

    .line 51
    :try_start_1
    invoke-static {}, Lgaq;->b()Lgac;

    .line 54
    move-result-object v6

    .line 55
    invoke-static {v1, p0, v6}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 58
    move-result-object v1

    .line 59
    check-cast v1, Lgca;

    .line 61
    monitor-enter v0

    .line 62
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget v7, v1, Lgca;->a:I

    .line 64
    const/4 v8, 0x1

    .line 65
    if-ne v7, v2, :cond_2

    .line 67
    iput-object v3, v1, Lgca;->b:Lfwt;

    .line 69
    add-int/lit8 v7, v7, 0x1

    .line 71
    iput v7, v1, Lgca;->a:I

    .line 73
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move v4, v8

    .line 74
    :cond_2
    :try_start_3
    monitor-exit v0

    .line 75
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit v5

    .line 76
    invoke-static {v6, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 79
    if-eqz v4, :cond_0

    .line 81
    return v8

    .line 82
    :catchall_0
    move-exception p0

    .line 83
    :try_start_4
    monitor-exit v0

    .line 84
    throw p0

    .line 85
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p0

    .line 86
    monitor-exit v5

    .line 87
    throw p0

    .line 88
    :catchall_2
    move-exception p0

    .line 89
    monitor-exit v0

    .line 90
    throw p0
.end method

.method public final synthetic b(Lgby;Lgby;Lgby;)Lgby;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final c(Lgby;)V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 3
    iput-object v0, p1, Lgby;->n:Lgby;

    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    check-cast p1, Lgca;

    .line 10
    iput-object p1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 12
    return-void
.end method

.method public final clear()V
    .locals 5

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    sget-object v1, Lgaq;->c:Ljava/lang/Object;

    .line 8
    monitor-enter v1

    .line 9
    :try_start_0
    invoke-static {}, Lgaq;->b()Lgac;

    .line 12
    move-result-object v2

    .line 13
    invoke-static {v0, p0, v2}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Lgca;

    .line 19
    sget-object v3, Lgbn;->a:Ljava/lang/Object;

    .line 21
    monitor-enter v3

    .line 22
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    sget-object v4, Lfwt;->a:Lfwt;

    .line 24
    iput-object v4, v0, Lgca;->b:Lfwt;

    .line 26
    iget v4, v0, Lgca;->a:I

    .line 28
    add-int/lit8 v4, v4, 0x1

    .line 30
    iput v4, v0, Lgca;->a:I

    .line 32
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    monitor-exit v3

    .line 33
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    monitor-exit v1

    .line 34
    invoke-static {v2, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 37
    return-void

    .line 38
    :catchall_0
    move-exception p0

    .line 39
    :try_start_3
    monitor-exit v3

    .line 40
    throw p0

    .line 41
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :catchall_1
    move-exception p0

    .line 42
    monitor-exit v1

    .line 43
    throw p0
.end method

.method public final contains(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lgca;

    .line 12
    iget-object p0, p0, Lgca;->b:Lfwt;

    .line 14
    invoke-virtual {p0, p1}, Lbhqf;->contains(Ljava/lang/Object;)Z

    .line 17
    move-result p0

    .line 18
    return p0
.end method

.method public final containsAll(Ljava/util/Collection;)Z
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lgca;

    .line 12
    iget-object p0, p0, Lgca;->b:Lfwt;

    .line 14
    invoke-virtual {p0, p1}, Lbhqf;->containsAll(Ljava/util/Collection;)Z

    .line 17
    move-result p0

    .line 18
    return p0
.end method

.method public final describeContents()I
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final isEmpty()Z
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lgca;

    .line 12
    iget-object p0, p0, Lgca;->b:Lfwt;

    .line 14
    invoke-virtual {p0}, Lbhqf;->isEmpty()Z

    .line 17
    move-result p0

    .line 18
    return p0
.end method

.method public final iterator()Ljava/util/Iterator;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TT;>;"
        }
    .end annotation

    .line 1
    new-instance v0, Lgbz;

    .line 3
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 5
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    invoke-static {v1, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 11
    move-result-object v1

    .line 12
    check-cast v1, Lgca;

    .line 14
    iget-object v1, v1, Lgca;->b:Lfwt;

    .line 16
    invoke-virtual {v1}, Lbhqs;->iterator()Ljava/util/Iterator;

    .line 19
    move-result-object v1

    .line 20
    invoke-direct {v0, p0, v1}, Lgbz;-><init>(Landroidx/compose/runtime/snapshots/SnapshotStateSet;Ljava/util/Iterator;)V

    .line 23
    return-object v0
.end method

.method public final remove(Ljava/lang/Object;)Z
    .locals 9

    .line 1
    :cond_0
    sget-object v0, Lgbn;->a:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    invoke-static {v1, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Lgca;

    .line 15
    iget v2, v1, Lgca;->a:I

    .line 17
    iget-object v1, v1, Lgca;->b:Lfwt;

    .line 19
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit v0

    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    invoke-virtual {v1, p1}, Lfwt;->c(Ljava/lang/Object;)Lfwt;

    .line 26
    move-result-object v3

    .line 27
    invoke-static {v3, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    move-result v1

    .line 31
    const/4 v4, 0x0

    .line 32
    if-eqz v1, :cond_1

    .line 34
    return v4

    .line 35
    :cond_1
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 37
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    sget-object v5, Lgaq;->c:Ljava/lang/Object;

    .line 42
    monitor-enter v5

    .line 43
    :try_start_1
    invoke-static {}, Lgaq;->b()Lgac;

    .line 46
    move-result-object v6

    .line 47
    invoke-static {v1, p0, v6}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 50
    move-result-object v1

    .line 51
    check-cast v1, Lgca;

    .line 53
    monitor-enter v0

    .line 54
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget v7, v1, Lgca;->a:I

    .line 56
    const/4 v8, 0x1

    .line 57
    if-ne v7, v2, :cond_2

    .line 59
    iput-object v3, v1, Lgca;->b:Lfwt;

    .line 61
    add-int/lit8 v7, v7, 0x1

    .line 63
    iput v7, v1, Lgca;->a:I

    .line 65
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move v4, v8

    .line 66
    :cond_2
    :try_start_3
    monitor-exit v0

    .line 67
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit v5

    .line 68
    invoke-static {v6, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 71
    if-eqz v4, :cond_0

    .line 73
    return v8

    .line 74
    :catchall_0
    move-exception p0

    .line 75
    :try_start_4
    monitor-exit v0

    .line 76
    throw p0

    .line 77
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p0

    .line 78
    monitor-exit v5

    .line 79
    throw p0

    .line 80
    :catchall_2
    move-exception p0

    .line 81
    monitor-exit v0

    .line 82
    throw p0
.end method

.method public final removeAll(Ljava/util/Collection;)Z
    .locals 9

    .line 1
    :cond_0
    sget-object v0, Lgbn;->a:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    invoke-static {v1, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Lgca;

    .line 15
    iget v2, v1, Lgca;->a:I

    .line 17
    iget-object v1, v1, Lgca;->b:Lfwt;

    .line 19
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit v0

    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    new-instance v3, Lfwu;

    .line 25
    invoke-direct {v3, v1}, Lfwu;-><init>(Lfwt;)V

    .line 28
    invoke-interface {v3, p1}, Ljava/util/Set;->removeAll(Ljava/util/Collection;)Z

    .line 31
    invoke-virtual {v3}, Lfwu;->a()Lfwt;

    .line 34
    move-result-object v3

    .line 35
    invoke-static {v3, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 38
    move-result v1

    .line 39
    const/4 v4, 0x0

    .line 40
    if-eqz v1, :cond_1

    .line 42
    return v4

    .line 43
    :cond_1
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 45
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 48
    sget-object v5, Lgaq;->c:Ljava/lang/Object;

    .line 50
    monitor-enter v5

    .line 51
    :try_start_1
    invoke-static {}, Lgaq;->b()Lgac;

    .line 54
    move-result-object v6

    .line 55
    invoke-static {v1, p0, v6}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 58
    move-result-object v1

    .line 59
    check-cast v1, Lgca;

    .line 61
    monitor-enter v0

    .line 62
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget v7, v1, Lgca;->a:I

    .line 64
    const/4 v8, 0x1

    .line 65
    if-ne v7, v2, :cond_2

    .line 67
    iput-object v3, v1, Lgca;->b:Lfwt;

    .line 69
    add-int/lit8 v7, v7, 0x1

    .line 71
    iput v7, v1, Lgca;->a:I

    .line 73
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move v4, v8

    .line 74
    :cond_2
    :try_start_3
    monitor-exit v0

    .line 75
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit v5

    .line 76
    invoke-static {v6, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 79
    if-eqz v4, :cond_0

    .line 81
    return v8

    .line 82
    :catchall_0
    move-exception p0

    .line 83
    :try_start_4
    monitor-exit v0

    .line 84
    throw p0

    .line 85
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p0

    .line 86
    monitor-exit v5

    .line 87
    throw p0

    .line 88
    :catchall_2
    move-exception p0

    .line 89
    monitor-exit v0

    .line 90
    throw p0
.end method

.method public final retainAll(Ljava/util/Collection;)Z
    .locals 8

    .line 1
    new-instance v0, Lgbl;

    .line 3
    invoke-direct {v0, p1}, Lgbl;-><init>(Ljava/util/Collection;)V

    .line 6
    :cond_0
    sget-object p1, Lgbn;->a:Ljava/lang/Object;

    .line 8
    monitor-enter p1

    .line 9
    :try_start_0
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    invoke-static {v1, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 17
    move-result-object v1

    .line 18
    check-cast v1, Lgca;

    .line 20
    iget v2, v1, Lgca;->a:I

    .line 22
    iget-object v1, v1, Lgca;->b:Lfwt;

    .line 24
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit p1

    .line 25
    if-eqz v1, :cond_3

    .line 27
    new-instance v3, Lfwu;

    .line 29
    invoke-direct {v3, v1}, Lfwu;-><init>(Lfwt;)V

    .line 32
    invoke-interface {v0, v3}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    move-result-object v4

    .line 36
    invoke-virtual {v3}, Lfwu;->a()Lfwt;

    .line 39
    move-result-object v3

    .line 40
    invoke-static {v3, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 43
    move-result v1

    .line 44
    if-nez v1, :cond_2

    .line 46
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 48
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    sget-object v5, Lgaq;->c:Ljava/lang/Object;

    .line 53
    monitor-enter v5

    .line 54
    :try_start_1
    invoke-static {}, Lgaq;->b()Lgac;

    .line 57
    move-result-object v6

    .line 58
    invoke-static {v1, p0, v6}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 61
    move-result-object v1

    .line 62
    check-cast v1, Lgca;

    .line 64
    monitor-enter p1

    .line 65
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget v7, v1, Lgca;->a:I

    .line 67
    if-ne v7, v2, :cond_1

    .line 69
    iput-object v3, v1, Lgca;->b:Lfwt;

    .line 71
    add-int/lit8 v7, v7, 0x1

    .line 73
    iput v7, v1, Lgca;->a:I

    .line 75
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v1, 0x1

    .line 76
    goto :goto_0

    .line 77
    :cond_1
    const/4 v1, 0x0

    .line 78
    :goto_0
    :try_start_3
    monitor-exit p1

    .line 79
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit v5

    .line 80
    invoke-static {v6, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 83
    if-eqz v1, :cond_0

    .line 85
    goto :goto_1

    .line 86
    :catchall_0
    move-exception p0

    .line 87
    :try_start_4
    monitor-exit p1

    .line 88
    throw p0

    .line 89
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p0

    .line 90
    monitor-exit v5

    .line 91
    throw p0

    .line 92
    :cond_2
    :goto_1
    check-cast v4, Ljava/lang/Boolean;

    .line 94
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 97
    move-result p0

    .line 98
    return p0

    .line 99
    :cond_3
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 101
    const-string p1, "No set to mutate"

    .line 103
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 106
    throw p0

    .line 107
    :catchall_2
    move-exception p0

    .line 108
    monitor-exit p1

    .line 109
    throw p0
.end method

.method public final size()I
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lgca;

    .line 12
    iget-object p0, p0, Lgca;->b:Lfwt;

    .line 14
    invoke-virtual {p0}, Lbhqf;->a()I

    .line 17
    move-result p0

    .line 18
    return p0
.end method

.method public final toArray()[Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {p0}, Lbhxj;->a(Ljava/util/Collection;)[Ljava/lang/Object;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 0

    .line 6
    invoke-static {p0, p1}, Lbhxj;->b(Ljava/util/Collection;[Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Lgca;

    .line 12
    iget-object v0, v0, Lgca;->b:Lfwt;

    .line 14
    invoke-virtual {p0}, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->hashCode()I

    .line 17
    move-result p0

    .line 18
    new-instance v1, Ljava/lang/StringBuilder;

    .line 20
    const-string v2, "SnapshotStateSet(value="

    .line 22
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 25
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 28
    const-string v0, ")@"

    .line 30
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 36
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    move-result-object p0

    .line 40
    return-object p0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 0

    .line 1
    iget-object p2, p0, Landroidx/compose/runtime/snapshots/SnapshotStateSet;->a:Lgby;

    .line 3
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {p2, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lgca;

    .line 12
    iget-object p0, p0, Lgca;->b:Lfwt;

    .line 14
    invoke-virtual {p0}, Lbhqf;->a()I

    .line 17
    move-result p2

    .line 18
    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    .line 21
    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 24
    move-result-object p0

    .line 25
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 28
    move-result p2

    .line 29
    if-eqz p2, :cond_0

    .line 31
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 34
    move-result-object p2

    .line 35
    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeValue(Ljava/lang/Object;)V

    .line 38
    goto :goto_0

    .line 39
    :cond_0
    return-void
.end method
