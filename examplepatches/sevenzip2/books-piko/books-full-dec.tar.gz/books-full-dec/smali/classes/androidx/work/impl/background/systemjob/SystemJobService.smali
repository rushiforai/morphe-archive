.class public Landroidx/work/impl/background/systemjob/SystemJobService;
.super Landroid/app/job/JobService;
.source "PG"

# interfaces
.implements Lnge;


# static fields
.field private static final a:Ljava/lang/String;


# instance fields
.field private b:Lnih;

.field private final c:Ljava/util/Map;

.field private final d:Lnhb;

.field private e:Lnif;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "SystemJobService"

    .line 3
    invoke-static {v0}, Lneq;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Ljava/lang/String;

    .line 9
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroid/app/job/JobService;-><init>()V

    .line 4
    new-instance v0, Ljava/util/HashMap;

    .line 6
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 9
    iput-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:Ljava/util/Map;

    .line 11
    new-instance v0, Lnhc;

    .line 13
    invoke-direct {v0}, Lnhc;-><init>()V

    .line 16
    iput-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Lnhb;

    .line 18
    return-void
.end method

.method private static b(Landroid/app/job/JobParameters;)Lnmu;
    .locals 3

    .line 1
    const-string v0, "EXTRA_WORK_SPEC_ID"

    .line 3
    :try_start_0
    invoke-virtual {p0}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    .line 6
    move-result-object p0

    .line 7
    if-eqz p0, :cond_0

    .line 9
    invoke-virtual {p0, v0}, Landroid/os/PersistableBundle;->containsKey(Ljava/lang/String;)Z

    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_0

    .line 15
    new-instance v1, Lnmu;

    .line 17
    invoke-virtual {p0, v0}, Landroid/os/PersistableBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 20
    move-result-object v0

    .line 21
    const-string v2, "EXTRA_WORK_SPEC_GENERATION"

    .line 23
    invoke-virtual {p0, v2}, Landroid/os/PersistableBundle;->getInt(Ljava/lang/String;)I

    .line 26
    move-result p0

    .line 27
    invoke-direct {v1, v0, p0}, Lnmu;-><init>(Ljava/lang/String;I)V

    .line 30
    :try_end_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    .line 31
    :catch_0
    :cond_0
    const/4 p0, 0x0

    .line 32
    return-object p0
.end method

.method private static c(Ljava/lang/String;)V
    .locals 3

    .line 1
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    .line 8
    move-result-object v0

    .line 9
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 12
    move-result-object v1

    .line 13
    if-ne v0, v1, :cond_0

    .line 15
    return-void

    .line 16
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 18
    const-string v1, "Cannot invoke "

    .line 20
    const-string v2, " on a background thread"

    .line 22
    invoke-static {p0, v1, v2}, La;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 25
    move-result-object p0

    .line 26
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 29
    throw v0
.end method


# virtual methods
.method public final a(Lnmu;Z)V
    .locals 4

    .line 1
    const-string v0, "onExecuted"

    .line 3
    invoke-static {v0}, Landroidx/work/impl/background/systemjob/SystemJobService;->c(Ljava/lang/String;)V

    .line 6
    iget-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:Ljava/util/Map;

    .line 8
    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Landroid/app/job/JobParameters;

    .line 14
    iget-object v1, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Lnhb;

    .line 16
    invoke-interface {v1, p1}, Lnhb;->a(Lnmu;)Lnha;

    .line 19
    if-eqz v0, :cond_0

    .line 21
    iget-object p1, p1, Lnmu;->a:Ljava/lang/String;

    .line 23
    invoke-static {}, Lneq;->c()Lneq;

    .line 26
    move-result-object v1

    .line 27
    sget-object v2, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Ljava/lang/String;

    .line 29
    const-string v3, " executed on JobScheduler"

    .line 31
    invoke-virtual {p1, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 34
    move-result-object p1

    .line 35
    invoke-virtual {v1, v2, p1}, Lneq;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 38
    invoke-virtual {p0, v0, p2}, Landroidx/work/impl/background/systemjob/SystemJobService;->jobFinished(Landroid/app/job/JobParameters;Z)V

    .line 41
    :cond_0
    return-void
.end method

.method public final onCreate()V
    .locals 3

    .line 1
    invoke-super {p0}, Landroid/app/job/JobService;->onCreate()V

    .line 4
    :try_start_0
    invoke-virtual {p0}, Landroidx/work/impl/background/systemjob/SystemJobService;->getApplicationContext()Landroid/content/Context;

    .line 7
    move-result-object v0

    .line 8
    invoke-static {v0}, Lnih;->j(Landroid/content/Context;)Lnih;

    .line 11
    move-result-object v0

    .line 12
    iput-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->b:Lnih;

    .line 14
    iget-object v1, v0, Lnih;->f:Lngu;

    .line 16
    new-instance v2, Lnif;

    .line 18
    iget-object v0, v0, Lnih;->k:Lnrh;

    .line 20
    invoke-direct {v2, v1, v0}, Lnif;-><init>(Lngu;Lnrh;)V

    .line 23
    iput-object v2, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->e:Lnif;

    .line 25
    invoke-virtual {v1, p0}, Lngu;->c(Lnge;)V

    .line 28
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 29
    :catch_0
    move-exception v0

    .line 30
    invoke-virtual {p0}, Landroidx/work/impl/background/systemjob/SystemJobService;->getApplication()Landroid/app/Application;

    .line 33
    move-result-object p0

    .line 34
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    move-result-object p0

    .line 38
    const-class v1, Landroid/app/Application;

    .line 40
    invoke-virtual {v1, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 43
    move-result p0

    .line 44
    if-eqz p0, :cond_0

    .line 46
    invoke-static {}, Lneq;->c()Lneq;

    .line 49
    sget-object p0, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Ljava/lang/String;

    .line 51
    const-string v0, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer."

    .line 53
    invoke-static {p0, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 56
    return-void

    .line 57
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 59
    const-string v1, "WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate()."

    .line 61
    invoke-direct {p0, v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 64
    throw p0
.end method

.method public final onDestroy()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/app/job/JobService;->onDestroy()V

    .line 4
    iget-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->b:Lnih;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    iget-object v0, v0, Lnih;->f:Lngu;

    .line 10
    invoke-virtual {v0, p0}, Lngu;->d(Lnge;)V

    .line 13
    :cond_0
    return-void
.end method

.method public final onStartJob(Landroid/app/job/JobParameters;)Z
    .locals 7

    .line 1
    const-string v0, "onStartJob"

    .line 3
    invoke-static {v0}, Landroidx/work/impl/background/systemjob/SystemJobService;->c(Ljava/lang/String;)V

    .line 6
    iget-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->b:Lnih;

    .line 8
    const/4 v1, 0x1

    .line 9
    const/4 v2, 0x0

    .line 10
    if-nez v0, :cond_0

    .line 12
    invoke-static {}, Lneq;->c()Lneq;

    .line 15
    move-result-object v0

    .line 16
    sget-object v3, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Ljava/lang/String;

    .line 18
    const-string v4, "WorkManager is not initialized; requesting retry."

    .line 20
    invoke-virtual {v0, v3, v4}, Lneq;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 23
    invoke-virtual {p0, p1, v1}, Landroidx/work/impl/background/systemjob/SystemJobService;->jobFinished(Landroid/app/job/JobParameters;Z)V

    .line 26
    return v2

    .line 27
    :cond_0
    invoke-static {p1}, Landroidx/work/impl/background/systemjob/SystemJobService;->b(Landroid/app/job/JobParameters;)Lnmu;

    .line 30
    move-result-object v0

    .line 31
    if-nez v0, :cond_1

    .line 33
    invoke-static {}, Lneq;->c()Lneq;

    .line 36
    sget-object p0, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Ljava/lang/String;

    .line 38
    const-string p1, "WorkSpec id not found!"

    .line 40
    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 43
    return v2

    .line 44
    :cond_1
    iget-object v3, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->b:Lnih;

    .line 46
    iget-object v3, v3, Lnih;->f:Lngu;

    .line 48
    iget-object v4, v3, Lngu;->l:Ljava/lang/Object;

    .line 50
    monitor-enter v4

    .line 51
    :try_start_0
    iget-object v3, v3, Lngu;->f:Ljava/util/Map;

    .line 53
    iget-object v5, v0, Lnmu;->a:Ljava/lang/String;

    .line 55
    invoke-interface {v3, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    move-result-object v3

    .line 59
    check-cast v3, Lnje;

    .line 61
    if-eqz v3, :cond_2

    .line 63
    invoke-virtual {v3}, Lnje;->a()Lnmu;

    .line 66
    move-result-object v3

    .line 67
    invoke-virtual {v3, v0}, Lnmu;->equals(Ljava/lang/Object;)Z

    .line 70
    move-result v3

    .line 71
    if-eqz v3, :cond_2

    .line 73
    move v3, v1

    .line 74
    goto :goto_0

    .line 75
    :cond_2
    move v3, v2

    .line 76
    :goto_0
    monitor-exit v4

    .line 77
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v3, :cond_3

    .line 79
    invoke-static {}, Lneq;->c()Lneq;

    .line 82
    move-result-object v3

    .line 83
    sget-object v4, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Ljava/lang/String;

    .line 85
    const-string v5, "Job is already running in foreground: "

    .line 87
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 90
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 93
    move-result-object v0

    .line 94
    invoke-virtual {v5, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 97
    move-result-object v0

    .line 98
    invoke-virtual {v3, v4, v0}, Lneq;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 101
    invoke-virtual {p0, p1, v1}, Landroidx/work/impl/background/systemjob/SystemJobService;->jobFinished(Landroid/app/job/JobParameters;Z)V

    .line 104
    return v2

    .line 105
    :cond_3
    iget-object v3, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:Ljava/util/Map;

    .line 107
    invoke-interface {v3, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 110
    move-result v4

    .line 111
    if-eqz v4, :cond_4

    .line 113
    invoke-static {}, Lneq;->c()Lneq;

    .line 116
    move-result-object p0

    .line 117
    sget-object p1, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Ljava/lang/String;

    .line 119
    const-string v1, "Job is already being executed by SystemJobService: "

    .line 121
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 124
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 127
    move-result-object v0

    .line 128
    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 131
    move-result-object v0

    .line 132
    invoke-virtual {p0, p1, v0}, Lneq;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 135
    return v2

    .line 136
    :cond_4
    invoke-static {}, Lneq;->c()Lneq;

    .line 139
    move-result-object v2

    .line 140
    sget-object v4, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Ljava/lang/String;

    .line 142
    const-string v5, "onStartJob for "

    .line 144
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 147
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 150
    move-result-object v6

    .line 151
    invoke-virtual {v5, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 154
    move-result-object v5

    .line 155
    invoke-virtual {v2, v4, v5}, Lneq;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 158
    invoke-interface {v3, v0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 161
    new-instance v2, Lnfz;

    .line 163
    invoke-direct {v2}, Lnfz;-><init>()V

    .line 166
    invoke-static {p1}, Lhc$$ExternalSyntheticApiModelOutline0;->m(Landroid/app/job/JobParameters;)[Landroid/net/Uri;

    .line 169
    move-result-object v3

    .line 170
    if-eqz v3, :cond_5

    .line 172
    invoke-static {p1}, Lhc$$ExternalSyntheticApiModelOutline0;->m(Landroid/app/job/JobParameters;)[Landroid/net/Uri;

    .line 175
    move-result-object v3

    .line 176
    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 179
    :cond_5
    invoke-static {p1}, Lhc$$ExternalSyntheticApiModelOutline0;->m(Landroid/app/job/JobParameters;)[Ljava/lang/String;

    .line 182
    move-result-object v3

    .line 183
    if-eqz v3, :cond_6

    .line 185
    invoke-static {p1}, Lhc$$ExternalSyntheticApiModelOutline0;->m(Landroid/app/job/JobParameters;)[Ljava/lang/String;

    .line 188
    move-result-object v3

    .line 189
    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 192
    :cond_6
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 194
    const/16 v4, 0x1c

    .line 196
    if-lt v3, v4, :cond_7

    .line 198
    invoke-static {p1}, Laag$$ExternalSyntheticApiModelOutline0;->m(Landroid/app/job/JobParameters;)Landroid/net/Network;

    .line 201
    :cond_7
    iget-object p1, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->e:Lnif;

    .line 203
    iget-object p0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Lnhb;

    .line 205
    invoke-interface {p0, v0}, Lnhb;->b(Lnmu;)Lnha;

    .line 208
    move-result-object p0

    .line 209
    invoke-virtual {p1, p0, v2}, Lnif;->a(Lnha;Lnfz;)V

    .line 212
    return v1

    .line 213
    :catchall_0
    move-exception p0

    .line 214
    :try_start_1
    monitor-exit v4

    .line 215
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public final onStopJob(Landroid/app/job/JobParameters;)Z
    .locals 7

    .line 1
    const-string v0, "onStopJob"

    .line 3
    invoke-static {v0}, Landroidx/work/impl/background/systemjob/SystemJobService;->c(Ljava/lang/String;)V

    .line 6
    iget-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->b:Lnih;

    .line 8
    const/4 v1, 0x1

    .line 9
    if-nez v0, :cond_0

    .line 11
    invoke-static {}, Lneq;->c()Lneq;

    .line 14
    move-result-object p0

    .line 15
    sget-object p1, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Ljava/lang/String;

    .line 17
    const-string v0, "WorkManager is not initialized; requesting retry."

    .line 19
    invoke-virtual {p0, p1, v0}, Lneq;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    return v1

    .line 23
    :cond_0
    invoke-static {p1}, Landroidx/work/impl/background/systemjob/SystemJobService;->b(Landroid/app/job/JobParameters;)Lnmu;

    .line 26
    move-result-object v0

    .line 27
    const/4 v2, 0x0

    .line 28
    if-nez v0, :cond_1

    .line 30
    invoke-static {}, Lneq;->c()Lneq;

    .line 33
    sget-object p0, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Ljava/lang/String;

    .line 35
    const-string p1, "WorkSpec id not found!"

    .line 37
    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 40
    return v2

    .line 41
    :cond_1
    invoke-static {}, Lneq;->c()Lneq;

    .line 44
    move-result-object v3

    .line 45
    sget-object v4, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Ljava/lang/String;

    .line 47
    const-string v5, "onStopJob for "

    .line 49
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 52
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 55
    move-result-object v6

    .line 56
    invoke-virtual {v5, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 59
    move-result-object v5

    .line 60
    invoke-virtual {v3, v4, v5}, Lneq;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 63
    iget-object v3, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:Ljava/util/Map;

    .line 65
    invoke-interface {v3, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    iget-object v3, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Lnhb;

    .line 70
    invoke-interface {v3, v0}, Lnhb;->a(Lnmu;)Lnha;

    .line 73
    move-result-object v3

    .line 74
    if-eqz v3, :cond_3

    .line 76
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 78
    const/16 v5, 0x1f

    .line 80
    const/16 v6, -0x200

    .line 82
    if-lt v4, v5, :cond_2

    .line 84
    invoke-static {p1}, Labl$$ExternalSyntheticApiModelOutline0;->m(Landroid/app/job/JobParameters;)I

    .line 87
    move-result p1

    .line 88
    packed-switch p1, :pswitch_data_0

    .line 91
    goto :goto_0

    .line 92
    :pswitch_0    # 0x2 0x3 0x4 0x5 0x6 0x7 0x8 0x9 0xa 0xb 0xc 0xd 0xe 0xf 0x1
    move v6, p1

    .line 93
    :cond_2
    :goto_0
    :pswitch_1    # 0x0
    iget-object p1, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->e:Lnif;

    .line 95
    invoke-virtual {p1, v3, v6}, Lnif;->b(Lnha;I)V

    .line 98
    :cond_3
    iget-object p0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->b:Lnih;

    .line 100
    iget-object p0, p0, Lnih;->f:Lngu;

    .line 102
    iget-object p1, v0, Lnmu;->a:Ljava/lang/String;

    .line 104
    iget-object v0, p0, Lngu;->l:Ljava/lang/Object;

    .line 106
    monitor-enter v0

    .line 107
    :try_start_0
    iget-object p0, p0, Lngu;->i:Ljava/util/Set;

    .line 109
    invoke-interface {p0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 112
    move-result p0

    .line 113
    monitor-exit v0

    .line 114
    if-nez p0, :cond_4

    .line 116
    return v1

    .line 117
    :cond_4
    return v2

    .line 118
    :catchall_0
    move-exception p0

    .line 119
    monitor-exit v0

    .line 120
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0

    .line 121
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1    # 0x0
        :pswitch_0    # 0x1
        :pswitch_0    # 0x2
        :pswitch_0    # 0x3
        :pswitch_0    # 0x4
        :pswitch_0    # 0x5
        :pswitch_0    # 0x6
        :pswitch_0    # 0x7
        :pswitch_0    # 0x8
        :pswitch_0    # 0x9
        :pswitch_0    # 0xa
        :pswitch_0    # 0xb
        :pswitch_0    # 0xc
        :pswitch_0    # 0xd
        :pswitch_0    # 0xe
        :pswitch_0    # 0xf
    .end packed-switch
.end method
