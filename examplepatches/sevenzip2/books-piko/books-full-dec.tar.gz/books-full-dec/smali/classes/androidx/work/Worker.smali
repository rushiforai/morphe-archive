.class public abstract Landroidx/work/Worker;
.super Lneo;
.source "PG"


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-direct {p0, p1, p2}, Lneo;-><init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V

    .line 10
    return-void
.end method


# virtual methods
.method public final a()Lazuj;
    .locals 2

    .line 1
    invoke-virtual {p0}, Lneo;->g()Ljava/util/concurrent/Executor;

    .line 4
    move-result-object p0

    .line 5
    new-instance v0, Lnft;

    .line 7
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 10
    new-instance v1, Lnfy;

    .line 12
    invoke-direct {v1, p0, v0}, Lnfy;-><init>(Ljava/util/concurrent/Executor;Lbhwf;)V

    .line 15
    invoke-static {v1}, Liuh;->a(Liue;)Lazuj;

    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method

.method public final b()Lazuj;
    .locals 2

    .line 1
    invoke-virtual {p0}, Lneo;->g()Ljava/util/concurrent/Executor;

    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Lnfs;

    .line 7
    invoke-direct {v1, p0}, Lnfs;-><init>(Landroidx/work/Worker;)V

    .line 10
    new-instance p0, Lnfy;

    .line 12
    invoke-direct {p0, v0, v1}, Lnfy;-><init>(Ljava/util/concurrent/Executor;Lbhwf;)V

    .line 15
    invoke-static {p0}, Liuh;->a(Liue;)Lazuj;

    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method

.method public abstract c()Lnen;
.end method
