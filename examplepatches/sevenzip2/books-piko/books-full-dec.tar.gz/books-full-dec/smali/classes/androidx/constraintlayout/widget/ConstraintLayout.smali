.class public Landroidx/constraintlayout/widget/ConstraintLayout;
.super Landroid/view/ViewGroup;
.source "PG"


# static fields
.field private static g:Lizo;


# instance fields
.field final a:Landroid/util/SparseArray;

.field public final b:Ljava/util/ArrayList;

.field protected final c:Lixt;

.field protected d:Z

.field public e:I

.field final f:Liyy;

.field private h:I

.field private i:I

.field private j:I

.field private k:I

.field private l:Lizi;

.field private m:I

.field private n:Ljava/util/HashMap;

.field private final o:Landroid/util/SparseArray;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 1
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-direct {p0, p1}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;)V

    .line 4
    new-instance p1, Landroid/util/SparseArray;

    .line 6
    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    .line 9
    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->a:Landroid/util/SparseArray;

    .line 11
    new-instance p1, Ljava/util/ArrayList;

    .line 13
    const/4 v0, 0x4

    .line 14
    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 17
    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Ljava/util/ArrayList;

    .line 19
    new-instance p1, Lixt;

    .line 21
    invoke-direct {p1}, Lixt;-><init>()V

    .line 24
    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    .line 26
    const/4 p1, 0x0

    .line 27
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    .line 29
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:I

    .line 31
    const v0, 0x7fffffff

    .line 34
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    .line 36
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:I

    .line 38
    const/4 v0, 0x1

    .line 39
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Z

    .line 41
    const/16 v0, 0x101

    .line 43
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    .line 45
    const/4 v0, 0x0

    .line 46
    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lizi;

    .line 48
    const/4 v1, -0x1

    .line 49
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->m:I

    .line 51
    new-instance v1, Ljava/util/HashMap;

    .line 53
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 56
    iput-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    .line 58
    new-instance v1, Landroid/util/SparseArray;

    .line 60
    invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V

    .line 63
    iput-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->o:Landroid/util/SparseArray;

    .line 65
    new-instance v1, Liyy;

    .line 67
    invoke-direct {v1, p0, p0}, Liyy;-><init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroidx/constraintlayout/widget/ConstraintLayout;)V

    .line 70
    iput-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:Liyy;

    .line 72
    invoke-direct {p0, v0, p1, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->e(Landroid/util/AttributeSet;II)V

    .line 75
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    .line 76
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    new-instance p1, Landroid/util/SparseArray;

    .line 77
    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->a:Landroid/util/SparseArray;

    new-instance p1, Ljava/util/ArrayList;

    const/4 v0, 0x4

    .line 78
    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Ljava/util/ArrayList;

    new-instance p1, Lixt;

    .line 79
    invoke-direct {p1}, Lixt;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    const/4 p1, 0x0

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:I

    const v0, 0x7fffffff

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Z

    const/16 v0, 0x101

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lizi;

    const/4 v0, -0x1

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->m:I

    new-instance v0, Ljava/util/HashMap;

    .line 80
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    new-instance v0, Landroid/util/SparseArray;

    .line 81
    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->o:Landroid/util/SparseArray;

    new-instance v0, Liyy;

    invoke-direct {v0, p0, p0}, Liyy;-><init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroidx/constraintlayout/widget/ConstraintLayout;)V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:Liyy;

    .line 82
    invoke-direct {p0, p2, p1, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->e(Landroid/util/AttributeSet;II)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 1

    .line 83
    invoke-direct {p0, p1, p2, p3}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance p1, Landroid/util/SparseArray;

    .line 84
    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->a:Landroid/util/SparseArray;

    new-instance p1, Ljava/util/ArrayList;

    const/4 v0, 0x4

    .line 85
    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Ljava/util/ArrayList;

    new-instance p1, Lixt;

    .line 86
    invoke-direct {p1}, Lixt;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    const/4 p1, 0x0

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:I

    const v0, 0x7fffffff

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Z

    const/16 v0, 0x101

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lizi;

    const/4 v0, -0x1

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->m:I

    new-instance v0, Ljava/util/HashMap;

    .line 87
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    new-instance v0, Landroid/util/SparseArray;

    .line 88
    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->o:Landroid/util/SparseArray;

    new-instance v0, Liyy;

    invoke-direct {v0, p0, p0}, Liyy;-><init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroidx/constraintlayout/widget/ConstraintLayout;)V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:Liyy;

    .line 89
    invoke-direct {p0, p2, p3, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->e(Landroid/util/AttributeSet;II)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 1

    .line 90
    invoke-direct {p0, p1, p2, p3, p4}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    new-instance p1, Landroid/util/SparseArray;

    .line 91
    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->a:Landroid/util/SparseArray;

    new-instance p1, Ljava/util/ArrayList;

    const/4 v0, 0x4

    .line 92
    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Ljava/util/ArrayList;

    new-instance p1, Lixt;

    .line 93
    invoke-direct {p1}, Lixt;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    const/4 p1, 0x0

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:I

    const p1, 0x7fffffff

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:I

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Z

    const/16 p1, 0x101

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lizi;

    const/4 p1, -0x1

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->m:I

    new-instance p1, Ljava/util/HashMap;

    .line 94
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    new-instance p1, Landroid/util/SparseArray;

    .line 95
    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->o:Landroid/util/SparseArray;

    new-instance p1, Liyy;

    invoke-direct {p1, p0, p0}, Liyy;-><init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroidx/constraintlayout/widget/ConstraintLayout;)V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:Liyy;

    .line 96
    invoke-direct {p0, p2, p3, p4}, Landroidx/constraintlayout/widget/ConstraintLayout;->e(Landroid/util/AttributeSet;II)V

    return-void
.end method

.method private final e(Landroid/util/AttributeSet;II)V
    .locals 6

    .line 1
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    .line 3
    iput-object p0, v0, Lixs;->aq:Ljava/lang/Object;

    .line 5
    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:Liyy;

    .line 7
    invoke-virtual {v0, v1}, Lixt;->ag(Liyd;)V

    .line 10
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->a:Landroid/util/SparseArray;

    .line 12
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getId()I

    .line 15
    move-result v1

    .line 16
    invoke-virtual {v0, v1, p0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 19
    const/4 v0, 0x0

    .line 20
    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lizi;

    .line 22
    if-eqz p1, :cond_8

    .line 24
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getContext()Landroid/content/Context;

    .line 27
    move-result-object v1

    .line 28
    sget-object v2, Lizn;->b:[I

    .line 30
    invoke-virtual {v1, p1, v2, p2, p3}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 33
    move-result-object p1

    .line 34
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    .line 37
    move-result p2

    .line 38
    const/4 p3, 0x0

    .line 39
    move v1, p3

    .line 40
    :goto_0
    if-ge v1, p2, :cond_7

    .line 42
    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getIndex(I)I

    .line 45
    move-result v2

    .line 46
    const/16 v3, 0x10

    .line 48
    if-ne v2, v3, :cond_0

    .line 50
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    .line 52
    invoke-virtual {p1, v3, v2}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 55
    move-result v2

    .line 56
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    .line 58
    goto/16 :goto_2

    .line 60
    :cond_0
    const/16 v3, 0x11

    .line 62
    if-ne v2, v3, :cond_1

    .line 64
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:I

    .line 66
    invoke-virtual {p1, v3, v2}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 69
    move-result v2

    .line 70
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:I

    .line 72
    goto :goto_2

    .line 73
    :cond_1
    const/16 v3, 0xe

    .line 75
    if-ne v2, v3, :cond_2

    .line 77
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    .line 79
    invoke-virtual {p1, v3, v2}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 82
    move-result v2

    .line 83
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    .line 85
    goto :goto_2

    .line 86
    :cond_2
    const/16 v3, 0xf

    .line 88
    if-ne v2, v3, :cond_3

    .line 90
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:I

    .line 92
    invoke-virtual {p1, v3, v2}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 95
    move-result v2

    .line 96
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:I

    .line 98
    goto :goto_2

    .line 99
    :cond_3
    const/16 v3, 0x71

    .line 101
    if-ne v2, v3, :cond_4

    .line 103
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    .line 105
    invoke-virtual {p1, v3, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 108
    move-result v2

    .line 109
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    .line 111
    goto :goto_2

    .line 112
    :cond_4
    const/16 v3, 0x38

    .line 114
    if-ne v2, v3, :cond_5

    .line 116
    invoke-virtual {p1, v3, p3}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 119
    move-result v2

    .line 120
    if-eqz v2, :cond_6

    .line 122
    :try_start_0
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getContext()Landroid/content/Context;

    .line 125
    move-result-object v3

    .line 126
    new-instance v4, Landroid/util/SparseArray;

    .line 128
    invoke-direct {v4}, Landroid/util/SparseArray;-><init>()V

    .line 131
    new-instance v5, Landroid/util/SparseArray;

    .line 133
    invoke-direct {v5}, Landroid/util/SparseArray;-><init>()V

    .line 136
    invoke-static {v3, v2, v4, v5}, Lizb;->a(Landroid/content/Context;ILandroid/util/SparseArray;Landroid/util/SparseArray;)V

    .line 139
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_1

    goto :goto_2

    .line 140
    :cond_5
    const/16 v3, 0x22

    .line 142
    if-ne v2, v3, :cond_6

    .line 144
    invoke-virtual {p1, v3, p3}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 147
    move-result v2

    .line 148
    :try_start_1
    new-instance v3, Lizi;

    .line 150
    invoke-direct {v3}, Lizi;-><init>()V

    .line 153
    iput-object v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lizi;

    .line 155
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getContext()Landroid/content/Context;

    .line 158
    move-result-object v4

    .line 159
    invoke-virtual {v3, v4, v2}, Lizi;->h(Landroid/content/Context;I)V

    .line 162
    :try_end_1
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_1

    .line 163
    :catch_0
    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lizi;

    .line 165
    :goto_1
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->m:I

    .line 167
    :catch_1
    :cond_6
    :goto_2
    add-int/lit8 v1, v1, 0x1

    .line 169
    goto/16 :goto_0

    .line 171
    :cond_7
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 174
    :cond_8
    iget-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    .line 176
    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    .line 178
    invoke-virtual {p1, p0}, Lixt;->ah(I)V

    .line 181
    return-void
.end method

.method private final f()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Z

    .line 4
    return-void
.end method

.method private final g()V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 3
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->isInEditMode()Z

    .line 6
    move-result v6

    .line 7
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildCount()I

    .line 10
    move-result v7

    .line 11
    const/4 v8, 0x0

    .line 12
    move v1, v8

    .line 13
    :goto_0
    if-ge v1, v7, :cond_1

    .line 15
    invoke-virtual {v0, v1}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildAt(I)Landroid/view/View;

    .line 18
    move-result-object v2

    .line 19
    invoke-virtual {v0, v2}, Landroidx/constraintlayout/widget/ConstraintLayout;->fp(Landroid/view/View;)Lixs;

    .line 22
    move-result-object v2

    .line 23
    if-eqz v2, :cond_0

    .line 25
    invoke-virtual {v2}, Lixs;->v()V

    .line 28
    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 30
    goto :goto_0

    .line 31
    :cond_1
    const/4 v1, 0x0

    .line 32
    const/4 v9, -0x1

    .line 33
    if-eqz v6, :cond_a

    .line 35
    move v2, v8

    .line 36
    :goto_1
    if-ge v2, v7, :cond_a

    .line 38
    invoke-virtual {v0, v2}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildAt(I)Landroid/view/View;

    .line 41
    move-result-object v3

    .line 42
    :try_start_0
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getResources()Landroid/content/res/Resources;

    .line 45
    move-result-object v4

    .line 46
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    .line 49
    move-result v5

    .line 50
    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    .line 53
    move-result-object v4

    .line 54
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    .line 57
    move-result v5

    .line 58
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 61
    move-result-object v10

    .line 62
    instance-of v11, v4, Ljava/lang/String;

    .line 64
    if-eqz v11, :cond_4

    .line 66
    iget-object v11, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    .line 68
    if-nez v11, :cond_2

    .line 70
    new-instance v11, Ljava/util/HashMap;

    .line 72
    invoke-direct {v11}, Ljava/util/HashMap;-><init>()V

    .line 75
    iput-object v11, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    .line 77
    :cond_2
    const-string v11, "/"

    .line 79
    invoke-virtual {v4, v11}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    .line 82
    move-result v11

    .line 83
    if-eq v11, v9, :cond_3

    .line 85
    add-int/lit8 v11, v11, 0x1

    .line 87
    invoke-virtual {v4, v11}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 90
    move-result-object v11

    .line 91
    goto :goto_2

    .line 92
    :cond_3
    move-object v11, v4

    .line 93
    :goto_2
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 96
    iget-object v10, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    .line 98
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 101
    move-result-object v5

    .line 102
    invoke-virtual {v10, v11, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 105
    :cond_4
    const/16 v5, 0x2f

    .line 107
    invoke-virtual {v4, v5}, Ljava/lang/String;->indexOf(I)I

    .line 110
    move-result v5

    .line 111
    if-eq v5, v9, :cond_5

    .line 113
    add-int/lit8 v5, v5, 0x1

    .line 115
    invoke-virtual {v4, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 118
    move-result-object v4

    .line 119
    :cond_5
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    .line 122
    move-result v3

    .line 123
    if-nez v3, :cond_6

    .line 125
    iget-object v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    .line 127
    goto :goto_3

    .line 128
    :cond_6
    iget-object v5, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->a:Landroid/util/SparseArray;

    .line 130
    invoke-virtual {v5, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 133
    move-result-object v5

    .line 134
    check-cast v5, Landroid/view/View;

    .line 136
    if-nez v5, :cond_7

    .line 138
    invoke-virtual {v0, v3}, Landroidx/constraintlayout/widget/ConstraintLayout;->findViewById(I)Landroid/view/View;

    .line 141
    move-result-object v5

    .line 142
    if-eqz v5, :cond_7

    .line 144
    if-eq v5, v0, :cond_7

    .line 146
    invoke-virtual {v5}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 149
    move-result-object v3

    .line 150
    if-ne v3, v0, :cond_7

    .line 152
    invoke-virtual {v0, v5}, Landroidx/constraintlayout/widget/ConstraintLayout;->onViewAdded(Landroid/view/View;)V

    .line 155
    :cond_7
    if-ne v5, v0, :cond_8

    .line 157
    iget-object v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    .line 159
    goto :goto_3

    .line 160
    :cond_8
    if-nez v5, :cond_9

    .line 162
    move-object v3, v1

    .line 163
    goto :goto_3

    .line 164
    :cond_9
    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 167
    move-result-object v3

    .line 168
    check-cast v3, Liyx;

    .line 170
    iget-object v3, v3, Liyx;->av:Lixs;

    .line 172
    :goto_3
    iput-object v4, v3, Lixs;->as:Ljava/lang/String;

    .line 174
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    add-int/lit8 v2, v2, 0x1

    .line 176
    goto/16 :goto_1

    .line 178
    :cond_a
    iget v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->m:I

    .line 180
    if-eq v2, v9, :cond_c

    .line 182
    move v2, v8

    .line 183
    :goto_4
    if-ge v2, v7, :cond_c

    .line 185
    invoke-virtual {v0, v2}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildAt(I)Landroid/view/View;

    .line 188
    move-result-object v3

    .line 189
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    .line 192
    move-result v4

    .line 193
    iget v5, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->m:I

    .line 195
    if-ne v4, v5, :cond_b

    .line 197
    instance-of v4, v3, Lizj;

    .line 199
    if-eqz v4, :cond_b

    .line 201
    check-cast v3, Lizj;

    .line 203
    invoke-virtual {v3}, Lizj;->getConstraintSet()Lizi;

    .line 206
    move-result-object v3

    .line 207
    iput-object v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lizi;

    .line 209
    :cond_b
    add-int/lit8 v2, v2, 0x1

    .line 211
    goto :goto_4

    .line 212
    :cond_c
    iget-object v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lizi;

    .line 214
    if-eqz v2, :cond_d

    .line 216
    invoke-virtual {v2, v0}, Lizi;->m(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    .line 219
    :cond_d
    iget-object v10, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    .line 221
    invoke-virtual {v10}, Liya;->ap()V

    .line 224
    iget-object v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Ljava/util/ArrayList;

    .line 226
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 229
    move-result v3

    .line 230
    if-lez v3, :cond_13

    .line 232
    move v4, v8

    .line 233
    :goto_5
    if-ge v4, v3, :cond_13

    .line 235
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 238
    move-result-object v5

    .line 239
    check-cast v5, Liyv;

    .line 241
    invoke-virtual {v5}, Liyv;->isInEditMode()Z

    .line 244
    move-result v11

    .line 245
    if-eqz v11, :cond_e

    .line 247
    iget-object v11, v5, Liyv;->d:Ljava/lang/String;

    .line 249
    invoke-virtual {v5, v11}, Liyv;->setIds(Ljava/lang/String;)V

    .line 252
    :cond_e
    iget-object v11, v5, Liyv;->g:Lixx;

    .line 254
    if-nez v11, :cond_f

    .line 256
    goto :goto_7

    .line 257
    :cond_f
    iput v8, v11, Lixx;->aM:I

    .line 259
    iget-object v11, v11, Lixx;->aL:[Lixs;

    .line 261
    invoke-static {v11, v1}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    .line 264
    move v11, v8

    .line 265
    :goto_6
    iget v12, v5, Liyv;->b:I

    .line 267
    if-ge v11, v12, :cond_12

    .line 269
    iget-object v12, v5, Liyv;->a:[I

    .line 271
    aget v12, v12, v11

    .line 273
    invoke-virtual {v0, v12}, Landroidx/constraintlayout/widget/ConstraintLayout;->fo(I)Landroid/view/View;

    .line 276
    move-result-object v13

    .line 277
    if-nez v13, :cond_10

    .line 279
    iget-object v14, v5, Liyv;->f:Ljava/util/HashMap;

    .line 281
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 284
    move-result-object v12

    .line 285
    invoke-virtual {v14, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 288
    move-result-object v12

    .line 289
    check-cast v12, Ljava/lang/String;

    .line 291
    invoke-virtual {v5, v0, v12}, Liyv;->d(Landroidx/constraintlayout/widget/ConstraintLayout;Ljava/lang/String;)I

    .line 294
    move-result v15

    .line 295
    if-eqz v15, :cond_10

    .line 297
    iget-object v13, v5, Liyv;->a:[I

    .line 299
    aput v15, v13, v11

    .line 301
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 304
    move-result-object v13

    .line 305
    invoke-virtual {v14, v13, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 308
    invoke-virtual {v0, v15}, Landroidx/constraintlayout/widget/ConstraintLayout;->fo(I)Landroid/view/View;

    .line 311
    move-result-object v13

    .line 312
    :cond_10
    if-eqz v13, :cond_11

    .line 314
    iget-object v12, v5, Liyv;->g:Lixx;

    .line 316
    invoke-virtual {v0, v13}, Landroidx/constraintlayout/widget/ConstraintLayout;->fp(Landroid/view/View;)Lixs;

    .line 319
    move-result-object v13

    .line 320
    invoke-virtual {v12, v13}, Lixx;->ag(Lixs;)V

    .line 323
    :cond_11
    add-int/lit8 v11, v11, 0x1

    .line 325
    goto :goto_6

    .line 326
    :cond_12
    iget-object v5, v5, Liyv;->g:Lixx;

    .line 328
    invoke-virtual {v5}, Lixx;->ai()V

    .line 331
    :goto_7
    add-int/lit8 v4, v4, 0x1

    .line 333
    goto :goto_5

    .line 334
    :cond_13
    move v2, v8

    .line 335
    :goto_8
    if-ge v2, v7, :cond_15

    .line 337
    invoke-virtual {v0, v2}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildAt(I)Landroid/view/View;

    .line 340
    move-result-object v3

    .line 341
    instance-of v4, v3, Lizl;

    .line 343
    if-nez v4, :cond_14

    .line 345
    add-int/lit8 v2, v2, 0x1

    .line 347
    goto :goto_8

    .line 348
    :cond_14
    check-cast v3, Lizl;

    .line 350
    throw v1

    .line 351
    :cond_15
    iget-object v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->o:Landroid/util/SparseArray;

    .line 353
    invoke-virtual {v3}, Landroid/util/SparseArray;->clear()V

    .line 356
    invoke-virtual {v3, v8, v10}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 359
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getId()I

    .line 362
    move-result v1

    .line 363
    invoke-virtual {v3, v1, v10}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 366
    move v1, v8

    .line 367
    :goto_9
    if-ge v1, v7, :cond_16

    .line 369
    invoke-virtual {v0, v1}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildAt(I)Landroid/view/View;

    .line 372
    move-result-object v2

    .line 373
    invoke-virtual {v0, v2}, Landroidx/constraintlayout/widget/ConstraintLayout;->fp(Landroid/view/View;)Lixs;

    .line 376
    move-result-object v4

    .line 377
    invoke-virtual {v2}, Landroid/view/View;->getId()I

    .line 380
    move-result v2

    .line 381
    invoke-virtual {v3, v2, v4}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 384
    add-int/lit8 v1, v1, 0x1

    .line 386
    goto :goto_9

    .line 387
    :cond_16
    move v11, v8

    .line 388
    :goto_a
    if-ge v11, v7, :cond_37

    .line 390
    invoke-virtual {v0, v11}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildAt(I)Landroid/view/View;

    .line 393
    move-result-object v1

    .line 394
    invoke-virtual {v0, v1}, Landroidx/constraintlayout/widget/ConstraintLayout;->fp(Landroid/view/View;)Lixs;

    .line 397
    move-result-object v12

    .line 398
    if-nez v12, :cond_18

    .line 400
    :cond_17
    :goto_b
    move v0, v8

    .line 401
    goto/16 :goto_16

    .line 403
    :cond_18
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 406
    move-result-object v2

    .line 407
    check-cast v2, Liyx;

    .line 409
    invoke-virtual {v10, v12}, Liya;->an(Lixs;)V

    .line 412
    invoke-virtual {v2}, Liyx;->a()V

    .line 415
    iput-boolean v8, v2, Liyx;->aw:Z

    .line 417
    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    .line 420
    move-result v4

    .line 421
    iput v4, v12, Lixs;->ar:I

    .line 423
    iget-boolean v4, v2, Liyx;->aj:Z

    .line 425
    iput-object v1, v12, Lixs;->aq:Ljava/lang/Object;

    .line 427
    instance-of v4, v1, Liyv;

    .line 429
    if-eqz v4, :cond_19

    .line 431
    check-cast v1, Liyv;

    .line 433
    iget-boolean v4, v10, Lixt;->e:Z

    .line 435
    invoke-virtual {v1, v12, v4}, Liyv;->c(Lixs;Z)V

    .line 438
    :cond_19
    iget-boolean v1, v2, Liyx;->ah:Z

    .line 440
    if-eqz v1, :cond_1c

    .line 442
    check-cast v12, Lixw;

    .line 444
    iget v1, v2, Liyx;->as:I

    .line 446
    iget v4, v2, Liyx;->at:I

    .line 448
    iget v2, v2, Liyx;->au:F

    .line 450
    const/high16 v5, -0x40800000    # -1.0f

    .line 452
    cmpl-float v5, v2, v5

    .line 454
    if-eqz v5, :cond_1a

    .line 456
    invoke-virtual {v12, v2}, Lixw;->ag(F)V

    .line 459
    goto :goto_b

    .line 460
    :cond_1a
    if-eq v1, v9, :cond_1b

    .line 462
    invoke-virtual {v12, v1}, Lixw;->c(I)V

    .line 465
    goto :goto_b

    .line 466
    :cond_1b
    if-eq v4, v9, :cond_17

    .line 468
    invoke-virtual {v12, v4}, Lixw;->af(I)V

    .line 471
    goto :goto_b

    .line 472
    :cond_1c
    iget v1, v2, Liyx;->al:I

    .line 474
    iget v4, v2, Liyx;->am:I

    .line 476
    iget v5, v2, Liyx;->an:I

    .line 478
    iget v13, v2, Liyx;->ao:I

    .line 480
    iget v14, v2, Liyx;->ap:I

    .line 482
    iget v15, v2, Liyx;->aq:I

    .line 484
    iget v8, v2, Liyx;->ar:F

    .line 486
    iget v0, v2, Liyx;->p:I

    .line 488
    if-eq v0, v9, :cond_1d

    .line 490
    invoke-virtual {v3, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 493
    move-result-object v0

    .line 494
    check-cast v0, Lixs;

    .line 496
    if-eqz v0, :cond_2b

    .line 498
    iget v1, v2, Liyx;->r:F

    .line 500
    iget v4, v2, Liyx;->q:I

    .line 502
    invoke-virtual {v12, v0, v1, v4}, Lixs;->r(Lixs;FI)V

    .line 505
    goto/16 :goto_11

    .line 507
    :cond_1d
    if-eq v1, v9, :cond_1f

    .line 509
    invoke-virtual {v3, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 512
    move-result-object v0

    .line 513
    check-cast v0, Lixs;

    .line 515
    if-eqz v0, :cond_1e

    .line 517
    move/from16 v17, v15

    .line 519
    const/4 v15, 0x2

    .line 520
    iget v1, v2, Liyx;->leftMargin:I

    .line 522
    move v4, v13

    .line 523
    const/4 v13, 0x2

    .line 524
    move/from16 v16, v1

    .line 526
    move/from16 v1, v17

    .line 528
    move/from16 v17, v14

    .line 530
    move-object v14, v0

    .line 531
    move v0, v4

    .line 532
    invoke-virtual/range {v12 .. v17}, Lixs;->ab(ILixs;III)V

    .line 535
    goto :goto_c

    .line 536
    :cond_1e
    move v0, v13

    .line 537
    move v1, v15

    .line 538
    goto :goto_c

    .line 539
    :cond_1f
    move v0, v13

    .line 540
    move/from16 v17, v14

    .line 542
    move v1, v15

    .line 543
    if-eq v4, v9, :cond_20

    .line 545
    invoke-virtual {v3, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 548
    move-result-object v4

    .line 549
    move-object v14, v4

    .line 550
    check-cast v14, Lixs;

    .line 552
    if-eqz v14, :cond_20

    .line 554
    const/4 v15, 0x4

    .line 555
    iget v4, v2, Liyx;->leftMargin:I

    .line 557
    const/4 v13, 0x2

    .line 558
    move/from16 v16, v4

    .line 560
    invoke-virtual/range {v12 .. v17}, Lixs;->ab(ILixs;III)V

    .line 563
    :cond_20
    :goto_c
    if-eq v5, v9, :cond_21

    .line 565
    invoke-virtual {v3, v5}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 568
    move-result-object v0

    .line 569
    move-object v14, v0

    .line 570
    check-cast v14, Lixs;

    .line 572
    if-eqz v14, :cond_22

    .line 574
    const/4 v15, 0x2

    .line 575
    iget v0, v2, Liyx;->rightMargin:I

    .line 577
    const/4 v13, 0x4

    .line 578
    move/from16 v16, v0

    .line 580
    move/from16 v17, v1

    .line 582
    invoke-virtual/range {v12 .. v17}, Lixs;->ab(ILixs;III)V

    .line 585
    goto :goto_d

    .line 586
    :cond_21
    move/from16 v17, v1

    .line 588
    if-eq v0, v9, :cond_22

    .line 590
    invoke-virtual {v3, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 593
    move-result-object v0

    .line 594
    move-object v14, v0

    .line 595
    check-cast v14, Lixs;

    .line 597
    if-eqz v14, :cond_22

    .line 599
    const/4 v15, 0x4

    .line 600
    iget v0, v2, Liyx;->rightMargin:I

    .line 602
    const/4 v13, 0x4

    .line 603
    move/from16 v16, v0

    .line 605
    invoke-virtual/range {v12 .. v17}, Lixs;->ab(ILixs;III)V

    .line 608
    :cond_22
    :goto_d
    iget v0, v2, Liyx;->i:I

    .line 610
    if-eq v0, v9, :cond_23

    .line 612
    invoke-virtual {v3, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 615
    move-result-object v0

    .line 616
    move-object v14, v0

    .line 617
    check-cast v14, Lixs;

    .line 619
    if-eqz v14, :cond_24

    .line 621
    iget v0, v2, Liyx;->topMargin:I

    .line 623
    iget v1, v2, Liyx;->x:I

    .line 625
    const/4 v13, 0x3

    .line 626
    const/4 v15, 0x3

    .line 627
    move/from16 v16, v0

    .line 629
    move/from16 v17, v1

    .line 631
    invoke-virtual/range {v12 .. v17}, Lixs;->ab(ILixs;III)V

    .line 634
    goto :goto_e

    .line 635
    :cond_23
    iget v0, v2, Liyx;->j:I

    .line 637
    if-eq v0, v9, :cond_24

    .line 639
    invoke-virtual {v3, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 642
    move-result-object v0

    .line 643
    move-object v14, v0

    .line 644
    check-cast v14, Lixs;

    .line 646
    if-eqz v14, :cond_24

    .line 648
    iget v0, v2, Liyx;->topMargin:I

    .line 650
    iget v1, v2, Liyx;->x:I

    .line 652
    const/4 v13, 0x3

    .line 653
    const/4 v15, 0x5

    .line 654
    move/from16 v16, v0

    .line 656
    move/from16 v17, v1

    .line 658
    invoke-virtual/range {v12 .. v17}, Lixs;->ab(ILixs;III)V

    .line 661
    :cond_24
    :goto_e
    iget v0, v2, Liyx;->k:I

    .line 663
    if-eq v0, v9, :cond_25

    .line 665
    invoke-virtual {v3, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 668
    move-result-object v0

    .line 669
    move-object v14, v0

    .line 670
    check-cast v14, Lixs;

    .line 672
    if-eqz v14, :cond_26

    .line 674
    iget v0, v2, Liyx;->bottomMargin:I

    .line 676
    iget v1, v2, Liyx;->z:I

    .line 678
    const/4 v13, 0x5

    .line 679
    const/4 v15, 0x3

    .line 680
    move/from16 v16, v0

    .line 682
    move/from16 v17, v1

    .line 684
    invoke-virtual/range {v12 .. v17}, Lixs;->ab(ILixs;III)V

    .line 687
    goto :goto_f

    .line 688
    :cond_25
    iget v0, v2, Liyx;->l:I

    .line 690
    if-eq v0, v9, :cond_26

    .line 692
    invoke-virtual {v3, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 695
    move-result-object v0

    .line 696
    move-object v14, v0

    .line 697
    check-cast v14, Lixs;

    .line 699
    if-eqz v14, :cond_26

    .line 701
    iget v0, v2, Liyx;->bottomMargin:I

    .line 703
    iget v1, v2, Liyx;->z:I

    .line 705
    const/4 v13, 0x5

    .line 706
    const/4 v15, 0x5

    .line 707
    move/from16 v16, v0

    .line 709
    move/from16 v17, v1

    .line 711
    invoke-virtual/range {v12 .. v17}, Lixs;->ab(ILixs;III)V

    .line 714
    :cond_26
    :goto_f
    iget v4, v2, Liyx;->m:I

    .line 716
    if-eq v4, v9, :cond_27

    .line 718
    const/4 v5, 0x6

    .line 719
    move-object/from16 v0, p0

    .line 721
    move-object v1, v12

    .line 722
    invoke-direct/range {v0 .. v5}, Landroidx/constraintlayout/widget/ConstraintLayout;->h(Lixs;Liyx;Landroid/util/SparseArray;II)V

    .line 725
    goto :goto_10

    .line 726
    :cond_27
    iget v4, v2, Liyx;->n:I

    .line 728
    if-eq v4, v9, :cond_28

    .line 730
    const/4 v5, 0x3

    .line 731
    move-object/from16 v0, p0

    .line 733
    move-object v1, v12

    .line 734
    invoke-direct/range {v0 .. v5}, Landroidx/constraintlayout/widget/ConstraintLayout;->h(Lixs;Liyx;Landroid/util/SparseArray;II)V

    .line 737
    goto :goto_10

    .line 738
    :cond_28
    iget v4, v2, Liyx;->o:I

    .line 740
    if-eq v4, v9, :cond_29

    .line 742
    const/4 v5, 0x5

    .line 743
    move-object/from16 v0, p0

    .line 745
    move-object v1, v12

    .line 746
    invoke-direct/range {v0 .. v5}, Landroidx/constraintlayout/widget/ConstraintLayout;->h(Lixs;Liyx;Landroid/util/SparseArray;II)V

    .line 749
    :cond_29
    :goto_10
    const/4 v0, 0x0

    .line 750
    cmpl-float v1, v8, v0

    .line 752
    if-ltz v1, :cond_2a

    .line 754
    iput v8, v12, Lixs;->ao:F

    .line 756
    :cond_2a
    iget v1, v2, Liyx;->H:F

    .line 758
    cmpl-float v0, v1, v0

    .line 760
    if-ltz v0, :cond_2b

    .line 762
    iput v1, v12, Lixs;->ap:F

    .line 764
    :cond_2b
    :goto_11
    if-eqz v6, :cond_2d

    .line 766
    iget v0, v2, Liyx;->X:I

    .line 768
    if-ne v0, v9, :cond_2c

    .line 770
    iget v0, v2, Liyx;->Y:I

    .line 772
    if-eq v0, v9, :cond_2d

    .line 774
    move v0, v9

    .line 775
    :cond_2c
    iget v1, v2, Liyx;->Y:I

    .line 777
    iput v0, v12, Lixs;->aj:I

    .line 779
    iput v1, v12, Lixs;->ak:I

    .line 781
    :cond_2d
    iget-boolean v0, v2, Liyx;->ae:Z

    .line 783
    const/4 v1, -0x2

    .line 784
    const/4 v4, 0x4

    .line 785
    const/4 v5, 0x2

    .line 786
    const/4 v8, 0x3

    .line 787
    const/4 v13, 0x1

    .line 788
    if-nez v0, :cond_30

    .line 790
    iget v0, v2, Liyx;->width:I

    .line 792
    if-ne v0, v9, :cond_2f

    .line 794
    iget-boolean v0, v2, Liyx;->aa:Z

    .line 796
    if-eqz v0, :cond_2e

    .line 798
    invoke-virtual {v12, v8}, Lixs;->ac(I)V

    .line 801
    goto :goto_12

    .line 802
    :cond_2e
    invoke-virtual {v12, v4}, Lixs;->ac(I)V

    .line 805
    :goto_12
    invoke-virtual {v12, v5}, Lixs;->W(I)Lixr;

    .line 808
    move-result-object v0

    .line 809
    iget v14, v2, Liyx;->leftMargin:I

    .line 811
    iput v14, v0, Lixr;->f:I

    .line 813
    invoke-virtual {v12, v4}, Lixs;->W(I)Lixr;

    .line 816
    move-result-object v0

    .line 817
    iget v14, v2, Liyx;->rightMargin:I

    .line 819
    iput v14, v0, Lixr;->f:I

    .line 821
    goto :goto_13

    .line 822
    :cond_2f
    invoke-virtual {v12, v8}, Lixs;->ac(I)V

    .line 825
    const/4 v0, 0x0

    .line 826
    invoke-virtual {v12, v0}, Lixs;->O(I)V

    .line 829
    goto :goto_13

    .line 830
    :cond_30
    invoke-virtual {v12, v13}, Lixs;->ac(I)V

    .line 833
    iget v0, v2, Liyx;->width:I

    .line 835
    invoke-virtual {v12, v0}, Lixs;->O(I)V

    .line 838
    iget v0, v2, Liyx;->width:I

    .line 840
    if-ne v0, v1, :cond_31

    .line 842
    invoke-virtual {v12, v5}, Lixs;->ac(I)V

    .line 845
    :cond_31
    :goto_13
    iget-boolean v0, v2, Liyx;->af:Z

    .line 847
    if-nez v0, :cond_34

    .line 849
    iget v0, v2, Liyx;->height:I

    .line 851
    if-ne v0, v9, :cond_33

    .line 853
    iget-boolean v0, v2, Liyx;->ab:Z

    .line 855
    if-eqz v0, :cond_32

    .line 857
    invoke-virtual {v12, v8}, Lixs;->ad(I)V

    .line 860
    goto :goto_14

    .line 861
    :cond_32
    invoke-virtual {v12, v4}, Lixs;->ad(I)V

    .line 864
    :goto_14
    invoke-virtual {v12, v8}, Lixs;->W(I)Lixr;

    .line 867
    move-result-object v0

    .line 868
    iget v1, v2, Liyx;->topMargin:I

    .line 870
    iput v1, v0, Lixr;->f:I

    .line 872
    const/4 v0, 0x5

    .line 873
    invoke-virtual {v12, v0}, Lixs;->W(I)Lixr;

    .line 876
    move-result-object v0

    .line 877
    iget v1, v2, Liyx;->bottomMargin:I

    .line 879
    iput v1, v0, Lixr;->f:I

    .line 881
    const/4 v0, 0x0

    .line 882
    goto :goto_15

    .line 883
    :cond_33
    invoke-virtual {v12, v8}, Lixs;->ad(I)V

    .line 886
    const/4 v0, 0x0

    .line 887
    invoke-virtual {v12, v0}, Lixs;->D(I)V

    .line 890
    goto :goto_15

    .line 891
    :cond_34
    const/4 v0, 0x0

    .line 892
    invoke-virtual {v12, v13}, Lixs;->ad(I)V

    .line 895
    iget v4, v2, Liyx;->height:I

    .line 897
    invoke-virtual {v12, v4}, Lixs;->D(I)V

    .line 900
    iget v4, v2, Liyx;->height:I

    .line 902
    if-ne v4, v1, :cond_35

    .line 904
    invoke-virtual {v12, v5}, Lixs;->ad(I)V

    .line 907
    :cond_35
    :goto_15
    iget-object v1, v2, Liyx;->I:Ljava/lang/String;

    .line 909
    invoke-virtual {v12, v1}, Lixs;->A(Ljava/lang/String;)V

    .line 912
    iget v1, v2, Liyx;->L:F

    .line 914
    invoke-virtual {v12, v1}, Lixs;->F(F)V

    .line 917
    iget v1, v2, Liyx;->M:F

    .line 919
    invoke-virtual {v12, v1}, Lixs;->N(F)V

    .line 922
    iget v1, v2, Liyx;->N:I

    .line 924
    iput v1, v12, Lixs;->at:I

    .line 926
    iget v1, v2, Liyx;->O:I

    .line 928
    iput v1, v12, Lixs;->au:I

    .line 930
    iget v1, v2, Liyx;->ad:I

    .line 932
    if-ltz v1, :cond_36

    .line 934
    if-gt v1, v8, :cond_36

    .line 936
    iput v1, v12, Lixs;->B:I

    .line 938
    :cond_36
    iget v1, v2, Liyx;->P:I

    .line 940
    iget v4, v2, Liyx;->R:I

    .line 942
    iget v5, v2, Liyx;->T:I

    .line 944
    iget v8, v2, Liyx;->V:F

    .line 946
    invoke-virtual {v12, v1, v4, v5, v8}, Lixs;->E(IIIF)V

    .line 949
    iget v1, v2, Liyx;->Q:I

    .line 951
    iget v4, v2, Liyx;->S:I

    .line 953
    iget v5, v2, Liyx;->U:I

    .line 955
    iget v2, v2, Liyx;->W:F

    .line 957
    invoke-virtual {v12, v1, v4, v5, v2}, Lixs;->M(IIIF)V

    .line 960
    :goto_16
    add-int/lit8 v11, v11, 0x1

    .line 962
    move v8, v0

    .line 963
    move-object/from16 v0, p0

    .line 965
    goto/16 :goto_a

    .line 967
    :cond_37
    return-void
.end method

.method public static getSharedValues()Lizo;
    .locals 1

    .line 1
    sget-object v0, Landroidx/constraintlayout/widget/ConstraintLayout;->g:Lizo;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, Lizo;

    .line 7
    invoke-direct {v0}, Lizo;-><init>()V

    .line 10
    sput-object v0, Landroidx/constraintlayout/widget/ConstraintLayout;->g:Lizo;

    .line 12
    :cond_0
    return-object v0
.end method

.method private final h(Lixs;Liyx;Landroid/util/SparseArray;II)V
    .locals 1

    .line 1
    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->a:Landroid/util/SparseArray;

    .line 3
    invoke-virtual {p0, p4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Landroid/view/View;

    .line 9
    invoke-virtual {p3, p4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 12
    move-result-object p3

    .line 13
    check-cast p3, Lixs;

    .line 15
    if-eqz p3, :cond_1

    .line 17
    if-eqz p0, :cond_1

    .line 19
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 22
    move-result-object p4

    .line 23
    instance-of p4, p4, Liyx;

    .line 25
    if-eqz p4, :cond_1

    .line 27
    const/4 p4, 0x1

    .line 28
    iput-boolean p4, p2, Liyx;->ag:Z

    .line 30
    const/4 v0, 0x6

    .line 31
    if-ne p5, v0, :cond_0

    .line 33
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 36
    move-result-object p0

    .line 37
    check-cast p0, Liyx;

    .line 39
    iput-boolean p4, p0, Liyx;->ag:Z

    .line 41
    iget-object p0, p0, Liyx;->av:Lixs;

    .line 43
    iput-boolean p4, p0, Lixs;->P:Z

    .line 45
    :cond_0
    invoke-virtual {p1, v0}, Lixs;->W(I)Lixr;

    .line 48
    move-result-object p0

    .line 49
    invoke-virtual {p3, p5}, Lixs;->W(I)Lixr;

    .line 52
    move-result-object p3

    .line 53
    iget p5, p2, Liyx;->D:I

    .line 55
    iget p2, p2, Liyx;->C:I

    .line 57
    invoke-virtual {p0, p3, p5, p2, p4}, Lixr;->l(Lixr;IIZ)V

    .line 60
    iput-boolean p4, p1, Lixs;->P:Z

    .line 62
    const/4 p0, 0x3

    .line 63
    invoke-virtual {p1, p0}, Lixs;->W(I)Lixr;

    .line 66
    move-result-object p0

    .line 67
    invoke-virtual {p0}, Lixr;->e()V

    .line 70
    const/4 p0, 0x5

    .line 71
    invoke-virtual {p1, p0}, Lixs;->W(I)Lixr;

    .line 74
    move-result-object p0

    .line 75
    invoke-virtual {p0}, Lixr;->e()V

    .line 78
    :cond_1
    return-void
.end method


# virtual methods
.method protected final checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 0

    .line 1
    instance-of p0, p1, Liyx;

    .line 3
    return p0
.end method

.method protected dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Ljava/util/ArrayList;

    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v1, :cond_0

    .line 8
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 11
    move-result v3

    .line 12
    if-lez v3, :cond_0

    .line 14
    move v4, v2

    .line 15
    :goto_0
    if-ge v4, v3, :cond_0

    .line 17
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 20
    move-result-object v5

    .line 21
    check-cast v5, Liyv;

    .line 23
    add-int/lit8 v4, v4, 0x1

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    invoke-super/range {p0 .. p1}, Landroid/view/ViewGroup;->dispatchDraw(Landroid/graphics/Canvas;)V

    .line 29
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->isInEditMode()Z

    .line 32
    move-result v1

    .line 33
    if-eqz v1, :cond_3

    .line 35
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getWidth()I

    .line 38
    move-result v1

    .line 39
    int-to-float v1, v1

    .line 40
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getHeight()I

    .line 43
    move-result v3

    .line 44
    int-to-float v3, v3

    .line 45
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildCount()I

    .line 48
    move-result v4

    .line 49
    move v5, v2

    .line 50
    :goto_1
    if-ge v5, v4, :cond_3

    .line 52
    invoke-virtual {v0, v5}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildAt(I)Landroid/view/View;

    .line 55
    move-result-object v6

    .line 56
    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    .line 59
    move-result v7

    .line 60
    const/16 v8, 0x8

    .line 62
    if-ne v7, v8, :cond_1

    .line 64
    goto/16 :goto_2

    .line 66
    :cond_1
    invoke-virtual {v6}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 69
    move-result-object v6

    .line 70
    if-eqz v6, :cond_2

    .line 72
    instance-of v7, v6, Ljava/lang/String;

    .line 74
    if-eqz v7, :cond_2

    .line 76
    check-cast v6, Ljava/lang/String;

    .line 78
    const-string v7, ","

    .line 80
    invoke-virtual {v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 83
    move-result-object v6

    .line 84
    array-length v7, v6

    .line 85
    const/4 v8, 0x4

    .line 86
    if-ne v7, v8, :cond_2

    .line 88
    aget-object v7, v6, v2

    .line 90
    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 93
    move-result v7

    .line 94
    const/4 v8, 0x1

    .line 95
    aget-object v8, v6, v8

    .line 97
    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 100
    move-result v8

    .line 101
    const/4 v9, 0x2

    .line 102
    aget-object v9, v6, v9

    .line 104
    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 107
    move-result v9

    .line 108
    const/4 v10, 0x3

    .line 109
    aget-object v6, v6, v10

    .line 111
    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 114
    move-result v6

    .line 115
    int-to-float v7, v7

    .line 116
    const/high16 v10, 0x44870000    # 1080.0f

    .line 118
    div-float/2addr v7, v10

    .line 119
    mul-float/2addr v7, v1

    .line 120
    int-to-float v8, v8

    .line 121
    const/high16 v11, 0x44f00000    # 1920.0f

    .line 123
    div-float/2addr v8, v11

    .line 124
    mul-float/2addr v8, v3

    .line 125
    int-to-float v9, v9

    .line 126
    div-float/2addr v9, v10

    .line 127
    mul-float/2addr v9, v1

    .line 128
    int-to-float v6, v6

    .line 129
    div-float/2addr v6, v11

    .line 130
    mul-float/2addr v6, v3

    .line 131
    new-instance v15, Landroid/graphics/Paint;

    .line 133
    invoke-direct {v15}, Landroid/graphics/Paint;-><init>()V

    .line 136
    const/high16 v10, -0x10000

    .line 138
    invoke-virtual {v15, v10}, Landroid/graphics/Paint;->setColor(I)V

    .line 141
    float-to-int v8, v8

    .line 142
    float-to-int v7, v7

    .line 143
    float-to-int v9, v9

    .line 144
    add-int/2addr v9, v7

    .line 145
    int-to-float v13, v9

    .line 146
    int-to-float v11, v7

    .line 147
    int-to-float v12, v8

    .line 148
    move v14, v12

    .line 149
    move-object/from16 v10, p1

    .line 151
    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 154
    move v7, v11

    .line 155
    float-to-int v6, v6

    .line 156
    add-int/2addr v8, v6

    .line 157
    int-to-float v14, v8

    .line 158
    move v11, v13

    .line 159
    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 162
    move v6, v12

    .line 163
    move v12, v14

    .line 164
    move v13, v7

    .line 165
    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 168
    move v7, v11

    .line 169
    move v11, v13

    .line 170
    move v14, v6

    .line 171
    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 174
    move/from16 v16, v14

    .line 176
    move v14, v12

    .line 177
    move/from16 v12, v16

    .line 179
    const v6, -0xff0100

    .line 182
    invoke-virtual {v15, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 185
    move v13, v7

    .line 186
    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 189
    move/from16 v16, v14

    .line 191
    move v14, v12

    .line 192
    move/from16 v12, v16

    .line 194
    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 197
    :cond_2
    :goto_2
    add-int/lit8 v5, v5, 0x1

    .line 199
    goto/16 :goto_1

    .line 201
    :cond_3
    return-void
.end method

.method public final fo(I)Landroid/view/View;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->a:Landroid/util/SparseArray;

    .line 3
    invoke-virtual {p0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Landroid/view/View;

    .line 9
    return-object p0
.end method

.method public final forceLayout()V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->f()V

    .line 4
    invoke-super {p0}, Landroid/view/ViewGroup;->forceLayout()V

    .line 7
    return-void
.end method

.method public final fp(Landroid/view/View;)Lixs;
    .locals 1

    .line 1
    if-ne p1, p0, :cond_0

    .line 3
    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    .line 5
    return-object p0

    .line 6
    :cond_0
    if-eqz p1, :cond_2

    .line 8
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 11
    move-result-object p0

    .line 12
    instance-of p0, p0, Liyx;

    .line 14
    if-eqz p0, :cond_1

    .line 16
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 19
    move-result-object p0

    .line 20
    check-cast p0, Liyx;

    .line 22
    iget-object p0, p0, Liyx;->av:Lixs;

    .line 24
    return-object p0

    .line 25
    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 28
    move-result-object p0

    .line 29
    new-instance v0, Liyx;

    .line 31
    invoke-direct {v0, p0}, Liyx;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    .line 34
    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 37
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 40
    move-result-object p0

    .line 41
    instance-of p0, p0, Liyx;

    .line 43
    if-eqz p0, :cond_2

    .line 45
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 48
    move-result-object p0

    .line 49
    check-cast p0, Liyx;

    .line 51
    iget-object p0, p0, Liyx;->av:Lixs;

    .line 53
    return-object p0

    .line 54
    :cond_2
    const/4 p0, 0x0

    .line 55
    return-object p0
.end method

.method protected final fq()Z
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getContext()Landroid/content/Context;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 8
    move-result-object v0

    .line 9
    iget v0, v0, Landroid/content/pm/ApplicationInfo;->flags:I

    .line 11
    const/high16 v1, 0x400000

    .line 13
    and-int/2addr v0, v1

    .line 14
    if-eqz v0, :cond_0

    .line 16
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getLayoutDirection()I

    .line 19
    move-result p0

    .line 20
    const/4 v0, 0x1

    .line 21
    if-ne p0, v0, :cond_0

    .line 23
    return v0

    .line 24
    :cond_0
    const/4 p0, 0x0

    .line 25
    return p0
.end method

.method public final fr(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    instance-of v0, p1, Ljava/lang/String;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    .line 7
    if-eqz v0, :cond_0

    .line 9
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 15
    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    .line 17
    invoke-virtual {p0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    move-result-object p0

    .line 21
    return-object p0

    .line 22
    :cond_0
    const/4 p0, 0x0

    .line 23
    return-object p0
.end method

.method protected final synthetic generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 0

    .line 1
    new-instance p0, Liyx;

    .line 3
    invoke-direct {p0}, Liyx;-><init>()V

    .line 6
    return-object p0
.end method

.method public final bridge synthetic generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    .line 1
    new-instance v0, Liyx;

    .line 3
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getContext()Landroid/content/Context;

    .line 6
    move-result-object p0

    .line 7
    invoke-direct {v0, p0, p1}, Liyx;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 10
    return-object v0
.end method

.method protected final generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 0

    .line 11
    new-instance p0, Liyx;

    invoke-direct {p0, p1}, Liyx;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p0
.end method

.method public getMaxHeight()I
    .locals 0

    .line 1
    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:I

    .line 3
    return p0
.end method

.method public getMaxWidth()I
    .locals 0

    .line 1
    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    .line 3
    return p0
.end method

.method public getMinHeight()I
    .locals 0

    .line 1
    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:I

    .line 3
    return p0
.end method

.method public getMinWidth()I
    .locals 0

    .line 1
    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    .line 3
    return p0
.end method

.method public getOptimizationLevel()I
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    .line 3
    iget p0, p0, Lixt;->aC:I

    .line 5
    return p0
.end method

.method public getSceneString()Ljava/lang/String;
    .locals 11

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 6
    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    .line 8
    iget-object v2, v1, Lixt;->v:Ljava/lang/String;

    .line 10
    const/4 v3, -0x1

    .line 11
    if-nez v2, :cond_1

    .line 13
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getId()I

    .line 16
    move-result v2

    .line 17
    if-eq v2, v3, :cond_0

    .line 19
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getContext()Landroid/content/Context;

    .line 22
    move-result-object v4

    .line 23
    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 26
    move-result-object v4

    .line 27
    invoke-virtual {v4, v2}, Landroid/content/res/Resources;->getResourceEntryName(I)Ljava/lang/String;

    .line 30
    move-result-object v2

    .line 31
    iput-object v2, v1, Lixt;->v:Ljava/lang/String;

    .line 33
    goto :goto_0

    .line 34
    :cond_0
    const-string v2, "parent"

    .line 36
    iput-object v2, v1, Lixt;->v:Ljava/lang/String;

    .line 38
    :cond_1
    :goto_0
    iget-object v2, v1, Lixs;->as:Ljava/lang/String;

    .line 40
    const-string v4, "ConstraintLayout"

    .line 42
    const-string v5, " setDebugName "

    .line 44
    if-nez v2, :cond_2

    .line 46
    iget-object v2, v1, Lixt;->v:Ljava/lang/String;

    .line 48
    iput-object v2, v1, Lixs;->as:Ljava/lang/String;

    .line 50
    iget-object v2, v1, Lixs;->as:Ljava/lang/String;

    .line 52
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 55
    move-result-object v2

    .line 56
    invoke-virtual {v5, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 59
    move-result-object v2

    .line 60
    invoke-static {v4, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 63
    :cond_2
    iget-object v2, v1, Liya;->aL:Ljava/util/ArrayList;

    .line 65
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 68
    move-result v6

    .line 69
    const/4 v7, 0x0

    .line 70
    :goto_1
    if-ge v7, v6, :cond_5

    .line 72
    invoke-interface {v2, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 75
    move-result-object v8

    .line 76
    check-cast v8, Lixs;

    .line 78
    iget-object v9, v8, Lixs;->aq:Ljava/lang/Object;

    .line 80
    check-cast v9, Landroid/view/View;

    .line 82
    if-eqz v9, :cond_4

    .line 84
    iget-object v10, v8, Lixs;->v:Ljava/lang/String;

    .line 86
    if-nez v10, :cond_3

    .line 88
    invoke-virtual {v9}, Landroid/view/View;->getId()I

    .line 91
    move-result v9

    .line 92
    if-eq v9, v3, :cond_3

    .line 94
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getContext()Landroid/content/Context;

    .line 97
    move-result-object v10

    .line 98
    invoke-virtual {v10}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 101
    move-result-object v10

    .line 102
    invoke-virtual {v10, v9}, Landroid/content/res/Resources;->getResourceEntryName(I)Ljava/lang/String;

    .line 105
    move-result-object v9

    .line 106
    iput-object v9, v8, Lixs;->v:Ljava/lang/String;

    .line 108
    :cond_3
    iget-object v9, v8, Lixs;->as:Ljava/lang/String;

    .line 110
    if-nez v9, :cond_4

    .line 112
    iget-object v9, v8, Lixs;->v:Ljava/lang/String;

    .line 114
    iput-object v9, v8, Lixs;->as:Ljava/lang/String;

    .line 116
    iget-object v8, v8, Lixs;->as:Ljava/lang/String;

    .line 118
    invoke-static {v8}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 121
    move-result-object v8

    .line 122
    invoke-virtual {v5, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 125
    move-result-object v8

    .line 126
    invoke-static {v4, v8}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 129
    :cond_4
    add-int/lit8 v7, v7, 0x1

    .line 131
    goto :goto_1

    .line 132
    :cond_5
    invoke-virtual {v1, v0}, Lixs;->u(Ljava/lang/StringBuilder;)V

    .line 135
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 138
    move-result-object p0

    .line 139
    return-object p0
.end method

.method protected final onLayout(ZIIII)V
    .locals 5

    .line 1
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildCount()I

    .line 4
    move-result p1

    .line 5
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->isInEditMode()Z

    .line 8
    move-result p2

    .line 9
    const/4 p3, 0x0

    .line 10
    move p4, p3

    .line 11
    :goto_0
    if-ge p4, p1, :cond_2

    .line 13
    invoke-virtual {p0, p4}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildAt(I)Landroid/view/View;

    .line 16
    move-result-object p5

    .line 17
    invoke-virtual {p5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 20
    move-result-object v0

    .line 21
    check-cast v0, Liyx;

    .line 23
    iget-object v1, v0, Liyx;->av:Lixs;

    .line 25
    invoke-virtual {p5}, Landroid/view/View;->getVisibility()I

    .line 28
    move-result v2

    .line 29
    const/16 v3, 0x8

    .line 31
    if-ne v2, v3, :cond_0

    .line 33
    iget-boolean v2, v0, Liyx;->ah:Z

    .line 35
    if-nez v2, :cond_0

    .line 37
    iget-boolean v2, v0, Liyx;->ai:Z

    .line 39
    if-nez v2, :cond_0

    .line 41
    iget-boolean v2, v0, Liyx;->ak:Z

    .line 43
    if-nez p2, :cond_0

    .line 45
    goto :goto_1

    .line 46
    :cond_0
    iget-boolean v0, v0, Liyx;->aj:Z

    .line 48
    invoke-virtual {v1}, Lixs;->k()I

    .line 51
    move-result v0

    .line 52
    invoke-virtual {v1}, Lixs;->l()I

    .line 55
    move-result v2

    .line 56
    invoke-virtual {v1}, Lixs;->j()I

    .line 59
    move-result v3

    .line 60
    add-int/2addr v3, v0

    .line 61
    invoke-virtual {v1}, Lixs;->h()I

    .line 64
    move-result v1

    .line 65
    add-int/2addr v1, v2

    .line 66
    invoke-virtual {p5, v0, v2, v3, v1}, Landroid/view/View;->layout(IIII)V

    .line 69
    instance-of v4, p5, Lizl;

    .line 71
    if-eqz v4, :cond_1

    .line 73
    check-cast p5, Lizl;

    .line 75
    invoke-virtual {p5}, Lizl;->getContent()Landroid/view/View;

    .line 78
    move-result-object p5

    .line 79
    if-eqz p5, :cond_1

    .line 81
    invoke-virtual {p5, p3}, Landroid/view/View;->setVisibility(I)V

    .line 84
    invoke-virtual {p5, v0, v2, v3, v1}, Landroid/view/View;->layout(IIII)V

    .line 87
    :cond_1
    :goto_1
    add-int/lit8 p4, p4, 0x1

    .line 89
    goto :goto_0

    .line 90
    :cond_2
    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Ljava/util/ArrayList;

    .line 92
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 95
    move-result p1

    .line 96
    if-lez p1, :cond_3

    .line 98
    :goto_2
    if-ge p3, p1, :cond_3

    .line 100
    invoke-virtual {p0, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 103
    move-result-object p2

    .line 104
    check-cast p2, Liyv;

    .line 106
    add-int/lit8 p3, p3, 0x1

    .line 108
    goto :goto_2

    .line 109
    :cond_3
    return-void
.end method

.method protected onMeasure(II)V
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 3
    move/from16 v1, p1

    .line 5
    move/from16 v2, p2

    .line 7
    iget-boolean v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Z

    .line 9
    const/4 v4, 0x1

    .line 10
    const/4 v5, 0x0

    .line 11
    if-nez v3, :cond_1

    .line 13
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildCount()I

    .line 16
    move-result v3

    .line 17
    move v6, v5

    .line 18
    :goto_0
    if-ge v6, v3, :cond_1

    .line 20
    invoke-virtual {v0, v6}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildAt(I)Landroid/view/View;

    .line 23
    move-result-object v7

    .line 24
    invoke-virtual {v7}, Landroid/view/View;->isLayoutRequested()Z

    .line 27
    move-result v7

    .line 28
    if-eqz v7, :cond_0

    .line 30
    iput-boolean v4, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Z

    .line 32
    goto :goto_1

    .line 33
    :cond_0
    add-int/lit8 v6, v6, 0x1

    .line 35
    goto :goto_0

    .line 36
    :cond_1
    :goto_1
    iget-object v7, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    .line 38
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->fq()Z

    .line 41
    move-result v3

    .line 42
    iput-boolean v3, v7, Lixt;->e:Z

    .line 44
    iget-boolean v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Z

    .line 46
    if-eqz v3, :cond_3

    .line 48
    iput-boolean v5, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Z

    .line 50
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildCount()I

    .line 53
    move-result v3

    .line 54
    move v6, v5

    .line 55
    :goto_2
    if-ge v6, v3, :cond_3

    .line 57
    invoke-virtual {v0, v6}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildAt(I)Landroid/view/View;

    .line 60
    move-result-object v8

    .line 61
    invoke-virtual {v8}, Landroid/view/View;->isLayoutRequested()Z

    .line 64
    move-result v8

    .line 65
    if-eqz v8, :cond_2

    .line 67
    invoke-direct {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->g()V

    .line 70
    invoke-virtual {v7}, Lixt;->ai()V

    .line 73
    goto :goto_3

    .line 74
    :cond_2
    add-int/lit8 v6, v6, 0x1

    .line 76
    goto :goto_2

    .line 77
    :cond_3
    :goto_3
    iget-object v3, v7, Lixt;->f:Livx;

    .line 79
    iget v8, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    .line 81
    invoke-static {v1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 84
    move-result v9

    .line 85
    invoke-static {v1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 88
    move-result v3

    .line 89
    invoke-static {v2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 92
    move-result v11

    .line 93
    invoke-static {v2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 96
    move-result v6

    .line 97
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getPaddingTop()I

    .line 100
    move-result v10

    .line 101
    invoke-static {v5, v10}, Ljava/lang/Math;->max(II)I

    .line 104
    move-result v14

    .line 105
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getPaddingBottom()I

    .line 108
    move-result v10

    .line 109
    invoke-static {v5, v10}, Ljava/lang/Math;->max(II)I

    .line 112
    move-result v10

    .line 113
    add-int v12, v14, v10

    .line 115
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getPaddingLeft()I

    .line 118
    move-result v13

    .line 119
    invoke-static {v5, v13}, Ljava/lang/Math;->max(II)I

    .line 122
    move-result v13

    .line 123
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getPaddingRight()I

    .line 126
    move-result v15

    .line 127
    invoke-static {v5, v15}, Ljava/lang/Math;->max(II)I

    .line 130
    move-result v15

    .line 131
    add-int/2addr v13, v15

    .line 132
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getPaddingStart()I

    .line 135
    move-result v15

    .line 136
    invoke-static {v5, v15}, Ljava/lang/Math;->max(II)I

    .line 139
    move-result v15

    .line 140
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getPaddingEnd()I

    .line 143
    move-result v4

    .line 144
    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    .line 147
    move-result v4

    .line 148
    add-int/2addr v15, v4

    .line 149
    if-lez v15, :cond_4

    .line 151
    move v13, v15

    .line 152
    :cond_4
    iget-object v4, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:Liyy;

    .line 154
    iput v14, v4, Liyy;->b:I

    .line 156
    iput v10, v4, Liyy;->c:I

    .line 158
    iput v13, v4, Liyy;->d:I

    .line 160
    iput v12, v4, Liyy;->e:I

    .line 162
    iput v1, v4, Liyy;->f:I

    .line 164
    iput v2, v4, Liyy;->g:I

    .line 166
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getPaddingStart()I

    .line 169
    move-result v10

    .line 170
    invoke-static {v5, v10}, Ljava/lang/Math;->max(II)I

    .line 173
    move-result v10

    .line 174
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getPaddingEnd()I

    .line 177
    move-result v15

    .line 178
    invoke-static {v5, v15}, Ljava/lang/Math;->max(II)I

    .line 181
    move-result v15

    .line 182
    if-gtz v10, :cond_6

    .line 184
    if-lez v15, :cond_5

    .line 186
    goto :goto_4

    .line 187
    :cond_5
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getPaddingLeft()I

    .line 190
    move-result v10

    .line 191
    invoke-static {v5, v10}, Ljava/lang/Math;->max(II)I

    .line 194
    move-result v10

    .line 195
    goto :goto_5

    .line 196
    :cond_6
    :goto_4
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->fq()Z

    .line 199
    move-result v16

    .line 200
    if-eqz v16, :cond_7

    .line 202
    move v10, v15

    .line 203
    :cond_7
    :goto_5
    sub-int/2addr v3, v13

    .line 204
    sub-int v12, v6, v12

    .line 206
    iget v6, v4, Liyy;->e:I

    .line 208
    iget v13, v4, Liyy;->d:I

    .line 210
    invoke-virtual {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getChildCount()I

    .line 213
    move-result v15

    .line 214
    const/high16 v5, -0x80000000

    .line 216
    const/16 v18, 0x2

    .line 218
    if-eq v9, v5, :cond_b

    .line 220
    if-eqz v9, :cond_9

    .line 222
    const/high16 v5, 0x40000000

    .line 224
    if-eq v9, v5, :cond_8

    .line 226
    move/from16 v19, v3

    .line 228
    move/from16 v20, v6

    .line 230
    const/4 v3, 0x1

    .line 231
    const/4 v5, 0x0

    .line 232
    goto :goto_6

    .line 233
    :cond_8
    iget v5, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    .line 235
    sub-int/2addr v5, v13

    .line 236
    invoke-static {v5, v3}, Ljava/lang/Math;->min(II)I

    .line 239
    move-result v5

    .line 240
    move/from16 v19, v3

    .line 242
    move/from16 v20, v6

    .line 244
    const/4 v3, 0x1

    .line 245
    :goto_6
    const/high16 v6, -0x80000000

    .line 247
    goto :goto_9

    .line 248
    :cond_9
    if-nez v15, :cond_a

    .line 250
    iget v5, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    .line 252
    const/4 v15, 0x0

    .line 253
    invoke-static {v15, v5}, Ljava/lang/Math;->max(II)I

    .line 256
    move-result v16

    .line 257
    move/from16 v19, v3

    .line 259
    move/from16 v20, v6

    .line 261
    move/from16 v5, v16

    .line 263
    goto :goto_8

    .line 264
    :cond_a
    const/4 v5, 0x0

    .line 265
    move/from16 v19, v3

    .line 267
    goto :goto_7

    .line 268
    :cond_b
    const/4 v5, 0x0

    .line 269
    if-nez v15, :cond_c

    .line 271
    iget v15, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    .line 273
    invoke-static {v5, v15}, Ljava/lang/Math;->max(II)I

    .line 276
    move-result v15

    .line 277
    move/from16 v19, v3

    .line 279
    move/from16 v20, v6

    .line 281
    move v5, v15

    .line 282
    move/from16 v3, v18

    .line 284
    const/high16 v6, -0x80000000

    .line 286
    const/4 v15, 0x0

    .line 287
    goto :goto_9

    .line 288
    :cond_c
    move v5, v3

    .line 289
    move/from16 v19, v5

    .line 291
    :goto_7
    move/from16 v20, v6

    .line 293
    :goto_8
    move/from16 v3, v18

    .line 295
    goto :goto_6

    .line 296
    :goto_9
    if-eq v11, v6, :cond_10

    .line 298
    if-eqz v11, :cond_e

    .line 300
    const/high16 v6, 0x40000000

    .line 302
    if-eq v11, v6, :cond_d

    .line 304
    move/from16 v17, v8

    .line 306
    const/4 v6, 0x1

    .line 307
    const/4 v15, 0x0

    .line 308
    goto :goto_c

    .line 309
    :cond_d
    iget v6, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:I

    .line 311
    sub-int v6, v6, v20

    .line 313
    invoke-static {v6, v12}, Ljava/lang/Math;->min(II)I

    .line 316
    move-result v6

    .line 317
    move v15, v6

    .line 318
    move/from16 v17, v8

    .line 320
    const/4 v6, 0x1

    .line 321
    goto :goto_c

    .line 322
    :cond_e
    if-nez v15, :cond_f

    .line 324
    iget v6, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:I

    .line 326
    const/4 v15, 0x0

    .line 327
    invoke-static {v15, v6}, Ljava/lang/Math;->max(II)I

    .line 330
    move-result v16

    .line 331
    move/from16 v17, v8

    .line 333
    move/from16 v15, v16

    .line 335
    goto :goto_b

    .line 336
    :cond_f
    const/4 v15, 0x0

    .line 337
    goto :goto_a

    .line 338
    :cond_10
    const/4 v6, 0x0

    .line 339
    if-nez v15, :cond_11

    .line 341
    iget v15, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:I

    .line 343
    invoke-static {v6, v15}, Ljava/lang/Math;->max(II)I

    .line 346
    move-result v15

    .line 347
    :goto_a
    move/from16 v17, v8

    .line 349
    goto :goto_b

    .line 350
    :cond_11
    move/from16 v17, v8

    .line 352
    move v15, v12

    .line 353
    :goto_b
    move/from16 v6, v18

    .line 355
    :goto_c
    invoke-virtual {v7}, Lixs;->j()I

    .line 358
    move-result v8

    .line 359
    if-ne v5, v8, :cond_13

    .line 361
    invoke-virtual {v7}, Lixs;->h()I

    .line 364
    move-result v8

    .line 365
    if-eq v15, v8, :cond_12

    .line 367
    goto :goto_d

    .line 368
    :cond_12
    move/from16 v18, v9

    .line 370
    goto :goto_e

    .line 371
    :cond_13
    :goto_d
    iget-object v8, v7, Lixt;->b:Liyh;

    .line 373
    move/from16 v18, v9

    .line 375
    const/4 v9, 0x1

    .line 376
    iput-boolean v9, v8, Liyh;->c:Z

    .line 378
    :goto_e
    const/4 v8, 0x0

    .line 379
    iput v8, v7, Lixs;->aj:I

    .line 381
    iput v8, v7, Lixs;->ak:I

    .line 383
    iget v9, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    .line 385
    sub-int/2addr v9, v13

    .line 386
    invoke-virtual {v7, v9}, Lixs;->J(I)V

    .line 389
    iget v9, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:I

    .line 391
    sub-int v9, v9, v20

    .line 393
    invoke-virtual {v7, v9}, Lixs;->I(I)V

    .line 396
    invoke-virtual {v7, v8}, Lixs;->L(I)V

    .line 399
    invoke-virtual {v7, v8}, Lixs;->K(I)V

    .line 402
    invoke-virtual {v7, v3}, Lixs;->ac(I)V

    .line 405
    invoke-virtual {v7, v5}, Lixs;->O(I)V

    .line 408
    invoke-virtual {v7, v6}, Lixs;->ad(I)V

    .line 411
    invoke-virtual {v7, v15}, Lixs;->D(I)V

    .line 414
    iget v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    .line 416
    sub-int/2addr v3, v13

    .line 417
    invoke-virtual {v7, v3}, Lixs;->L(I)V

    .line 420
    iget v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:I

    .line 422
    sub-int v3, v3, v20

    .line 424
    invoke-virtual {v7, v3}, Lixs;->K(I)V

    .line 427
    move v13, v10

    .line 428
    move/from16 v8, v17

    .line 430
    move/from16 v9, v18

    .line 432
    move/from16 v10, v19

    .line 434
    invoke-virtual/range {v7 .. v14}, Lixt;->al(IIIIIII)V

    .line 437
    invoke-virtual {v7}, Lixs;->j()I

    .line 440
    move-result v3

    .line 441
    invoke-virtual {v7}, Lixs;->h()I

    .line 444
    move-result v5

    .line 445
    iget-boolean v6, v7, Lixt;->aD:Z

    .line 447
    iget-boolean v7, v7, Lixt;->aE:Z

    .line 449
    iget v8, v4, Liyy;->e:I

    .line 451
    iget v4, v4, Liyy;->d:I

    .line 453
    add-int/2addr v3, v4

    .line 454
    add-int/2addr v5, v8

    .line 455
    const/4 v15, 0x0

    .line 456
    invoke-static {v3, v1, v15}, Landroidx/constraintlayout/widget/ConstraintLayout;->resolveSizeAndState(III)I

    .line 459
    move-result v1

    .line 460
    invoke-static {v5, v2, v15}, Landroidx/constraintlayout/widget/ConstraintLayout;->resolveSizeAndState(III)I

    .line 463
    move-result v2

    .line 464
    const v3, 0xffffff

    .line 467
    and-int/2addr v1, v3

    .line 468
    and-int/2addr v2, v3

    .line 469
    iget v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    .line 471
    invoke-static {v3, v1}, Ljava/lang/Math;->min(II)I

    .line 474
    move-result v1

    .line 475
    iget v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:I

    .line 477
    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    .line 480
    move-result v2

    .line 481
    const/high16 v3, 0x1000000

    .line 483
    if-eqz v6, :cond_14

    .line 485
    or-int/2addr v1, v3

    .line 486
    :cond_14
    if-eqz v7, :cond_15

    .line 488
    or-int/2addr v2, v3

    .line 489
    :cond_15
    invoke-virtual {v0, v1, v2}, Landroidx/constraintlayout/widget/ConstraintLayout;->setMeasuredDimension(II)V

    .line 492
    return-void
.end method

.method public final onViewAdded(Landroid/view/View;)V
    .locals 4

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onViewAdded(Landroid/view/View;)V

    .line 4
    instance-of v0, p1, Landroidx/constraintlayout/widget/Guideline;

    .line 6
    invoke-virtual {p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->fp(Landroid/view/View;)Lixs;

    .line 9
    move-result-object v1

    .line 10
    const/4 v2, 0x1

    .line 11
    if-eqz v0, :cond_0

    .line 13
    instance-of v0, v1, Lixw;

    .line 15
    if-nez v0, :cond_0

    .line 17
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 20
    move-result-object v0

    .line 21
    check-cast v0, Liyx;

    .line 23
    new-instance v1, Lixw;

    .line 25
    invoke-direct {v1}, Lixw;-><init>()V

    .line 28
    iput-object v1, v0, Liyx;->av:Lixs;

    .line 30
    iput-boolean v2, v0, Liyx;->ah:Z

    .line 32
    iget-object v1, v0, Liyx;->av:Lixs;

    .line 34
    check-cast v1, Lixw;

    .line 36
    iget v0, v0, Liyx;->Z:I

    .line 38
    invoke-virtual {v1, v0}, Lixw;->ah(I)V

    .line 41
    :cond_0
    instance-of v0, p1, Liyv;

    .line 43
    if-eqz v0, :cond_1

    .line 45
    move-object v0, p1

    .line 46
    check-cast v0, Liyv;

    .line 48
    invoke-virtual {v0}, Liyv;->h()V

    .line 51
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 54
    move-result-object v1

    .line 55
    check-cast v1, Liyx;

    .line 57
    iput-boolean v2, v1, Liyx;->ai:Z

    .line 59
    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Ljava/util/ArrayList;

    .line 61
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 64
    move-result v3

    .line 65
    if-nez v3, :cond_1

    .line 67
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 70
    :cond_1
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->a:Landroid/util/SparseArray;

    .line 72
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 75
    move-result v1

    .line 76
    invoke-virtual {v0, v1, p1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 79
    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Z

    .line 81
    return-void
.end method

.method public final onViewRemoved(Landroid/view/View;)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onViewRemoved(Landroid/view/View;)V

    .line 4
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->a:Landroid/util/SparseArray;

    .line 6
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 9
    move-result v1

    .line 10
    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->remove(I)V

    .line 13
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    .line 15
    invoke-virtual {p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->fp(Landroid/view/View;)Lixs;

    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v0, v1}, Liya;->ao(Lixs;)V

    .line 22
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Ljava/util/ArrayList;

    .line 24
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 27
    const/4 p1, 0x1

    .line 28
    iput-boolean p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Z

    .line 30
    return-void
.end method

.method public final requestLayout()V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->f()V

    .line 4
    invoke-super {p0}, Landroid/view/ViewGroup;->requestLayout()V

    .line 7
    return-void
.end method

.method public setConstraintSet(Lizi;)V
    .locals 0

    .line 1
    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lizi;

    .line 3
    return-void
.end method

.method public setId(I)V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->a:Landroid/util/SparseArray;

    .line 3
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getId()I

    .line 6
    move-result v1

    .line 7
    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->remove(I)V

    .line 10
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->setId(I)V

    .line 13
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getId()I

    .line 16
    move-result p1

    .line 17
    invoke-virtual {v0, p1, p0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 20
    return-void
.end method

.method public setMaxHeight(I)V
    .locals 1

    .line 1
    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:I

    .line 3
    if-ne p1, v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:I

    .line 8
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    .line 11
    return-void
.end method

.method public setMaxWidth(I)V
    .locals 1

    .line 1
    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    .line 3
    if-ne p1, v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    .line 8
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    .line 11
    return-void
.end method

.method public setMinHeight(I)V
    .locals 1

    .line 1
    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:I

    .line 3
    if-ne p1, v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:I

    .line 8
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    .line 11
    return-void
.end method

.method public setMinWidth(I)V
    .locals 1

    .line 1
    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    .line 3
    if-ne p1, v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    .line 8
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    .line 11
    return-void
.end method

.method public setOnConstraintsChanged(Lizk;)V
    .locals 0

    .line 1
    return-void
.end method

.method public setOptimizationLevel(I)V
    .locals 0

    .line 1
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    .line 3
    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Lixt;

    .line 5
    invoke-virtual {p0, p1}, Lixt;->ah(I)V

    .line 8
    return-void
.end method

.method public final shouldDelayChildPressedState()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
