.class public abstract Landroidx/work/impl/WorkDatabase;
.super Lmmt;
.source "PG"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lmmt;-><init>()V

    .line 4
    return-void
.end method


# virtual methods
.method public abstract A()Lnmg;
.end method

.method public abstract B()Lnmn;
.end method

.method public abstract C()Lnmw;
.end method

.method public abstract D()Lnnb;
.end method

.method public abstract E()Lnnk;
.end method

.method public abstract F()Lnpb;
.end method

.method public abstract z()Lnlx;
.end method
