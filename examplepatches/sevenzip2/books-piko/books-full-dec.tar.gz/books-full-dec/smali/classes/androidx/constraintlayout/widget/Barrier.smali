.class public Landroidx/constraintlayout/widget/Barrier;
.super Liyv;
.source "PG"


# instance fields
.field private h:I

.field private i:Lixo;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Liyv;-><init>(Landroid/content/Context;)V

    .line 4
    const/16 p1, 0x8

    .line 6
    invoke-super {p0, p1}, Liyv;->setVisibility(I)V

    .line 9
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 10
    invoke-direct {p0, p1, p2}, Liyv;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/16 p1, 0x8

    .line 11
    invoke-super {p0, p1}, Liyv;->setVisibility(I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 12
    invoke-direct {p0, p1, p2, p3}, Liyv;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/16 p1, 0x8

    .line 13
    invoke-super {p0, p1}, Liyv;->setVisibility(I)V

    return-void
.end method


# virtual methods
.method protected final a(Landroid/util/AttributeSet;)V
    .locals 6

    .line 1
    invoke-super {p0, p1}, Liyv;->a(Landroid/util/AttributeSet;)V

    .line 4
    new-instance v0, Lixo;

    .line 6
    invoke-direct {v0}, Lixo;-><init>()V

    .line 9
    iput-object v0, p0, Landroidx/constraintlayout/widget/Barrier;->i:Lixo;

    .line 11
    if-eqz p1, :cond_4

    .line 13
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/Barrier;->getContext()Landroid/content/Context;

    .line 16
    move-result-object v0

    .line 17
    sget-object v1, Lizn;->b:[I

    .line 19
    invoke-virtual {v0, p1, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 22
    move-result-object p1

    .line 23
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    .line 26
    move-result v0

    .line 27
    const/4 v1, 0x0

    .line 28
    move v2, v1

    .line 29
    :goto_0
    if-ge v2, v0, :cond_3

    .line 31
    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->getIndex(I)I

    .line 34
    move-result v3

    .line 35
    const/16 v4, 0x1a

    .line 37
    if-ne v3, v4, :cond_0

    .line 39
    invoke-virtual {p1, v4, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 42
    move-result v3

    .line 43
    invoke-virtual {p0, v3}, Landroidx/constraintlayout/widget/Barrier;->setType(I)V

    .line 46
    goto :goto_1

    .line 47
    :cond_0
    const/16 v4, 0x19

    .line 49
    if-ne v3, v4, :cond_1

    .line 51
    iget-object v3, p0, Landroidx/constraintlayout/widget/Barrier;->i:Lixo;

    .line 53
    const/4 v5, 0x1

    .line 54
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 57
    move-result v4

    .line 58
    iput-boolean v4, v3, Lixo;->b:Z

    .line 60
    goto :goto_1

    .line 61
    :cond_1
    const/16 v4, 0x1b

    .line 63
    if-ne v3, v4, :cond_2

    .line 65
    invoke-virtual {p1, v4, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 68
    move-result v3

    .line 69
    iget-object v4, p0, Landroidx/constraintlayout/widget/Barrier;->i:Lixo;

    .line 71
    iput v3, v4, Lixo;->c:I

    .line 73
    :cond_2
    :goto_1
    add-int/lit8 v2, v2, 0x1

    .line 75
    goto :goto_0

    .line 76
    :cond_3
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 79
    :cond_4
    iget-object p1, p0, Landroidx/constraintlayout/widget/Barrier;->i:Lixo;

    .line 81
    iput-object p1, p0, Landroidx/constraintlayout/widget/Barrier;->g:Lixx;

    .line 83
    invoke-virtual {p0}, Liyv;->h()V

    .line 86
    return-void
.end method

.method public final c(Lixs;Z)V
    .locals 4

    .line 1
    iget p0, p0, Landroidx/constraintlayout/widget/Barrier;->h:I

    .line 3
    const/4 v0, 0x1

    .line 4
    const/4 v1, 0x0

    .line 5
    const/4 v2, 0x6

    .line 6
    const/4 v3, 0x5

    .line 7
    if-eqz p2, :cond_1

    .line 9
    if-ne p0, v3, :cond_0

    .line 11
    :goto_0
    move p0, v0

    .line 12
    goto :goto_2

    .line 13
    :cond_0
    if-ne p0, v2, :cond_3

    .line 15
    goto :goto_1

    .line 16
    :cond_1
    if-ne p0, v3, :cond_2

    .line 18
    :goto_1
    move p0, v1

    .line 19
    goto :goto_2

    .line 20
    :cond_2
    if-ne p0, v2, :cond_3

    .line 22
    goto :goto_0

    .line 23
    :cond_3
    :goto_2
    instance-of p2, p1, Lixo;

    .line 25
    if-eqz p2, :cond_4

    .line 27
    check-cast p1, Lixo;

    .line 29
    iput p0, p1, Lixo;->a:I

    .line 31
    :cond_4
    return-void
.end method

.method public getAllowsGoneWidget()Z
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/constraintlayout/widget/Barrier;->i:Lixo;

    .line 3
    iget-boolean p0, p0, Lixo;->b:Z

    .line 5
    return p0
.end method

.method public getMargin()I
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/constraintlayout/widget/Barrier;->i:Lixo;

    .line 3
    iget p0, p0, Lixo;->c:I

    .line 5
    return p0
.end method

.method public getType()I
    .locals 0

    .line 1
    iget p0, p0, Landroidx/constraintlayout/widget/Barrier;->h:I

    .line 3
    return p0
.end method

.method public setAllowsGoneWidget(Z)V
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/constraintlayout/widget/Barrier;->i:Lixo;

    .line 3
    iput-boolean p1, p0, Lixo;->b:Z

    .line 5
    return-void
.end method

.method public setDpMargin(I)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/Barrier;->getResources()Landroid/content/res/Resources;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 8
    move-result-object v0

    .line 9
    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    .line 11
    int-to-float p1, p1

    .line 12
    mul-float/2addr p1, v0

    .line 13
    iget-object p0, p0, Landroidx/constraintlayout/widget/Barrier;->i:Lixo;

    .line 15
    const/high16 v0, 0x3f000000    # 0.5f

    .line 17
    add-float/2addr p1, v0

    .line 18
    float-to-int p1, p1

    .line 19
    iput p1, p0, Lixo;->c:I

    .line 21
    return-void
.end method

.method public setMargin(I)V
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/constraintlayout/widget/Barrier;->i:Lixo;

    .line 3
    iput p1, p0, Lixo;->c:I

    .line 5
    return-void
.end method

.method public setType(I)V
    .locals 0

    .line 1
    iput p1, p0, Landroidx/constraintlayout/widget/Barrier;->h:I

    .line 3
    return-void
.end method
