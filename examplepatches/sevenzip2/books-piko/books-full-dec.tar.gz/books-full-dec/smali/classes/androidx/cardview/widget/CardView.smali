.class public Landroidx/cardview/widget/CardView;
.super Landroid/widget/FrameLayout;
.source "PG"


# static fields
.field private static final c:[I

.field private static final f:Lagk;


# instance fields
.field public final a:Landroid/graphics/Rect;

.field public final b:Landroid/graphics/Rect;

.field private d:Z

.field private e:Z

.field private final g:Lagj;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const v0, 0x1010031

    .line 4
    filled-new-array {v0}, [I

    .line 7
    move-result-object v0

    .line 8
    sput-object v0, Landroidx/cardview/widget/CardView;->c:[I

    .line 10
    new-instance v0, Lagk;

    .line 12
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 15
    sput-object v0, Landroidx/cardview/widget/CardView;->f:Lagk;

    .line 17
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    const/4 v0, 0x0

    .line 222
    invoke-direct {p0, p1, v0}, Landroidx/cardview/widget/CardView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    const v0, 0x7f040139

    .line 221
    invoke-direct {p0, p1, p2, v0}, Landroidx/cardview/widget/CardView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 9

    .line 1
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 4
    new-instance v0, Landroid/graphics/Rect;

    .line 6
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 9
    iput-object v0, p0, Landroidx/cardview/widget/CardView;->a:Landroid/graphics/Rect;

    .line 11
    new-instance v1, Landroid/graphics/Rect;

    .line 13
    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    .line 16
    iput-object v1, p0, Landroidx/cardview/widget/CardView;->b:Landroid/graphics/Rect;

    .line 18
    new-instance v1, Lagj;

    .line 20
    invoke-direct {v1, p0}, Lagj;-><init>(Landroidx/cardview/widget/CardView;)V

    .line 23
    iput-object v1, p0, Landroidx/cardview/widget/CardView;->g:Lagj;

    .line 25
    sget-object v4, Lagi;->a:[I

    .line 27
    const v2, 0x7f140204

    .line 30
    invoke-virtual {p1, p2, v4, p3, v2}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 33
    move-result-object v6

    .line 34
    const v8, 0x7f140204

    .line 37
    move-object v2, p0

    .line 38
    move-object v3, p1

    .line 39
    move-object v5, p2

    .line 40
    move v7, p3

    .line 41
    invoke-static/range {v2 .. v8}, Ljmy;->o(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V

    .line 44
    const/4 p0, 0x2

    .line 45
    invoke-virtual {v6, p0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 48
    move-result p1

    .line 49
    const/4 p2, 0x3

    .line 50
    const/4 p3, 0x0

    .line 51
    if-eqz p1, :cond_0

    .line 53
    invoke-virtual {v6, p0}, Landroid/content/res/TypedArray;->getColorStateList(I)Landroid/content/res/ColorStateList;

    .line 56
    move-result-object p0

    .line 57
    goto :goto_1

    .line 58
    :cond_0
    invoke-virtual {v2}, Landroidx/cardview/widget/CardView;->getContext()Landroid/content/Context;

    .line 61
    move-result-object p1

    .line 62
    sget-object v3, Landroidx/cardview/widget/CardView;->c:[I

    .line 64
    invoke-virtual {p1, v3}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    .line 67
    move-result-object p1

    .line 68
    invoke-virtual {p1, p3, p3}, Landroid/content/res/TypedArray;->getColor(II)I

    .line 71
    move-result v3

    .line 72
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 75
    new-array p1, p2, [F

    .line 77
    invoke-static {v3, p1}, Landroid/graphics/Color;->colorToHSV(I[F)V

    .line 80
    aget p0, p1, p0

    .line 82
    const/high16 p1, 0x3f000000    # 0.5f

    .line 84
    cmpl-float p0, p0, p1

    .line 86
    if-lez p0, :cond_1

    .line 88
    invoke-virtual {v2}, Landroidx/cardview/widget/CardView;->getResources()Landroid/content/res/Resources;

    .line 91
    move-result-object p0

    .line 92
    const p1, 0x7f0600b8

    .line 95
    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getColor(I)I

    .line 98
    move-result p0

    .line 99
    goto :goto_0

    .line 100
    :cond_1
    invoke-virtual {v2}, Landroidx/cardview/widget/CardView;->getResources()Landroid/content/res/Resources;

    .line 103
    move-result-object p0

    .line 104
    const p1, 0x7f0600b7

    .line 107
    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getColor(I)I

    .line 110
    move-result p0

    .line 111
    :goto_0
    invoke-static {p0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 114
    move-result-object p0

    .line 115
    :goto_1
    const/4 p1, 0x0

    .line 116
    invoke-virtual {v6, p2, p1}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 119
    move-result p2

    .line 120
    const/4 v3, 0x4    # 5.6E-45f

    .line 121
    invoke-virtual {v6, v3, p1}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 124
    move-result v3

    .line 125
    const/4 v4, 0x5    # 7.0E-45f

    .line 126
    invoke-virtual {v6, v4, p1}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 129
    move-result p1

    .line 130
    const/4 v4, 0x7

    .line 131
    invoke-virtual {v6, v4, p3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 134
    move-result v4

    .line 135
    iput-boolean v4, v2, Landroidx/cardview/widget/CardView;->d:Z

    .line 137
    const/4 v4, 0x6

    .line 138
    const/4 v5, 0x1

    .line 139
    invoke-virtual {v6, v4, v5}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 142
    move-result v4

    .line 143
    iput-boolean v4, v2, Landroidx/cardview/widget/CardView;->e:Z

    .line 145
    const/16 v2, 0x8

    .line 147
    invoke-virtual {v6, v2, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 150
    move-result v2

    .line 151
    const/16 v4, 0xa

    .line 153
    invoke-virtual {v6, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 156
    move-result v4

    .line 157
    iput v4, v0, Landroid/graphics/Rect;->left:I

    .line 159
    const/16 v4, 0xc

    .line 161
    invoke-virtual {v6, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 164
    move-result v4

    .line 165
    iput v4, v0, Landroid/graphics/Rect;->top:I

    .line 167
    const/16 v4, 0xb

    .line 169
    invoke-virtual {v6, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 172
    move-result v4

    .line 173
    iput v4, v0, Landroid/graphics/Rect;->right:I

    .line 175
    const/16 v4, 0x9

    .line 177
    invoke-virtual {v6, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 180
    move-result v2

    .line 181
    iput v2, v0, Landroid/graphics/Rect;->bottom:I

    .line 183
    cmpl-float v0, v3, p1

    .line 185
    if-lez v0, :cond_2

    .line 187
    move p1, v3

    .line 188
    :cond_2
    invoke-virtual {v6, p3, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 191
    invoke-virtual {v6, v5, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 194
    invoke-virtual {v6}, Landroid/content/res/TypedArray;->recycle()V

    .line 197
    new-instance p3, Lagl;

    .line 199
    invoke-direct {p3, p0, p2}, Lagl;-><init>(Landroid/content/res/ColorStateList;F)V

    .line 202
    iput-object p3, v1, Lagj;->a:Landroid/graphics/drawable/Drawable;

    .line 204
    iget-object p0, v1, Lagj;->b:Landroidx/cardview/widget/CardView;

    .line 206
    invoke-virtual {p0, p3}, Landroidx/cardview/widget/CardView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 209
    iget-object p0, v1, Lagj;->b:Landroidx/cardview/widget/CardView;

    .line 211
    invoke-virtual {p0, v5}, Landroid/view/View;->setClipToOutline(Z)V

    .line 214
    invoke-virtual {p0, v3}, Landroid/view/View;->setElevation(F)V

    .line 217
    invoke-static {v1, p1}, Lagk;->e(Lagj;F)V

    .line 220
    return-void
.end method

.method public static synthetic fl(Landroidx/cardview/widget/CardView;IIII)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 4
    return-void
.end method


# virtual methods
.method public final fm(IIII)V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/cardview/widget/CardView;->a:Landroid/graphics/Rect;

    .line 3
    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/graphics/Rect;->set(IIII)V

    .line 6
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->g:Lagj;

    .line 8
    invoke-static {p0}, Lagk;->d(Lagj;)V

    .line 11
    return-void
.end method

.method public getCardBackgroundColor()Landroid/content/res/ColorStateList;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->g:Lagj;

    .line 3
    iget-object p0, p0, Lagj;->a:Landroid/graphics/drawable/Drawable;

    .line 5
    check-cast p0, Lagl;

    .line 7
    iget-object p0, p0, Lagl;->e:Landroid/content/res/ColorStateList;

    .line 9
    return-object p0
.end method

.method public getCardElevation()F
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->g:Lagj;

    .line 3
    iget-object p0, p0, Lagj;->b:Landroidx/cardview/widget/CardView;

    .line 5
    invoke-virtual {p0}, Landroid/view/View;->getElevation()F

    .line 8
    move-result p0

    .line 9
    return p0
.end method

.method public getContentPaddingBottom()I
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->a:Landroid/graphics/Rect;

    .line 3
    iget p0, p0, Landroid/graphics/Rect;->bottom:I

    .line 5
    return p0
.end method

.method public getContentPaddingLeft()I
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->a:Landroid/graphics/Rect;

    .line 3
    iget p0, p0, Landroid/graphics/Rect;->left:I

    .line 5
    return p0
.end method

.method public getContentPaddingRight()I
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->a:Landroid/graphics/Rect;

    .line 3
    iget p0, p0, Landroid/graphics/Rect;->right:I

    .line 5
    return p0
.end method

.method public getContentPaddingTop()I
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->a:Landroid/graphics/Rect;

    .line 3
    iget p0, p0, Landroid/graphics/Rect;->top:I

    .line 5
    return p0
.end method

.method public getMaxCardElevation()F
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->g:Lagj;

    .line 3
    invoke-static {p0}, Lagk;->a(Lagj;)F

    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public getPreventCornerOverlap()Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Landroidx/cardview/widget/CardView;->e:Z

    .line 3
    return p0
.end method

.method public getRadius()F
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->g:Lagj;

    .line 3
    invoke-static {p0}, Lagk;->b(Lagj;)F

    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public getUseCompatPadding()Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Landroidx/cardview/widget/CardView;->d:Z

    .line 3
    return p0
.end method

.method public setCardBackgroundColor(I)V
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->g:Lagj;

    .line 3
    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 6
    move-result-object p1

    .line 7
    invoke-static {p0, p1}, Lagk;->c(Lagj;Landroid/content/res/ColorStateList;)V

    .line 10
    return-void
.end method

.method public setCardBackgroundColor(Landroid/content/res/ColorStateList;)V
    .locals 0

    .line 11
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->g:Lagj;

    invoke-static {p0, p1}, Lagk;->c(Lagj;Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public setCardElevation(F)V
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->g:Lagj;

    .line 3
    iget-object p0, p0, Lagj;->b:Landroidx/cardview/widget/CardView;

    .line 5
    invoke-virtual {p0, p1}, Landroid/view/View;->setElevation(F)V

    .line 8
    return-void
.end method

.method public setMaxCardElevation(F)V
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->g:Lagj;

    .line 3
    invoke-static {p0, p1}, Lagk;->e(Lagj;F)V

    .line 6
    return-void
.end method

.method public setMinimumHeight(I)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setMinimumHeight(I)V

    .line 4
    return-void
.end method

.method public setMinimumWidth(I)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setMinimumWidth(I)V

    .line 4
    return-void
.end method

.method public final setPadding(IIII)V
    .locals 0

    .line 1
    return-void
.end method

.method public final setPaddingRelative(IIII)V
    .locals 0

    .line 1
    return-void
.end method

.method public setPreventCornerOverlap(Z)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Landroidx/cardview/widget/CardView;->e:Z

    .line 3
    if-eq p1, v0, :cond_0

    .line 5
    iput-boolean p1, p0, Landroidx/cardview/widget/CardView;->e:Z

    .line 7
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->g:Lagj;

    .line 9
    invoke-static {p0}, Lagk;->a(Lagj;)F

    .line 12
    move-result p1

    .line 13
    invoke-static {p0, p1}, Lagk;->e(Lagj;F)V

    .line 16
    :cond_0
    return-void
.end method

.method public setRadius(F)V
    .locals 1

    .line 1
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->g:Lagj;

    .line 3
    iget-object p0, p0, Lagj;->a:Landroid/graphics/drawable/Drawable;

    .line 5
    check-cast p0, Lagl;

    .line 7
    iget v0, p0, Lagl;->a:F

    .line 9
    cmpl-float v0, p1, v0

    .line 11
    if-nez v0, :cond_0

    .line 13
    return-void

    .line 14
    :cond_0
    iput p1, p0, Lagl;->a:F

    .line 16
    const/4 p1, 0x0

    .line 17
    invoke-virtual {p0, p1}, Lagl;->b(Landroid/graphics/Rect;)V

    .line 20
    invoke-virtual {p0}, Lagl;->invalidateSelf()V

    .line 23
    return-void
.end method

.method public setUseCompatPadding(Z)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Landroidx/cardview/widget/CardView;->d:Z

    .line 3
    if-eq v0, p1, :cond_0

    .line 5
    iput-boolean p1, p0, Landroidx/cardview/widget/CardView;->d:Z

    .line 7
    iget-object p0, p0, Landroidx/cardview/widget/CardView;->g:Lagj;

    .line 9
    invoke-static {p0}, Lagk;->a(Lagj;)F

    .line 12
    move-result p1

    .line 13
    invoke-static {p0, p1}, Lagk;->e(Lagj;F)V

    .line 16
    :cond_0
    return-void
.end method
