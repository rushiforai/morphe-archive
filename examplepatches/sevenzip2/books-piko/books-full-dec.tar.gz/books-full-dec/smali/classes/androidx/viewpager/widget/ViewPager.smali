.class public Landroidx/viewpager/widget/ViewPager;
.super Landroid/view/ViewGroup;
.source "PG"


# static fields
.field public static final a:[I

.field private static final h:Ljava/util/Comparator;

.field private static final i:Landroid/view/animation/Interpolator;


# instance fields
.field private A:I

.field private B:Z

.field private C:Z

.field private D:I

.field private E:I

.field private F:I

.field private G:Z

.field private H:F

.field private I:F

.field private J:F

.field private K:F

.field private L:I

.field private M:Landroid/view/VelocityTracker;

.field private N:I

.field private O:I

.field private P:I

.field private Q:I

.field private R:Z

.field private S:Z

.field private T:I

.field private U:Lmyl;

.field private final V:Ljava/lang/Runnable;

.field private W:I

.field public b:Lmyc;

.field public c:I

.field public d:Landroid/widget/EdgeEffect;

.field public e:Landroid/widget/EdgeEffect;

.field public f:Ljava/util/List;

.field public g:Ljava/util/List;

.field private j:I

.field private final k:Ljava/util/ArrayList;

.field private final l:Lmyi;

.field private final m:Landroid/graphics/Rect;

.field private n:I

.field private o:Landroid/widget/Scroller;

.field private p:Z

.field private q:Lmym;

.field private r:I

.field private s:Landroid/graphics/drawable/Drawable;

.field private t:I

.field private u:I

.field private v:F

.field private w:F

.field private x:Z

.field private y:Z

.field private z:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const v0, 0x10100b3

    .line 4
    filled-new-array {v0}, [I

    .line 7
    move-result-object v0

    .line 8
    sput-object v0, Landroidx/viewpager/widget/ViewPager;->a:[I

    .line 10
    new-instance v0, Lmyd;

    .line 12
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 15
    sput-object v0, Landroidx/viewpager/widget/ViewPager;->h:Ljava/util/Comparator;

    .line 17
    new-instance v0, Lmye;

    .line 19
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 22
    sput-object v0, Landroidx/viewpager/widget/ViewPager;->i:Landroid/view/animation/Interpolator;

    .line 24
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-direct {p0, p1}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;)V

    .line 4
    new-instance v0, Ljava/util/ArrayList;

    .line 6
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 9
    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 11
    new-instance v0, Lmyi;

    .line 13
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 16
    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->l:Lmyi;

    .line 18
    new-instance v0, Landroid/graphics/Rect;

    .line 20
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 23
    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->m:Landroid/graphics/Rect;

    .line 25
    const/4 v0, -0x1

    .line 26
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->n:I

    .line 28
    const v1, -0x800001    # -3.4028235E38f

    .line 31
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->v:F

    .line 33
    const v1, 0x7f7fffff    # 3.4028235E38f

    .line 36
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->w:F

    .line 38
    const/4 v1, 0x1

    .line 39
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->A:I

    .line 41
    iput-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->G:Z

    .line 43
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 45
    iput-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->R:Z

    .line 47
    new-instance v0, Lmyf;

    .line 49
    invoke-direct {v0, p0}, Lmyf;-><init>(Landroidx/viewpager/widget/ViewPager;)V

    .line 52
    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->V:Ljava/lang/Runnable;

    .line 54
    const/4 v0, 0x0

    .line 55
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->W:I

    .line 57
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->o(Landroid/content/Context;)V

    .line 60
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    .line 61
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    new-instance p2, Ljava/util/ArrayList;

    .line 62
    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    new-instance p2, Lmyi;

    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Landroidx/viewpager/widget/ViewPager;->l:Lmyi;

    new-instance p2, Landroid/graphics/Rect;

    .line 63
    invoke-direct {p2}, Landroid/graphics/Rect;-><init>()V

    iput-object p2, p0, Landroidx/viewpager/widget/ViewPager;->m:Landroid/graphics/Rect;

    const/4 p2, -0x1

    iput p2, p0, Landroidx/viewpager/widget/ViewPager;->n:I

    const v0, -0x800001    # -3.4028235E38f

    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->v:F

    const v0, 0x7f7fffff    # 3.4028235E38f

    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->w:F

    const/4 v0, 0x1

    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->A:I

    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->G:Z

    iput p2, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->R:Z

    new-instance p2, Lmyf;

    invoke-direct {p2, p0}, Lmyf;-><init>(Landroidx/viewpager/widget/ViewPager;)V

    iput-object p2, p0, Landroidx/viewpager/widget/ViewPager;->V:Ljava/lang/Runnable;

    const/4 p2, 0x0

    iput p2, p0, Landroidx/viewpager/widget/ViewPager;->W:I

    .line 64
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->o(Landroid/content/Context;)V

    return-void
.end method

.method private final A(FF)Z
    .locals 11

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 3
    sub-float/2addr v0, p1

    .line 4
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 6
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getHeight()I

    .line 9
    move-result p1

    .line 10
    int-to-float p1, p1

    .line 11
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getWidth()I

    .line 14
    move-result v1

    .line 15
    int-to-float v1, v1

    .line 16
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 18
    invoke-static {v2}, Ljrb;->a(Landroid/widget/EdgeEffect;)F

    .line 21
    move-result v2

    .line 22
    const/4 v3, 0x0

    .line 23
    cmpl-float v2, v2, v3

    .line 25
    div-float v1, v0, v1

    .line 27
    div-float p1, p2, p1

    .line 29
    const/high16 v4, 0x3f800000

    .line 31
    if-eqz v2, :cond_0

    .line 33
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 35
    neg-float v1, v1

    .line 36
    sub-float p1, v4, p1

    .line 38
    invoke-static {v2, v1, p1}, Ljrb;->b(Landroid/widget/EdgeEffect;FF)F

    .line 41
    move-result p1

    .line 42
    neg-float p1, p1

    .line 43
    goto :goto_0

    .line 44
    :cond_0
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 46
    invoke-static {v2}, Ljrb;->a(Landroid/widget/EdgeEffect;)F

    .line 49
    move-result v2

    .line 50
    cmpl-float v2, v2, v3

    .line 52
    if-eqz v2, :cond_1

    .line 54
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 56
    invoke-static {v2, v1, p1}, Ljrb;->b(Landroid/widget/EdgeEffect;FF)F

    .line 59
    move-result p1

    .line 60
    goto :goto_0

    .line 61
    :cond_1
    move p1, v3

    .line 62
    :goto_0
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getWidth()I

    .line 65
    move-result v1

    .line 66
    int-to-float v1, v1

    .line 67
    mul-float/2addr p1, v1

    .line 68
    sub-float/2addr v0, p1

    .line 69
    cmpl-float p1, p1, v3

    .line 71
    const/4 v1, 0x0

    .line 72
    const/4 v2, 0x1

    .line 73
    if-eqz p1, :cond_2

    .line 75
    move p1, v2

    .line 76
    goto :goto_1

    .line 77
    :cond_2
    move p1, v1

    .line 78
    :goto_1
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 81
    move-result v3

    .line 82
    const v5, 0x38d1b717    # 1.0E-4f

    .line 85
    cmpg-float v3, v3, v5

    .line 87
    if-gez v3, :cond_3

    .line 89
    return p1

    .line 90
    :cond_3
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollX()I

    .line 93
    move-result v3

    .line 94
    int-to-float v3, v3

    .line 95
    add-float/2addr v3, v0

    .line 96
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->q()I

    .line 99
    move-result v0

    .line 100
    int-to-float v0, v0

    .line 101
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->v:F

    .line 103
    mul-float/2addr v5, v0

    .line 104
    iget v6, p0, Landroidx/viewpager/widget/ViewPager;->w:F

    .line 106
    mul-float/2addr v6, v0

    .line 107
    iget-object v7, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 109
    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 112
    move-result-object v8

    .line 113
    check-cast v8, Lmyi;

    .line 115
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 118
    move-result v9

    .line 119
    add-int/lit8 v9, v9, -0x1

    .line 121
    invoke-virtual {v7, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 124
    move-result-object v7

    .line 125
    check-cast v7, Lmyi;

    .line 127
    iget v9, v8, Lmyi;->b:I

    .line 129
    if-eqz v9, :cond_4

    .line 131
    iget v5, v8, Lmyi;->e:F

    .line 133
    mul-float/2addr v5, v0

    .line 134
    move v8, v1

    .line 135
    goto :goto_2

    .line 136
    :cond_4
    move v8, v2

    .line 137
    :goto_2
    iget v9, v7, Lmyi;->b:I

    .line 139
    iget-object v10, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 141
    invoke-virtual {v10}, Lmyc;->i()I

    .line 144
    move-result v10

    .line 145
    add-int/lit8 v10, v10, -0x1

    .line 147
    if-eq v9, v10, :cond_5

    .line 149
    iget v6, v7, Lmyi;->e:F

    .line 151
    mul-float/2addr v6, v0

    .line 152
    goto :goto_3

    .line 153
    :cond_5
    move v1, v2

    .line 154
    :goto_3
    cmpg-float v7, v3, v5

    .line 156
    if-gez v7, :cond_7

    .line 158
    if-eqz v8, :cond_6

    .line 160
    sub-float p1, v5, v3

    .line 162
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 164
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getHeight()I

    .line 167
    move-result v3

    .line 168
    int-to-float v3, v3

    .line 169
    div-float/2addr p2, v3

    .line 170
    sub-float/2addr v4, p2

    .line 171
    div-float/2addr p1, v0

    .line 172
    invoke-static {v1, p1, v4}, Ljrb;->b(Landroid/widget/EdgeEffect;FF)F

    .line 175
    goto :goto_4

    .line 176
    :cond_6
    move v2, p1

    .line 177
    :goto_4
    move v3, v5

    .line 178
    goto :goto_6

    .line 179
    :cond_7
    cmpl-float v4, v3, v6

    .line 181
    if-lez v4, :cond_9

    .line 183
    if-eqz v1, :cond_8

    .line 185
    sub-float/2addr v3, v6

    .line 186
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 188
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getHeight()I

    .line 191
    move-result v1

    .line 192
    int-to-float v1, v1

    .line 193
    div-float/2addr p2, v1

    .line 194
    div-float/2addr v3, v0

    .line 195
    invoke-static {p1, v3, p2}, Ljrb;->b(Landroid/widget/EdgeEffect;FF)F

    .line 198
    goto :goto_5

    .line 199
    :cond_8
    move v2, p1

    .line 200
    :goto_5
    move v3, v6

    .line 201
    goto :goto_6

    .line 202
    :cond_9
    move v2, p1

    .line 203
    :goto_6
    iget p1, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 205
    float-to-int p2, v3

    .line 206
    int-to-float v0, p2

    .line 207
    sub-float/2addr v3, v0

    .line 208
    add-float/2addr p1, v3

    .line 209
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 211
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollY()I

    .line 214
    move-result p1

    .line 215
    invoke-virtual {p0, p2, p1}, Landroidx/viewpager/widget/ViewPager;->scrollTo(II)V

    .line 218
    invoke-direct {p0, p2}, Landroidx/viewpager/widget/ViewPager;->z(I)Z

    .line 221
    return v2
.end method

.method private final B()Z
    .locals 2

    .line 1
    const/4 v0, -0x1

    .line 2
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->B:Z

    .line 7
    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->C:Z

    .line 9
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->M:Landroid/view/VelocityTracker;

    .line 11
    if-eqz v1, :cond_0

    .line 13
    invoke-virtual {v1}, Landroid/view/VelocityTracker;->recycle()V

    .line 16
    const/4 v1, 0x0

    .line 17
    iput-object v1, p0, Landroidx/viewpager/widget/ViewPager;->M:Landroid/view/VelocityTracker;

    .line 19
    :cond_0
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 21
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->onRelease()V

    .line 24
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 26
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->onRelease()V

    .line 29
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 31
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 34
    move-result v1

    .line 35
    if-eqz v1, :cond_2

    .line 37
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 39
    invoke-virtual {p0}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 42
    move-result p0

    .line 43
    if-nez p0, :cond_1

    .line 45
    goto :goto_0

    .line 46
    :cond_1
    return v0

    .line 47
    :cond_2
    :goto_0
    const/4 p0, 0x1

    .line 48
    return p0
.end method

.method private final C()V
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getParent()Landroid/view/ViewParent;

    .line 4
    move-result-object p0

    .line 5
    if-eqz p0, :cond_0

    .line 7
    const/4 v0, 0x1

    .line 8
    invoke-interface {p0, v0}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 11
    :cond_0
    return-void
.end method

.method private final q()I
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getMeasuredWidth()I

    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingLeft()I

    .line 8
    move-result v1

    .line 9
    sub-int/2addr v0, v1

    .line 10
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingRight()I

    .line 13
    move-result p0

    .line 14
    sub-int/2addr v0, p0

    .line 15
    return v0
.end method

.method private final r(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    .locals 2

    .line 1
    if-nez p1, :cond_0

    .line 3
    new-instance p1, Landroid/graphics/Rect;

    .line 5
    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    .line 8
    :cond_0
    if-nez p2, :cond_1

    .line 10
    const/4 p0, 0x0

    .line 11
    invoke-virtual {p1, p0, p0, p0, p0}, Landroid/graphics/Rect;->set(IIII)V

    .line 14
    return-object p1

    .line 15
    :cond_1
    invoke-virtual {p2}, Landroid/view/View;->getLeft()I

    .line 18
    move-result v0

    .line 19
    iput v0, p1, Landroid/graphics/Rect;->left:I

    .line 21
    invoke-virtual {p2}, Landroid/view/View;->getRight()I

    .line 24
    move-result v0

    .line 25
    iput v0, p1, Landroid/graphics/Rect;->right:I

    .line 27
    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    .line 30
    move-result v0

    .line 31
    iput v0, p1, Landroid/graphics/Rect;->top:I

    .line 33
    invoke-virtual {p2}, Landroid/view/View;->getBottom()I

    .line 36
    move-result v0

    .line 37
    iput v0, p1, Landroid/graphics/Rect;->bottom:I

    .line 39
    invoke-virtual {p2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 42
    move-result-object p2

    .line 43
    :goto_0
    instance-of v0, p2, Landroid/view/ViewGroup;

    .line 45
    if-eqz v0, :cond_2

    .line 47
    if-eq p2, p0, :cond_2

    .line 49
    check-cast p2, Landroid/view/ViewGroup;

    .line 51
    iget v0, p1, Landroid/graphics/Rect;->left:I

    .line 53
    invoke-virtual {p2}, Landroid/view/ViewGroup;->getLeft()I

    .line 56
    move-result v1

    .line 57
    add-int/2addr v0, v1

    .line 58
    iput v0, p1, Landroid/graphics/Rect;->left:I

    .line 60
    iget v0, p1, Landroid/graphics/Rect;->right:I

    .line 62
    invoke-virtual {p2}, Landroid/view/ViewGroup;->getRight()I

    .line 65
    move-result v1

    .line 66
    add-int/2addr v0, v1

    .line 67
    iput v0, p1, Landroid/graphics/Rect;->right:I

    .line 69
    iget v0, p1, Landroid/graphics/Rect;->top:I

    .line 71
    invoke-virtual {p2}, Landroid/view/ViewGroup;->getTop()I

    .line 74
    move-result v1

    .line 75
    add-int/2addr v0, v1

    .line 76
    iput v0, p1, Landroid/graphics/Rect;->top:I

    .line 78
    iget v0, p1, Landroid/graphics/Rect;->bottom:I

    .line 80
    invoke-virtual {p2}, Landroid/view/ViewGroup;->getBottom()I

    .line 83
    move-result v1

    .line 84
    add-int/2addr v0, v1

    .line 85
    iput v0, p1, Landroid/graphics/Rect;->bottom:I

    .line 87
    invoke-virtual {p2}, Landroid/view/ViewGroup;->getParent()Landroid/view/ViewParent;

    .line 90
    move-result-object p2

    .line 91
    goto :goto_0

    .line 92
    :cond_2
    return-object p1
.end method

.method private final s()Lmyi;
    .locals 14

    .line 1
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->q()I

    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-lez v0, :cond_0

    .line 8
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollX()I

    .line 11
    move-result v2

    .line 12
    int-to-float v2, v2

    .line 13
    int-to-float v3, v0

    .line 14
    div-float/2addr v2, v3

    .line 15
    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->r:I

    .line 17
    int-to-float v3, v3

    .line 18
    int-to-float v0, v0

    .line 19
    div-float/2addr v3, v0

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    move v2, v1

    .line 22
    move v3, v2

    .line 23
    :goto_0
    const/4 v0, 0x0

    .line 24
    const/4 v4, -0x1

    .line 25
    const/4 v5, 0x1

    .line 26
    const/4 v6, 0x0

    .line 27
    move v8, v0

    .line 28
    move v10, v4

    .line 29
    move v9, v5

    .line 30
    move-object v7, v6

    .line 31
    move v6, v1

    .line 32
    :goto_1
    iget-object v11, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 34
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 37
    move-result v12

    .line 38
    if-ge v8, v12, :cond_5

    .line 40
    invoke-virtual {v11, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 43
    move-result-object v12

    .line 44
    check-cast v12, Lmyi;

    .line 46
    if-nez v9, :cond_1

    .line 48
    iget v13, v12, Lmyi;->b:I

    .line 50
    add-int/2addr v10, v5

    .line 51
    if-eq v13, v10, :cond_1

    .line 53
    iget-object v12, p0, Landroidx/viewpager/widget/ViewPager;->l:Lmyi;

    .line 55
    add-float/2addr v1, v6

    .line 56
    add-float/2addr v1, v3

    .line 57
    iput v1, v12, Lmyi;->e:F

    .line 59
    iput v10, v12, Lmyi;->b:I

    .line 61
    const/high16 v1, 0x3f800000    # 1.0f

    .line 63
    iput v1, v12, Lmyi;->d:F

    .line 65
    add-int/lit8 v8, v8, -0x1

    .line 67
    :cond_1
    move-object v6, v12

    .line 68
    iget v1, v6, Lmyi;->e:F

    .line 70
    iget v10, v6, Lmyi;->d:F

    .line 72
    add-float/2addr v10, v1

    .line 73
    add-float/2addr v10, v3

    .line 74
    if-nez v9, :cond_2

    .line 76
    cmpl-float v9, v2, v1

    .line 78
    if-ltz v9, :cond_5

    .line 80
    :cond_2
    cmpg-float v7, v2, v10

    .line 82
    if-ltz v7, :cond_4

    .line 84
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 87
    move-result v7

    .line 88
    add-int/2addr v7, v4

    .line 89
    if-ne v8, v7, :cond_3

    .line 91
    goto :goto_2

    .line 92
    :cond_3
    iget v10, v6, Lmyi;->b:I

    .line 94
    iget v7, v6, Lmyi;->d:F

    .line 96
    add-int/lit8 v8, v8, 0x1

    .line 98
    move v9, v7

    .line 99
    move-object v7, v6

    .line 100
    move v6, v9

    .line 101
    move v9, v0

    .line 102
    goto :goto_1

    .line 103
    :cond_4
    :goto_2
    return-object v6

    .line 104
    :cond_5
    return-object v7
.end method

.method private final t(Z)V
    .locals 7

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->W:I

    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    const/4 v3, 0x0

    .line 6
    if-ne v0, v1, :cond_0

    .line 8
    move v0, v2

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    move v0, v3

    .line 11
    :goto_0
    if-eqz v0, :cond_2

    .line 13
    invoke-direct {p0, v3}, Landroidx/viewpager/widget/ViewPager;->y(Z)V

    .line 16
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 18
    invoke-virtual {v1}, Landroid/widget/Scroller;->isFinished()Z

    .line 21
    move-result v1

    .line 22
    if-nez v1, :cond_2

    .line 24
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 26
    invoke-virtual {v1}, Landroid/widget/Scroller;->abortAnimation()V

    .line 29
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollX()I

    .line 32
    move-result v1

    .line 33
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollY()I

    .line 36
    move-result v4

    .line 37
    iget-object v5, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 39
    invoke-virtual {v5}, Landroid/widget/Scroller;->getCurrX()I

    .line 42
    move-result v5

    .line 43
    iget-object v6, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 45
    invoke-virtual {v6}, Landroid/widget/Scroller;->getCurrY()I

    .line 48
    move-result v6

    .line 49
    if-ne v1, v5, :cond_1

    .line 51
    if-eq v4, v6, :cond_2

    .line 53
    :cond_1
    invoke-virtual {p0, v5, v6}, Landroidx/viewpager/widget/ViewPager;->scrollTo(II)V

    .line 56
    if-eq v5, v1, :cond_2

    .line 58
    invoke-direct {p0, v5}, Landroidx/viewpager/widget/ViewPager;->z(I)Z

    .line 61
    :cond_2
    iput-boolean v3, p0, Landroidx/viewpager/widget/ViewPager;->z:Z

    .line 63
    move v1, v3

    .line 64
    :goto_1
    iget-object v4, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 66
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 69
    move-result v5

    .line 70
    if-ge v1, v5, :cond_4

    .line 72
    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 75
    move-result-object v4

    .line 76
    check-cast v4, Lmyi;

    .line 78
    iget-boolean v5, v4, Lmyi;->c:Z

    .line 80
    if-eqz v5, :cond_3

    .line 82
    iput-boolean v3, v4, Lmyi;->c:Z

    .line 84
    move v0, v2

    .line 85
    :cond_3
    add-int/lit8 v1, v1, 0x1

    .line 87
    goto :goto_1

    .line 88
    :cond_4
    if-eqz v0, :cond_6

    .line 90
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->V:Ljava/lang/Runnable;

    .line 92
    if-eqz p1, :cond_5

    .line 94
    sget p1, Ljmy;->a:I

    .line 96
    invoke-virtual {p0, v0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    .line 99
    return-void

    .line 100
    :cond_5
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    .line 103
    :cond_6
    return-void
.end method

.method private final u(I)V
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->U:Lmyl;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-interface {v0, p1}, Lmyl;->b(I)V

    .line 8
    :cond_0
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->f:Ljava/util/List;

    .line 10
    if-eqz v0, :cond_2

    .line 12
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 15
    move-result v0

    .line 16
    const/4 v1, 0x0

    .line 17
    :goto_0
    if-ge v1, v0, :cond_2

    .line 19
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->f:Ljava/util/List;

    .line 21
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 24
    move-result-object v2

    .line 25
    check-cast v2, Lmyl;

    .line 27
    if-eqz v2, :cond_1

    .line 29
    invoke-interface {v2, p1}, Lmyl;->b(I)V

    .line 32
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 34
    goto :goto_0

    .line 35
    :cond_2
    return-void
.end method

.method private final v(Landroid/view/MotionEvent;)V
    .locals 3

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 4
    move-result v0

    .line 5
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 8
    move-result v1

    .line 9
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 11
    if-ne v1, v2, :cond_1

    .line 13
    if-nez v0, :cond_0

    .line 15
    const/4 v0, 0x1

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/4 v0, 0x0

    .line 18
    :goto_0
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 21
    move-result v1

    .line 22
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 24
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 27
    move-result p1

    .line 28
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 30
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->M:Landroid/view/VelocityTracker;

    .line 32
    if-eqz p0, :cond_1

    .line 34
    invoke-virtual {p0}, Landroid/view/VelocityTracker;->clear()V

    .line 37
    :cond_1
    return-void
.end method

.method private final w(IIII)V
    .locals 1

    .line 1
    if-lez p2, :cond_1

    .line 3
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 5
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_1

    .line 11
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 13
    invoke-virtual {v0}, Landroid/widget/Scroller;->isFinished()Z

    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_0

    .line 19
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 21
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getCurrentItem()I

    .line 24
    move-result p2

    .line 25
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->q()I

    .line 28
    move-result p0

    .line 29
    mul-int/2addr p2, p0

    .line 30
    invoke-virtual {p1, p2}, Landroid/widget/Scroller;->setFinalX(I)V

    .line 33
    return-void

    .line 34
    :cond_0
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingLeft()I

    .line 37
    move-result v0

    .line 38
    sub-int/2addr p1, v0

    .line 39
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingRight()I

    .line 42
    move-result v0

    .line 43
    sub-int/2addr p1, v0

    .line 44
    add-int/2addr p1, p3

    .line 45
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingLeft()I

    .line 48
    move-result p3

    .line 49
    sub-int/2addr p2, p3

    .line 50
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingRight()I

    .line 53
    move-result p3

    .line 54
    sub-int/2addr p2, p3

    .line 55
    add-int/2addr p2, p4

    .line 56
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollX()I

    .line 59
    move-result p3

    .line 60
    int-to-float p3, p3

    .line 61
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollY()I

    .line 64
    move-result p4

    .line 65
    int-to-float p2, p2

    .line 66
    div-float/2addr p3, p2

    .line 67
    int-to-float p1, p1

    .line 68
    mul-float/2addr p3, p1

    .line 69
    float-to-int p1, p3

    .line 70
    invoke-virtual {p0, p1, p4}, Landroidx/viewpager/widget/ViewPager;->scrollTo(II)V

    .line 73
    return-void

    .line 74
    :cond_1
    iget p2, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 76
    invoke-virtual {p0, p2}, Landroidx/viewpager/widget/ViewPager;->c(I)Lmyi;

    .line 79
    move-result-object p2

    .line 80
    if-eqz p2, :cond_2

    .line 82
    iget p2, p2, Lmyi;->e:F

    .line 84
    iget p3, p0, Landroidx/viewpager/widget/ViewPager;->w:F

    .line 86
    invoke-static {p2, p3}, Ljava/lang/Math;->min(FF)F

    .line 89
    move-result p2

    .line 90
    goto :goto_0

    .line 91
    :cond_2
    const/4 p2, 0x0

    .line 92
    :goto_0
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingLeft()I

    .line 95
    move-result p3

    .line 96
    sub-int/2addr p1, p3

    .line 97
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingRight()I

    .line 100
    move-result p3

    .line 101
    sub-int/2addr p1, p3

    .line 102
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollX()I

    .line 105
    move-result p3

    .line 106
    int-to-float p1, p1

    .line 107
    mul-float/2addr p2, p1

    .line 108
    float-to-int p1, p2

    .line 109
    if-eq p1, p3, :cond_3

    .line 111
    const/4 p2, 0x0

    .line 112
    invoke-direct {p0, p2}, Landroidx/viewpager/widget/ViewPager;->t(Z)V

    .line 115
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollY()I

    .line 118
    move-result p2

    .line 119
    invoke-virtual {p0, p1, p2}, Landroidx/viewpager/widget/ViewPager;->scrollTo(II)V

    .line 122
    :cond_3
    return-void
.end method

.method private final x(IZIZ)V
    .locals 10

    .line 1
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->c(I)Lmyi;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->q()I

    .line 11
    move-result v2

    .line 12
    int-to-float v2, v2

    .line 13
    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->v:F

    .line 15
    iget v0, v0, Lmyi;->e:F

    .line 17
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->w:F

    .line 19
    invoke-static {v0, v4}, Ljava/lang/Math;->min(FF)F

    .line 22
    move-result v0

    .line 23
    invoke-static {v3, v0}, Ljava/lang/Math;->max(FF)F

    .line 26
    move-result v0

    .line 27
    mul-float/2addr v2, v0

    .line 28
    float-to-int v0, v2

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    move v0, v1

    .line 31
    :goto_0
    if-eqz p2, :cond_8

    .line 33
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getChildCount()I

    .line 36
    move-result p2

    .line 37
    if-nez p2, :cond_1

    .line 39
    invoke-direct {p0, v1}, Landroidx/viewpager/widget/ViewPager;->y(Z)V

    .line 42
    goto/16 :goto_5

    .line 44
    :cond_1
    iget-object p2, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 46
    if-eqz p2, :cond_3

    .line 48
    invoke-virtual {p2}, Landroid/widget/Scroller;->isFinished()Z

    .line 51
    move-result p2

    .line 52
    if-nez p2, :cond_3

    .line 54
    iget-boolean p2, p0, Landroidx/viewpager/widget/ViewPager;->p:Z

    .line 56
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 58
    if-eqz p2, :cond_2

    .line 60
    invoke-virtual {v2}, Landroid/widget/Scroller;->getCurrX()I

    .line 63
    move-result p2

    .line 64
    goto :goto_1

    .line 65
    :cond_2
    invoke-virtual {v2}, Landroid/widget/Scroller;->getStartX()I

    .line 68
    move-result p2

    .line 69
    :goto_1
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 71
    invoke-virtual {v2}, Landroid/widget/Scroller;->abortAnimation()V

    .line 74
    invoke-direct {p0, v1}, Landroidx/viewpager/widget/ViewPager;->y(Z)V

    .line 77
    goto :goto_2

    .line 78
    :cond_3
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollX()I

    .line 81
    move-result p2

    .line 82
    :goto_2
    move v3, p2

    .line 83
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollY()I

    .line 86
    move-result v4

    .line 87
    sub-int/2addr v0, v3

    .line 88
    neg-int v6, v4

    .line 89
    if-nez v0, :cond_5

    .line 91
    if-nez v6, :cond_4

    .line 93
    invoke-direct {p0, v1}, Landroidx/viewpager/widget/ViewPager;->t(Z)V

    .line 96
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->f()V

    .line 99
    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->j(I)V

    .line 102
    goto :goto_5

    .line 103
    :cond_4
    move v5, v1

    .line 104
    goto :goto_3

    .line 105
    :cond_5
    move v5, v0

    .line 106
    :goto_3
    const/4 p2, 0x1

    .line 107
    invoke-direct {p0, p2}, Landroidx/viewpager/widget/ViewPager;->y(Z)V

    .line 110
    const/4 p2, 0x2

    .line 111
    invoke-virtual {p0, p2}, Landroidx/viewpager/widget/ViewPager;->j(I)V

    .line 114
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->q()I

    .line 117
    move-result p2

    .line 118
    div-int/lit8 v0, p2, 0x2

    .line 120
    invoke-static {v5}, Ljava/lang/Math;->abs(I)I

    .line 123
    move-result v2

    .line 124
    int-to-float v2, v2

    .line 125
    int-to-float p2, p2

    .line 126
    div-float/2addr v2, p2

    .line 127
    const/high16 v7, 0x3f800000    # 1.0f

    .line 129
    invoke-static {v7, v2}, Ljava/lang/Math;->min(FF)F

    .line 132
    move-result v2

    .line 133
    const/high16 v8, -0x41000000    # -0.5f

    .line 135
    add-float/2addr v2, v8

    .line 136
    const v8, 0x3ef1463b    # 0.47123894f

    .line 139
    mul-float/2addr v2, v8

    .line 140
    float-to-double v8, v2

    .line 141
    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    .line 144
    move-result-wide v8

    .line 145
    double-to-float v2, v8

    .line 146
    invoke-static {p3}, Ljava/lang/Math;->abs(I)I

    .line 149
    move-result p3

    .line 150
    if-lez p3, :cond_6

    .line 152
    int-to-float p2, v0

    .line 153
    mul-float/2addr v2, p2

    .line 154
    add-float/2addr p2, v2

    .line 155
    int-to-float p3, p3

    .line 156
    div-float/2addr p2, p3

    .line 157
    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    .line 160
    move-result p2

    .line 161
    const/high16 p3, 0x447a0000    # 1000.0f

    .line 163
    mul-float/2addr p2, p3

    .line 164
    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    .line 167
    move-result p2

    .line 168
    mul-int/lit8 p2, p2, 0x4

    .line 170
    goto :goto_4

    .line 171
    :cond_6
    invoke-static {v5}, Ljava/lang/Math;->abs(I)I

    .line 174
    move-result p3

    .line 175
    int-to-float p3, p3

    .line 176
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->r:I

    .line 178
    int-to-float v0, v0

    .line 179
    add-float/2addr p2, v0

    .line 180
    div-float/2addr p3, p2

    .line 181
    add-float/2addr p3, v7

    .line 182
    const/high16 p2, 0x42c80000    # 100.0f

    .line 184
    mul-float/2addr p3, p2

    .line 185
    float-to-int p2, p3

    .line 186
    :goto_4
    const/16 p3, 0x258

    .line 188
    invoke-static {p2, p3}, Ljava/lang/Math;->min(II)I

    .line 191
    move-result v7

    .line 192
    iput-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->p:Z

    .line 194
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 196
    invoke-virtual/range {v2 .. v7}, Landroid/widget/Scroller;->startScroll(IIIII)V

    .line 199
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->postInvalidateOnAnimation()V

    .line 202
    :goto_5
    if-eqz p4, :cond_7

    .line 204
    invoke-direct {p0, p1}, Landroidx/viewpager/widget/ViewPager;->u(I)V

    .line 207
    :cond_7
    return-void

    .line 208
    :cond_8
    if-eqz p4, :cond_9

    .line 210
    invoke-direct {p0, p1}, Landroidx/viewpager/widget/ViewPager;->u(I)V

    .line 213
    :cond_9
    invoke-direct {p0, v1}, Landroidx/viewpager/widget/ViewPager;->t(Z)V

    .line 216
    invoke-virtual {p0, v0, v1}, Landroidx/viewpager/widget/ViewPager;->scrollTo(II)V

    .line 219
    invoke-direct {p0, v0}, Landroidx/viewpager/widget/ViewPager;->z(I)Z

    .line 222
    return-void
.end method

.method private final y(Z)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->y:Z

    .line 3
    if-eq v0, p1, :cond_0

    .line 5
    iput-boolean p1, p0, Landroidx/viewpager/widget/ViewPager;->y:Z

    .line 7
    :cond_0
    return-void
.end method

.method private final z(I)Z
    .locals 7

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 6
    move-result v0

    .line 7
    const-string v1, "onPageScrolled did not call superclass implementation"

    .line 9
    const/4 v2, 0x0

    .line 10
    if-nez v0, :cond_2

    .line 12
    iget-boolean p1, p0, Landroidx/viewpager/widget/ViewPager;->R:Z

    .line 14
    if-eqz p1, :cond_0

    .line 16
    return v2

    .line 17
    :cond_0
    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->S:Z

    .line 19
    const/4 p1, 0x0

    .line 20
    invoke-virtual {p0, v2, p1}, Landroidx/viewpager/widget/ViewPager;->p(IF)V

    .line 23
    iget-boolean p0, p0, Landroidx/viewpager/widget/ViewPager;->S:Z

    .line 25
    if-eqz p0, :cond_1

    .line 27
    return v2

    .line 28
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 30
    invoke-direct {p0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 33
    throw p0

    .line 34
    :cond_2
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->s()Lmyi;

    .line 37
    move-result-object v0

    .line 38
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->q()I

    .line 41
    move-result v3

    .line 42
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->r:I

    .line 44
    int-to-float v4, v4

    .line 45
    int-to-float v3, v3

    .line 46
    iget v5, v0, Lmyi;->b:I

    .line 48
    int-to-float p1, p1

    .line 49
    iget v6, v0, Lmyi;->e:F

    .line 51
    div-float/2addr p1, v3

    .line 52
    sub-float/2addr p1, v6

    .line 53
    iget v0, v0, Lmyi;->d:F

    .line 55
    div-float/2addr v4, v3

    .line 56
    add-float/2addr v0, v4

    .line 57
    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->S:Z

    .line 59
    div-float/2addr p1, v0

    .line 60
    invoke-virtual {p0, v5, p1}, Landroidx/viewpager/widget/ViewPager;->p(IF)V

    .line 63
    iget-boolean p0, p0, Landroidx/viewpager/widget/ViewPager;->S:Z

    .line 65
    if-eqz p0, :cond_3

    .line 67
    const/4 p0, 0x1

    .line 68
    return p0

    .line 69
    :cond_3
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 71
    invoke-direct {p0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 74
    throw p0
.end method


# virtual methods
.method final a(II)Lmyi;
    .locals 2

    .line 1
    new-instance v0, Lmyi;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput p1, v0, Lmyi;->b:I

    .line 8
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 10
    invoke-virtual {v1, p0, p1}, Lmyc;->b(Landroid/view/ViewGroup;I)Ljava/lang/Object;

    .line 13
    move-result-object p1

    .line 14
    iput-object p1, v0, Lmyi;->a:Ljava/lang/Object;

    .line 16
    const/high16 p1, 0x3f800000    # 1.0f

    .line 18
    iput p1, v0, Lmyi;->d:F

    .line 20
    if-ltz p2, :cond_1

    .line 22
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 24
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 27
    move-result v1

    .line 28
    if-lt p2, v1, :cond_0

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    invoke-virtual {p1, p2, v0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 34
    return-object v0

    .line 35
    :cond_1
    :goto_0
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 37
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 40
    return-object v0
.end method

.method public final addFocusables(Ljava/util/ArrayList;II)V
    .locals 6

    .line 1
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getDescendantFocusability()I

    .line 8
    move-result v1

    .line 9
    const/high16 v2, 0x60000

    .line 11
    if-eq v1, v2, :cond_2

    .line 13
    const/4 v2, 0x0

    .line 14
    :goto_0
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getChildCount()I

    .line 17
    move-result v3

    .line 18
    if-ge v2, v3, :cond_1

    .line 20
    invoke-virtual {p0, v2}, Landroidx/viewpager/widget/ViewPager;->getChildAt(I)Landroid/view/View;

    .line 23
    move-result-object v3

    .line 24
    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    .line 27
    move-result v4

    .line 28
    if-nez v4, :cond_0

    .line 30
    invoke-virtual {p0, v3}, Landroidx/viewpager/widget/ViewPager;->b(Landroid/view/View;)Lmyi;

    .line 33
    move-result-object v4

    .line 34
    if-eqz v4, :cond_0

    .line 36
    iget v4, v4, Lmyi;->b:I

    .line 38
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 40
    if-ne v4, v5, :cond_0

    .line 42
    invoke-virtual {v3, p1, p2, p3}, Landroid/view/View;->addFocusables(Ljava/util/ArrayList;II)V

    .line 45
    :cond_0
    add-int/lit8 v2, v2, 0x1

    .line 47
    goto :goto_0

    .line 48
    :cond_1
    const/high16 p2, 0x40000

    .line 50
    if-ne v1, p2, :cond_2

    .line 52
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 55
    move-result p2

    .line 56
    if-ne v0, p2, :cond_5

    .line 58
    :cond_2
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->isFocusable()Z

    .line 61
    move-result p2

    .line 62
    if-nez p2, :cond_3

    .line 64
    goto :goto_1

    .line 65
    :cond_3
    const/4 p2, 0x1

    .line 66
    and-int/2addr p3, p2

    .line 67
    if-ne p3, p2, :cond_4

    .line 69
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->isInTouchMode()Z

    .line 72
    move-result p2

    .line 73
    if-eqz p2, :cond_4

    .line 75
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->isFocusableInTouchMode()Z

    .line 78
    move-result p2

    .line 79
    if-eqz p2, :cond_5

    .line 81
    :cond_4
    if-eqz p1, :cond_5

    .line 83
    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 86
    :cond_5
    :goto_1
    return-void
.end method

.method public final addTouchables(Ljava/util/ArrayList;)V
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_0
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getChildCount()I

    .line 5
    move-result v1

    .line 6
    if-ge v0, v1, :cond_1

    .line 8
    invoke-virtual {p0, v0}, Landroidx/viewpager/widget/ViewPager;->getChildAt(I)Landroid/view/View;

    .line 11
    move-result-object v1

    .line 12
    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    .line 15
    move-result v2

    .line 16
    if-nez v2, :cond_0

    .line 18
    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->b(Landroid/view/View;)Lmyi;

    .line 21
    move-result-object v2

    .line 22
    if-eqz v2, :cond_0

    .line 24
    iget v2, v2, Lmyi;->b:I

    .line 26
    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 28
    if-ne v2, v3, :cond_0

    .line 30
    invoke-virtual {v1, p1}, Landroid/view/View;->addTouchables(Ljava/util/ArrayList;)V

    .line 33
    :cond_0
    add-int/lit8 v0, v0, 0x1

    .line 35
    goto :goto_0

    .line 36
    :cond_1
    return-void
.end method

.method public final addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .locals 4

    .line 1
    invoke-virtual {p0, p3}, Landroidx/viewpager/widget/ViewPager;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 7
    new-instance p3, Lmyj;

    .line 9
    invoke-direct {p3}, Lmyj;-><init>()V

    .line 12
    :cond_0
    move-object v0, p3

    .line 13
    check-cast v0, Lmyj;

    .line 15
    iget-boolean v1, v0, Lmyj;->a:Z

    .line 17
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    move-result-object v2

    .line 21
    const-class v3, Lmyh;

    .line 23
    invoke-virtual {v2, v3}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    .line 26
    move-result-object v2

    .line 27
    const/4 v3, 0x1

    .line 28
    if-eqz v2, :cond_1

    .line 30
    move v2, v3

    .line 31
    goto :goto_0

    .line 32
    :cond_1
    const/4 v2, 0x0

    .line 33
    :goto_0
    or-int/2addr v1, v2

    .line 34
    iput-boolean v1, v0, Lmyj;->a:Z

    .line 36
    iget-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 38
    if-eqz v2, :cond_4

    .line 40
    if-eqz v0, :cond_3

    .line 42
    if-nez v1, :cond_2

    .line 44
    goto :goto_1

    .line 45
    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 47
    const-string p1, "Cannot add pager decor view during layout"

    .line 49
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 52
    throw p0

    .line 53
    :cond_3
    :goto_1
    iput-boolean v3, v0, Lmyj;->d:Z

    .line 55
    invoke-virtual {p0, p1, p2, p3}, Landroidx/viewpager/widget/ViewPager;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)Z

    .line 58
    return-void

    .line 59
    :cond_4
    invoke-super {p0, p1, p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 62
    return-void
.end method

.method final b(Landroid/view/View;)Lmyi;
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_0
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 4
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 7
    move-result v2

    .line 8
    if-ge v0, v2, :cond_1

    .line 10
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 13
    move-result-object v1

    .line 14
    check-cast v1, Lmyi;

    .line 16
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 18
    iget-object v3, v1, Lmyi;->a:Ljava/lang/Object;

    .line 20
    invoke-virtual {v2, p1, v3}, Lmyc;->d(Landroid/view/View;Ljava/lang/Object;)Z

    .line 23
    move-result v2

    .line 24
    if-eqz v2, :cond_0

    .line 26
    return-object v1

    .line 27
    :cond_0
    add-int/lit8 v0, v0, 0x1

    .line 29
    goto :goto_0

    .line 30
    :cond_1
    const/4 p0, 0x0

    .line 31
    return-object p0
.end method

.method final c(I)Lmyi;
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_0
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 4
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 7
    move-result v2

    .line 8
    if-ge v0, v2, :cond_1

    .line 10
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 13
    move-result-object v1

    .line 14
    check-cast v1, Lmyi;

    .line 16
    iget v2, v1, Lmyi;->b:I

    .line 18
    if-ne v2, p1, :cond_0

    .line 20
    return-object v1

    .line 21
    :cond_0
    add-int/lit8 v0, v0, 0x1

    .line 23
    goto :goto_0

    .line 24
    :cond_1
    const/4 p0, 0x0

    .line 25
    return-object p0
.end method

.method public final canScrollHorizontally(I)Z
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 6
    return v1

    .line 7
    :cond_0
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->q()I

    .line 10
    move-result v0

    .line 11
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollX()I

    .line 14
    move-result v2

    .line 15
    const/4 v3, 0x1

    .line 16
    if-gez p1, :cond_2

    .line 18
    int-to-float p1, v0

    .line 19
    iget p0, p0, Landroidx/viewpager/widget/ViewPager;->v:F

    .line 21
    mul-float/2addr p1, p0

    .line 22
    float-to-int p0, p1

    .line 23
    if-le v2, p0, :cond_1

    .line 25
    return v3

    .line 26
    :cond_1
    return v1

    .line 27
    :cond_2
    if-lez p1, :cond_3

    .line 29
    int-to-float p1, v0

    .line 30
    iget p0, p0, Landroidx/viewpager/widget/ViewPager;->w:F

    .line 32
    mul-float/2addr p1, p0

    .line 33
    float-to-int p0, p1

    .line 34
    if-ge v2, p0, :cond_3

    .line 36
    return v3

    .line 37
    :cond_3
    return v1
.end method

.method protected final checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 1

    .line 1
    instance-of v0, p1, Lmyj;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    .line 8
    move-result p0

    .line 9
    if-eqz p0, :cond_0

    .line 11
    const/4 p0, 0x1

    .line 12
    return p0

    .line 13
    :cond_0
    const/4 p0, 0x0

    .line 14
    return p0
.end method

.method public final computeScroll()V
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->p:Z

    .line 4
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 6
    invoke-virtual {v1}, Landroid/widget/Scroller;->isFinished()Z

    .line 9
    move-result v1

    .line 10
    if-nez v1, :cond_2

    .line 12
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 14
    invoke-virtual {v1}, Landroid/widget/Scroller;->computeScrollOffset()Z

    .line 17
    move-result v1

    .line 18
    if-eqz v1, :cond_2

    .line 20
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollX()I

    .line 23
    move-result v0

    .line 24
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollY()I

    .line 27
    move-result v1

    .line 28
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 30
    invoke-virtual {v2}, Landroid/widget/Scroller;->getCurrX()I

    .line 33
    move-result v2

    .line 34
    iget-object v3, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 36
    invoke-virtual {v3}, Landroid/widget/Scroller;->getCurrY()I

    .line 39
    move-result v3

    .line 40
    if-ne v0, v2, :cond_0

    .line 42
    if-eq v1, v3, :cond_1

    .line 44
    :cond_0
    invoke-virtual {p0, v2, v3}, Landroidx/viewpager/widget/ViewPager;->scrollTo(II)V

    .line 47
    invoke-direct {p0, v2}, Landroidx/viewpager/widget/ViewPager;->z(I)Z

    .line 50
    move-result v0

    .line 51
    if-nez v0, :cond_1

    .line 53
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 55
    invoke-virtual {v0}, Landroid/widget/Scroller;->abortAnimation()V

    .line 58
    const/4 v0, 0x0

    .line 59
    invoke-virtual {p0, v0, v3}, Landroidx/viewpager/widget/ViewPager;->scrollTo(II)V

    .line 62
    :cond_1
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->postInvalidateOnAnimation()V

    .line 65
    return-void

    .line 66
    :cond_2
    invoke-direct {p0, v0}, Landroidx/viewpager/widget/ViewPager;->t(Z)V

    .line 69
    return-void
.end method

.method public final d(Lmyl;)V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->f:Ljava/util/List;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, Ljava/util/ArrayList;

    .line 7
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 10
    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->f:Ljava/util/List;

    .line 12
    :cond_0
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->f:Ljava/util/List;

    .line 14
    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 17
    return-void
.end method

.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 5

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-nez v0, :cond_8

    .line 8
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 11
    move-result v0

    .line 12
    const/4 v2, 0x0

    .line 13
    if-nez v0, :cond_6

    .line 15
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 18
    move-result v0

    .line 19
    const/16 v3, 0x15

    .line 21
    const/4 v4, 0x2

    .line 22
    if-eq v0, v3, :cond_4

    .line 24
    const/16 v3, 0x16

    .line 26
    if-eq v0, v3, :cond_2

    .line 28
    const/16 v3, 0x3d

    .line 30
    if-eq v0, v3, :cond_0

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    invoke-virtual {p1}, Landroid/view/KeyEvent;->hasNoModifiers()Z

    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_1

    .line 39
    invoke-virtual {p0, v4}, Landroidx/viewpager/widget/ViewPager;->k(I)Z

    .line 42
    move-result p0

    .line 43
    goto :goto_1

    .line 44
    :cond_1
    invoke-virtual {p1, v1}, Landroid/view/KeyEvent;->hasModifiers(I)Z

    .line 47
    move-result p1

    .line 48
    if-eqz p1, :cond_6

    .line 50
    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->k(I)Z

    .line 53
    move-result p0

    .line 54
    goto :goto_1

    .line 55
    :cond_2
    invoke-virtual {p1, v4}, Landroid/view/KeyEvent;->hasModifiers(I)Z

    .line 58
    move-result p1

    .line 59
    if-eqz p1, :cond_3

    .line 61
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->n()Z

    .line 64
    move-result p0

    .line 65
    goto :goto_1

    .line 66
    :cond_3
    const/16 p1, 0x42

    .line 68
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->k(I)Z

    .line 71
    move-result p0

    .line 72
    goto :goto_1

    .line 73
    :cond_4
    invoke-virtual {p1, v4}, Landroid/view/KeyEvent;->hasModifiers(I)Z

    .line 76
    move-result p1

    .line 77
    if-eqz p1, :cond_5

    .line 79
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->m()Z

    .line 82
    move-result p0

    .line 83
    goto :goto_1

    .line 84
    :cond_5
    const/16 p1, 0x11

    .line 86
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->k(I)Z

    .line 89
    move-result p0

    .line 90
    goto :goto_1

    .line 91
    :cond_6
    :goto_0
    move p0, v2

    .line 92
    :goto_1
    if-eqz p0, :cond_7

    .line 94
    goto :goto_2

    .line 95
    :cond_7
    return v2

    .line 96
    :cond_8
    :goto_2
    return v1
.end method

.method public final dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)Z
    .locals 6

    .line 1
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    .line 4
    move-result v0

    .line 5
    const/16 v1, 0x1000

    .line 7
    if-ne v0, v1, :cond_0

    .line 9
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)Z

    .line 12
    move-result p0

    .line 13
    return p0

    .line 14
    :cond_0
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getChildCount()I

    .line 17
    move-result v0

    .line 18
    const/4 v1, 0x0

    .line 19
    move v2, v1

    .line 20
    :goto_0
    if-ge v2, v0, :cond_2

    .line 22
    invoke-virtual {p0, v2}, Landroidx/viewpager/widget/ViewPager;->getChildAt(I)Landroid/view/View;

    .line 25
    move-result-object v3

    .line 26
    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    .line 29
    move-result v4

    .line 30
    if-nez v4, :cond_1

    .line 32
    invoke-virtual {p0, v3}, Landroidx/viewpager/widget/ViewPager;->b(Landroid/view/View;)Lmyi;

    .line 35
    move-result-object v4

    .line 36
    if-eqz v4, :cond_1

    .line 38
    iget v4, v4, Lmyi;->b:I

    .line 40
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 42
    if-ne v4, v5, :cond_1

    .line 44
    invoke-virtual {v3, p1}, Landroid/view/View;->dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)Z

    .line 47
    move-result v3

    .line 48
    if-eqz v3, :cond_1

    .line 50
    const/4 p0, 0x1

    .line 51
    return p0

    .line 52
    :cond_1
    add-int/lit8 v2, v2, 0x1

    .line 54
    goto :goto_0

    .line 55
    :cond_2
    return v1
.end method

.method public final draw(Landroid/graphics/Canvas;)V
    .locals 7

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->draw(Landroid/graphics/Canvas;)V

    .line 4
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getOverScrollMode()I

    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_1

    .line 10
    const/4 v1, 0x1

    .line 11
    if-ne v0, v1, :cond_0

    .line 13
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 15
    if-eqz v0, :cond_0

    .line 17
    invoke-virtual {v0}, Lmyc;->i()I

    .line 20
    move-result v0

    .line 21
    if-le v0, v1, :cond_0

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 26
    invoke-virtual {p1}, Landroid/widget/EdgeEffect;->finish()V

    .line 29
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 31
    invoke-virtual {p0}, Landroid/widget/EdgeEffect;->finish()V

    .line 34
    return-void

    .line 35
    :cond_1
    :goto_0
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 37
    invoke-virtual {v0}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 40
    move-result v0

    .line 41
    if-nez v0, :cond_2

    .line 43
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 46
    move-result v0

    .line 47
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getHeight()I

    .line 50
    move-result v1

    .line 51
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingTop()I

    .line 54
    move-result v2

    .line 55
    sub-int/2addr v1, v2

    .line 56
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingBottom()I

    .line 59
    move-result v2

    .line 60
    sub-int/2addr v1, v2

    .line 61
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getWidth()I

    .line 64
    move-result v2

    .line 65
    const/high16 v3, 0x43870000

    .line 67
    invoke-virtual {p1, v3}, Landroid/graphics/Canvas;->rotate(F)V

    .line 70
    neg-int v3, v1

    .line 71
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingTop()I

    .line 74
    move-result v4

    .line 75
    add-int/2addr v3, v4

    .line 76
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->v:F

    .line 78
    int-to-float v5, v2

    .line 79
    mul-float/2addr v4, v5

    .line 80
    int-to-float v3, v3

    .line 81
    invoke-virtual {p1, v3, v4}, Landroid/graphics/Canvas;->translate(FF)V

    .line 84
    iget-object v3, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 86
    invoke-virtual {v3, v1, v2}, Landroid/widget/EdgeEffect;->setSize(II)V

    .line 89
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 91
    invoke-virtual {v1, p1}, Landroid/widget/EdgeEffect;->draw(Landroid/graphics/Canvas;)Z

    .line 94
    move-result v1

    .line 95
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 98
    goto :goto_1

    .line 99
    :cond_2
    const/4 v1, 0x0

    .line 100
    :goto_1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 102
    invoke-virtual {v0}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 105
    move-result v0

    .line 106
    if-nez v0, :cond_3

    .line 108
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 111
    move-result v0

    .line 112
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getWidth()I

    .line 115
    move-result v2

    .line 116
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getHeight()I

    .line 119
    move-result v3

    .line 120
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingTop()I

    .line 123
    move-result v4

    .line 124
    sub-int/2addr v3, v4

    .line 125
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingBottom()I

    .line 128
    move-result v4

    .line 129
    sub-int/2addr v3, v4

    .line 130
    const/high16 v4, 0x42b40000

    .line 132
    invoke-virtual {p1, v4}, Landroid/graphics/Canvas;->rotate(F)V

    .line 135
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingTop()I

    .line 138
    move-result v4

    .line 139
    neg-int v4, v4

    .line 140
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->w:F

    .line 142
    const/high16 v6, 0x3f800000    # 1.0f

    .line 144
    add-float/2addr v5, v6

    .line 145
    neg-float v5, v5

    .line 146
    int-to-float v6, v2

    .line 147
    int-to-float v4, v4

    .line 148
    mul-float/2addr v5, v6

    .line 149
    invoke-virtual {p1, v4, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 152
    iget-object v4, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 154
    invoke-virtual {v4, v3, v2}, Landroid/widget/EdgeEffect;->setSize(II)V

    .line 157
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 159
    invoke-virtual {v2, p1}, Landroid/widget/EdgeEffect;->draw(Landroid/graphics/Canvas;)Z

    .line 162
    move-result v2

    .line 163
    or-int/2addr v1, v2

    .line 164
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 167
    :cond_3
    if-eqz v1, :cond_4

    .line 169
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->postInvalidateOnAnimation()V

    .line 172
    :cond_4
    return-void
.end method

.method protected final drawableStateChanged()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->drawableStateChanged()V

    .line 4
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->s:Landroid/graphics/drawable/Drawable;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    .line 11
    move-result v1

    .line 12
    if-eqz v1, :cond_0

    .line 14
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getDrawableState()[I

    .line 17
    move-result-object p0

    .line 18
    invoke-virtual {v0, p0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 21
    :cond_0
    return-void
.end method

.method public final e()V
    .locals 12

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 3
    invoke-virtual {v0}, Lmyc;->i()I

    .line 6
    move-result v0

    .line 7
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->j:I

    .line 9
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 11
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 14
    move-result v2

    .line 15
    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->A:I

    .line 17
    add-int/2addr v3, v3

    .line 18
    const/4 v4, 0x1

    .line 19
    add-int/2addr v3, v4

    .line 20
    const/4 v5, 0x0

    .line 21
    if-ge v2, v3, :cond_0

    .line 23
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 26
    move-result v2

    .line 27
    if-ge v2, v0, :cond_0

    .line 29
    move v2, v4

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    move v2, v5

    .line 32
    :goto_0
    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 34
    move v6, v5

    .line 35
    move v7, v6

    .line 36
    :goto_1
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 39
    move-result v8

    .line 40
    if-ge v6, v8, :cond_7

    .line 42
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 45
    move-result-object v8

    .line 46
    check-cast v8, Lmyi;

    .line 48
    iget-object v9, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 50
    iget-object v10, v8, Lmyi;->a:Ljava/lang/Object;

    .line 52
    invoke-virtual {v9, v10}, Lmyc;->j(Ljava/lang/Object;)I

    .line 55
    move-result v9

    .line 56
    const/4 v10, -0x1

    .line 57
    if-ne v9, v10, :cond_1

    .line 59
    goto :goto_2

    .line 60
    :cond_1
    const/4 v11, -0x2

    .line 61
    if-ne v9, v11, :cond_4

    .line 63
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 66
    add-int/lit8 v6, v6, -0x1

    .line 68
    if-nez v7, :cond_2

    .line 70
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 72
    invoke-virtual {v2, p0}, Lmyc;->c(Landroid/view/ViewGroup;)V

    .line 75
    :cond_2
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 77
    iget v7, v8, Lmyi;->b:I

    .line 79
    iget-object v7, v8, Lmyi;->a:Ljava/lang/Object;

    .line 81
    invoke-virtual {v2, p0, v7}, Lmyc;->e(Landroid/view/ViewGroup;Ljava/lang/Object;)V

    .line 84
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 86
    iget v7, v8, Lmyi;->b:I

    .line 88
    if-ne v2, v7, :cond_3

    .line 90
    add-int/2addr v10, v0

    .line 91
    invoke-static {v2, v10}, Ljava/lang/Math;->min(II)I

    .line 94
    move-result v2

    .line 95
    invoke-static {v5, v2}, Ljava/lang/Math;->max(II)I

    .line 98
    move-result v2

    .line 99
    move v3, v2

    .line 100
    :cond_3
    move v2, v4

    .line 101
    move v7, v2

    .line 102
    goto :goto_2

    .line 103
    :cond_4
    iget v10, v8, Lmyi;->b:I

    .line 105
    if-eq v10, v9, :cond_6

    .line 107
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 109
    if-ne v10, v2, :cond_5

    .line 111
    move v3, v9

    .line 112
    :cond_5
    iput v9, v8, Lmyi;->b:I

    .line 114
    move v2, v4

    .line 115
    :cond_6
    :goto_2
    add-int/2addr v6, v4

    .line 116
    goto :goto_1

    .line 117
    :cond_7
    if-eqz v7, :cond_8

    .line 119
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 121
    invoke-virtual {v0}, Lmyc;->f()V

    .line 124
    :cond_8
    sget-object v0, Landroidx/viewpager/widget/ViewPager;->h:Ljava/util/Comparator;

    .line 126
    invoke-static {v1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 129
    if-eqz v2, :cond_b

    .line 131
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getChildCount()I

    .line 134
    move-result v0

    .line 135
    move v1, v5

    .line 136
    :goto_3
    if-ge v1, v0, :cond_a

    .line 138
    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->getChildAt(I)Landroid/view/View;

    .line 141
    move-result-object v2

    .line 142
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 145
    move-result-object v2

    .line 146
    check-cast v2, Lmyj;

    .line 148
    iget-boolean v6, v2, Lmyj;->a:Z

    .line 150
    if-nez v6, :cond_9

    .line 152
    const/4 v6, 0x0

    .line 153
    iput v6, v2, Lmyj;->c:F

    .line 155
    :cond_9
    add-int/lit8 v1, v1, 0x1

    .line 157
    goto :goto_3

    .line 158
    :cond_a
    invoke-virtual {p0, v3, v5, v4, v5}, Landroidx/viewpager/widget/ViewPager;->i(IZZI)V

    .line 161
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->requestLayout()V

    .line 164
    :cond_b
    return-void
.end method

.method public final f()V
    .locals 1

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 3
    invoke-virtual {p0, v0}, Landroidx/viewpager/widget/ViewPager;->g(I)V

    .line 6
    return-void
.end method

.method final g(I)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 3
    move/from16 v1, p1

    .line 5
    iget v2, v0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 7
    if-eq v2, v1, :cond_0

    .line 9
    invoke-virtual {v0, v2}, Landroidx/viewpager/widget/ViewPager;->c(I)Lmyi;

    .line 12
    move-result-object v2

    .line 13
    iput v1, v0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const/4 v2, 0x0

    .line 17
    :goto_0
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 19
    if-nez v1, :cond_1

    .line 21
    goto/16 :goto_24

    .line 23
    :cond_1
    iget-boolean v1, v0, Landroidx/viewpager/widget/ViewPager;->z:Z

    .line 25
    if-nez v1, :cond_30

    .line 27
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getWindowToken()Landroid/os/IBinder;

    .line 30
    move-result-object v1

    .line 31
    if-eqz v1, :cond_30

    .line 33
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 35
    invoke-virtual {v1, v0}, Lmyc;->c(Landroid/view/ViewGroup;)V

    .line 38
    iget v1, v0, Landroidx/viewpager/widget/ViewPager;->A:I

    .line 40
    iget v4, v0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 42
    sub-int/2addr v4, v1

    .line 43
    const/4 v5, 0x0

    .line 44
    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    .line 47
    move-result v4

    .line 48
    iget-object v6, v0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 50
    invoke-virtual {v6}, Lmyc;->i()I

    .line 53
    move-result v6

    .line 54
    add-int/lit8 v7, v6, -0x1

    .line 56
    iget v8, v0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 58
    add-int/2addr v8, v1

    .line 59
    invoke-static {v7, v8}, Ljava/lang/Math;->min(II)I

    .line 62
    move-result v1

    .line 63
    iget v7, v0, Landroidx/viewpager/widget/ViewPager;->j:I

    .line 65
    if-ne v6, v7, :cond_2f

    .line 67
    move v7, v5

    .line 68
    :goto_1
    iget-object v8, v0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 70
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 73
    move-result v9

    .line 74
    if-ge v7, v9, :cond_3

    .line 76
    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 79
    move-result-object v9

    .line 80
    check-cast v9, Lmyi;

    .line 82
    iget v10, v9, Lmyi;->b:I

    .line 84
    iget v11, v0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 86
    if-lt v10, v11, :cond_2

    .line 88
    if-eq v10, v11, :cond_4

    .line 90
    goto :goto_2

    .line 91
    :cond_2
    add-int/lit8 v7, v7, 0x1

    .line 93
    goto :goto_1

    .line 94
    :cond_3
    :goto_2
    const/4 v9, 0x0

    .line 95
    :cond_4
    if-nez v9, :cond_5

    .line 97
    if-lez v6, :cond_5

    .line 99
    iget v9, v0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 101
    invoke-virtual {v0, v9, v7}, Landroidx/viewpager/widget/ViewPager;->a(II)Lmyi;

    .line 104
    move-result-object v9

    .line 105
    :cond_5
    if-eqz v9, :cond_27

    .line 107
    add-int/lit8 v11, v7, -0x1

    .line 109
    if-ltz v11, :cond_6

    .line 111
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 114
    move-result-object v12

    .line 115
    check-cast v12, Lmyi;

    .line 117
    goto :goto_3

    .line 118
    :cond_6
    const/4 v12, 0x0

    .line 119
    :goto_3
    invoke-direct {v0}, Landroidx/viewpager/widget/ViewPager;->q()I

    .line 122
    move-result v13

    .line 123
    const/high16 v14, 0x40000000

    .line 125
    if-gtz v13, :cond_7

    .line 127
    const/4 v15, 0x0

    .line 128
    goto :goto_4

    .line 129
    :cond_7
    iget v15, v9, Lmyi;->d:F

    .line 131
    sub-float v15, v14, v15

    .line 133
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getPaddingLeft()I

    .line 136
    move-result v3

    .line 137
    int-to-float v3, v3

    .line 138
    int-to-float v5, v13

    .line 139
    div-float/2addr v3, v5

    .line 140
    add-float/2addr v15, v3

    .line 141
    :goto_4
    iget v3, v0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 143
    add-int/lit8 v3, v3, -0x1

    .line 145
    const/4 v5, 0x0

    .line 146
    :goto_5
    if-ltz v3, :cond_e

    .line 148
    cmpl-float v16, v5, v15

    .line 150
    if-ltz v16, :cond_a

    .line 152
    if-ge v3, v4, :cond_a

    .line 154
    if-nez v12, :cond_8

    .line 156
    goto :goto_9

    .line 157
    :cond_8
    const/16 v16, 0x0

    .line 159
    iget v10, v12, Lmyi;->b:I

    .line 161
    if-ne v3, v10, :cond_d

    .line 163
    iget-boolean v10, v12, Lmyi;->c:Z

    .line 165
    if-nez v10, :cond_d

    .line 167
    add-int/lit8 v10, v11, -0x1

    .line 169
    add-int/lit8 v7, v7, -0x1

    .line 171
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 174
    iget-object v11, v0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 176
    iget-object v12, v12, Lmyi;->a:Ljava/lang/Object;

    .line 178
    invoke-virtual {v11, v0, v12}, Lmyc;->e(Landroid/view/ViewGroup;Ljava/lang/Object;)V

    .line 181
    if-ltz v10, :cond_9

    .line 183
    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 186
    move-result-object v11

    .line 187
    check-cast v11, Lmyi;

    .line 189
    goto :goto_6

    .line 190
    :cond_9
    const/4 v11, 0x0

    .line 191
    :goto_6
    move-object v12, v11

    .line 192
    move v11, v10

    .line 193
    goto :goto_8

    .line 194
    :cond_a
    const/16 v16, 0x0

    .line 196
    if-eqz v12, :cond_b

    .line 198
    iget v10, v12, Lmyi;->b:I

    .line 200
    if-ne v3, v10, :cond_b

    .line 202
    add-int/lit8 v11, v11, -0x1

    .line 204
    iget v10, v12, Lmyi;->d:F

    .line 206
    add-float/2addr v5, v10

    .line 207
    if-ltz v11, :cond_c

    .line 209
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 212
    move-result-object v10

    .line 213
    check-cast v10, Lmyi;

    .line 215
    goto :goto_7

    .line 216
    :cond_b
    add-int/lit8 v7, v7, 0x1

    .line 218
    add-int/lit8 v10, v11, 0x1

    .line 220
    invoke-virtual {v0, v3, v10}, Landroidx/viewpager/widget/ViewPager;->a(II)Lmyi;

    .line 223
    move-result-object v10

    .line 224
    iget v10, v10, Lmyi;->d:F

    .line 226
    add-float/2addr v5, v10

    .line 227
    if-ltz v11, :cond_c

    .line 229
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 232
    move-result-object v10

    .line 233
    check-cast v10, Lmyi;

    .line 235
    :goto_7
    move-object v12, v10

    .line 236
    goto :goto_8

    .line 237
    :cond_c
    const/4 v12, 0x0

    .line 238
    :cond_d
    :goto_8
    add-int/lit8 v3, v3, -0x1

    .line 240
    goto :goto_5

    .line 241
    :cond_e
    :goto_9
    const/16 v16, 0x0

    .line 243
    add-int/lit8 v3, v7, 0x1

    .line 245
    add-int/lit8 v7, v7, -0x1

    .line 247
    iget v4, v9, Lmyi;->d:F

    .line 249
    cmpg-float v5, v4, v14

    .line 251
    if-gez v5, :cond_17

    .line 253
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 256
    move-result v5

    .line 257
    if-ge v3, v5, :cond_f

    .line 259
    invoke-virtual {v8, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 262
    move-result-object v5

    .line 263
    check-cast v5, Lmyi;

    .line 265
    goto :goto_a

    .line 266
    :cond_f
    const/4 v5, 0x0

    .line 267
    :goto_a
    if-gtz v13, :cond_10

    .line 269
    move/from16 v10, v16

    .line 271
    goto :goto_b

    .line 272
    :cond_10
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getPaddingRight()I

    .line 275
    move-result v10

    .line 276
    int-to-float v10, v10

    .line 277
    int-to-float v11, v13

    .line 278
    div-float/2addr v10, v11

    .line 279
    add-float/2addr v10, v14

    .line 280
    :goto_b
    iget v11, v0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 282
    add-int/lit8 v11, v11, 0x1

    .line 284
    move v12, v3

    .line 285
    :goto_c
    if-ge v11, v6, :cond_17

    .line 287
    cmpl-float v13, v4, v10

    .line 289
    if-ltz v13, :cond_13

    .line 291
    if-le v11, v1, :cond_13

    .line 293
    if-nez v5, :cond_11

    .line 295
    goto :goto_f

    .line 296
    :cond_11
    iget v13, v5, Lmyi;->b:I

    .line 298
    if-ne v11, v13, :cond_16

    .line 300
    iget-boolean v13, v5, Lmyi;->c:Z

    .line 302
    if-nez v13, :cond_16

    .line 304
    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 307
    iget-object v13, v0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 309
    iget-object v5, v5, Lmyi;->a:Ljava/lang/Object;

    .line 311
    invoke-virtual {v13, v0, v5}, Lmyc;->e(Landroid/view/ViewGroup;Ljava/lang/Object;)V

    .line 314
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 317
    move-result v5

    .line 318
    if-ge v12, v5, :cond_12

    .line 320
    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 323
    move-result-object v5

    .line 324
    check-cast v5, Lmyi;

    .line 326
    goto :goto_e

    .line 327
    :cond_12
    const/4 v5, 0x0

    .line 328
    goto :goto_e

    .line 329
    :cond_13
    add-int/lit8 v13, v12, 0x1

    .line 331
    if-eqz v5, :cond_14

    .line 333
    iget v14, v5, Lmyi;->b:I

    .line 335
    if-ne v11, v14, :cond_14

    .line 337
    iget v5, v5, Lmyi;->d:F

    .line 339
    add-float/2addr v4, v5

    .line 340
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 343
    move-result v5

    .line 344
    if-ge v13, v5, :cond_15

    .line 346
    invoke-virtual {v8, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 349
    move-result-object v5

    .line 350
    check-cast v5, Lmyi;

    .line 352
    goto :goto_d

    .line 353
    :cond_14
    invoke-virtual {v0, v11, v12}, Landroidx/viewpager/widget/ViewPager;->a(II)Lmyi;

    .line 356
    move-result-object v5

    .line 357
    iget v5, v5, Lmyi;->d:F

    .line 359
    add-float/2addr v4, v5

    .line 360
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 363
    move-result v5

    .line 364
    if-ge v13, v5, :cond_15

    .line 366
    invoke-virtual {v8, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 369
    move-result-object v5

    .line 370
    check-cast v5, Lmyi;

    .line 372
    goto :goto_d

    .line 373
    :cond_15
    const/4 v5, 0x0

    .line 374
    :goto_d
    move v12, v13

    .line 375
    :cond_16
    :goto_e
    add-int/lit8 v11, v11, 0x1

    .line 377
    goto :goto_c

    .line 378
    :cond_17
    :goto_f
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 380
    invoke-virtual {v1}, Lmyc;->i()I

    .line 383
    move-result v1

    .line 384
    invoke-direct {v0}, Landroidx/viewpager/widget/ViewPager;->q()I

    .line 387
    move-result v4

    .line 388
    if-lez v4, :cond_18

    .line 390
    iget v5, v0, Landroidx/viewpager/widget/ViewPager;->r:I

    .line 392
    int-to-float v5, v5

    .line 393
    int-to-float v4, v4

    .line 394
    div-float/2addr v5, v4

    .line 395
    goto :goto_10

    .line 396
    :cond_18
    move/from16 v5, v16

    .line 398
    :goto_10
    const/high16 v4, 0x3f800000

    .line 400
    if-eqz v2, :cond_1e

    .line 402
    iget v6, v2, Lmyi;->b:I

    .line 404
    iget v10, v9, Lmyi;->b:I

    .line 406
    if-ge v6, v10, :cond_1b

    .line 408
    iget v10, v2, Lmyi;->e:F

    .line 410
    iget v2, v2, Lmyi;->d:F

    .line 412
    add-float/2addr v10, v2

    .line 413
    add-float/2addr v10, v5

    .line 414
    add-int/lit8 v6, v6, 0x1

    .line 416
    const/4 v2, 0x0

    .line 417
    :goto_11
    iget v11, v9, Lmyi;->b:I

    .line 419
    if-gt v6, v11, :cond_1e

    .line 421
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 424
    move-result v11

    .line 425
    if-ge v2, v11, :cond_1e

    .line 427
    invoke-virtual {v8, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 430
    move-result-object v11

    .line 431
    check-cast v11, Lmyi;

    .line 433
    :goto_12
    iget v12, v11, Lmyi;->b:I

    .line 435
    if-le v6, v12, :cond_19

    .line 437
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 440
    move-result v12

    .line 441
    add-int/lit8 v12, v12, -0x1

    .line 443
    if-ge v2, v12, :cond_19

    .line 445
    add-int/lit8 v2, v2, 0x1

    .line 447
    invoke-virtual {v8, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 450
    move-result-object v11

    .line 451
    check-cast v11, Lmyi;

    .line 453
    goto :goto_12

    .line 454
    :cond_19
    :goto_13
    iget v12, v11, Lmyi;->b:I

    .line 456
    if-ge v6, v12, :cond_1a

    .line 458
    add-float v12, v5, v4

    .line 460
    add-float/2addr v10, v12

    .line 461
    add-int/lit8 v6, v6, 0x1

    .line 463
    goto :goto_13

    .line 464
    :cond_1a
    iput v10, v11, Lmyi;->e:F

    .line 466
    iget v11, v11, Lmyi;->d:F

    .line 468
    add-float/2addr v11, v5

    .line 469
    add-float/2addr v10, v11

    .line 470
    add-int/lit8 v6, v6, 0x1

    .line 472
    goto :goto_11

    .line 473
    :cond_1b
    if-le v6, v10, :cond_1e

    .line 475
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 478
    move-result v10

    .line 479
    add-int/lit8 v10, v10, -0x1

    .line 481
    iget v2, v2, Lmyi;->e:F

    .line 483
    :goto_14
    add-int/lit8 v6, v6, -0x1

    .line 485
    iget v11, v9, Lmyi;->b:I

    .line 487
    if-lt v6, v11, :cond_1e

    .line 489
    if-ltz v10, :cond_1e

    .line 491
    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 494
    move-result-object v11

    .line 495
    check-cast v11, Lmyi;

    .line 497
    :goto_15
    iget v12, v11, Lmyi;->b:I

    .line 499
    if-ge v6, v12, :cond_1c

    .line 501
    if-lez v10, :cond_1c

    .line 503
    add-int/lit8 v10, v10, -0x1

    .line 505
    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 508
    move-result-object v11

    .line 509
    check-cast v11, Lmyi;

    .line 511
    goto :goto_15

    .line 512
    :cond_1c
    :goto_16
    iget v12, v11, Lmyi;->b:I

    .line 514
    if-le v6, v12, :cond_1d

    .line 516
    add-float v12, v5, v4

    .line 518
    sub-float/2addr v2, v12

    .line 519
    add-int/lit8 v6, v6, -0x1

    .line 521
    goto :goto_16

    .line 522
    :cond_1d
    iget v12, v11, Lmyi;->d:F

    .line 524
    add-float/2addr v12, v5

    .line 525
    sub-float/2addr v2, v12

    .line 526
    iput v2, v11, Lmyi;->e:F

    .line 528
    goto :goto_14

    .line 529
    :cond_1e
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 532
    move-result v2

    .line 533
    iget v6, v9, Lmyi;->e:F

    .line 535
    iget v10, v9, Lmyi;->b:I

    .line 537
    add-int/lit8 v11, v10, -0x1

    .line 539
    if-nez v10, :cond_1f

    .line 541
    move v12, v6

    .line 542
    goto :goto_17

    .line 543
    :cond_1f
    const v12, -0x800001    # -3.4028235E38f

    .line 546
    :goto_17
    iput v12, v0, Landroidx/viewpager/widget/ViewPager;->v:F

    .line 548
    add-int/lit8 v1, v1, -0x1

    .line 550
    const/high16 v12, -0x40800000

    .line 552
    if-ne v10, v1, :cond_20

    .line 554
    iget v10, v9, Lmyi;->d:F

    .line 556
    add-float/2addr v10, v6

    .line 557
    add-float/2addr v10, v12

    .line 558
    goto :goto_18

    .line 559
    :cond_20
    const v10, 0x7f7fffff    # 3.4028235E38f

    .line 562
    :goto_18
    iput v10, v0, Landroidx/viewpager/widget/ViewPager;->w:F

    .line 564
    :goto_19
    if-ltz v7, :cond_23

    .line 566
    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 569
    move-result-object v10

    .line 570
    check-cast v10, Lmyi;

    .line 572
    :goto_1a
    iget v13, v10, Lmyi;->b:I

    .line 574
    if-le v11, v13, :cond_21

    .line 576
    add-float v13, v5, v4

    .line 578
    sub-float/2addr v6, v13

    .line 579
    add-int/lit8 v11, v11, -0x1

    .line 581
    goto :goto_1a

    .line 582
    :cond_21
    iget v14, v10, Lmyi;->d:F

    .line 584
    add-float/2addr v14, v5

    .line 585
    sub-float/2addr v6, v14

    .line 586
    iput v6, v10, Lmyi;->e:F

    .line 588
    if-nez v13, :cond_22

    .line 590
    iput v6, v0, Landroidx/viewpager/widget/ViewPager;->v:F

    .line 592
    :cond_22
    add-int/lit8 v11, v11, -0x1

    .line 594
    add-int/lit8 v7, v7, -0x1

    .line 596
    goto :goto_19

    .line 597
    :cond_23
    iget v6, v9, Lmyi;->e:F

    .line 599
    iget v7, v9, Lmyi;->d:F

    .line 601
    add-float/2addr v6, v7

    .line 602
    add-float/2addr v6, v5

    .line 603
    iget v7, v9, Lmyi;->b:I

    .line 605
    add-int/lit8 v7, v7, 0x1

    .line 607
    :goto_1b
    if-ge v3, v2, :cond_26

    .line 609
    invoke-virtual {v8, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 612
    move-result-object v10

    .line 613
    check-cast v10, Lmyi;

    .line 615
    :goto_1c
    iget v11, v10, Lmyi;->b:I

    .line 617
    if-ge v7, v11, :cond_24

    .line 619
    add-float v11, v5, v4

    .line 621
    add-float/2addr v6, v11

    .line 622
    add-int/lit8 v7, v7, 0x1

    .line 624
    goto :goto_1c

    .line 625
    :cond_24
    if-ne v11, v1, :cond_25

    .line 627
    iget v11, v10, Lmyi;->d:F

    .line 629
    add-float/2addr v11, v6

    .line 630
    add-float/2addr v11, v12

    .line 631
    iput v11, v0, Landroidx/viewpager/widget/ViewPager;->w:F

    .line 633
    :cond_25
    iput v6, v10, Lmyi;->e:F

    .line 635
    iget v10, v10, Lmyi;->d:F

    .line 637
    add-float/2addr v10, v5

    .line 638
    add-float/2addr v6, v10

    .line 639
    add-int/lit8 v7, v7, 0x1

    .line 641
    add-int/lit8 v3, v3, 0x1

    .line 643
    goto :goto_1b

    .line 644
    :cond_26
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 646
    iget-object v2, v9, Lmyi;->a:Ljava/lang/Object;

    .line 648
    invoke-virtual {v1, v2}, Lmyc;->h(Ljava/lang/Object;)V

    .line 651
    goto :goto_1d

    .line 652
    :cond_27
    const/16 v16, 0x0

    .line 654
    :goto_1d
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 656
    invoke-virtual {v1}, Lmyc;->f()V

    .line 659
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getChildCount()I

    .line 662
    move-result v1

    .line 663
    const/4 v2, 0x0

    .line 664
    :goto_1e
    if-ge v2, v1, :cond_29

    .line 666
    invoke-virtual {v0, v2}, Landroidx/viewpager/widget/ViewPager;->getChildAt(I)Landroid/view/View;

    .line 669
    move-result-object v3

    .line 670
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 673
    move-result-object v4

    .line 674
    check-cast v4, Lmyj;

    .line 676
    iput v2, v4, Lmyj;->f:I

    .line 678
    iget-boolean v5, v4, Lmyj;->a:Z

    .line 680
    if-nez v5, :cond_28

    .line 682
    iget v5, v4, Lmyj;->c:F

    .line 684
    cmpl-float v5, v5, v16

    .line 686
    if-nez v5, :cond_28

    .line 688
    invoke-virtual {v0, v3}, Landroidx/viewpager/widget/ViewPager;->b(Landroid/view/View;)Lmyi;

    .line 691
    move-result-object v3

    .line 692
    if-eqz v3, :cond_28

    .line 694
    iget v5, v3, Lmyi;->d:F

    .line 696
    iput v5, v4, Lmyj;->c:F

    .line 698
    iget v3, v3, Lmyi;->b:I

    .line 700
    iput v3, v4, Lmyj;->e:I

    .line 702
    :cond_28
    add-int/lit8 v2, v2, 0x1

    .line 704
    goto :goto_1e

    .line 705
    :cond_29
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->hasFocus()Z

    .line 708
    move-result v1

    .line 709
    if-eqz v1, :cond_30

    .line 711
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->findFocus()Landroid/view/View;

    .line 714
    move-result-object v1

    .line 715
    if-eqz v1, :cond_2c

    .line 717
    :goto_1f
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 720
    move-result-object v2

    .line 721
    if-eq v2, v0, :cond_2b

    .line 723
    instance-of v1, v2, Landroid/view/View;

    .line 725
    if-nez v1, :cond_2a

    .line 727
    goto :goto_20

    .line 728
    :cond_2a
    move-object v1, v2

    .line 729
    check-cast v1, Landroid/view/View;

    .line 731
    goto :goto_1f

    .line 732
    :cond_2b
    invoke-virtual {v0, v1}, Landroidx/viewpager/widget/ViewPager;->b(Landroid/view/View;)Lmyi;

    .line 735
    move-result-object v3

    .line 736
    goto :goto_21

    .line 737
    :cond_2c
    :goto_20
    const/4 v3, 0x0

    .line 738
    :goto_21
    if-eqz v3, :cond_2d

    .line 740
    iget v1, v3, Lmyi;->b:I

    .line 742
    iget v2, v0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 744
    if-eq v1, v2, :cond_30

    .line 746
    :cond_2d
    const/4 v5, 0x0

    .line 747
    :goto_22
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getChildCount()I

    .line 750
    move-result v1

    .line 751
    if-ge v5, v1, :cond_30

    .line 753
    invoke-virtual {v0, v5}, Landroidx/viewpager/widget/ViewPager;->getChildAt(I)Landroid/view/View;

    .line 756
    move-result-object v1

    .line 757
    invoke-virtual {v0, v1}, Landroidx/viewpager/widget/ViewPager;->b(Landroid/view/View;)Lmyi;

    .line 760
    move-result-object v2

    .line 761
    if-eqz v2, :cond_2e

    .line 763
    iget v2, v2, Lmyi;->b:I

    .line 765
    iget v3, v0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 767
    if-ne v2, v3, :cond_2e

    .line 769
    const/4 v2, 0x2

    .line 770
    invoke-virtual {v1, v2}, Landroid/view/View;->requestFocus(I)Z

    .line 773
    move-result v1

    .line 774
    if-nez v1, :cond_30

    .line 776
    :cond_2e
    add-int/lit8 v5, v5, 0x1

    .line 778
    goto :goto_22

    .line 779
    :cond_2f
    :try_start_0
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getResources()Landroid/content/res/Resources;

    .line 782
    move-result-object v1

    .line 783
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getId()I

    .line 786
    move-result v2

    .line 787
    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    .line 790
    move-result-object v1

    .line 791
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_23

    .line 792
    :catch_0
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getId()I

    .line 795
    move-result v1

    .line 796
    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 799
    move-result-object v1

    .line 800
    :goto_23
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 802
    new-instance v3, Ljava/lang/StringBuilder;

    .line 804
    const-string v4, "The application\'s PagerAdapter changed the adapter\'s contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: "

    .line 806
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 809
    iget v4, v0, Landroidx/viewpager/widget/ViewPager;->j:I

    .line 811
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 814
    const-string v4, ", found: "

    .line 816
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 819
    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 822
    const-string v4, " Pager id: "

    .line 824
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 827
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 830
    const-string v1, " Pager class: "

    .line 832
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 835
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 838
    move-result-object v1

    .line 839
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 842
    const-string v1, " Problematic adapter: "

    .line 844
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 847
    iget-object v0, v0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 849
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 852
    move-result-object v0

    .line 853
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 856
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 859
    move-result-object v0

    .line 860
    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 863
    throw v2

    .line 864
    :cond_30
    :goto_24
    return-void
.end method

.method protected final generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 0

    .line 1
    new-instance p0, Lmyj;

    .line 3
    invoke-direct {p0}, Lmyj;-><init>()V

    .line 6
    return-object p0
.end method

.method public final generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    .line 1
    new-instance v0, Lmyj;

    .line 3
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getContext()Landroid/content/Context;

    .line 6
    move-result-object p0

    .line 7
    invoke-direct {v0, p0, p1}, Lmyj;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 10
    return-object v0
.end method

.method protected final generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 0

    .line 11
    new-instance p0, Lmyj;

    invoke-direct {p0}, Lmyj;-><init>()V

    return-object p0
.end method

.method public getAdapter()Lmyc;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 3
    return-object p0
.end method

.method protected final getChildDrawingOrder(II)I
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    throw p0
.end method

.method public getCurrentItem()I
    .locals 0

    .line 1
    iget p0, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 3
    return p0
.end method

.method public getOffscreenPageLimit()I
    .locals 0

    .line 1
    iget p0, p0, Landroidx/viewpager/widget/ViewPager;->A:I

    .line 3
    return p0
.end method

.method public getPageMargin()I
    .locals 0

    .line 1
    iget p0, p0, Landroidx/viewpager/widget/ViewPager;->r:I

    .line 3
    return p0
.end method

.method public final h(IZ)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->z:Z

    .line 4
    invoke-virtual {p0, p1, p2, v0, v0}, Landroidx/viewpager/widget/ViewPager;->i(IZZI)V

    .line 7
    return-void
.end method

.method final i(IZZI)V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_9

    .line 6
    invoke-virtual {v0}, Lmyc;->i()I

    .line 9
    move-result v0

    .line 10
    if-gtz v0, :cond_0

    .line 12
    goto :goto_2

    .line 13
    :cond_0
    if-nez p3, :cond_1

    .line 15
    iget p3, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 17
    if-ne p3, p1, :cond_1

    .line 19
    iget-object p3, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 21
    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    .line 24
    move-result p3

    .line 25
    if-eqz p3, :cond_1

    .line 27
    invoke-direct {p0, v1}, Landroidx/viewpager/widget/ViewPager;->y(Z)V

    .line 30
    return-void

    .line 31
    :cond_1
    if-gez p1, :cond_2

    .line 33
    move p1, v1

    .line 34
    goto :goto_0

    .line 35
    :cond_2
    iget-object p3, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 37
    invoke-virtual {p3}, Lmyc;->i()I

    .line 40
    move-result p3

    .line 41
    if-lt p1, p3, :cond_3

    .line 43
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 45
    invoke-virtual {p1}, Lmyc;->i()I

    .line 48
    move-result p1

    .line 49
    add-int/lit8 p1, p1, -0x1

    .line 51
    :cond_3
    :goto_0
    iget p3, p0, Landroidx/viewpager/widget/ViewPager;->A:I

    .line 53
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 55
    add-int v2, v0, p3

    .line 57
    const/4 v3, 0x1

    .line 58
    if-gt p1, v2, :cond_4

    .line 60
    sub-int/2addr v0, p3

    .line 61
    if-ge p1, v0, :cond_5

    .line 63
    :cond_4
    move p3, v1

    .line 64
    :goto_1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 66
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 69
    move-result v2

    .line 70
    if-ge p3, v2, :cond_5

    .line 72
    invoke-virtual {v0, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 75
    move-result-object v0

    .line 76
    check-cast v0, Lmyi;

    .line 78
    iput-boolean v3, v0, Lmyi;->c:Z

    .line 80
    add-int/lit8 p3, p3, 0x1

    .line 82
    goto :goto_1

    .line 83
    :cond_5
    iget p3, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 85
    if-eq p3, p1, :cond_6

    .line 87
    move v1, v3

    .line 88
    :cond_6
    iget-boolean p3, p0, Landroidx/viewpager/widget/ViewPager;->R:Z

    .line 90
    if-eqz p3, :cond_8

    .line 92
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 94
    if-eqz v1, :cond_7

    .line 96
    invoke-direct {p0, p1}, Landroidx/viewpager/widget/ViewPager;->u(I)V

    .line 99
    :cond_7
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->requestLayout()V

    .line 102
    return-void

    .line 103
    :cond_8
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->g(I)V

    .line 106
    invoke-direct {p0, p1, p2, p4, v1}, Landroidx/viewpager/widget/ViewPager;->x(IZIZ)V

    .line 109
    return-void

    .line 110
    :cond_9
    :goto_2
    invoke-direct {p0, v1}, Landroidx/viewpager/widget/ViewPager;->y(Z)V

    .line 113
    return-void
.end method

.method public final j(I)V
    .locals 3

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->W:I

    .line 3
    if-ne v0, p1, :cond_0

    .line 5
    goto :goto_1

    .line 6
    :cond_0
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->W:I

    .line 8
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->U:Lmyl;

    .line 10
    if-eqz v0, :cond_1

    .line 12
    invoke-interface {v0, p1}, Lmyl;->a(I)V

    .line 15
    :cond_1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->f:Ljava/util/List;

    .line 17
    if-eqz v0, :cond_3

    .line 19
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 22
    move-result v0

    .line 23
    const/4 v1, 0x0

    .line 24
    :goto_0
    if-ge v1, v0, :cond_3

    .line 26
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->f:Ljava/util/List;

    .line 28
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 31
    move-result-object v2

    .line 32
    check-cast v2, Lmyl;

    .line 34
    if-eqz v2, :cond_2

    .line 36
    invoke-interface {v2, p1}, Lmyl;->a(I)V

    .line 39
    :cond_2
    add-int/lit8 v1, v1, 0x1

    .line 41
    goto :goto_0

    .line 42
    :cond_3
    :goto_1
    return-void
.end method

.method public final k(I)Z
    .locals 5

    .line 1
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->findFocus()Landroid/view/View;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-ne v0, p0, :cond_0

    .line 8
    :goto_0
    move-object v0, v1

    .line 9
    goto :goto_3

    .line 10
    :cond_0
    if-eqz v0, :cond_4

    .line 12
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 15
    move-result-object v2

    .line 16
    :goto_1
    instance-of v3, v2, Landroid/view/ViewGroup;

    .line 18
    if-eqz v3, :cond_2

    .line 20
    if-ne v2, p0, :cond_1

    .line 22
    goto :goto_3

    .line 23
    :cond_1
    invoke-interface {v2}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 26
    move-result-object v2

    .line 27
    goto :goto_1

    .line 28
    :cond_2
    new-instance v2, Ljava/lang/StringBuilder;

    .line 30
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 33
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    move-result-object v3

    .line 37
    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 40
    move-result-object v3

    .line 41
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 47
    move-result-object v0

    .line 48
    :goto_2
    instance-of v3, v0, Landroid/view/ViewGroup;

    .line 50
    if-eqz v3, :cond_3

    .line 52
    const-string v3, " => "

    .line 54
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 57
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    move-result-object v3

    .line 61
    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 64
    move-result-object v3

    .line 65
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 71
    move-result-object v0

    .line 72
    goto :goto_2

    .line 73
    :cond_3
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 76
    move-result-object v0

    .line 77
    const-string v2, "arrowScroll tried to find focus based on non-child current focused view "

    .line 79
    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 82
    move-result-object v0

    .line 83
    const-string v2, "ViewPager"

    .line 85
    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 88
    goto :goto_0

    .line 89
    :cond_4
    :goto_3
    invoke-static {}, Landroid/view/FocusFinder;->getInstance()Landroid/view/FocusFinder;

    .line 92
    move-result-object v1

    .line 93
    invoke-virtual {v1, p0, v0, p1}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    .line 96
    move-result-object v1

    .line 97
    const/4 v2, 0x0

    .line 98
    const/16 v3, 0x42

    .line 100
    const/16 v4, 0x11

    .line 102
    if-eqz v1, :cond_8

    .line 104
    if-eq v1, v0, :cond_8

    .line 106
    if-ne p1, v4, :cond_6

    .line 108
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->m:Landroid/graphics/Rect;

    .line 110
    invoke-direct {p0, v2, v1}, Landroidx/viewpager/widget/ViewPager;->r(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;

    .line 113
    move-result-object v3

    .line 114
    iget v3, v3, Landroid/graphics/Rect;->left:I

    .line 116
    invoke-direct {p0, v2, v0}, Landroidx/viewpager/widget/ViewPager;->r(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;

    .line 119
    move-result-object v2

    .line 120
    iget v2, v2, Landroid/graphics/Rect;->left:I

    .line 122
    if-eqz v0, :cond_5

    .line 124
    if-lt v3, v2, :cond_5

    .line 126
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->m()Z

    .line 129
    move-result v2

    .line 130
    goto :goto_5

    .line 131
    :cond_5
    invoke-virtual {v1}, Landroid/view/View;->requestFocus()Z

    .line 134
    move-result v2

    .line 135
    goto :goto_5

    .line 136
    :cond_6
    if-ne p1, v3, :cond_c

    .line 138
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->m:Landroid/graphics/Rect;

    .line 140
    invoke-direct {p0, v2, v1}, Landroidx/viewpager/widget/ViewPager;->r(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;

    .line 143
    move-result-object v3

    .line 144
    iget v3, v3, Landroid/graphics/Rect;->left:I

    .line 146
    invoke-direct {p0, v2, v0}, Landroidx/viewpager/widget/ViewPager;->r(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;

    .line 149
    move-result-object v2

    .line 150
    iget v2, v2, Landroid/graphics/Rect;->left:I

    .line 152
    if-eqz v0, :cond_7

    .line 154
    if-gt v3, v2, :cond_7

    .line 156
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->n()Z

    .line 159
    move-result v2

    .line 160
    goto :goto_5

    .line 161
    :cond_7
    invoke-virtual {v1}, Landroid/view/View;->requestFocus()Z

    .line 164
    move-result v2

    .line 165
    goto :goto_5

    .line 166
    :cond_8
    if-eq p1, v4, :cond_b

    .line 168
    const/4 v0, 0x1

    .line 169
    if-ne p1, v0, :cond_9

    .line 171
    goto :goto_4

    .line 172
    :cond_9
    if-eq p1, v3, :cond_a

    .line 174
    const/4 v0, 0x2

    .line 175
    if-ne p1, v0, :cond_c

    .line 177
    :cond_a
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->n()Z

    .line 180
    move-result v2

    .line 181
    goto :goto_5

    .line 182
    :cond_b
    :goto_4
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->m()Z

    .line 185
    move-result v2

    .line 186
    :cond_c
    :goto_5
    if-eqz v2, :cond_d

    .line 188
    invoke-static {p1}, Landroid/view/SoundEffectConstants;->getContantForFocusDirection(I)I

    .line 191
    move-result p1

    .line 192
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->playSoundEffect(I)V

    .line 195
    :cond_d
    return v2
.end method

.method protected final l(Landroid/view/View;ZIII)Z
    .locals 11

    .line 1
    instance-of v0, p1, Landroid/view/ViewGroup;

    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 6
    move-object v0, p1

    .line 7
    check-cast v0, Landroid/view/ViewGroup;

    .line 9
    invoke-virtual {p1}, Landroid/view/View;->getScrollX()I

    .line 12
    move-result v2

    .line 13
    invoke-virtual {p1}, Landroid/view/View;->getScrollY()I

    .line 16
    move-result v3

    .line 17
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 20
    move-result v4

    .line 21
    :cond_0
    add-int/lit8 v4, v4, -0x1

    .line 23
    if-ltz v4, :cond_1

    .line 25
    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 28
    move-result-object v6

    .line 29
    add-int v5, p4, v2

    .line 31
    invoke-virtual {v6}, Landroid/view/View;->getLeft()I

    .line 34
    move-result v7

    .line 35
    if-lt v5, v7, :cond_0

    .line 37
    invoke-virtual {v6}, Landroid/view/View;->getRight()I

    .line 40
    move-result v7

    .line 41
    if-ge v5, v7, :cond_0

    .line 43
    add-int v7, p5, v3

    .line 45
    invoke-virtual {v6}, Landroid/view/View;->getTop()I

    .line 48
    move-result v8

    .line 49
    if-lt v7, v8, :cond_0

    .line 51
    invoke-virtual {v6}, Landroid/view/View;->getBottom()I

    .line 54
    move-result v8

    .line 55
    if-ge v7, v8, :cond_0

    .line 57
    invoke-virtual {v6}, Landroid/view/View;->getLeft()I

    .line 60
    move-result v8

    .line 61
    sub-int v9, v5, v8

    .line 63
    invoke-virtual {v6}, Landroid/view/View;->getTop()I

    .line 66
    move-result v5

    .line 67
    sub-int v10, v7, v5

    .line 69
    const/4 v7, 0x1

    .line 70
    move-object v5, p0

    .line 71
    move v8, p3

    .line 72
    invoke-virtual/range {v5 .. v10}, Landroidx/viewpager/widget/ViewPager;->l(Landroid/view/View;ZIII)Z

    .line 75
    move-result v6

    .line 76
    if-eqz v6, :cond_0

    .line 78
    return v1

    .line 79
    :cond_1
    if-eqz p2, :cond_2

    .line 81
    neg-int p0, p3

    .line 82
    invoke-virtual {p1, p0}, Landroid/view/View;->canScrollHorizontally(I)Z

    .line 85
    move-result p0

    .line 86
    if-eqz p0, :cond_2

    .line 88
    return v1

    .line 89
    :cond_2
    const/4 p0, 0x0

    .line 90
    return p0
.end method

.method public m()Z
    .locals 2

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 3
    if-lez v0, :cond_0

    .line 5
    add-int/lit8 v0, v0, -0x1

    .line 7
    const/4 v1, 0x1

    .line 8
    invoke-virtual {p0, v0, v1}, Landroidx/viewpager/widget/ViewPager;->h(IZ)V

    .line 11
    return v1

    .line 12
    :cond_0
    const/4 p0, 0x0

    .line 13
    return p0
.end method

.method public n()Z
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget v1, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 7
    invoke-virtual {v0}, Lmyc;->i()I

    .line 10
    move-result v0

    .line 11
    add-int/lit8 v0, v0, -0x1

    .line 13
    if-ge v1, v0, :cond_0

    .line 15
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 17
    const/4 v1, 0x1

    .line 18
    add-int/2addr v0, v1

    .line 19
    invoke-virtual {p0, v0, v1}, Landroidx/viewpager/widget/ViewPager;->h(IZ)V

    .line 22
    return v1

    .line 23
    :cond_0
    const/4 p0, 0x0

    .line 24
    return p0
.end method

.method final o(Landroid/content/Context;)V
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0}, Landroidx/viewpager/widget/ViewPager;->setWillNotDraw(Z)V

    .line 5
    const/high16 v0, 0x40000

    .line 7
    invoke-virtual {p0, v0}, Landroidx/viewpager/widget/ViewPager;->setDescendantFocusability(I)V

    .line 10
    const/4 v0, 0x1

    .line 11
    invoke-virtual {p0, v0}, Landroidx/viewpager/widget/ViewPager;->setFocusable(Z)V

    .line 14
    new-instance v1, Landroid/widget/Scroller;

    .line 16
    sget-object v2, Landroidx/viewpager/widget/ViewPager;->i:Landroid/view/animation/Interpolator;

    .line 18
    invoke-direct {v1, p1, v2}, Landroid/widget/Scroller;-><init>(Landroid/content/Context;Landroid/view/animation/Interpolator;)V

    .line 21
    iput-object v1, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 23
    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    .line 26
    move-result-object v1

    .line 27
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 30
    move-result-object v2

    .line 31
    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 34
    move-result-object v2

    .line 35
    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    .line 37
    invoke-virtual {v1}, Landroid/view/ViewConfiguration;->getScaledPagingTouchSlop()I

    .line 40
    move-result v3

    .line 41
    iput v3, p0, Landroidx/viewpager/widget/ViewPager;->F:I

    .line 43
    const/high16 v3, 0x43c80000    # 400.0f

    .line 45
    mul-float/2addr v3, v2

    .line 46
    float-to-int v3, v3

    .line 47
    iput v3, p0, Landroidx/viewpager/widget/ViewPager;->N:I

    .line 49
    invoke-virtual {v1}, Landroid/view/ViewConfiguration;->getScaledMaximumFlingVelocity()I

    .line 52
    move-result v1

    .line 53
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->O:I

    .line 55
    new-instance v1, Landroid/widget/EdgeEffect;

    .line 57
    invoke-direct {v1, p1}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;)V

    .line 60
    iput-object v1, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 62
    new-instance v1, Landroid/widget/EdgeEffect;

    .line 64
    invoke-direct {v1, p1}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;)V

    .line 67
    iput-object v1, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 69
    const/high16 p1, 0x41c80000    # 25.0f

    .line 71
    mul-float/2addr p1, v2

    .line 72
    float-to-int p1, p1

    .line 73
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->P:I

    .line 75
    add-float p1, v2, v2

    .line 77
    float-to-int p1, p1

    .line 78
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->Q:I

    .line 80
    const/high16 p1, 0x41800000    # 16.0f

    .line 82
    mul-float/2addr v2, p1

    .line 83
    float-to-int p1, v2

    .line 84
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->D:I

    .line 86
    new-instance p1, Lmyk;

    .line 88
    invoke-direct {p1, p0}, Lmyk;-><init>(Landroidx/viewpager/widget/ViewPager;)V

    .line 91
    invoke-static {p0, p1}, Ljmy;->p(Landroid/view/View;Ljkl;)V

    .line 94
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getImportantForAccessibility()I

    .line 97
    move-result p1

    .line 98
    if-nez p1, :cond_0

    .line 100
    invoke-virtual {p0, v0}, Landroidx/viewpager/widget/ViewPager;->setImportantForAccessibility(I)V

    .line 103
    :cond_0
    new-instance p1, Lmyg;

    .line 105
    invoke-direct {p1, p0}, Lmyg;-><init>(Landroidx/viewpager/widget/ViewPager;)V

    .line 108
    invoke-static {p0, p1}, Ljmo;->c(Landroid/view/View;Ljlp;)V

    .line 111
    return-void
.end method

.method protected final onAttachedToWindow()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onAttachedToWindow()V

    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->R:Z

    .line 7
    return-void
.end method

.method protected final onDetachedFromWindow()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->V:Ljava/lang/Runnable;

    .line 3
    invoke-virtual {p0, v0}, Landroidx/viewpager/widget/ViewPager;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 6
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 8
    if-eqz v0, :cond_0

    .line 10
    invoke-virtual {v0}, Landroid/widget/Scroller;->isFinished()Z

    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 16
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 18
    invoke-virtual {v0}, Landroid/widget/Scroller;->abortAnimation()V

    .line 21
    :cond_0
    invoke-super {p0}, Landroid/view/ViewGroup;->onDetachedFromWindow()V

    .line 24
    return-void
.end method

.method protected final onDraw(Landroid/graphics/Canvas;)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 3
    invoke-super/range {p0 .. p1}, Landroid/view/ViewGroup;->onDraw(Landroid/graphics/Canvas;)V

    .line 6
    iget v1, v0, Landroidx/viewpager/widget/ViewPager;->r:I

    .line 8
    if-lez v1, :cond_4

    .line 10
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->s:Landroid/graphics/drawable/Drawable;

    .line 12
    if-eqz v1, :cond_4

    .line 14
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 16
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 19
    move-result v2

    .line 20
    if-lez v2, :cond_4

    .line 22
    iget-object v2, v0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 24
    if-eqz v2, :cond_4

    .line 26
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getScrollX()I

    .line 29
    move-result v2

    .line 30
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getWidth()I

    .line 33
    move-result v3

    .line 34
    iget v4, v0, Landroidx/viewpager/widget/ViewPager;->r:I

    .line 36
    int-to-float v4, v4

    .line 37
    int-to-float v5, v3

    .line 38
    const/4 v6, 0x0

    .line 39
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 42
    move-result-object v7

    .line 43
    check-cast v7, Lmyi;

    .line 45
    iget v8, v7, Lmyi;->e:F

    .line 47
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 50
    move-result v9

    .line 51
    iget v10, v7, Lmyi;->b:I

    .line 53
    add-int/lit8 v11, v9, -0x1

    .line 55
    invoke-virtual {v1, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 58
    move-result-object v11

    .line 59
    check-cast v11, Lmyi;

    .line 61
    iget v11, v11, Lmyi;->b:I

    .line 63
    :goto_0
    if-ge v10, v11, :cond_4

    .line 65
    :goto_1
    iget v12, v7, Lmyi;->b:I

    .line 67
    if-le v10, v12, :cond_0

    .line 69
    if-ge v6, v9, :cond_0

    .line 71
    add-int/lit8 v6, v6, 0x1

    .line 73
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 76
    move-result-object v7

    .line 77
    check-cast v7, Lmyi;

    .line 79
    goto :goto_1

    .line 80
    :cond_0
    div-float v13, v4, v5

    .line 82
    if-ne v10, v12, :cond_1

    .line 84
    iget v8, v7, Lmyi;->e:F

    .line 86
    iget v12, v7, Lmyi;->d:F

    .line 88
    add-float/2addr v8, v12

    .line 89
    add-float/2addr v13, v8

    .line 90
    mul-float/2addr v8, v5

    .line 91
    goto :goto_2

    .line 92
    :cond_1
    const/high16 v12, 0x3f800000    # 1.0f

    .line 94
    add-float v14, v8, v12

    .line 96
    add-float/2addr v13, v12

    .line 97
    add-float/2addr v8, v13

    .line 98
    mul-float v12, v14, v5

    .line 100
    move v13, v8

    .line 101
    move v8, v12

    .line 102
    :goto_2
    iget v12, v0, Landroidx/viewpager/widget/ViewPager;->r:I

    .line 104
    int-to-float v12, v12

    .line 105
    int-to-float v14, v2

    .line 106
    add-float/2addr v12, v8

    .line 107
    cmpl-float v12, v12, v14

    .line 109
    if-lez v12, :cond_2

    .line 111
    iget-object v12, v0, Landroidx/viewpager/widget/ViewPager;->s:Landroid/graphics/drawable/Drawable;

    .line 113
    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    .line 116
    move-result v14

    .line 117
    iget v15, v0, Landroidx/viewpager/widget/ViewPager;->t:I

    .line 119
    move-object/from16 v16, v1

    .line 121
    iget v1, v0, Landroidx/viewpager/widget/ViewPager;->r:I

    .line 123
    int-to-float v1, v1

    .line 124
    add-float/2addr v1, v8

    .line 125
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    .line 128
    move-result v1

    .line 129
    move/from16 v17, v2

    .line 131
    iget v2, v0, Landroidx/viewpager/widget/ViewPager;->u:I

    .line 133
    invoke-virtual {v12, v14, v15, v1, v2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 136
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->s:Landroid/graphics/drawable/Drawable;

    .line 138
    move-object/from16 v2, p1

    .line 140
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 143
    goto :goto_3

    .line 144
    :cond_2
    move-object/from16 v16, v1

    .line 146
    move/from16 v17, v2

    .line 148
    move-object/from16 v2, p1

    .line 150
    :goto_3
    add-int v1, v17, v3

    .line 152
    int-to-float v1, v1

    .line 153
    cmpl-float v1, v8, v1

    .line 155
    if-lez v1, :cond_3

    .line 157
    goto :goto_4

    .line 158
    :cond_3
    add-int/lit8 v10, v10, 0x1

    .line 160
    move v8, v13

    .line 161
    move-object/from16 v1, v16

    .line 163
    move/from16 v2, v17

    .line 165
    goto :goto_0

    .line 166
    :cond_4
    :goto_4
    return-void
.end method

.method public onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 13

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 4
    move-result v1

    .line 5
    and-int/lit16 v1, v1, 0xff

    .line 7
    const/4 v2, 0x3

    .line 8
    const/4 v6, 0x0

    .line 9
    if-eq v1, v2, :cond_13

    .line 11
    const/4 v7, 0x1

    .line 12
    if-ne v1, v7, :cond_0

    .line 14
    goto/16 :goto_6

    .line 16
    :cond_0
    const/4 v2, 0x2

    .line 17
    const/4 v3, 0x0

    .line 18
    if-eqz v1, :cond_c

    .line 20
    iget-boolean v4, p0, Landroidx/viewpager/widget/ViewPager;->B:Z

    .line 22
    if-eqz v4, :cond_1

    .line 24
    return v7

    .line 25
    :cond_1
    iget-boolean v4, p0, Landroidx/viewpager/widget/ViewPager;->C:Z

    .line 27
    if-eqz v4, :cond_2

    .line 29
    return v6

    .line 30
    :cond_2
    if-eq v1, v2, :cond_4

    .line 32
    const/4 v2, 0x6

    .line 33
    if-eq v1, v2, :cond_3

    .line 35
    goto/16 :goto_5

    .line 37
    :cond_3
    invoke-direct/range {p0 .. p1}, Landroidx/viewpager/widget/ViewPager;->v(Landroid/view/MotionEvent;)V

    .line 40
    goto/16 :goto_5

    .line 42
    :cond_4
    iget v1, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 44
    const/4 v2, -0x1

    .line 45
    if-eq v1, v2, :cond_11

    .line 47
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 50
    move-result v1

    .line 51
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getX(I)F

    .line 54
    move-result v8

    .line 55
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 57
    sub-float v2, v8, v2

    .line 59
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    .line 62
    move-result v9

    .line 63
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getY(I)F

    .line 66
    move-result v10

    .line 67
    iget v1, p0, Landroidx/viewpager/widget/ViewPager;->K:F

    .line 69
    sub-float v1, v10, v1

    .line 71
    cmpl-float v11, v2, v3

    .line 73
    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    .line 76
    move-result v12

    .line 77
    if-eqz v11, :cond_8

    .line 79
    iget v1, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 81
    iget-boolean v4, p0, Landroidx/viewpager/widget/ViewPager;->G:Z

    .line 83
    if-eqz v4, :cond_5

    .line 85
    goto :goto_0

    .line 86
    :cond_5
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->E:I

    .line 88
    int-to-float v4, v4

    .line 89
    cmpg-float v4, v1, v4

    .line 91
    if-gez v4, :cond_6

    .line 93
    if-gtz v11, :cond_8

    .line 95
    :cond_6
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getWidth()I

    .line 98
    move-result v4

    .line 99
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->E:I

    .line 101
    sub-int/2addr v4, v5

    .line 102
    int-to-float v4, v4

    .line 103
    cmpl-float v1, v1, v4

    .line 105
    if-lez v1, :cond_7

    .line 107
    cmpg-float v1, v2, v3

    .line 109
    if-gez v1, :cond_7

    .line 111
    goto :goto_1

    .line 112
    :cond_7
    :goto_0
    float-to-int v3, v2

    .line 113
    float-to-int v4, v8

    .line 114
    float-to-int v5, v10

    .line 115
    const/4 v2, 0x0

    .line 116
    move-object v1, p0

    .line 117
    move-object v0, p0

    .line 118
    invoke-virtual/range {v0 .. v5}, Landroidx/viewpager/widget/ViewPager;->l(Landroid/view/View;ZIII)Z

    .line 121
    move-result v1

    .line 122
    if-eqz v1, :cond_8

    .line 124
    iput v8, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 126
    iput v10, p0, Landroidx/viewpager/widget/ViewPager;->I:F

    .line 128
    iput-boolean v7, p0, Landroidx/viewpager/widget/ViewPager;->C:Z

    .line 130
    return v6

    .line 131
    :cond_8
    :goto_1
    iget v1, p0, Landroidx/viewpager/widget/ViewPager;->F:I

    .line 133
    int-to-float v1, v1

    .line 134
    cmpl-float v2, v9, v1

    .line 136
    if-lez v2, :cond_a

    .line 138
    const/high16 v2, 0x3f000000    # 0.5f

    .line 140
    mul-float/2addr v9, v2

    .line 141
    cmpl-float v2, v9, v12

    .line 143
    if-lez v2, :cond_a

    .line 145
    iput-boolean v7, p0, Landroidx/viewpager/widget/ViewPager;->B:Z

    .line 147
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->C()V

    .line 150
    invoke-virtual {p0, v7}, Landroidx/viewpager/widget/ViewPager;->j(I)V

    .line 153
    iget v1, p0, Landroidx/viewpager/widget/ViewPager;->J:F

    .line 155
    if-lez v11, :cond_9

    .line 157
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->F:I

    .line 159
    int-to-float v2, v2

    .line 160
    add-float/2addr v1, v2

    .line 161
    goto :goto_2

    .line 162
    :cond_9
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->F:I

    .line 164
    int-to-float v2, v2

    .line 165
    sub-float/2addr v1, v2

    .line 166
    :goto_2
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 168
    iput v10, p0, Landroidx/viewpager/widget/ViewPager;->I:F

    .line 170
    invoke-direct {p0, v7}, Landroidx/viewpager/widget/ViewPager;->y(Z)V

    .line 173
    goto :goto_3

    .line 174
    :cond_a
    cmpl-float v1, v12, v1

    .line 176
    if-lez v1, :cond_b

    .line 178
    iput-boolean v7, p0, Landroidx/viewpager/widget/ViewPager;->C:Z

    .line 180
    :cond_b
    :goto_3
    iget-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->B:Z

    .line 182
    if-eqz v1, :cond_11

    .line 184
    invoke-direct {p0, v8, v10}, Landroidx/viewpager/widget/ViewPager;->A(FF)Z

    .line 187
    move-result v1

    .line 188
    if-eqz v1, :cond_11

    .line 190
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->postInvalidateOnAnimation()V

    .line 193
    goto/16 :goto_5

    .line 195
    :cond_c
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 198
    move-result v1

    .line 199
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->J:F

    .line 201
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 203
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 206
    move-result v1

    .line 207
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->K:F

    .line 209
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->I:F

    .line 211
    invoke-virtual {p1, v6}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 214
    move-result v1

    .line 215
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 217
    iput-boolean v6, p0, Landroidx/viewpager/widget/ViewPager;->C:Z

    .line 219
    iput-boolean v7, p0, Landroidx/viewpager/widget/ViewPager;->p:Z

    .line 221
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 223
    invoke-virtual {v1}, Landroid/widget/Scroller;->computeScrollOffset()Z

    .line 226
    iget v1, p0, Landroidx/viewpager/widget/ViewPager;->W:I

    .line 228
    if-ne v1, v2, :cond_d

    .line 230
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 232
    invoke-virtual {v1}, Landroid/widget/Scroller;->getFinalX()I

    .line 235
    move-result v1

    .line 236
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 238
    invoke-virtual {v2}, Landroid/widget/Scroller;->getCurrX()I

    .line 241
    move-result v2

    .line 242
    sub-int/2addr v1, v2

    .line 243
    invoke-static {v1}, Ljava/lang/Math;->abs(I)I

    .line 246
    move-result v1

    .line 247
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->Q:I

    .line 249
    if-le v1, v2, :cond_d

    .line 251
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 253
    invoke-virtual {v1}, Landroid/widget/Scroller;->abortAnimation()V

    .line 256
    iput-boolean v6, p0, Landroidx/viewpager/widget/ViewPager;->z:Z

    .line 258
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->f()V

    .line 261
    iput-boolean v7, p0, Landroidx/viewpager/widget/ViewPager;->B:Z

    .line 263
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->C()V

    .line 266
    invoke-virtual {p0, v7}, Landroidx/viewpager/widget/ViewPager;->j(I)V

    .line 269
    goto :goto_5

    .line 270
    :cond_d
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 272
    invoke-static {v1}, Ljrb;->a(Landroid/widget/EdgeEffect;)F

    .line 275
    move-result v1

    .line 276
    cmpl-float v1, v1, v3

    .line 278
    if-nez v1, :cond_f

    .line 280
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 282
    invoke-static {v1}, Ljrb;->a(Landroid/widget/EdgeEffect;)F

    .line 285
    move-result v1

    .line 286
    cmpl-float v1, v1, v3

    .line 288
    if-eqz v1, :cond_e

    .line 290
    goto :goto_4

    .line 291
    :cond_e
    invoke-direct {p0, v6}, Landroidx/viewpager/widget/ViewPager;->t(Z)V

    .line 294
    iput-boolean v6, p0, Landroidx/viewpager/widget/ViewPager;->B:Z

    .line 296
    goto :goto_5

    .line 297
    :cond_f
    :goto_4
    iput-boolean v7, p0, Landroidx/viewpager/widget/ViewPager;->B:Z

    .line 299
    invoke-virtual {p0, v7}, Landroidx/viewpager/widget/ViewPager;->j(I)V

    .line 302
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 304
    invoke-static {v1}, Ljrb;->a(Landroid/widget/EdgeEffect;)F

    .line 307
    move-result v1

    .line 308
    cmpl-float v1, v1, v3

    .line 310
    if-eqz v1, :cond_10

    .line 312
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 314
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->I:F

    .line 316
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getHeight()I

    .line 319
    move-result v4

    .line 320
    int-to-float v4, v4

    .line 321
    div-float/2addr v2, v4

    .line 322
    const/high16 v4, 0x3f800000    # 1.0f

    .line 324
    sub-float/2addr v4, v2

    .line 325
    invoke-static {v1, v3, v4}, Ljrb;->b(Landroid/widget/EdgeEffect;FF)F

    .line 328
    :cond_10
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 330
    invoke-static {v1}, Ljrb;->a(Landroid/widget/EdgeEffect;)F

    .line 333
    move-result v1

    .line 334
    cmpl-float v1, v1, v3

    .line 336
    if-eqz v1, :cond_11

    .line 338
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 340
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->I:F

    .line 342
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getHeight()I

    .line 345
    move-result v4

    .line 346
    int-to-float v4, v4

    .line 347
    div-float/2addr v2, v4

    .line 348
    invoke-static {v1, v3, v2}, Ljrb;->b(Landroid/widget/EdgeEffect;FF)F

    .line 351
    :cond_11
    :goto_5
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->M:Landroid/view/VelocityTracker;

    .line 353
    if-nez v1, :cond_12

    .line 355
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    .line 358
    move-result-object v1

    .line 359
    iput-object v1, p0, Landroidx/viewpager/widget/ViewPager;->M:Landroid/view/VelocityTracker;

    .line 361
    :cond_12
    invoke-virtual {v1, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 364
    iget-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->B:Z

    .line 366
    return v0

    .line 367
    :cond_13
    :goto_6
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->B()Z

    .line 370
    return v6
.end method

.method protected final onLayout(ZIIII)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 3
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getChildCount()I

    .line 6
    move-result v1

    .line 7
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getPaddingLeft()I

    .line 10
    move-result v2

    .line 11
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getPaddingTop()I

    .line 14
    move-result v3

    .line 15
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getPaddingRight()I

    .line 18
    move-result v4

    .line 19
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getPaddingBottom()I

    .line 22
    move-result v5

    .line 23
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getScrollX()I

    .line 26
    move-result v6

    .line 27
    const/4 v7, 0x0

    .line 28
    move v8, v7

    .line 29
    move v9, v8

    .line 30
    :goto_0
    sub-int v10, p5, p3

    .line 32
    sub-int v11, p4, p2

    .line 34
    const/16 v12, 0x8

    .line 36
    if-ge v8, v1, :cond_7

    .line 38
    invoke-virtual {v0, v8}, Landroidx/viewpager/widget/ViewPager;->getChildAt(I)Landroid/view/View;

    .line 41
    move-result-object v13

    .line 42
    invoke-virtual {v13}, Landroid/view/View;->getVisibility()I

    .line 45
    move-result v14

    .line 46
    if-eq v14, v12, :cond_6

    .line 48
    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 51
    move-result-object v12

    .line 52
    check-cast v12, Lmyj;

    .line 54
    iget-boolean v14, v12, Lmyj;->a:Z

    .line 56
    if-eqz v14, :cond_6

    .line 58
    iget v12, v12, Lmyj;->b:I

    .line 60
    and-int/lit8 v14, v12, 0x7

    .line 62
    and-int/lit8 v12, v12, 0x70

    .line 64
    const/4 v15, 0x1

    .line 65
    if-eq v14, v15, :cond_2

    .line 67
    const/4 v15, 0x3

    .line 68
    if-eq v14, v15, :cond_1

    .line 70
    const/4 v15, 0x5

    .line 71
    if-eq v14, v15, :cond_0

    .line 73
    move v11, v2

    .line 74
    goto :goto_2

    .line 75
    :cond_0
    sub-int/2addr v11, v4

    .line 76
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    .line 79
    move-result v14

    .line 80
    sub-int/2addr v11, v14

    .line 81
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    .line 84
    move-result v14

    .line 85
    add-int/2addr v4, v14

    .line 86
    goto :goto_1

    .line 87
    :cond_1
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    .line 90
    move-result v11

    .line 91
    add-int/2addr v11, v2

    .line 92
    goto :goto_2

    .line 93
    :cond_2
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    .line 96
    move-result v14

    .line 97
    sub-int/2addr v11, v14

    .line 98
    div-int/lit8 v11, v11, 0x2

    .line 100
    invoke-static {v11, v2}, Ljava/lang/Math;->max(II)I

    .line 103
    move-result v11

    .line 104
    :goto_1
    move/from16 v16, v11

    .line 106
    move v11, v2

    .line 107
    move/from16 v2, v16

    .line 109
    :goto_2
    const/16 v14, 0x10

    .line 111
    if-eq v12, v14, :cond_5

    .line 113
    const/16 v14, 0x30

    .line 115
    if-eq v12, v14, :cond_4

    .line 117
    const/16 v14, 0x50

    .line 119
    if-eq v12, v14, :cond_3

    .line 121
    move v10, v3

    .line 122
    goto :goto_4

    .line 123
    :cond_3
    sub-int/2addr v10, v5

    .line 124
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    .line 127
    move-result v12

    .line 128
    sub-int/2addr v10, v12

    .line 129
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    .line 132
    move-result v12

    .line 133
    add-int/2addr v5, v12

    .line 134
    goto :goto_3

    .line 135
    :cond_4
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    .line 138
    move-result v10

    .line 139
    add-int/2addr v10, v3

    .line 140
    goto :goto_4

    .line 141
    :cond_5
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    .line 144
    move-result v12

    .line 145
    sub-int/2addr v10, v12

    .line 146
    div-int/lit8 v10, v10, 0x2

    .line 148
    invoke-static {v10, v3}, Ljava/lang/Math;->max(II)I

    .line 151
    move-result v10

    .line 152
    :goto_3
    move/from16 v16, v10

    .line 154
    move v10, v3

    .line 155
    move/from16 v3, v16

    .line 157
    :goto_4
    add-int/2addr v2, v6

    .line 158
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    .line 161
    move-result v12

    .line 162
    add-int/2addr v12, v2

    .line 163
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    .line 166
    move-result v14

    .line 167
    add-int/2addr v14, v3

    .line 168
    invoke-virtual {v13, v2, v3, v12, v14}, Landroid/view/View;->layout(IIII)V

    .line 171
    add-int/lit8 v9, v9, 0x1

    .line 173
    move v3, v10

    .line 174
    move v2, v11

    .line 175
    :cond_6
    add-int/lit8 v8, v8, 0x1

    .line 177
    goto/16 :goto_0

    .line 179
    :cond_7
    sub-int v6, v10, v5

    .line 181
    sub-int/2addr v11, v2

    .line 182
    sub-int/2addr v11, v4

    .line 183
    move v4, v7

    .line 184
    :goto_5
    if-ge v4, v1, :cond_a

    .line 186
    invoke-virtual {v0, v4}, Landroidx/viewpager/widget/ViewPager;->getChildAt(I)Landroid/view/View;

    .line 189
    move-result-object v8

    .line 190
    invoke-virtual {v8}, Landroid/view/View;->getVisibility()I

    .line 193
    move-result v13

    .line 194
    if-eq v13, v12, :cond_9

    .line 196
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 199
    move-result-object v13

    .line 200
    check-cast v13, Lmyj;

    .line 202
    iget-boolean v14, v13, Lmyj;->a:Z

    .line 204
    if-nez v14, :cond_9

    .line 206
    invoke-virtual {v0, v8}, Landroidx/viewpager/widget/ViewPager;->b(Landroid/view/View;)Lmyi;

    .line 209
    move-result-object v14

    .line 210
    if-eqz v14, :cond_9

    .line 212
    int-to-float v15, v11

    .line 213
    iget v14, v14, Lmyi;->e:F

    .line 215
    mul-float/2addr v14, v15

    .line 216
    float-to-int v14, v14

    .line 217
    add-int/2addr v14, v2

    .line 218
    iget-boolean v12, v13, Lmyj;->d:Z

    .line 220
    if-eqz v12, :cond_8

    .line 222
    iput-boolean v7, v13, Lmyj;->d:Z

    .line 224
    iget v12, v13, Lmyj;->c:F

    .line 226
    mul-float/2addr v15, v12

    .line 227
    sub-int v12, v10, v3

    .line 229
    sub-int/2addr v12, v5

    .line 230
    float-to-int v13, v15

    .line 231
    const/high16 v15, 0x40000000

    .line 233
    invoke-static {v13, v15}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 236
    move-result v13

    .line 237
    invoke-static {v12, v15}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 240
    move-result v12

    .line 241
    invoke-virtual {v8, v13, v12}, Landroid/view/View;->measure(II)V

    .line 244
    :cond_8
    invoke-virtual {v8}, Landroid/view/View;->getMeasuredWidth()I

    .line 247
    move-result v12

    .line 248
    add-int/2addr v12, v14

    .line 249
    invoke-virtual {v8}, Landroid/view/View;->getMeasuredHeight()I

    .line 252
    move-result v13

    .line 253
    add-int/2addr v13, v3

    .line 254
    invoke-virtual {v8, v14, v3, v12, v13}, Landroid/view/View;->layout(IIII)V

    .line 257
    :cond_9
    add-int/lit8 v4, v4, 0x1

    .line 259
    const/16 v12, 0x8

    .line 261
    goto :goto_5

    .line 262
    :cond_a
    iput v3, v0, Landroidx/viewpager/widget/ViewPager;->t:I

    .line 264
    iput v6, v0, Landroidx/viewpager/widget/ViewPager;->u:I

    .line 266
    iput v9, v0, Landroidx/viewpager/widget/ViewPager;->T:I

    .line 268
    iget-boolean v1, v0, Landroidx/viewpager/widget/ViewPager;->R:Z

    .line 270
    if-eqz v1, :cond_b

    .line 272
    iget v1, v0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 274
    invoke-direct {v0, v1, v7, v7, v7}, Landroidx/viewpager/widget/ViewPager;->x(IZIZ)V

    .line 277
    :cond_b
    iput-boolean v7, v0, Landroidx/viewpager/widget/ViewPager;->R:Z

    .line 279
    return-void
.end method

.method protected onMeasure(II)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 3
    const/4 v1, 0x0

    .line 4
    move/from16 v2, p1

    .line 6
    invoke-static {v1, v2}, Landroidx/viewpager/widget/ViewPager;->getDefaultSize(II)I

    .line 9
    move-result v2

    .line 10
    move/from16 v3, p2

    .line 12
    invoke-static {v1, v3}, Landroidx/viewpager/widget/ViewPager;->getDefaultSize(II)I

    .line 15
    move-result v3

    .line 16
    invoke-virtual {v0, v2, v3}, Landroidx/viewpager/widget/ViewPager;->setMeasuredDimension(II)V

    .line 19
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getMeasuredWidth()I

    .line 22
    move-result v2

    .line 23
    div-int/lit8 v3, v2, 0xa

    .line 25
    iget v4, v0, Landroidx/viewpager/widget/ViewPager;->D:I

    .line 27
    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    .line 30
    move-result v3

    .line 31
    iput v3, v0, Landroidx/viewpager/widget/ViewPager;->E:I

    .line 33
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getPaddingLeft()I

    .line 36
    move-result v3

    .line 37
    sub-int/2addr v2, v3

    .line 38
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getPaddingRight()I

    .line 41
    move-result v3

    .line 42
    sub-int/2addr v2, v3

    .line 43
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getMeasuredHeight()I

    .line 46
    move-result v3

    .line 47
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getPaddingTop()I

    .line 50
    move-result v4

    .line 51
    sub-int/2addr v3, v4

    .line 52
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getPaddingBottom()I

    .line 55
    move-result v4

    .line 56
    sub-int/2addr v3, v4

    .line 57
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getChildCount()I

    .line 60
    move-result v4

    .line 61
    move v5, v1

    .line 62
    :goto_0
    const/16 v6, 0x8

    .line 64
    const/4 v7, 0x1

    .line 65
    const/high16 v8, 0x40000000

    .line 67
    if-ge v5, v4, :cond_c

    .line 69
    invoke-virtual {v0, v5}, Landroidx/viewpager/widget/ViewPager;->getChildAt(I)Landroid/view/View;

    .line 72
    move-result-object v9

    .line 73
    invoke-virtual {v9}, Landroid/view/View;->getVisibility()I

    .line 76
    move-result v10

    .line 77
    if-eq v10, v6, :cond_b

    .line 79
    invoke-virtual {v9}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 82
    move-result-object v6

    .line 83
    check-cast v6, Lmyj;

    .line 85
    if-eqz v6, :cond_b

    .line 87
    iget-boolean v10, v6, Lmyj;->a:Z

    .line 89
    if-eqz v10, :cond_b

    .line 91
    iget v10, v6, Lmyj;->b:I

    .line 93
    and-int/lit8 v11, v10, 0x7

    .line 95
    and-int/lit8 v10, v10, 0x70

    .line 97
    const/16 v12, 0x30

    .line 99
    if-eq v10, v12, :cond_1

    .line 101
    const/16 v12, 0x50

    .line 103
    if-ne v10, v12, :cond_0

    .line 105
    goto :goto_1

    .line 106
    :cond_0
    move v10, v1

    .line 107
    goto :goto_2

    .line 108
    :cond_1
    :goto_1
    move v10, v7

    .line 109
    :goto_2
    const/4 v12, 0x3

    .line 110
    if-eq v11, v12, :cond_3

    .line 112
    const/4 v12, 0x5

    .line 113
    if-ne v11, v12, :cond_2

    .line 115
    goto :goto_3

    .line 116
    :cond_2
    move v7, v1

    .line 117
    :cond_3
    :goto_3
    const/high16 v11, -0x80000000

    .line 119
    if-eqz v10, :cond_4

    .line 121
    move v12, v11

    .line 122
    move v11, v8

    .line 123
    goto :goto_4

    .line 124
    :cond_4
    if-eqz v7, :cond_5

    .line 126
    move v12, v8

    .line 127
    goto :goto_4

    .line 128
    :cond_5
    move v12, v11

    .line 129
    :goto_4
    iget v13, v6, Lmyj;->width:I

    .line 131
    const/4 v14, -0x1

    .line 132
    const/4 v15, -0x2

    .line 133
    if-eq v13, v15, :cond_7

    .line 135
    iget v11, v6, Lmyj;->width:I

    .line 137
    if-eq v11, v14, :cond_6

    .line 139
    iget v11, v6, Lmyj;->width:I

    .line 141
    move v13, v11

    .line 142
    goto :goto_5

    .line 143
    :cond_6
    move v13, v2

    .line 144
    :goto_5
    move v11, v8

    .line 145
    goto :goto_6

    .line 146
    :cond_7
    move v13, v2

    .line 147
    :goto_6
    iget v1, v6, Lmyj;->height:I

    .line 149
    if-eq v1, v15, :cond_9

    .line 151
    iget v1, v6, Lmyj;->height:I

    .line 153
    if-eq v1, v14, :cond_8

    .line 155
    iget v1, v6, Lmyj;->height:I

    .line 157
    goto :goto_7

    .line 158
    :cond_8
    move v1, v3

    .line 159
    goto :goto_7

    .line 160
    :cond_9
    move v1, v3

    .line 161
    move v8, v12

    .line 162
    :goto_7
    invoke-static {v13, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 165
    move-result v6

    .line 166
    invoke-static {v1, v8}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 169
    move-result v1

    .line 170
    invoke-virtual {v9, v6, v1}, Landroid/view/View;->measure(II)V

    .line 173
    if-eqz v10, :cond_a

    .line 175
    invoke-virtual {v9}, Landroid/view/View;->getMeasuredHeight()I

    .line 178
    move-result v1

    .line 179
    sub-int/2addr v3, v1

    .line 180
    goto :goto_8

    .line 181
    :cond_a
    if-eqz v7, :cond_b

    .line 183
    invoke-virtual {v9}, Landroid/view/View;->getMeasuredWidth()I

    .line 186
    move-result v1

    .line 187
    sub-int/2addr v2, v1

    .line 188
    :cond_b
    :goto_8
    add-int/lit8 v5, v5, 0x1

    .line 190
    const/4 v1, 0x0

    .line 191
    goto/16 :goto_0

    .line 193
    :cond_c
    invoke-static {v3, v8}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 196
    move-result v1

    .line 197
    iput-boolean v7, v0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 199
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->f()V

    .line 202
    const/4 v3, 0x0

    .line 203
    iput-boolean v3, v0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 205
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getChildCount()I

    .line 208
    move-result v4

    .line 209
    :goto_9
    if-ge v3, v4, :cond_f

    .line 211
    invoke-virtual {v0, v3}, Landroidx/viewpager/widget/ViewPager;->getChildAt(I)Landroid/view/View;

    .line 214
    move-result-object v5

    .line 215
    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    .line 218
    move-result v7

    .line 219
    if-eq v7, v6, :cond_e

    .line 221
    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 224
    move-result-object v7

    .line 225
    check-cast v7, Lmyj;

    .line 227
    if-eqz v7, :cond_d

    .line 229
    iget-boolean v9, v7, Lmyj;->a:Z

    .line 231
    if-nez v9, :cond_e

    .line 233
    :cond_d
    int-to-float v9, v2

    .line 234
    iget v7, v7, Lmyj;->c:F

    .line 236
    mul-float/2addr v9, v7

    .line 237
    float-to-int v7, v9

    .line 238
    invoke-static {v7, v8}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 241
    move-result v7

    .line 242
    invoke-virtual {v5, v7, v1}, Landroid/view/View;->measure(II)V

    .line 245
    :cond_e
    add-int/lit8 v3, v3, 0x1

    .line 247
    goto :goto_9

    .line 248
    :cond_f
    return-void
.end method

.method protected final onRequestFocusInDescendants(ILandroid/graphics/Rect;)Z
    .locals 8

    .line 1
    and-int/lit8 v0, p1, 0x2

    .line 3
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getChildCount()I

    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x1

    .line 9
    if-eqz v0, :cond_0

    .line 11
    move v4, v1

    .line 12
    move v1, v2

    .line 13
    move v0, v3

    .line 14
    goto :goto_0

    .line 15
    :cond_0
    add-int/lit8 v1, v1, -0x1

    .line 17
    const/4 v0, -0x1

    .line 18
    move v4, v0

    .line 19
    :goto_0
    if-eq v1, v4, :cond_2

    .line 21
    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->getChildAt(I)Landroid/view/View;

    .line 24
    move-result-object v5

    .line 25
    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    .line 28
    move-result v6

    .line 29
    if-nez v6, :cond_1

    .line 31
    invoke-virtual {p0, v5}, Landroidx/viewpager/widget/ViewPager;->b(Landroid/view/View;)Lmyi;

    .line 34
    move-result-object v6

    .line 35
    if-eqz v6, :cond_1

    .line 37
    iget v6, v6, Lmyi;->b:I

    .line 39
    iget v7, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 41
    if-ne v6, v7, :cond_1

    .line 43
    invoke-virtual {v5, p1, p2}, Landroid/view/View;->requestFocus(ILandroid/graphics/Rect;)Z

    .line 46
    move-result v5

    .line 47
    if-eqz v5, :cond_1

    .line 49
    return v3

    .line 50
    :cond_1
    add-int/2addr v1, v0

    .line 51
    goto :goto_0

    .line 52
    :cond_2
    return v2
.end method

.method public final onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 2

    .line 1
    instance-of v0, p1, Landroidx/viewpager/widget/ViewPager$SavedState;

    .line 3
    if-nez v0, :cond_0

    .line 5
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 8
    return-void

    .line 9
    :cond_0
    check-cast p1, Landroidx/viewpager/widget/ViewPager$SavedState;

    .line 11
    iget-object v0, p1, Landroidx/customview/view/AbsSavedState;->d:Landroid/os/Parcelable;

    .line 13
    invoke-super {p0, v0}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 16
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 18
    if-eqz v0, :cond_1

    .line 20
    iget-object v0, p1, Landroidx/viewpager/widget/ViewPager$SavedState;->b:Landroid/os/Parcelable;

    .line 22
    iget-object v0, p1, Landroidx/viewpager/widget/ViewPager$SavedState;->e:Ljava/lang/ClassLoader;

    .line 24
    iget p1, p1, Landroidx/viewpager/widget/ViewPager$SavedState;->a:I

    .line 26
    const/4 v0, 0x1

    .line 27
    const/4 v1, 0x0

    .line 28
    invoke-virtual {p0, p1, v1, v0, v1}, Landroidx/viewpager/widget/ViewPager;->i(IZZI)V

    .line 31
    return-void

    .line 32
    :cond_1
    iget v0, p1, Landroidx/viewpager/widget/ViewPager$SavedState;->a:I

    .line 34
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->n:I

    .line 36
    iget-object p0, p1, Landroidx/viewpager/widget/ViewPager$SavedState;->b:Landroid/os/Parcelable;

    .line 38
    iget-object p0, p1, Landroidx/viewpager/widget/ViewPager$SavedState;->e:Ljava/lang/ClassLoader;

    .line 40
    return-void
.end method

.method public final onSaveInstanceState()Landroid/os/Parcelable;
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onSaveInstanceState()Landroid/os/Parcelable;

    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Landroidx/viewpager/widget/ViewPager$SavedState;

    .line 7
    invoke-direct {v1, v0}, Landroidx/viewpager/widget/ViewPager$SavedState;-><init>(Landroid/os/Parcelable;)V

    .line 10
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 12
    iput v0, v1, Landroidx/viewpager/widget/ViewPager$SavedState;->a:I

    .line 14
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 16
    if-eqz p0, :cond_0

    .line 18
    const/4 p0, 0x0

    .line 19
    iput-object p0, v1, Landroidx/viewpager/widget/ViewPager$SavedState;->b:Landroid/os/Parcelable;

    .line 21
    :cond_0
    return-object v1
.end method

.method protected final onSizeChanged(IIII)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/ViewGroup;->onSizeChanged(IIII)V

    .line 4
    if-eq p1, p3, :cond_0

    .line 6
    iget p2, p0, Landroidx/viewpager/widget/ViewPager;->r:I

    .line 8
    invoke-direct {p0, p1, p3, p2, p2}, Landroidx/viewpager/widget/ViewPager;->w(IIII)V

    .line 11
    :cond_0
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 11

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez v0, :cond_0

    .line 8
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getEdgeFlags()I

    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 14
    return v1

    .line 15
    :cond_0
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 17
    if-eqz v0, :cond_13

    .line 19
    invoke-virtual {v0}, Lmyc;->i()I

    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_1

    .line 25
    goto/16 :goto_6

    .line 27
    :cond_1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->M:Landroid/view/VelocityTracker;

    .line 29
    if-nez v0, :cond_2

    .line 31
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    .line 34
    move-result-object v0

    .line 35
    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->M:Landroid/view/VelocityTracker;

    .line 37
    :cond_2
    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 40
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 43
    move-result v0

    .line 44
    and-int/lit16 v0, v0, 0xff

    .line 46
    const/4 v2, 0x1

    .line 47
    if-eqz v0, :cond_11

    .line 49
    const/4 v3, -0x1

    .line 50
    const/4 v4, 0x0

    .line 51
    if-eq v0, v2, :cond_a

    .line 53
    const/4 v5, 0x2

    .line 54
    if-eq v0, v5, :cond_6

    .line 56
    const/4 v3, 0x3

    .line 57
    if-eq v0, v3, :cond_5

    .line 59
    const/4 v1, 0x5

    .line 60
    if-eq v0, v1, :cond_4

    .line 62
    const/4 v1, 0x6

    .line 63
    if-eq v0, v1, :cond_3

    .line 65
    goto/16 :goto_5

    .line 67
    :cond_3
    invoke-direct {p0, p1}, Landroidx/viewpager/widget/ViewPager;->v(Landroid/view/MotionEvent;)V

    .line 70
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 72
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 75
    move-result v0

    .line 76
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 79
    move-result p1

    .line 80
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 82
    goto/16 :goto_5

    .line 84
    :cond_4
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 87
    move-result v0

    .line 88
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 91
    move-result v1

    .line 92
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 94
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 97
    move-result p1

    .line 98
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 100
    goto/16 :goto_5

    .line 102
    :cond_5
    iget-boolean p1, p0, Landroidx/viewpager/widget/ViewPager;->B:Z

    .line 104
    if-eqz p1, :cond_12

    .line 106
    iget p1, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 108
    invoke-direct {p0, p1, v2, v1, v1}, Landroidx/viewpager/widget/ViewPager;->x(IZIZ)V

    .line 111
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->B()Z

    .line 114
    move-result p1

    .line 115
    goto/16 :goto_4

    .line 117
    :cond_6
    iget-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->B:Z

    .line 119
    if-nez v0, :cond_9

    .line 121
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 123
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 126
    move-result v0

    .line 127
    if-ne v0, v3, :cond_7

    .line 129
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->B()Z

    .line 132
    move-result p1

    .line 133
    goto/16 :goto_4

    .line 135
    :cond_7
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 138
    move-result v1

    .line 139
    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 141
    sub-float v3, v1, v3

    .line 143
    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    .line 146
    move-result v3

    .line 147
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 150
    move-result v0

    .line 151
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->I:F

    .line 153
    sub-float v5, v0, v5

    .line 155
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    .line 158
    move-result v5

    .line 159
    iget v6, p0, Landroidx/viewpager/widget/ViewPager;->F:I

    .line 161
    int-to-float v6, v6

    .line 162
    cmpl-float v6, v3, v6

    .line 164
    if-lez v6, :cond_9

    .line 166
    cmpl-float v3, v3, v5

    .line 168
    if-lez v3, :cond_9

    .line 170
    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->B:Z

    .line 172
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->C()V

    .line 175
    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->J:F

    .line 177
    sub-float/2addr v1, v3

    .line 178
    cmpl-float v1, v1, v4

    .line 180
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->F:I

    .line 182
    if-lez v1, :cond_8

    .line 184
    int-to-float v1, v4

    .line 185
    add-float/2addr v3, v1

    .line 186
    goto :goto_0

    .line 187
    :cond_8
    int-to-float v1, v4

    .line 188
    sub-float/2addr v3, v1

    .line 189
    :goto_0
    iput v3, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 191
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->I:F

    .line 193
    invoke-virtual {p0, v2}, Landroidx/viewpager/widget/ViewPager;->j(I)V

    .line 196
    invoke-direct {p0, v2}, Landroidx/viewpager/widget/ViewPager;->y(Z)V

    .line 199
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getParent()Landroid/view/ViewParent;

    .line 202
    move-result-object v0

    .line 203
    if-eqz v0, :cond_9

    .line 205
    invoke-interface {v0, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 208
    :cond_9
    iget-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->B:Z

    .line 210
    if-eqz v0, :cond_12

    .line 212
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 214
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 217
    move-result v0

    .line 218
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 221
    move-result v1

    .line 222
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 225
    move-result p1

    .line 226
    invoke-direct {p0, v1, p1}, Landroidx/viewpager/widget/ViewPager;->A(FF)Z

    .line 229
    move-result p1

    .line 230
    goto/16 :goto_4

    .line 232
    :cond_a
    iget-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->B:Z

    .line 234
    if-eqz v0, :cond_12

    .line 236
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->M:Landroid/view/VelocityTracker;

    .line 238
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->O:I

    .line 240
    int-to-float v5, v5

    .line 241
    const/16 v6, 0x3e8    # 1.401E-42f

    .line 243
    invoke-virtual {v0, v6, v5}, Landroid/view/VelocityTracker;->computeCurrentVelocity(IF)V

    .line 246
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 248
    invoke-virtual {v0, v5}, Landroid/view/VelocityTracker;->getXVelocity(I)F

    .line 251
    move-result v0

    .line 252
    float-to-int v0, v0

    .line 253
    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->z:Z

    .line 255
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->q()I

    .line 258
    move-result v5

    .line 259
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollX()I

    .line 262
    move-result v6

    .line 263
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->s()Lmyi;

    .line 266
    move-result-object v7

    .line 267
    iget v8, p0, Landroidx/viewpager/widget/ViewPager;->r:I

    .line 269
    int-to-float v8, v8

    .line 270
    int-to-float v5, v5

    .line 271
    iget v9, v7, Lmyi;->b:I

    .line 273
    int-to-float v6, v6

    .line 274
    iget v10, v7, Lmyi;->e:F

    .line 276
    div-float/2addr v6, v5

    .line 277
    sub-float/2addr v6, v10

    .line 278
    iget v7, v7, Lmyi;->d:F

    .line 280
    div-float/2addr v8, v5

    .line 281
    add-float/2addr v7, v8

    .line 282
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 284
    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 287
    move-result v5

    .line 288
    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->getX(I)F

    .line 291
    move-result p1

    .line 292
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->J:F

    .line 294
    sub-float/2addr p1, v5

    .line 295
    float-to-int p1, p1

    .line 296
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    .line 299
    move-result p1

    .line 300
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->P:I

    .line 302
    if-le p1, v5, :cond_c

    .line 304
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 307
    move-result p1

    .line 308
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->N:I

    .line 310
    if-le p1, v5, :cond_c

    .line 312
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 314
    invoke-static {p1}, Ljrb;->a(Landroid/widget/EdgeEffect;)F

    .line 317
    move-result p1

    .line 318
    cmpl-float p1, p1, v4

    .line 320
    if-nez p1, :cond_c

    .line 322
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 324
    invoke-static {p1}, Ljrb;->a(Landroid/widget/EdgeEffect;)F

    .line 327
    move-result p1

    .line 328
    cmpl-float p1, p1, v4

    .line 330
    if-nez p1, :cond_c

    .line 332
    if-lez v0, :cond_b

    .line 334
    move p1, v9

    .line 335
    goto :goto_2

    .line 336
    :cond_b
    add-int/lit8 p1, v9, 0x1

    .line 338
    goto :goto_2

    .line 339
    :cond_c
    div-float/2addr v6, v7

    .line 340
    iget p1, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 342
    if-lt v9, p1, :cond_d

    .line 344
    const p1, 0x3ecccccd

    .line 347
    goto :goto_1

    .line 348
    :cond_d
    const p1, 0x3f19999a    # 0.6f

    .line 351
    :goto_1
    add-float/2addr v6, p1

    .line 352
    float-to-int p1, v6

    .line 353
    add-int/2addr p1, v9

    .line 354
    :goto_2
    iget-object v5, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 356
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 359
    move-result v6

    .line 360
    if-lez v6, :cond_e

    .line 362
    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 365
    move-result-object v1

    .line 366
    check-cast v1, Lmyi;

    .line 368
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 371
    move-result v6

    .line 372
    add-int/2addr v6, v3

    .line 373
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 376
    move-result-object v3

    .line 377
    check-cast v3, Lmyi;

    .line 379
    iget v1, v1, Lmyi;->b:I

    .line 381
    iget v3, v3, Lmyi;->b:I

    .line 383
    invoke-static {p1, v3}, Ljava/lang/Math;->min(II)I

    .line 386
    move-result p1

    .line 387
    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    .line 390
    move-result p1

    .line 391
    :cond_e
    invoke-virtual {p0, p1, v2, v2, v0}, Landroidx/viewpager/widget/ViewPager;->i(IZZI)V

    .line 394
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->B()Z

    .line 397
    move-result v1

    .line 398
    if-ne p1, v9, :cond_10

    .line 400
    if-eqz v1, :cond_10

    .line 402
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 404
    invoke-static {p1}, Ljrb;->a(Landroid/widget/EdgeEffect;)F

    .line 407
    move-result p1

    .line 408
    cmpl-float p1, p1, v4

    .line 410
    if-eqz p1, :cond_f

    .line 412
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->e:Landroid/widget/EdgeEffect;

    .line 414
    neg-int v0, v0

    .line 415
    invoke-virtual {p1, v0}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    .line 418
    goto :goto_3

    .line 419
    :cond_f
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 421
    invoke-static {p1}, Ljrb;->a(Landroid/widget/EdgeEffect;)F

    .line 424
    move-result p1

    .line 425
    cmpl-float p1, p1, v4

    .line 427
    if-eqz p1, :cond_10

    .line 429
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/widget/EdgeEffect;

    .line 431
    invoke-virtual {p1, v0}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    .line 434
    :cond_10
    :goto_3
    move p1, v1

    .line 435
    :goto_4
    if-eqz p1, :cond_12

    .line 437
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->postInvalidateOnAnimation()V

    .line 440
    goto :goto_5

    .line 441
    :cond_11
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->o:Landroid/widget/Scroller;

    .line 443
    invoke-virtual {v0}, Landroid/widget/Scroller;->abortAnimation()V

    .line 446
    iput-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->z:Z

    .line 448
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->f()V

    .line 451
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 454
    move-result v0

    .line 455
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->J:F

    .line 457
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->H:F

    .line 459
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 462
    move-result v0

    .line 463
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->K:F

    .line 465
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->I:F

    .line 467
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 470
    move-result p1

    .line 471
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 473
    :cond_12
    :goto_5
    return v2

    .line 474
    :cond_13
    :goto_6
    return v1
.end method

.method protected final p(IF)V
    .locals 12

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->T:I

    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    if-lez v0, :cond_5

    .line 7
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getScrollX()I

    .line 10
    move-result v0

    .line 11
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingLeft()I

    .line 14
    move-result v3

    .line 15
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getPaddingRight()I

    .line 18
    move-result v4

    .line 19
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getWidth()I

    .line 22
    move-result v5

    .line 23
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getChildCount()I

    .line 26
    move-result v6

    .line 27
    move v7, v1

    .line 28
    :goto_0
    if-ge v7, v6, :cond_5

    .line 30
    invoke-virtual {p0, v7}, Landroidx/viewpager/widget/ViewPager;->getChildAt(I)Landroid/view/View;

    .line 33
    move-result-object v8

    .line 34
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 37
    move-result-object v9

    .line 38
    check-cast v9, Lmyj;

    .line 40
    iget-boolean v10, v9, Lmyj;->a:Z

    .line 42
    if-eqz v10, :cond_4

    .line 44
    iget v9, v9, Lmyj;->b:I

    .line 46
    and-int/lit8 v9, v9, 0x7

    .line 48
    if-eq v9, v2, :cond_2

    .line 50
    const/4 v10, 0x3

    .line 51
    if-eq v9, v10, :cond_1

    .line 53
    const/4 v10, 0x5

    .line 54
    if-eq v9, v10, :cond_0

    .line 56
    move v9, v3

    .line 57
    goto :goto_2

    .line 58
    :cond_0
    sub-int v9, v5, v4

    .line 60
    invoke-virtual {v8}, Landroid/view/View;->getMeasuredWidth()I

    .line 63
    move-result v10

    .line 64
    sub-int/2addr v9, v10

    .line 65
    invoke-virtual {v8}, Landroid/view/View;->getMeasuredWidth()I

    .line 68
    move-result v10

    .line 69
    add-int/2addr v4, v10

    .line 70
    goto :goto_1

    .line 71
    :cond_1
    invoke-virtual {v8}, Landroid/view/View;->getWidth()I

    .line 74
    move-result v9

    .line 75
    add-int/2addr v9, v3

    .line 76
    goto :goto_2

    .line 77
    :cond_2
    invoke-virtual {v8}, Landroid/view/View;->getMeasuredWidth()I

    .line 80
    move-result v9

    .line 81
    sub-int v9, v5, v9

    .line 83
    div-int/lit8 v9, v9, 0x2

    .line 85
    invoke-static {v9, v3}, Ljava/lang/Math;->max(II)I

    .line 88
    move-result v9

    .line 89
    :goto_1
    move v11, v9

    .line 90
    move v9, v3

    .line 91
    move v3, v11

    .line 92
    :goto_2
    add-int/2addr v3, v0

    .line 93
    invoke-virtual {v8}, Landroid/view/View;->getLeft()I

    .line 96
    move-result v10

    .line 97
    sub-int/2addr v3, v10

    .line 98
    if-eqz v3, :cond_3

    .line 100
    invoke-virtual {v8, v3}, Landroid/view/View;->offsetLeftAndRight(I)V

    .line 103
    :cond_3
    move v3, v9

    .line 104
    :cond_4
    add-int/lit8 v7, v7, 0x1

    .line 106
    goto :goto_0

    .line 107
    :cond_5
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->U:Lmyl;

    .line 109
    if-eqz v0, :cond_6

    .line 111
    invoke-interface {v0, p1, p2}, Lmyl;->c(IF)V

    .line 114
    :cond_6
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->f:Ljava/util/List;

    .line 116
    if-eqz v0, :cond_8

    .line 118
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 121
    move-result v0

    .line 122
    :goto_3
    if-ge v1, v0, :cond_8

    .line 124
    iget-object v3, p0, Landroidx/viewpager/widget/ViewPager;->f:Ljava/util/List;

    .line 126
    invoke-interface {v3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 129
    move-result-object v3

    .line 130
    check-cast v3, Lmyl;

    .line 132
    if-eqz v3, :cond_7

    .line 134
    invoke-interface {v3, p1, p2}, Lmyl;->c(IF)V

    .line 137
    :cond_7
    add-int/lit8 v1, v1, 0x1

    .line 139
    goto :goto_3

    .line 140
    :cond_8
    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->S:Z

    .line 142
    return-void
.end method

.method public final removeView(Landroid/view/View;)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->removeViewInLayout(Landroid/view/View;)V

    .line 8
    return-void

    .line 9
    :cond_0
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 12
    return-void
.end method

.method public setAdapter(Lmyc;)V
    .locals 6

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    if-eqz v0, :cond_3

    .line 7
    const/4 v3, 0x0

    .line 8
    invoke-virtual {v0, v3}, Lmyc;->m(Landroid/database/DataSetObserver;)V

    .line 11
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 13
    invoke-virtual {v0, p0}, Lmyc;->c(Landroid/view/ViewGroup;)V

    .line 16
    move v0, v2

    .line 17
    :goto_0
    iget-object v3, p0, Landroidx/viewpager/widget/ViewPager;->k:Ljava/util/ArrayList;

    .line 19
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 22
    move-result v4

    .line 23
    if-ge v0, v4, :cond_0

    .line 25
    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 28
    move-result-object v3

    .line 29
    check-cast v3, Lmyi;

    .line 31
    iget-object v4, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 33
    iget v5, v3, Lmyi;->b:I

    .line 35
    iget-object v3, v3, Lmyi;->a:Ljava/lang/Object;

    .line 37
    invoke-virtual {v4, p0, v3}, Lmyc;->e(Landroid/view/ViewGroup;Ljava/lang/Object;)V

    .line 40
    add-int/lit8 v0, v0, 0x1

    .line 42
    goto :goto_0

    .line 43
    :cond_0
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 45
    invoke-virtual {v0}, Lmyc;->f()V

    .line 48
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 51
    move v0, v2

    .line 52
    :goto_1
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getChildCount()I

    .line 55
    move-result v3

    .line 56
    if-ge v0, v3, :cond_2

    .line 58
    invoke-virtual {p0, v0}, Landroidx/viewpager/widget/ViewPager;->getChildAt(I)Landroid/view/View;

    .line 61
    move-result-object v3

    .line 62
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 65
    move-result-object v3

    .line 66
    check-cast v3, Lmyj;

    .line 68
    iget-boolean v3, v3, Lmyj;->a:Z

    .line 70
    if-nez v3, :cond_1

    .line 72
    invoke-virtual {p0, v0}, Landroidx/viewpager/widget/ViewPager;->removeViewAt(I)V

    .line 75
    add-int/lit8 v0, v0, -0x1

    .line 77
    :cond_1
    add-int/2addr v0, v1

    .line 78
    goto :goto_1

    .line 79
    :cond_2
    iput v2, p0, Landroidx/viewpager/widget/ViewPager;->c:I

    .line 81
    invoke-virtual {p0, v2, v2}, Landroidx/viewpager/widget/ViewPager;->scrollTo(II)V

    .line 84
    :cond_3
    iput-object p1, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 86
    iput v2, p0, Landroidx/viewpager/widget/ViewPager;->j:I

    .line 88
    if-eqz p1, :cond_7

    .line 90
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->q:Lmym;

    .line 92
    if-nez v0, :cond_4

    .line 94
    new-instance v0, Lmym;

    .line 96
    invoke-direct {v0, p0}, Lmym;-><init>(Landroidx/viewpager/widget/ViewPager;)V

    .line 99
    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->q:Lmym;

    .line 101
    :cond_4
    iget-object v3, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 103
    invoke-virtual {v3, v0}, Lmyc;->m(Landroid/database/DataSetObserver;)V

    .line 106
    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->z:Z

    .line 108
    iget-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->R:Z

    .line 110
    iput-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->R:Z

    .line 112
    iget-object v3, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 114
    invoke-virtual {v3}, Lmyc;->i()I

    .line 117
    move-result v3

    .line 118
    iput v3, p0, Landroidx/viewpager/widget/ViewPager;->j:I

    .line 120
    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->n:I

    .line 122
    if-ltz v3, :cond_5

    .line 124
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Lmyc;

    .line 126
    invoke-virtual {v0}, Lmyc;->g()V

    .line 129
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->n:I

    .line 131
    invoke-virtual {p0, v0, v2, v1, v2}, Landroidx/viewpager/widget/ViewPager;->i(IZZI)V

    .line 134
    const/4 v0, -0x1

    .line 135
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->n:I

    .line 137
    goto :goto_2

    .line 138
    :cond_5
    if-nez v0, :cond_6

    .line 140
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->f()V

    .line 143
    goto :goto_2

    .line 144
    :cond_6
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->requestLayout()V

    .line 147
    :cond_7
    :goto_2
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->g:Ljava/util/List;

    .line 149
    if-eqz v0, :cond_9

    .line 151
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 154
    move-result v0

    .line 155
    if-nez v0, :cond_9

    .line 157
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->g:Ljava/util/List;

    .line 159
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 162
    move-result v0

    .line 163
    :goto_3
    if-ge v2, v0, :cond_9

    .line 165
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->g:Ljava/util/List;

    .line 167
    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 170
    move-result-object v1

    .line 171
    check-cast v1, Laxra;

    .line 173
    iget-object v3, v1, Laxra;->b:Lcom/google/android/material/tabs/TabLayout;

    .line 175
    iget-object v4, v3, Lcom/google/android/material/tabs/TabLayout;->E:Landroidx/viewpager/widget/ViewPager;

    .line 177
    if-ne v4, p0, :cond_8

    .line 179
    iget-boolean v1, v1, Laxra;->a:Z

    .line 181
    invoke-virtual {v3, p1, v1}, Lcom/google/android/material/tabs/TabLayout;->i(Lmyc;Z)V

    .line 184
    :cond_8
    add-int/lit8 v2, v2, 0x1

    .line 186
    goto :goto_3

    .line 187
    :cond_9
    return-void
.end method

.method public setCurrentItem(I)V
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->z:Z

    .line 4
    iget-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->R:Z

    .line 6
    xor-int/lit8 v1, v1, 0x1

    .line 8
    invoke-virtual {p0, p1, v1, v0, v0}, Landroidx/viewpager/widget/ViewPager;->i(IZZI)V

    .line 11
    return-void
.end method

.method public setDragInGutterEnabled(Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, Landroidx/viewpager/widget/ViewPager;->G:Z

    .line 3
    return-void
.end method

.method public setOffscreenPageLimit(I)V
    .locals 2

    .line 1
    if-gtz p1, :cond_0

    .line 3
    const-string v0, "Requested offscreen page limit "

    .line 5
    const-string v1, " too small; defaulting to 1"

    .line 7
    invoke-static {p1, v0, v1}, La;->j(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 10
    move-result-object p1

    .line 11
    const-string v0, "ViewPager"

    .line 13
    invoke-static {v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 16
    const/4 p1, 0x1

    .line 17
    :cond_0
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->A:I

    .line 19
    if-eq p1, v0, :cond_1

    .line 21
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->A:I

    .line 23
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->f()V

    .line 26
    :cond_1
    return-void
.end method

.method public setOnPageChangeListener(Lmyl;)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    iput-object p1, p0, Landroidx/viewpager/widget/ViewPager;->U:Lmyl;

    .line 3
    return-void
.end method

.method public setPageMargin(I)V
    .locals 2

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->r:I

    .line 3
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->r:I

    .line 5
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getWidth()I

    .line 8
    move-result v1

    .line 9
    invoke-direct {p0, v1, v1, p1, v0}, Landroidx/viewpager/widget/ViewPager;->w(IIII)V

    .line 12
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->requestLayout()V

    .line 15
    return-void
.end method

.method public setPageMarginDrawable(I)V
    .locals 1

    .line 18
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getContext()Landroid/content/Context;

    move-result-object v0

    .line 19
    invoke-virtual {v0, p1}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    .line 20
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->setPageMarginDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public setPageMarginDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    iput-object p1, p0, Landroidx/viewpager/widget/ViewPager;->s:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz p1, :cond_0

    .line 5
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->refreshDrawableState()V

    .line 8
    const/4 p1, 0x0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 p1, 0x1

    .line 11
    :goto_0
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->setWillNotDraw(Z)V

    .line 14
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->invalidate()V

    .line 17
    return-void
.end method

.method protected final verifyDrawable(Landroid/graphics/drawable/Drawable;)Z
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->verifyDrawable(Landroid/graphics/drawable/Drawable;)Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_1

    .line 7
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->s:Landroid/graphics/drawable/Drawable;

    .line 9
    if-ne p1, p0, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 p0, 0x0

    .line 13
    return p0

    .line 14
    :cond_1
    :goto_0
    const/4 p0, 0x1

    .line 15
    return p0
.end method
