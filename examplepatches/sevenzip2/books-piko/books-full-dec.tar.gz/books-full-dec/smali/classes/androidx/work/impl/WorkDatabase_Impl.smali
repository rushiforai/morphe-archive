.class public final Landroidx/work/impl/WorkDatabase_Impl;
.super Landroidx/work/impl/WorkDatabase;
.source "PG"


# instance fields
.field private final l:Lbhph;

.field private final m:Lbhph;

.field private final n:Lbhph;

.field private final o:Lbhph;

.field private final p:Lbhph;

.field private final q:Lbhph;

.field private final r:Lbhph;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Landroidx/work/impl/WorkDatabase;-><init>()V

    .line 4
    new-instance v0, Lnhw;

    .line 6
    invoke-direct {v0, p0}, Lnhw;-><init>(Landroidx/work/impl/WorkDatabase_Impl;)V

    .line 9
    new-instance v1, Lbhps;

    .line 11
    invoke-direct {v1, v0}, Lbhps;-><init>(Lbhwf;)V

    .line 14
    iput-object v1, p0, Landroidx/work/impl/WorkDatabase_Impl;->l:Lbhph;

    .line 16
    new-instance v0, Lnhx;

    .line 18
    invoke-direct {v0, p0}, Lnhx;-><init>(Landroidx/work/impl/WorkDatabase_Impl;)V

    .line 21
    new-instance v1, Lbhps;

    .line 23
    invoke-direct {v1, v0}, Lbhps;-><init>(Lbhwf;)V

    .line 26
    iput-object v1, p0, Landroidx/work/impl/WorkDatabase_Impl;->m:Lbhph;

    .line 28
    new-instance v0, Lnhy;

    .line 30
    invoke-direct {v0, p0}, Lnhy;-><init>(Landroidx/work/impl/WorkDatabase_Impl;)V

    .line 33
    new-instance v1, Lbhps;

    .line 35
    invoke-direct {v1, v0}, Lbhps;-><init>(Lbhwf;)V

    .line 38
    iput-object v1, p0, Landroidx/work/impl/WorkDatabase_Impl;->n:Lbhph;

    .line 40
    new-instance v0, Lnhz;

    .line 42
    invoke-direct {v0, p0}, Lnhz;-><init>(Landroidx/work/impl/WorkDatabase_Impl;)V

    .line 45
    new-instance v1, Lbhps;

    .line 47
    invoke-direct {v1, v0}, Lbhps;-><init>(Lbhwf;)V

    .line 50
    iput-object v1, p0, Landroidx/work/impl/WorkDatabase_Impl;->o:Lbhph;

    .line 52
    new-instance v0, Lnia;

    .line 54
    invoke-direct {v0, p0}, Lnia;-><init>(Landroidx/work/impl/WorkDatabase_Impl;)V

    .line 57
    new-instance v1, Lbhps;

    .line 59
    invoke-direct {v1, v0}, Lbhps;-><init>(Lbhwf;)V

    .line 62
    iput-object v1, p0, Landroidx/work/impl/WorkDatabase_Impl;->p:Lbhph;

    .line 64
    new-instance v0, Lnib;

    .line 66
    invoke-direct {v0, p0}, Lnib;-><init>(Landroidx/work/impl/WorkDatabase_Impl;)V

    .line 69
    new-instance v1, Lbhps;

    .line 71
    invoke-direct {v1, v0}, Lbhps;-><init>(Lbhwf;)V

    .line 74
    iput-object v1, p0, Landroidx/work/impl/WorkDatabase_Impl;->q:Lbhph;

    .line 76
    new-instance v0, Lnic;

    .line 78
    invoke-direct {v0, p0}, Lnic;-><init>(Landroidx/work/impl/WorkDatabase_Impl;)V

    .line 81
    new-instance v1, Lbhps;

    .line 83
    invoke-direct {v1, v0}, Lbhps;-><init>(Lbhwf;)V

    .line 86
    iput-object v1, p0, Landroidx/work/impl/WorkDatabase_Impl;->r:Lbhph;

    .line 88
    return-void
.end method


# virtual methods
.method public final A()Lnmg;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/work/impl/WorkDatabase_Impl;->r:Lbhph;

    .line 3
    invoke-interface {p0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lnmg;

    .line 9
    return-object p0
.end method

.method public final B()Lnmn;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/work/impl/WorkDatabase_Impl;->o:Lbhph;

    .line 3
    invoke-interface {p0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lnmn;

    .line 9
    return-object p0
.end method

.method public final C()Lnmw;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/work/impl/WorkDatabase_Impl;->p:Lbhph;

    .line 3
    invoke-interface {p0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lnmw;

    .line 9
    return-object p0
.end method

.method public final D()Lnnb;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/work/impl/WorkDatabase_Impl;->q:Lbhph;

    .line 3
    invoke-interface {p0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lnnb;

    .line 9
    return-object p0
.end method

.method public final E()Lnnk;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/work/impl/WorkDatabase_Impl;->l:Lbhph;

    .line 3
    invoke-interface {p0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lnnk;

    .line 9
    return-object p0
.end method

.method public final F()Lnpb;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/work/impl/WorkDatabase_Impl;->n:Lbhph;

    .line 3
    invoke-interface {p0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lnpb;

    .line 9
    return-object p0
.end method

.method protected final a()Lmlp;
    .locals 10

    .line 1
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 3
    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 6
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 8
    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 11
    new-instance v2, Lmlp;

    .line 13
    const-string v8, "WorkProgress"

    .line 15
    const-string v9, "Preference"

    .line 17
    const-string v3, "Dependency"

    .line 19
    const-string v4, "WorkSpec"

    .line 21
    const-string v5, "WorkTag"

    .line 23
    const-string v6, "SystemIdInfo"

    .line 25
    const-string v7, "WorkName"

    .line 27
    filled-new-array/range {v3 .. v9}, [Ljava/lang/String;

    .line 30
    move-result-object v3

    .line 31
    invoke-direct {v2, p0, v0, v1, v3}, Lmlp;-><init>(Lmmt;Ljava/util/Map;Ljava/util/Map;[Ljava/lang/String;)V

    .line 34
    return-object v2
.end method

.method public final synthetic c()Lmnc;
    .locals 1

    .line 1
    new-instance v0, Lnid;

    .line 3
    invoke-direct {v0, p0}, Lnid;-><init>(Landroidx/work/impl/WorkDatabase_Impl;)V

    .line 6
    return-object v0
.end method

.method public final f(Ljava/util/Map;)Ljava/util/List;
    .locals 0

    .line 1
    new-instance p0, Ljava/util/ArrayList;

    .line 3
    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    .line 6
    new-instance p1, Lnhn;

    .line 8
    invoke-direct {p1}, Lnhn;-><init>()V

    .line 11
    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 14
    new-instance p1, Lnho;

    .line 16
    invoke-direct {p1}, Lnho;-><init>()V

    .line 19
    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 22
    new-instance p1, Lnhp;

    .line 24
    invoke-direct {p1}, Lnhp;-><init>()V

    .line 27
    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 30
    new-instance p1, Lnhq;

    .line 32
    invoke-direct {p1}, Lnhq;-><init>()V

    .line 35
    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 38
    new-instance p1, Lnhr;

    .line 40
    invoke-direct {p1}, Lnhr;-><init>()V

    .line 43
    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 46
    new-instance p1, Lnhs;

    .line 48
    invoke-direct {p1}, Lnhs;-><init>()V

    .line 51
    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 54
    new-instance p1, Lnht;

    .line 56
    invoke-direct {p1}, Lnht;-><init>()V

    .line 59
    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 62
    new-instance p1, Lnhu;

    .line 64
    invoke-direct {p1}, Lnhu;-><init>()V

    .line 67
    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 70
    new-instance p1, Lnhv;

    .line 72
    invoke-direct {p1}, Lnhv;-><init>()V

    .line 75
    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 78
    return-object p0
.end method

.method protected final g()Ljava/util/Map;
    .locals 3

    .line 1
    new-instance p0, Ljava/util/LinkedHashMap;

    .line 3
    invoke-direct {p0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 6
    sget v0, Lbhyi;->a:I

    .line 8
    new-instance v0, Lbhxi;

    .line 10
    const-class v1, Lnnk;

    .line 12
    invoke-direct {v0, v1}, Lbhxi;-><init>(Ljava/lang/Class;)V

    .line 15
    sget-object v1, Lbhrq;->a:Lbhrq;

    .line 17
    invoke-interface {p0, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    new-instance v0, Lbhxi;

    .line 22
    const-class v2, Lnlx;

    .line 24
    invoke-direct {v0, v2}, Lbhxi;-><init>(Ljava/lang/Class;)V

    .line 27
    invoke-interface {p0, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    new-instance v0, Lbhxi;

    .line 32
    const-class v2, Lnpb;

    .line 34
    invoke-direct {v0, v2}, Lbhxi;-><init>(Ljava/lang/Class;)V

    .line 37
    invoke-interface {p0, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    new-instance v0, Lbhxi;

    .line 42
    const-class v2, Lnmn;

    .line 44
    invoke-direct {v0, v2}, Lbhxi;-><init>(Ljava/lang/Class;)V

    .line 47
    invoke-interface {p0, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    new-instance v0, Lbhxi;

    .line 52
    const-class v2, Lnmw;

    .line 54
    invoke-direct {v0, v2}, Lbhxi;-><init>(Ljava/lang/Class;)V

    .line 57
    invoke-interface {p0, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    new-instance v0, Lbhxi;

    .line 62
    const-class v2, Lnnb;

    .line 64
    invoke-direct {v0, v2}, Lbhxi;-><init>(Ljava/lang/Class;)V

    .line 67
    invoke-interface {p0, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 70
    new-instance v0, Lbhxi;

    .line 72
    const-class v2, Lnmg;

    .line 74
    invoke-direct {v0, v2}, Lbhxi;-><init>(Ljava/lang/Class;)V

    .line 77
    invoke-interface {p0, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    new-instance v0, Lbhxi;

    .line 82
    const-class v2, Lnml;

    .line 84
    invoke-direct {v0, v2}, Lbhxi;-><init>(Ljava/lang/Class;)V

    .line 87
    invoke-interface {p0, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 90
    return-object p0
.end method

.method public final i()Ljava/util/Set;
    .locals 0

    .line 1
    new-instance p0, Ljava/util/LinkedHashSet;

    .line 3
    invoke-direct {p0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 6
    return-object p0
.end method

.method public final o()V
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    throw p0
.end method

.method public final z()Lnlx;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/work/impl/WorkDatabase_Impl;->m:Lbhph;

    .line 3
    invoke-interface {p0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lnlx;

    .line 9
    return-object p0
.end method
