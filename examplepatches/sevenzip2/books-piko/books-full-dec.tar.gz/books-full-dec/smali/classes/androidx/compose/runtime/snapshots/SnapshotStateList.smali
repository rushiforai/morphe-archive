.class public final Landroidx/compose/runtime/snapshots/SnapshotStateList;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Landroid/os/Parcelable;
.implements Ljava/util/List;
.implements Ljava/util/RandomAccess;
.implements Lgbw;
.implements Lbhym;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable;",
        "Ljava/util/List<",
        "TT;>;",
        "Ljava/util/RandomAccess;",
        "Lgbw;",
        "Lbhym;"
    }
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field


# instance fields
.field public a:Lgby;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lgaz;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    sput-object v0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 8
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 33
    sget-object v0, Lfvo;->a:Lfvo;

    .line 34
    invoke-direct {p0, v0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;-><init>(Lfva;)V

    return-void
.end method

.method public constructor <init>(Lfva;)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-static {}, Lgaq;->b()Lgac;

    .line 7
    move-result-object v0

    .line 8
    new-instance v1, Lgbq;

    .line 10
    invoke-virtual {v0}, Lgac;->v()J

    .line 13
    move-result-wide v2

    .line 14
    invoke-direct {v1, v2, v3, p1}, Lgbq;-><init>(JLfva;)V

    .line 17
    instance-of v0, v0, Lfzv;

    .line 19
    if-nez v0, :cond_0

    .line 21
    new-instance v0, Lgbq;

    .line 23
    const-wide/16 v2, 0x1

    .line 25
    invoke-direct {v0, v2, v3, p1}, Lgbq;-><init>(JLfva;)V

    .line 28
    iput-object v0, v1, Lgby;->n:Lgby;

    .line 30
    :cond_0
    iput-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 32
    return-void
.end method


# virtual methods
.method public final a()Lgby;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 3
    return-object p0
.end method

.method public final add(ILjava/lang/Object;)V
    .locals 7

    .line 1
    :cond_0
    sget-object v0, Lgba;->a:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    invoke-static {v1, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Lgbq;

    .line 15
    iget v2, v1, Lgbq;->b:I

    .line 17
    iget-object v1, v1, Lgbq;->a:Lfva;

    .line 19
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit v0

    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    invoke-interface {v1, p1, p2}, Lfva;->d(ILjava/lang/Object;)Lfva;

    .line 26
    move-result-object v3

    .line 27
    invoke-static {v3, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    move-result v1

    .line 31
    if-nez v1, :cond_2

    .line 33
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 35
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 38
    sget-object v4, Lgaq;->c:Ljava/lang/Object;

    .line 40
    monitor-enter v4

    .line 41
    :try_start_1
    invoke-static {}, Lgaq;->b()Lgac;

    .line 44
    move-result-object v5

    .line 45
    invoke-static {v1, p0, v5}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 48
    move-result-object v1

    .line 49
    check-cast v1, Lgbq;

    .line 51
    monitor-enter v0

    .line 52
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget v6, v1, Lgbq;->b:I

    .line 54
    if-ne v6, v2, :cond_1

    .line 56
    iput-object v3, v1, Lgbq;->a:Lfva;

    .line 58
    iget v2, v1, Lgbq;->c:I

    .line 60
    const/4 v3, 0x1

    .line 61
    add-int/2addr v2, v3

    .line 62
    iput v2, v1, Lgbq;->c:I

    .line 64
    add-int/lit8 v6, v6, 0x1

    .line 66
    iput v6, v1, Lgbq;->b:I

    .line 68
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    .line 69
    :cond_1
    const/4 v3, 0x0

    .line 70
    :goto_0
    :try_start_3
    monitor-exit v0

    .line 71
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit v4

    .line 72
    invoke-static {v5, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 75
    if-eqz v3, :cond_0

    .line 77
    goto :goto_1

    .line 78
    :catchall_0
    move-exception p0

    .line 79
    :try_start_4
    monitor-exit v0

    .line 80
    throw p0

    .line 81
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p0

    .line 82
    monitor-exit v4

    .line 83
    throw p0

    .line 84
    :cond_2
    :goto_1
    return-void

    .line 85
    :catchall_2
    move-exception p0

    .line 86
    monitor-exit v0

    .line 87
    throw p0
.end method

.method public final add(Ljava/lang/Object;)Z
    .locals 9

    .line 88
    :cond_0
    sget-object v0, Lgba;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 89
    invoke-static {v1, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    move-result-object v1

    .line 90
    check-cast v1, Lgbq;

    iget v2, v1, Lgbq;->b:I

    iget-object v1, v1, Lgbq;->a:Lfva;

    .line 91
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit v0

    .line 92
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 93
    invoke-interface {v1, p1}, Lfva;->c(Ljava/lang/Object;)Lfva;

    move-result-object v3

    .line 94
    invoke-static {v3, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    return v4

    :cond_1
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 95
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v5, Lgaq;->c:Ljava/lang/Object;

    .line 96
    monitor-enter v5

    .line 97
    :try_start_1
    invoke-static {}, Lgaq;->b()Lgac;

    move-result-object v6

    .line 98
    invoke-static {v1, p0, v6}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    move-result-object v1

    check-cast v1, Lgbq;

    monitor-enter v0

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget v7, v1, Lgbq;->b:I

    const/4 v8, 0x1

    if-ne v7, v2, :cond_2

    iput-object v3, v1, Lgbq;->a:Lfva;

    iget v2, v1, Lgbq;->c:I

    add-int/2addr v2, v8

    iput v2, v1, Lgbq;->c:I

    add-int/lit8 v7, v7, 0x1

    iput v7, v1, Lgbq;->b:I

    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move v4, v8

    .line 99
    :cond_2
    :try_start_3
    monitor-exit v0

    .line 100
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit v5

    .line 101
    invoke-static {v6, p0}, Lgaq;->r(Lgac;Lgbw;)V

    if-eqz v4, :cond_0

    return v8

    :catchall_0
    move-exception p0

    .line 102
    :try_start_4
    monitor-exit v0

    throw p0

    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p0

    .line 103
    monitor-exit v5

    throw p0

    :catchall_2
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public final addAll(ILjava/util/Collection;)Z
    .locals 1

    .line 88
    new-instance v0, Lgax;

    invoke-direct {v0, p1, p2}, Lgax;-><init>(ILjava/util/Collection;)V

    invoke-static {p0, v0}, Lgba;->c(Landroidx/compose/runtime/snapshots/SnapshotStateList;Lbhwq;)Z

    move-result p0

    return p0
.end method

.method public final addAll(Ljava/util/Collection;)Z
    .locals 9

    .line 1
    :cond_0
    sget-object v0, Lgba;->a:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    invoke-static {v1, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Lgbq;

    .line 15
    iget v2, v1, Lgbq;->b:I

    .line 17
    iget-object v1, v1, Lgbq;->a:Lfva;

    .line 19
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit v0

    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    invoke-interface {v1, p1}, Lfva;->e(Ljava/util/Collection;)Lfva;

    .line 26
    move-result-object v3

    .line 27
    invoke-static {v3, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    move-result v1

    .line 31
    const/4 v4, 0x0

    .line 32
    if-eqz v1, :cond_1

    .line 34
    return v4

    .line 35
    :cond_1
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 37
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    sget-object v5, Lgaq;->c:Ljava/lang/Object;

    .line 42
    monitor-enter v5

    .line 43
    :try_start_1
    invoke-static {}, Lgaq;->b()Lgac;

    .line 46
    move-result-object v6

    .line 47
    invoke-static {v1, p0, v6}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 50
    move-result-object v1

    .line 51
    check-cast v1, Lgbq;

    .line 53
    monitor-enter v0

    .line 54
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget v7, v1, Lgbq;->b:I

    .line 56
    const/4 v8, 0x1

    .line 57
    if-ne v7, v2, :cond_2

    .line 59
    iput-object v3, v1, Lgbq;->a:Lfva;

    .line 61
    iget v2, v1, Lgbq;->c:I

    .line 63
    add-int/2addr v2, v8

    .line 64
    iput v2, v1, Lgbq;->c:I

    .line 66
    add-int/lit8 v7, v7, 0x1

    .line 68
    iput v7, v1, Lgbq;->b:I

    .line 70
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move v4, v8

    .line 71
    :cond_2
    :try_start_3
    monitor-exit v0

    .line 72
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit v5

    .line 73
    invoke-static {v6, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 76
    if-eqz v4, :cond_0

    .line 78
    return v8

    .line 79
    :catchall_0
    move-exception p0

    .line 80
    :try_start_4
    monitor-exit v0

    .line 81
    throw p0

    .line 82
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p0

    .line 83
    monitor-exit v5

    .line 84
    throw p0

    .line 85
    :catchall_2
    move-exception p0

    .line 86
    monitor-exit v0

    .line 87
    throw p0
.end method

.method public final synthetic b(Lgby;Lgby;Lgby;)Lgby;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final c(Lgby;)V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 3
    iput-object v0, p1, Lgby;->n:Lgby;

    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    check-cast p1, Lgbq;

    .line 10
    iput-object p1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 12
    return-void
.end method

.method public final clear()V
    .locals 5

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    sget-object v1, Lgaq;->c:Ljava/lang/Object;

    .line 8
    monitor-enter v1

    .line 9
    :try_start_0
    invoke-static {}, Lgaq;->b()Lgac;

    .line 12
    move-result-object v2

    .line 13
    invoke-static {v0, p0, v2}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Lgbq;

    .line 19
    sget-object v3, Lgba;->a:Ljava/lang/Object;

    .line 21
    monitor-enter v3

    .line 22
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    sget-object v4, Lfvo;->a:Lfvo;

    .line 24
    iput-object v4, v0, Lgbq;->a:Lfva;

    .line 26
    iget v4, v0, Lgbq;->b:I

    .line 28
    add-int/lit8 v4, v4, 0x1

    .line 30
    iput v4, v0, Lgbq;->b:I

    .line 32
    iget v4, v0, Lgbq;->c:I

    .line 34
    add-int/lit8 v4, v4, 0x1

    .line 36
    iput v4, v0, Lgbq;->c:I

    .line 38
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    monitor-exit v3

    .line 39
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    monitor-exit v1

    .line 40
    invoke-static {v2, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 43
    return-void

    .line 44
    :catchall_0
    move-exception p0

    .line 45
    :try_start_3
    monitor-exit v3

    .line 46
    throw p0

    .line 47
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :catchall_1
    move-exception p0

    .line 48
    monitor-exit v1

    .line 49
    throw p0
.end method

.method public final contains(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lgbq;

    .line 12
    iget-object p0, p0, Lgbq;->a:Lfva;

    .line 14
    invoke-interface {p0, p1}, Lfva;->contains(Ljava/lang/Object;)Z

    .line 17
    move-result p0

    .line 18
    return p0
.end method

.method public final containsAll(Ljava/util/Collection;)Z
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lgbq;

    .line 12
    iget-object p0, p0, Lgbq;->a:Lfva;

    .line 14
    invoke-interface {p0, p1}, Lfva;->containsAll(Ljava/util/Collection;)Z

    .line 17
    move-result p0

    .line 18
    return p0
.end method

.method public final d()I
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lgbq;

    .line 12
    iget-object p0, p0, Lgbq;->a:Lfva;

    .line 14
    invoke-interface {p0}, Lfva;->size()I

    .line 17
    move-result p0

    .line 18
    return p0
.end method

.method public final describeContents()I
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final e(I)Ljava/lang/Object;
    .locals 8

    .line 1
    invoke-virtual {p0, p1}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->get(I)Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    :cond_0
    sget-object v1, Lgba;->a:Ljava/lang/Object;

    .line 7
    monitor-enter v1

    .line 8
    :try_start_0
    iget-object v2, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 10
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    invoke-static {v2, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 16
    move-result-object v2

    .line 17
    check-cast v2, Lgbq;

    .line 19
    iget v3, v2, Lgbq;->b:I

    .line 21
    iget-object v2, v2, Lgbq;->a:Lfva;

    .line 23
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit v1

    .line 24
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    invoke-interface {v2, p1}, Lfva;->i(I)Lfva;

    .line 30
    move-result-object v4

    .line 31
    invoke-static {v4, v2}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 34
    move-result v2

    .line 35
    if-nez v2, :cond_2

    .line 37
    iget-object v2, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 39
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    sget-object v5, Lgaq;->c:Ljava/lang/Object;

    .line 44
    monitor-enter v5

    .line 45
    :try_start_1
    invoke-static {}, Lgaq;->b()Lgac;

    .line 48
    move-result-object v6

    .line 49
    invoke-static {v2, p0, v6}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 52
    move-result-object v2

    .line 53
    check-cast v2, Lgbq;

    .line 55
    monitor-enter v1

    .line 56
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget v7, v2, Lgbq;->b:I

    .line 58
    if-ne v7, v3, :cond_1

    .line 60
    iput-object v4, v2, Lgbq;->a:Lfva;

    .line 62
    iget v3, v2, Lgbq;->c:I

    .line 64
    const/4 v4, 0x1

    .line 65
    add-int/2addr v3, v4

    .line 66
    iput v3, v2, Lgbq;->c:I

    .line 68
    add-int/lit8 v7, v7, 0x1

    .line 70
    iput v7, v2, Lgbq;->b:I

    .line 72
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    .line 73
    :cond_1
    const/4 v4, 0x0

    .line 74
    :goto_0
    :try_start_3
    monitor-exit v1

    .line 75
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit v5

    .line 76
    invoke-static {v6, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 79
    if-eqz v4, :cond_0

    .line 81
    goto :goto_1

    .line 82
    :catchall_0
    move-exception p0

    .line 83
    :try_start_4
    monitor-exit v1

    .line 84
    throw p0

    .line 85
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p0

    .line 86
    monitor-exit v5

    .line 87
    throw p0

    .line 88
    :cond_2
    :goto_1
    return-object v0

    .line 89
    :catchall_2
    move-exception p0

    .line 90
    monitor-exit v1

    .line 91
    throw p0
.end method

.method public final f()Ljava/util/List;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lgbq;

    .line 12
    iget-object p0, p0, Lgbq;->a:Lfva;

    .line 14
    return-object p0
.end method

.method public final g(II)V
    .locals 7

    .line 1
    :cond_0
    sget-object v0, Lgba;->a:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    invoke-static {v1, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Lgbq;

    .line 15
    iget v2, v1, Lgbq;->b:I

    .line 17
    iget-object v1, v1, Lgbq;->a:Lfva;

    .line 19
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit v0

    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    invoke-interface {v1}, Lfva;->b()Lfuz;

    .line 26
    move-result-object v3

    .line 27
    invoke-interface {v3, p1, p2}, Ljava/util/List;->subList(II)Ljava/util/List;

    .line 30
    move-result-object v4

    .line 31
    invoke-interface {v4}, Ljava/util/List;->clear()V

    .line 34
    invoke-interface {v3}, Lfuz;->a()Lfva;

    .line 37
    move-result-object v3

    .line 38
    invoke-static {v3, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 41
    move-result v1

    .line 42
    if-nez v1, :cond_2

    .line 44
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 46
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    sget-object v4, Lgaq;->c:Ljava/lang/Object;

    .line 51
    monitor-enter v4

    .line 52
    :try_start_1
    invoke-static {}, Lgaq;->b()Lgac;

    .line 55
    move-result-object v5

    .line 56
    invoke-static {v1, p0, v5}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 59
    move-result-object v1

    .line 60
    check-cast v1, Lgbq;

    .line 62
    monitor-enter v0

    .line 63
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget v6, v1, Lgbq;->b:I

    .line 65
    if-ne v6, v2, :cond_1

    .line 67
    iput-object v3, v1, Lgbq;->a:Lfva;

    .line 69
    iget v2, v1, Lgbq;->c:I

    .line 71
    const/4 v3, 0x1

    .line 72
    add-int/2addr v2, v3

    .line 73
    iput v2, v1, Lgbq;->c:I

    .line 75
    add-int/lit8 v6, v6, 0x1

    .line 77
    iput v6, v1, Lgbq;->b:I

    .line 79
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    .line 80
    :cond_1
    const/4 v3, 0x0

    .line 81
    :goto_0
    :try_start_3
    monitor-exit v0

    .line 82
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit v4

    .line 83
    invoke-static {v5, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 86
    if-eqz v3, :cond_0

    .line 88
    goto :goto_1

    .line 89
    :catchall_0
    move-exception p0

    .line 90
    :try_start_4
    monitor-exit v0

    .line 91
    throw p0

    .line 92
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p0

    .line 93
    monitor-exit v4

    .line 94
    throw p0

    .line 95
    :cond_2
    :goto_1
    return-void

    .line 96
    :catchall_2
    move-exception p0

    .line 97
    monitor-exit v0

    .line 98
    throw p0
.end method

.method public final get(I)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lgbq;

    .line 12
    iget-object p0, p0, Lgbq;->a:Lfva;

    .line 14
    invoke-interface {p0, p1}, Lfva;->get(I)Ljava/lang/Object;

    .line 17
    move-result-object p0

    .line 18
    return-object p0
.end method

.method public final indexOf(Ljava/lang/Object;)I
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lgbq;

    .line 12
    iget-object p0, p0, Lgbq;->a:Lfva;

    .line 14
    invoke-interface {p0, p1}, Lfva;->indexOf(Ljava/lang/Object;)I

    .line 17
    move-result p0

    .line 18
    return p0
.end method

.method public final isEmpty()Z
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lgbq;

    .line 12
    iget-object p0, p0, Lgbq;->a:Lfva;

    .line 14
    invoke-interface {p0}, Lfva;->isEmpty()Z

    .line 17
    move-result p0

    .line 18
    return p0
.end method

.method public final iterator()Ljava/util/Iterator;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TT;>;"
        }
    .end annotation

    .line 1
    new-instance v0, Lgbp;

    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, p0, v1}, Lgbp;-><init>(Landroidx/compose/runtime/snapshots/SnapshotStateList;I)V

    .line 7
    return-object v0
.end method

.method public final lastIndexOf(Ljava/lang/Object;)I
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->i(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lgbq;

    .line 12
    iget-object p0, p0, Lgbq;->a:Lfva;

    .line 14
    invoke-interface {p0, p1}, Lfva;->lastIndexOf(Ljava/lang/Object;)I

    .line 17
    move-result p0

    .line 18
    return p0
.end method

.method public final listIterator()Ljava/util/ListIterator;
    .locals 2

    .line 1
    new-instance v0, Lgbp;

    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, p0, v1}, Lgbp;-><init>(Landroidx/compose/runtime/snapshots/SnapshotStateList;I)V

    .line 7
    return-object v0
.end method

.method public final listIterator(I)Ljava/util/ListIterator;
    .locals 1

    .line 8
    new-instance v0, Lgbp;

    invoke-direct {v0, p0, p1}, Lgbp;-><init>(Landroidx/compose/runtime/snapshots/SnapshotStateList;I)V

    return-object v0
.end method

.method public final bridge remove(I)Ljava/lang/Object;
    .locals 0

    .line 88
    invoke-virtual {p0, p1}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->e(I)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final remove(Ljava/lang/Object;)Z
    .locals 9

    .line 1
    :cond_0
    sget-object v0, Lgba;->a:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    invoke-static {v1, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Lgbq;

    .line 15
    iget v2, v1, Lgbq;->b:I

    .line 17
    iget-object v1, v1, Lgbq;->a:Lfva;

    .line 19
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit v0

    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    invoke-interface {v1, p1}, Lfva;->f(Ljava/lang/Object;)Lfva;

    .line 26
    move-result-object v3

    .line 27
    invoke-static {v3, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    move-result v1

    .line 31
    const/4 v4, 0x0

    .line 32
    if-eqz v1, :cond_1

    .line 34
    return v4

    .line 35
    :cond_1
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 37
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    sget-object v5, Lgaq;->c:Ljava/lang/Object;

    .line 42
    monitor-enter v5

    .line 43
    :try_start_1
    invoke-static {}, Lgaq;->b()Lgac;

    .line 46
    move-result-object v6

    .line 47
    invoke-static {v1, p0, v6}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 50
    move-result-object v1

    .line 51
    check-cast v1, Lgbq;

    .line 53
    monitor-enter v0

    .line 54
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget v7, v1, Lgbq;->b:I

    .line 56
    const/4 v8, 0x1

    .line 57
    if-ne v7, v2, :cond_2

    .line 59
    iput-object v3, v1, Lgbq;->a:Lfva;

    .line 61
    iget v2, v1, Lgbq;->c:I

    .line 63
    add-int/2addr v2, v8

    .line 64
    iput v2, v1, Lgbq;->c:I

    .line 66
    add-int/lit8 v7, v7, 0x1

    .line 68
    iput v7, v1, Lgbq;->b:I

    .line 70
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move v4, v8

    .line 71
    :cond_2
    :try_start_3
    monitor-exit v0

    .line 72
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit v5

    .line 73
    invoke-static {v6, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 76
    if-eqz v4, :cond_0

    .line 78
    return v8

    .line 79
    :catchall_0
    move-exception p0

    .line 80
    :try_start_4
    monitor-exit v0

    .line 81
    throw p0

    .line 82
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p0

    .line 83
    monitor-exit v5

    .line 84
    throw p0

    .line 85
    :catchall_2
    move-exception p0

    .line 86
    monitor-exit v0

    .line 87
    throw p0
.end method

.method public final removeAll(Ljava/util/Collection;)Z
    .locals 9

    .line 1
    :cond_0
    sget-object v0, Lgba;->a:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    invoke-static {v1, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Lgbq;

    .line 15
    iget v2, v1, Lgbq;->b:I

    .line 17
    iget-object v1, v1, Lgbq;->a:Lfva;

    .line 19
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit v0

    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    invoke-interface {v1, p1}, Lfva;->g(Ljava/util/Collection;)Lfva;

    .line 26
    move-result-object v3

    .line 27
    invoke-static {v3, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    move-result v1

    .line 31
    const/4 v4, 0x0

    .line 32
    if-eqz v1, :cond_1

    .line 34
    return v4

    .line 35
    :cond_1
    iget-object v1, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 37
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    sget-object v5, Lgaq;->c:Ljava/lang/Object;

    .line 42
    monitor-enter v5

    .line 43
    :try_start_1
    invoke-static {}, Lgaq;->b()Lgac;

    .line 46
    move-result-object v6

    .line 47
    invoke-static {v1, p0, v6}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 50
    move-result-object v1

    .line 51
    check-cast v1, Lgbq;

    .line 53
    monitor-enter v0

    .line 54
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget v7, v1, Lgbq;->b:I

    .line 56
    const/4 v8, 0x1

    .line 57
    if-ne v7, v2, :cond_2

    .line 59
    iput-object v3, v1, Lgbq;->a:Lfva;

    .line 61
    iget v2, v1, Lgbq;->c:I

    .line 63
    add-int/2addr v2, v8

    .line 64
    iput v2, v1, Lgbq;->c:I

    .line 66
    add-int/lit8 v7, v7, 0x1

    .line 68
    iput v7, v1, Lgbq;->b:I

    .line 70
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move v4, v8

    .line 71
    :cond_2
    :try_start_3
    monitor-exit v0

    .line 72
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit v5

    .line 73
    invoke-static {v6, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 76
    if-eqz v4, :cond_0

    .line 78
    return v8

    .line 79
    :catchall_0
    move-exception p0

    .line 80
    :try_start_4
    monitor-exit v0

    .line 81
    throw p0

    .line 82
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p0

    .line 83
    monitor-exit v5

    .line 84
    throw p0

    .line 85
    :catchall_2
    move-exception p0

    .line 86
    monitor-exit v0

    .line 87
    throw p0
.end method

.method public final retainAll(Ljava/util/Collection;)Z
    .locals 1

    .line 1
    new-instance v0, Lgaw;

    .line 3
    invoke-direct {v0, p1}, Lgaw;-><init>(Ljava/util/Collection;)V

    .line 6
    invoke-static {p0, v0}, Lgba;->c(Landroidx/compose/runtime/snapshots/SnapshotStateList;Lbhwq;)Z

    .line 9
    move-result p0

    .line 10
    return p0
.end method

.method public final set(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    invoke-virtual {p0, p1}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->get(I)Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    :cond_0
    sget-object v1, Lgba;->a:Ljava/lang/Object;

    .line 7
    monitor-enter v1

    .line 8
    :try_start_0
    iget-object v2, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 10
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    invoke-static {v2, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 16
    move-result-object v2

    .line 17
    check-cast v2, Lgbq;

    .line 19
    iget v3, v2, Lgbq;->b:I

    .line 21
    iget-object v2, v2, Lgbq;->a:Lfva;

    .line 23
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit v1

    .line 24
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    invoke-interface {v2, p1, p2}, Lfva;->j(ILjava/lang/Object;)Lfva;

    .line 30
    move-result-object v4

    .line 31
    invoke-static {v4, v2}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 34
    move-result v2

    .line 35
    if-nez v2, :cond_2

    .line 37
    iget-object v2, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 39
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    sget-object v5, Lgaq;->c:Ljava/lang/Object;

    .line 44
    monitor-enter v5

    .line 45
    :try_start_1
    invoke-static {}, Lgaq;->b()Lgac;

    .line 48
    move-result-object v6

    .line 49
    invoke-static {v2, p0, v6}, Lgaq;->k(Lgby;Lgbw;Lgac;)Lgby;

    .line 52
    move-result-object v2

    .line 53
    check-cast v2, Lgbq;

    .line 55
    monitor-enter v1

    .line 56
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget v7, v2, Lgbq;->b:I

    .line 58
    if-ne v7, v3, :cond_1

    .line 60
    iput-object v4, v2, Lgbq;->a:Lfva;

    .line 62
    add-int/lit8 v7, v7, 0x1

    .line 64
    iput v7, v2, Lgbq;->b:I

    .line 66
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v2, 0x1

    .line 67
    goto :goto_0

    .line 68
    :cond_1
    const/4 v2, 0x0

    .line 69
    :goto_0
    :try_start_3
    monitor-exit v1

    .line 70
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit v5

    .line 71
    invoke-static {v6, p0}, Lgaq;->r(Lgac;Lgbw;)V

    .line 74
    if-eqz v2, :cond_0

    .line 76
    goto :goto_1

    .line 77
    :catchall_0
    move-exception p0

    .line 78
    :try_start_4
    monitor-exit v1

    .line 79
    throw p0

    .line 80
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p0

    .line 81
    monitor-exit v5

    .line 82
    throw p0

    .line 83
    :cond_2
    :goto_1
    return-object v0

    .line 84
    :catchall_2
    move-exception p0

    .line 85
    monitor-exit v1

    .line 86
    throw p0
.end method

.method public final bridge size()I
    .locals 0

    .line 1
    invoke-virtual {p0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->d()I

    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public final subList(II)Ljava/util/List;
    .locals 1

    .line 1
    if-ltz p1, :cond_0

    .line 3
    if-gt p1, p2, :cond_0

    .line 5
    invoke-virtual {p0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->d()I

    .line 8
    move-result v0

    .line 9
    if-le p2, v0, :cond_1

    .line 11
    :cond_0
    const-string v0, "fromIndex or toIndex are out of bounds"

    .line 13
    invoke-static {v0}, Lfoz;->a(Ljava/lang/String;)V

    .line 16
    :cond_1
    new-instance v0, Lgcc;

    .line 18
    invoke-direct {v0, p0, p1, p2}, Lgcc;-><init>(Landroidx/compose/runtime/snapshots/SnapshotStateList;II)V

    .line 21
    return-object v0
.end method

.method public final toArray()[Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {p0}, Lbhxj;->a(Ljava/util/Collection;)[Ljava/lang/Object;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 0

    .line 6
    invoke-static {p0, p1}, Lbhxj;->b(Ljava/util/Collection;[Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/compose/runtime/snapshots/SnapshotStateList;->a:Lgby;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v0, p0}, Lgaq;->f(Lgby;Lgbw;)Lgby;

    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Lgbq;

    .line 12
    iget-object v0, v0, Lgbq;->a:Lfva;

    .line 14
    invoke-virtual {p0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->hashCode()I

    .line 17
    move-result p0

    .line 18
    new-instance v1, Ljava/lang/StringBuilder;

    .line 20
    const-string v2, "SnapshotStateList(value="

    .line 22
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 25
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 28
    const-string v0, ")@"

    .line 30
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 36
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    move-result-object p0

    .line 40
    return-object p0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->f()Ljava/util/List;

    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 8
    move-result p2

    .line 9
    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    .line 12
    const/4 v0, 0x0

    .line 13
    :goto_0
    if-ge v0, p2, :cond_0

    .line 15
    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeValue(Ljava/lang/Object;)V

    .line 22
    add-int/lit8 v0, v0, 0x1

    .line 24
    goto :goto_0

    .line 25
    :cond_0
    return-void
.end method
