.class public interface abstract Landroidx/compose/ui/input/pointer/PointerInputEventHandler;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract invoke(Lgwd;Lbhtu;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgwd;",
            "Lbhtu<",
            "-",
            "Lbhqc;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation
.end method
