.class public interface abstract Ladqs;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract a(Ljava/lang/String;Lacps;Lacpo;Lajej;)Lacpi;
.end method

.method public abstract b(Ljava/lang/String;Ladqx;)Lacpk;
.end method

.method public abstract c(Ljava/lang/String;Lacpq;Lajej;)Lajeh;
.end method

.method public abstract d(Ljava/lang/String;Ljava/lang/String;Lajej;)Lajeh;
.end method

.method public abstract e(Ljava/lang/String;)Ljava/io/InputStream;
.end method

.method public abstract f(Ljava/lang/String;)Ljava/io/InputStream;
.end method

.method public abstract g(Ljava/lang/String;Lacpu;Lacpo;Lajej;Ljava/lang/String;Z)Ladrd;
.end method
