.class public final Laarb;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;

.field private final g:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laarb;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laarb;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laarb;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laarb;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laarb;->e:Lbeye;

    .line 14
    iput-object p6, p0, Laarb;->f:Lbeye;

    .line 16
    iput-object p7, p0, Laarb;->g:Lbeye;

    .line 18
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 10

    .line 1
    iget-object v0, p0, Laarb;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v2

    .line 9
    iget-object v0, p0, Laarb;->b:Lbeye;

    .line 11
    check-cast v0, Labjt;

    .line 13
    invoke-virtual {v0}, Labjt;->a()Labjs;

    .line 16
    move-result-object v3

    .line 17
    iget-object v0, p0, Laarb;->c:Lbeye;

    .line 19
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 22
    move-result-object v0

    .line 23
    move-object v4, v0

    .line 24
    check-cast v4, Lavnw;

    .line 26
    iget-object v0, p0, Laarb;->e:Lbeye;

    .line 28
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 31
    move-result-object v0

    .line 32
    move-object v6, v0

    .line 33
    check-cast v6, Lalnn;

    .line 35
    iget-object v0, p0, Laarb;->f:Lbeye;

    .line 37
    check-cast v0, Lzvr;

    .line 39
    invoke-virtual {v0}, Lzvr;->a()Lalyv;

    .line 42
    move-result-object v7

    .line 43
    iget-object v8, p0, Laarb;->g:Lbeye;

    .line 45
    iget-object v5, p0, Laarb;->d:Lbeye;

    .line 47
    invoke-static {}, Lzvs;->a()Lalyv;

    .line 50
    move-result-object v9

    .line 51
    new-instance v1, Laaqz;

    .line 53
    invoke-direct/range {v1 .. v9}, Laaqz;-><init>(Ldw;Labjs;Lavnw;Lbhpa;Lalnn;Lalyv;Lbhpa;Lalyv;)V

    .line 56
    return-object v1
.end method
