.class final Lacfh;
.super Lmld;
.source "PG"


# virtual methods
.method public final a()Ljava/lang/String;
    .locals 0

    .line 1
    const-string p0, "INSERT OR REPLACE INTO `copy_quota` (`volumeId`,`remainingCharacterCount`,`allowedCharacterCount`,`limitType`) VALUES (?,?,?,?)"

    .line 3
    return-object p0
.end method

.method public final bridge synthetic b(Lmrh;Ljava/lang/Object;)V
    .locals 2

    .line 1
    check-cast p2, Lacfm;

    .line 3
    iget-object p0, p2, Lacfm;->a:Ljava/lang/String;

    .line 5
    const/4 v0, 0x1

    .line 6
    invoke-interface {p1, v0, p0}, Lmrh;->j(ILjava/lang/String;)V

    .line 9
    iget-wide v0, p2, Lacfm;->b:J

    .line 11
    const/4 p0, 0x2

    .line 12
    invoke-interface {p1, p0, v0, v1}, Lmrh;->h(IJ)V

    .line 15
    iget-wide v0, p2, Lacfm;->c:J

    .line 17
    const/4 p0, 0x3

    .line 18
    invoke-interface {p1, p0, v0, v1}, Lmrh;->h(IJ)V

    .line 21
    iget p0, p2, Lacfm;->d:I

    .line 23
    add-int/lit8 p0, p0, -0x1

    .line 25
    if-eqz p0, :cond_0

    .line 27
    const-string p0, "UNLIMITED"

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    const-string p0, "LIMITED"

    .line 32
    :goto_0
    const/4 p2, 0x4

    .line 33
    invoke-interface {p1, p2, p0}, Lmrh;->j(ILjava/lang/String;)V

    .line 36
    return-void
.end method
