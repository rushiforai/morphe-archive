.class public final Laamp;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;

.field private final g:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laamp;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laamp;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laamp;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laamp;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laamp;->e:Lbeye;

    .line 14
    iput-object p6, p0, Laamp;->f:Lbeye;

    .line 16
    iput-object p7, p0, Laamp;->g:Lbeye;

    .line 18
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 9

    .line 1
    iget-object v0, p0, Laamp;->a:Lbeye;

    .line 3
    check-cast v0, Lpzw;

    .line 5
    invoke-virtual {v0}, Lpzw;->a()Landroid/content/Context;

    .line 8
    move-result-object v2

    .line 9
    iget-object v0, p0, Laamp;->b:Lbeye;

    .line 11
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object v0

    .line 15
    move-object v3, v0

    .line 16
    check-cast v3, Lbifb;

    .line 18
    iget-object v0, p0, Laamp;->c:Lbeye;

    .line 20
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 23
    move-result-object v0

    .line 24
    move-object v4, v0

    .line 25
    check-cast v4, Lalnn;

    .line 27
    iget-object v0, p0, Laamp;->d:Lbeye;

    .line 29
    check-cast v0, Lpwn;

    .line 31
    invoke-virtual {v0}, Lpwn;->a()Landroid/accounts/Account;

    .line 34
    move-result-object v5

    .line 35
    iget-object v0, p0, Laamp;->e:Lbeye;

    .line 37
    check-cast v0, Lqgk;

    .line 39
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 42
    move-result-object v6

    .line 43
    iget-object v0, p0, Laamp;->f:Lbeye;

    .line 45
    check-cast v0, Labxb;

    .line 47
    invoke-virtual {v0}, Labxb;->a()Labxa;

    .line 50
    move-result-object v7

    .line 51
    iget-object p0, p0, Laamp;->g:Lbeye;

    .line 53
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 56
    move-result-object p0

    .line 57
    move-object v8, p0

    .line 58
    check-cast v8, Laams;

    .line 60
    new-instance v1, Laamo;

    .line 62
    invoke-direct/range {v1 .. v8}, Laamo;-><init>(Landroid/content/Context;Lbifb;Lalnn;Landroid/accounts/Account;Ldw;Labxa;Laams;)V

    .line 65
    return-object v1
.end method
