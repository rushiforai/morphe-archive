.class public final Lacwn;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacwn;->a:Lbeye;

    .line 6
    iput-object p2, p0, Lacwn;->b:Lbeye;

    .line 8
    iput-object p3, p0, Lacwn;->c:Lbeye;

    .line 10
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, Lacwn;->a:Lbeye;

    .line 3
    check-cast v0, Lacxj;

    .line 5
    invoke-virtual {v0}, Lacxj;->a()Lacwy;

    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Lacwn;->b:Lbeye;

    .line 11
    invoke-interface {v1}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Lbifb;

    .line 17
    iget-object p0, p0, Lacwn;->c:Lbeye;

    .line 19
    check-cast p0, Lacwe;

    .line 21
    invoke-virtual {p0}, Lacwe;->a()Lacwd;

    .line 24
    move-result-object p0

    .line 25
    new-instance v2, Lacwm;

    .line 27
    invoke-direct {v2, v0, v1, p0}, Lacwm;-><init>(Lacwy;Lbifb;Lacwd;)V

    .line 30
    return-object v2
.end method
