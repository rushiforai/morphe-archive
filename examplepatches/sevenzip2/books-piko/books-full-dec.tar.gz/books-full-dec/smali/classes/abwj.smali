.class public final Labwj;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    new-instance p0, Labuv;

    .line 3
    invoke-direct {p0}, Labuv;-><init>()V

    .line 6
    return-object p0
.end method
