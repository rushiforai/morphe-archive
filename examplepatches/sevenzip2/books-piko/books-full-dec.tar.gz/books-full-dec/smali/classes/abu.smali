.class Labu;
.super Labt;
.source "PG"


# virtual methods
.method public a(Lacm;Lacm;Landroid/view/Window;Landroid/view/View;ZZ)V
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    invoke-static {p3, p0}, Ljnr;->a(Landroid/view/Window;Z)V

    .line 5
    invoke-virtual {p3, p0}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 8
    invoke-virtual {p3, p0}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 11
    invoke-static {p3, p0}, Labu$$ExternalSyntheticApiModelOutline0;->m(Landroid/view/Window;Z)V

    .line 14
    const/4 p0, 0x1

    .line 15
    invoke-static {p3, p0}, Labu$$ExternalSyntheticApiModelOutline0;->m$1(Landroid/view/Window;Z)V

    .line 18
    new-instance p1, Ljpf;

    .line 20
    invoke-direct {p1, p3, p4}, Ljpf;-><init>(Landroid/view/Window;Landroid/view/View;)V

    .line 23
    xor-int/lit8 p2, p5, 0x1

    .line 25
    invoke-virtual {p1, p2}, Ljpf;->c(Z)V

    .line 28
    xor-int/2addr p0, p6

    .line 29
    invoke-virtual {p1, p0}, Ljpf;->b(Z)V

    .line 32
    return-void
.end method
