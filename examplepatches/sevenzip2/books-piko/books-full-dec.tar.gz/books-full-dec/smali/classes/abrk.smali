.class public final Labrk;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labrk;->a:Lbeye;

    .line 6
    iput-object p2, p0, Labrk;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final a()Labrj;
    .locals 2

    .line 1
    new-instance v0, Labrj;

    .line 3
    iget-object v1, p0, Labrk;->a:Lbeye;

    .line 5
    iget-object p0, p0, Labrk;->b:Lbeye;

    .line 7
    invoke-direct {v0, v1, p0}, Labrj;-><init>(Lbhpa;Lbhpa;)V

    .line 10
    return-object v0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Labrk;->a()Labrj;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
