.class public final Lacsj;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacsj;->a:Lbeye;

    .line 6
    iput-object p2, p0, Lacsj;->b:Lbeye;

    .line 8
    iput-object p3, p0, Lacsj;->c:Lbeye;

    .line 10
    iput-object p4, p0, Lacsj;->d:Lbeye;

    .line 12
    iput-object p5, p0, Lacsj;->e:Lbeye;

    .line 14
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, Lacsj;->a:Lbeye;

    .line 3
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lacxt;

    .line 9
    iget-object v1, p0, Lacsj;->b:Lbeye;

    .line 11
    check-cast v1, Lacxj;

    .line 13
    invoke-virtual {v1}, Lacxj;->a()Lacwy;

    .line 16
    iget-object v1, p0, Lacsj;->c:Lbeye;

    .line 18
    invoke-interface {v1}, Lbeye;->b()Ljava/lang/Object;

    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Lbifb;

    .line 24
    iget-object v2, p0, Lacsj;->d:Lbeye;

    .line 26
    check-cast v2, Ladjy;

    .line 28
    invoke-virtual {v2}, Ladjy;->a()Ladjx;

    .line 31
    move-result-object v2

    .line 32
    iget-object p0, p0, Lacsj;->e:Lbeye;

    .line 34
    invoke-static {p0}, Lbexu;->a(Lbeye;)Lbexl;

    .line 37
    move-result-object p0

    .line 38
    new-instance v3, Lacsh;

    .line 40
    invoke-direct {v3, v0, v1, v2, p0}, Lacsh;-><init>(Lacxt;Lbifb;Ladjx;Lbexl;)V

    .line 43
    return-object v3
.end method
