.class public interface abstract Labtt;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract ak(Lcom/google/android/apps/play/books/ebook/activity/video/FullScreenVideoActivity;)V
.end method
