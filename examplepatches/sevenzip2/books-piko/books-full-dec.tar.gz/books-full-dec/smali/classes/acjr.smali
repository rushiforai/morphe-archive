.class public final synthetic Lacjr;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lakuc;


# instance fields
.field public final synthetic a:Lacjx;


# direct methods
.method public synthetic constructor <init>(Lacjx;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacjr;->a:Lacjx;

    .line 6
    return-void
.end method


# virtual methods
.method public final fu(Ljava/lang/Object;)V
    .locals 3

    .line 1
    iget-object p0, p0, Lacjr;->a:Lacjx;

    .line 3
    iget-object v0, p0, Lacjx;->b:Landroid/content/ContentResolver;

    .line 5
    check-cast p1, Lyep;

    .line 7
    sget-object v1, Lyin;->a:Landroid/net/Uri;

    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-virtual {v0, v1, v2, v2}, Landroid/content/ContentResolver;->delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I

    .line 13
    iget-object p1, p1, Lyep;->a:Lajvv;

    .line 15
    if-eqz p1, :cond_0

    .line 17
    invoke-interface {p1}, Lajvv;->j()Ljava/io/File;

    .line 20
    move-result-object p1

    .line 21
    :try_start_0
    sget v0, Lajuu;->e:I

    .line 23
    new-instance v0, Ljava/io/File;

    .line 25
    const-string v1, "uuid.txt"

    .line 27
    invoke-direct {v0, p1, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 30
    invoke-static {v0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    .line 33
    move-result-object v0

    .line 34
    invoke-static {p1, v0}, Lakuz;->h(Ljava/io/File;Ljava/util/Set;)Z

    .line 37
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 38
    :catch_0
    move-exception p1

    .line 39
    const/4 v0, 0x6

    .line 40
    const-string v1, "VolumeContentStore"

    .line 42
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_0

    .line 48
    const-string v0, "Error deleting content files"

    .line 50
    invoke-static {v1, v0, p1}, Lakvo;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 53
    :cond_0
    :goto_0
    iput-object v2, p0, Lacjx;->g:Lajut;

    .line 55
    return-void
.end method
