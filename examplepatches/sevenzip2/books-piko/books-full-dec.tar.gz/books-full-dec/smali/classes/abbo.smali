.class public interface abstract Labbo;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract F()Lalls;
.end method
