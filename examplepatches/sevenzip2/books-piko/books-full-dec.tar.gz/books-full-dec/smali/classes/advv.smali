.class public final synthetic Ladvv;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# instance fields
.field public final synthetic a:Ladvw;


# direct methods
.method public synthetic constructor <init>(Ladvw;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladvv;->a:Ladvw;

    .line 6
    return-void
.end method


# virtual methods
.method public final onPreDraw()Z
    .locals 3

    .line 1
    sget v0, Ljmy;->a:I

    .line 3
    iget-object p0, p0, Ladvv;->a:Ladvw;

    .line 5
    iget-object v0, p0, Ladvw;->c:Landroid/view/View;

    .line 7
    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_1

    .line 13
    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    .line 16
    move-result v1

    .line 17
    if-nez v1, :cond_0

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    invoke-static {v0}, Ladvw;->a(Landroid/view/View;)Landroid/graphics/Rect;

    .line 23
    move-result-object v0

    .line 24
    iget-object v1, p0, Ladvw;->d:Landroid/graphics/Rect;

    .line 26
    invoke-virtual {v0, v1}, Landroid/graphics/Rect;->equals(Ljava/lang/Object;)Z

    .line 29
    move-result v2

    .line 30
    if-nez v2, :cond_1

    .line 32
    invoke-virtual {v1, v0}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 35
    iget-object p0, p0, Ladvw;->e:Ladvk;

    .line 37
    iget-object p0, p0, Ladvk;->a:Ladvm;

    .line 39
    iget-object v0, p0, Ladvm;->b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 41
    if-eqz v0, :cond_1

    .line 43
    invoke-virtual {v0, v1}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->c(Landroid/graphics/Rect;)V

    .line 46
    iget-object p0, p0, Ladvm;->b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 48
    invoke-virtual {p0}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->requestLayout()V

    .line 51
    :cond_1
    :goto_0
    const/4 p0, 0x1

    .line 52
    return p0
.end method
