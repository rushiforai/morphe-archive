.class public final Labjw;
.super Ljava/lang/Object;
.source "PG"


# direct methods
.method public static final a()Lalyv;
    .locals 3

    .line 1
    new-instance v0, Labjv;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance v1, Lalyv;

    .line 8
    const-class v2, Labka;

    .line 10
    invoke-direct {v1, v2, v0}, Lalyv;-><init>(Ljava/lang/Class;Lbhwq;)V

    .line 13
    return-object v1
.end method
