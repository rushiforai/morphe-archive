.class public final Laatl;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;

.field private final g:Lbeye;

.field private final h:Lbeye;

.field private final i:Lbeye;

.field private final j:Lbeye;

.field private final k:Lbeye;

.field private final l:Lbeye;

.field private final m:Lbeye;

.field private final n:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laatl;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laatl;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laatl;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laatl;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laatl;->e:Lbeye;

    .line 14
    iput-object p6, p0, Laatl;->f:Lbeye;

    .line 16
    iput-object p7, p0, Laatl;->g:Lbeye;

    .line 18
    iput-object p8, p0, Laatl;->h:Lbeye;

    .line 20
    iput-object p9, p0, Laatl;->i:Lbeye;

    .line 22
    iput-object p10, p0, Laatl;->j:Lbeye;

    .line 24
    iput-object p11, p0, Laatl;->k:Lbeye;

    .line 26
    iput-object p12, p0, Laatl;->l:Lbeye;

    .line 28
    iput-object p13, p0, Laatl;->m:Lbeye;

    .line 30
    iput-object p14, p0, Laatl;->n:Lbeye;

    .line 32
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, Laatl;->a:Lbeye;

    .line 5
    check-cast v1, Lqgk;

    .line 7
    invoke-virtual {v1}, Lqgk;->a()Ldw;

    .line 10
    move-result-object v3

    .line 11
    invoke-static {}, Lzvs;->a()Lalyv;

    .line 14
    move-result-object v4

    .line 15
    iget-object v1, v0, Laatl;->b:Lbeye;

    .line 17
    check-cast v1, Labxb;

    .line 19
    invoke-virtual {v1}, Labxb;->a()Labxa;

    .line 22
    move-result-object v5

    .line 23
    iget-object v1, v0, Laatl;->c:Lbeye;

    .line 25
    check-cast v1, Lzvr;

    .line 27
    invoke-virtual {v1}, Lzvr;->a()Lalyv;

    .line 30
    move-result-object v6

    .line 31
    iget-object v1, v0, Laatl;->f:Lbeye;

    .line 33
    check-cast v1, Labjc;

    .line 35
    invoke-virtual {v1}, Labjc;->a()Labjb;

    .line 38
    move-result-object v9

    .line 39
    iget-object v1, v0, Laatl;->g:Lbeye;

    .line 41
    check-cast v1, Labjt;

    .line 43
    invoke-virtual {v1}, Labjt;->a()Labjs;

    .line 46
    move-result-object v10

    .line 47
    iget-object v1, v0, Laatl;->h:Lbeye;

    .line 49
    check-cast v1, Labjp;

    .line 51
    invoke-virtual {v1}, Labjp;->a()Labjo;

    .line 54
    move-result-object v11

    .line 55
    iget-object v1, v0, Laatl;->i:Lbeye;

    .line 57
    check-cast v1, Labvc;

    .line 59
    invoke-virtual {v1}, Labvc;->a()Labvb;

    .line 62
    move-result-object v12

    .line 63
    iget-object v1, v0, Laatl;->j:Lbeye;

    .line 65
    check-cast v1, Lacqw;

    .line 67
    invoke-virtual {v1}, Lacqw;->a()Lacqv;

    .line 70
    move-result-object v13

    .line 71
    iget-object v1, v0, Laatl;->k:Lbeye;

    .line 73
    check-cast v1, Laake;

    .line 75
    invoke-virtual {v1}, Laake;->a()Laakd;

    .line 78
    move-result-object v14

    .line 79
    iget-object v1, v0, Laatl;->l:Lbeye;

    .line 81
    invoke-interface {v1}, Lbeye;->b()Ljava/lang/Object;

    .line 84
    move-result-object v1

    .line 85
    move-object v15, v1

    .line 86
    check-cast v15, Laawv;

    .line 88
    iget-object v1, v0, Laatl;->m:Lbeye;

    .line 90
    invoke-interface {v1}, Lbeye;->b()Ljava/lang/Object;

    .line 93
    move-result-object v1

    .line 94
    move-object/from16 v16, v1

    .line 96
    check-cast v16, Laadi;

    .line 98
    iget-object v1, v0, Laatl;->n:Lbeye;

    .line 100
    check-cast v1, Laanv;

    .line 102
    invoke-virtual {v1}, Laanv;->a()Laanu;

    .line 105
    move-result-object v17

    .line 106
    iget-object v7, v0, Laatl;->d:Lbeye;

    .line 108
    iget-object v8, v0, Laatl;->e:Lbeye;

    .line 110
    new-instance v2, Laatk;

    .line 112
    invoke-direct/range {v2 .. v17}, Laatk;-><init>(Ldw;Lalyv;Labxa;Lalyv;Lbhpa;Lbhpa;Labjb;Labjs;Labjo;Labvb;Lacqv;Laakd;Laawv;Laadi;Laanu;)V

    .line 115
    return-object v2
.end method
