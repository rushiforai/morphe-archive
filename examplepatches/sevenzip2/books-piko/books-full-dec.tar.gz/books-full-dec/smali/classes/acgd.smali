.class public final Lacgd;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lamdx;


# instance fields
.field private final a:Lbhpa;

.field private final b:Lbhpa;

.field private final c:Lbhpa;

.field private final d:Lbhpa;

.field private final e:Lbhpa;


# direct methods
.method public constructor <init>(Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    iput-object p1, p0, Lacgd;->a:Lbhpa;

    .line 9
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    iput-object p2, p0, Lacgd;->b:Lbhpa;

    .line 14
    iput-object p3, p0, Lacgd;->c:Lbhpa;

    .line 16
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    iput-object p4, p0, Lacgd;->d:Lbhpa;

    .line 21
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    iput-object p5, p0, Lacgd;->e:Lbhpa;

    .line 26
    return-void
.end method


# virtual methods
.method public final synthetic a(Landroidx/work/WorkerParameters;)Lneo;
    .locals 9

    .line 1
    iget-object v0, p0, Lacgd;->c:Lbhpa;

    .line 3
    iget-object v1, p0, Lacgd;->b:Lbhpa;

    .line 5
    new-instance v2, Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 7
    iget-object v3, p0, Lacgd;->a:Lbhpa;

    .line 9
    invoke-interface {v3}, Lbhpa;->b()Ljava/lang/Object;

    .line 12
    move-result-object v3

    .line 13
    invoke-interface {v1}, Lbhpa;->b()Ljava/lang/Object;

    .line 16
    move-result-object v1

    .line 17
    invoke-interface {v0}, Lbhpa;->b()Ljava/lang/Object;

    .line 20
    move-result-object v0

    .line 21
    move-object v5, v0

    .line 22
    check-cast v5, Lavnw;

    .line 24
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    iget-object v0, p0, Lacgd;->d:Lbhpa;

    .line 29
    invoke-interface {v0}, Lbhpa;->b()Ljava/lang/Object;

    .line 32
    move-result-object v0

    .line 33
    move-object v6, v0

    .line 34
    check-cast v6, Lafjo;

    .line 36
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    iget-object p0, p0, Lacgd;->e:Lbhpa;

    .line 41
    check-cast p0, Lpzw;

    .line 43
    invoke-virtual {p0}, Lpzw;->a()Landroid/content/Context;

    .line 46
    move-result-object v7

    .line 47
    move-object v4, v1

    .line 48
    check-cast v4, Lacft;

    .line 50
    move-object v8, p1

    .line 51
    invoke-direct/range {v2 .. v8}, Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;-><init>(Lacek;Lacft;Lavnw;Lafjo;Landroid/content/Context;Landroidx/work/WorkerParameters;)V

    .line 54
    return-object v2
.end method
