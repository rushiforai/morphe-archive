.class public final Laam;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Lajm;

.field public final b:Lahs;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Lajm;

    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-direct {v0, v1}, Lajm;-><init>(I)V

    .line 10
    iput-object v0, p0, Laam;->a:Lajm;

    .line 12
    new-instance v0, Lahs;

    .line 14
    const/16 v1, 0xa

    .line 16
    invoke-direct {v0, v1}, Lahs;-><init>(I)V

    .line 19
    iput-object v0, p0, Laam;->b:Lahs;

    .line 21
    return-void
.end method


# virtual methods
.method public final a(Lxw;I)Lww;
    .locals 4

    .line 1
    iget-object p0, p0, Laam;->a:Lajm;

    .line 3
    invoke-virtual {p0, p1}, Lajm;->c(Ljava/lang/Object;)I

    .line 6
    move-result p1

    .line 7
    const/4 v0, 0x0

    .line 8
    if-gez p1, :cond_0

    .line 10
    return-object v0

    .line 11
    :cond_0
    invoke-virtual {p0, p1}, Lajm;->g(I)Ljava/lang/Object;

    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Laal;

    .line 17
    if-eqz v1, :cond_4

    .line 19
    iget v2, v1, Laal;->a:I

    .line 21
    and-int v3, v2, p2

    .line 23
    if-eqz v3, :cond_4

    .line 25
    not-int v0, p2

    .line 26
    and-int/2addr v0, v2

    .line 27
    iput v0, v1, Laal;->a:I

    .line 29
    const/4 v2, 0x4

    .line 30
    if-ne p2, v2, :cond_1

    .line 32
    iget-object p2, v1, Laal;->b:Lww;

    .line 34
    goto :goto_0

    .line 35
    :cond_1
    const/16 v2, 0x8

    .line 37
    if-ne p2, v2, :cond_3

    .line 39
    iget-object p2, v1, Laal;->c:Lww;

    .line 41
    :goto_0
    and-int/lit8 v0, v0, 0xc

    .line 43
    if-nez v0, :cond_2

    .line 45
    invoke-virtual {p0, p1}, Lajm;->e(I)Ljava/lang/Object;

    .line 48
    invoke-static {v1}, Laal;->b(Laal;)V

    .line 51
    :cond_2
    return-object p2

    .line 52
    :cond_3
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 54
    const-string p1, "Must provide flag PRE or POST"

    .line 56
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 59
    throw p0

    .line 60
    :cond_4
    return-object v0
.end method

.method final b(Lxw;)V
    .locals 1

    .line 1
    iget-object p0, p0, Laam;->a:Lajm;

    .line 3
    invoke-virtual {p0, p1}, Lajm;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Laal;

    .line 9
    if-nez v0, :cond_0

    .line 11
    invoke-static {}, Laal;->a()Laal;

    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {p0, p1, v0}, Lajm;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    :cond_0
    iget p0, v0, Laal;->a:I

    .line 20
    or-int/lit8 p0, p0, 0x1

    .line 22
    iput p0, v0, Laal;->a:I

    .line 24
    return-void
.end method

.method public final c(JLxw;)V
    .locals 0

    .line 1
    iget-object p0, p0, Laam;->b:Lahs;

    .line 3
    invoke-virtual {p0, p1, p2, p3}, Lahs;->g(JLjava/lang/Object;)V

    .line 6
    return-void
.end method

.method public final d(Lxw;Lww;)V
    .locals 1

    .line 1
    iget-object p0, p0, Laam;->a:Lajm;

    .line 3
    invoke-virtual {p0, p1}, Lajm;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Laal;

    .line 9
    if-nez v0, :cond_0

    .line 11
    invoke-static {}, Laal;->a()Laal;

    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {p0, p1, v0}, Lajm;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    :cond_0
    iput-object p2, v0, Laal;->c:Lww;

    .line 20
    iget p0, v0, Laal;->a:I

    .line 22
    or-int/lit8 p0, p0, 0x8

    .line 24
    iput p0, v0, Laal;->a:I

    .line 26
    return-void
.end method

.method public final e(Lxw;Lww;)V
    .locals 1

    .line 1
    iget-object p0, p0, Laam;->a:Lajm;

    .line 3
    invoke-virtual {p0, p1}, Lajm;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Laal;

    .line 9
    if-nez v0, :cond_0

    .line 11
    invoke-static {}, Laal;->a()Laal;

    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {p0, p1, v0}, Lajm;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    :cond_0
    iput-object p2, v0, Laal;->b:Lww;

    .line 20
    iget p0, v0, Laal;->a:I

    .line 22
    or-int/lit8 p0, p0, 0x4

    .line 24
    iput p0, v0, Laal;->a:I

    .line 26
    return-void
.end method

.method public final f()V
    .locals 1

    .line 1
    iget-object v0, p0, Laam;->a:Lajm;

    .line 3
    invoke-virtual {v0}, Lajm;->clear()V

    .line 6
    iget-object p0, p0, Laam;->b:Lahs;

    .line 8
    invoke-virtual {p0}, Lahs;->f()V

    .line 11
    return-void
.end method

.method final g(Lxw;)V
    .locals 0

    .line 1
    iget-object p0, p0, Laam;->a:Lajm;

    .line 3
    invoke-virtual {p0, p1}, Lajm;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Laal;

    .line 9
    if-nez p0, :cond_0

    .line 11
    return-void

    .line 12
    :cond_0
    iget p1, p0, Laal;->a:I

    .line 14
    and-int/lit8 p1, p1, -0x2

    .line 16
    iput p1, p0, Laal;->a:I

    .line 18
    return-void
.end method

.method final h(Lxw;)V
    .locals 5

    .line 1
    iget-object v0, p0, Laam;->b:Lahs;

    .line 3
    invoke-virtual {v0}, Lahs;->b()I

    .line 6
    move-result v1

    .line 7
    :cond_0
    add-int/lit8 v1, v1, -0x1

    .line 9
    if-ltz v1, :cond_1

    .line 11
    invoke-virtual {v0, v1}, Lahs;->e(I)Ljava/lang/Object;

    .line 14
    move-result-object v2

    .line 15
    if-ne p1, v2, :cond_0

    .line 17
    iget-object v2, v0, Lahs;->c:[Ljava/lang/Object;

    .line 19
    aget-object v3, v2, v1

    .line 21
    sget-object v4, Laht;->a:Ljava/lang/Object;

    .line 23
    if-eq v3, v4, :cond_1

    .line 25
    aput-object v4, v2, v1

    .line 27
    const/4 v1, 0x1

    .line 28
    iput-boolean v1, v0, Lahs;->a:Z

    .line 30
    :cond_1
    iget-object p0, p0, Laam;->a:Lajm;

    .line 32
    invoke-virtual {p0, p1}, Lajm;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    move-result-object p0

    .line 36
    check-cast p0, Laal;

    .line 38
    if-eqz p0, :cond_2

    .line 40
    invoke-static {p0}, Laal;->b(Laal;)V

    .line 43
    :cond_2
    return-void
.end method

.method public final i(Lxw;)Z
    .locals 0

    .line 1
    iget-object p0, p0, Laam;->a:Lajm;

    .line 3
    invoke-virtual {p0, p1}, Lajm;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Laal;

    .line 9
    if-eqz p0, :cond_0

    .line 11
    iget p0, p0, Laal;->a:I

    .line 13
    const/4 p1, 0x1

    .line 14
    and-int/2addr p0, p1

    .line 15
    if-eqz p0, :cond_0

    .line 17
    return p1

    .line 18
    :cond_0
    const/4 p0, 0x0

    .line 19
    return p0
.end method
