.class public final Ladux;
.super Ljava/lang/Object;
.source "PG"


# direct methods
.method public static final a(I)I
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    if-eq p0, v0, :cond_0

    .line 4
    const/4 p0, 0x2

    .line 5
    return p0

    .line 6
    :cond_0
    return v0
.end method
