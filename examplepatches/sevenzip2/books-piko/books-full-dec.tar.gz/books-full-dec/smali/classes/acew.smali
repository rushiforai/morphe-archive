.class final Lacew;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwq;


# instance fields
.field a:I

.field final synthetic b:Lacey;

.field final synthetic c:Ljava/util/Collection;

.field final synthetic d:Ljava/util/List;


# direct methods
.method public constructor <init>(Lacey;Ljava/util/Collection;Ljava/util/List;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lacew;->b:Lacey;

    .line 3
    iput-object p2, p0, Lacew;->c:Ljava/util/Collection;

    .line 5
    iput-object p3, p0, Lacew;->d:Ljava/util/List;

    .line 7
    const/4 p1, 0x1

    .line 8
    invoke-direct {p0, p1, p4}, Lbhuu;-><init>(ILbhtu;)V

    .line 11
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    check-cast p1, Lbhtu;

    .line 3
    new-instance v0, Lacew;

    .line 5
    iget-object v1, p0, Lacew;->b:Lacey;

    .line 7
    iget-object v2, p0, Lacew;->c:Ljava/util/Collection;

    .line 9
    iget-object p0, p0, Lacew;->d:Ljava/util/List;

    .line 11
    invoke-direct {v0, v1, v2, p0, p1}, Lacew;-><init>(Lacey;Ljava/util/Collection;Ljava/util/List;Lbhtu;)V

    .line 14
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 16
    invoke-virtual {v0, p0}, Lacew;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    move-result-object p0

    .line 20
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Lacew;->a:I

    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 10
    if-eqz v1, :cond_0

    .line 12
    if-eq v1, v3, :cond_2

    .line 14
    goto :goto_2

    .line 15
    :cond_0
    iget-object p1, p0, Lacew;->b:Lacey;

    .line 17
    iget-object v1, p0, Lacew;->c:Ljava/util/Collection;

    .line 19
    new-instance v4, Ljava/util/ArrayList;

    .line 21
    invoke-static {v1}, Lbhrc;->p(Ljava/lang/Iterable;)I

    .line 24
    move-result v5

    .line 25
    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 28
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 31
    move-result-object v1

    .line 32
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 35
    move-result v5

    .line 36
    if-eqz v5, :cond_1

    .line 38
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 41
    move-result-object v5

    .line 42
    check-cast v5, Lacfo;

    .line 44
    iget-object v7, v5, Lacfo;->a:Ljava/lang/String;

    .line 46
    iget-wide v8, v5, Lacfo;->b:J

    .line 48
    iget-wide v10, v5, Lacfo;->c:J

    .line 50
    iget v12, v5, Lacfo;->d:I

    .line 52
    new-instance v6, Lacfm;

    .line 54
    invoke-direct/range {v6 .. v12}, Lacfm;-><init>(Ljava/lang/String;JJI)V

    .line 57
    invoke-interface {v4, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 60
    goto :goto_0

    .line 61
    :cond_1
    iget-object p1, p1, Lacey;->b:Lacfa;

    .line 63
    iput v3, p0, Lacew;->a:I

    .line 65
    new-instance v1, Lacfc;

    .line 67
    check-cast p1, Lacfk;

    .line 69
    invoke-direct {v1, p1, v4}, Lacfc;-><init>(Lacfk;Ljava/util/Collection;)V

    .line 72
    iget-object p1, p1, Lacfk;->a:Lmmt;

    .line 74
    invoke-static {p1, v2, v3, v1, p0}, Lmpv;->d(Lmmt;ZZLbhwq;Lbhtu;)Ljava/lang/Object;

    .line 77
    move-result-object p1

    .line 78
    if-ne p1, v0, :cond_2

    .line 80
    goto :goto_1

    .line 81
    :cond_2
    iget-object p1, p0, Lacew;->b:Lacey;

    .line 83
    iget-object v1, p0, Lacew;->d:Ljava/util/List;

    .line 85
    const/4 v4, 0x2

    .line 86
    iput v4, p0, Lacew;->a:I

    .line 88
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 91
    iget-object p1, p1, Lacey;->b:Lacfa;

    .line 93
    new-instance v4, Lacfe;

    .line 95
    check-cast p1, Lacfk;

    .line 97
    invoke-direct {v4, p1, v1}, Lacfe;-><init>(Lacfk;Ljava/util/List;)V

    .line 100
    iget-object p1, p1, Lacfk;->a:Lmmt;

    .line 102
    invoke-static {p1, v2, v3, v4, p0}, Lmpv;->d(Lmmt;ZZLbhwq;Lbhtu;)Ljava/lang/Object;

    .line 105
    move-result-object p0

    .line 106
    if-ne p0, v0, :cond_3

    .line 108
    :goto_1
    return-object v0

    .line 109
    :cond_3
    :goto_2
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 111
    return-object p0
.end method
