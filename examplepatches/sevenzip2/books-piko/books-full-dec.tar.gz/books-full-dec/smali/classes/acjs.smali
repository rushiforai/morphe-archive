.class public final synthetic Lacjs;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lakuc;


# instance fields
.field public final synthetic a:Lacjx;


# direct methods
.method public synthetic constructor <init>(Lacjx;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacjs;->a:Lacjx;

    .line 6
    return-void
.end method


# virtual methods
.method public final fu(Ljava/lang/Object;)V
    .locals 7

    .line 1
    check-cast p1, Lajel;

    .line 3
    invoke-virtual {p1}, Lajel;->a()Landroid/accounts/Account;

    .line 6
    move-result-object p1

    .line 7
    iget-object p1, p1, Landroid/accounts/Account;->name:Ljava/lang/String;

    .line 9
    iget-object p0, p0, Lacjs;->a:Lacjx;

    .line 11
    :try_start_0
    iget-object p0, p0, Lacjx;->c:Lajuu;

    .line 13
    invoke-virtual {p0}, Lajuu;->k()Lajut;

    .line 16
    move-result-object v0

    .line 17
    iget-object v0, v0, Lajut;->b:Lajvv;

    .line 19
    invoke-static {p1, v0}, Lacjx;->j(Ljava/lang/String;Lajvv;)V

    .line 22
    invoke-virtual {p0}, Lajuu;->b()Ljava/util/List;

    .line 25
    move-result-object p0

    .line 26
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 29
    move-result-object p0

    .line 30
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 36
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 39
    move-result-object v0

    .line 40
    check-cast v0, Lajut;

    .line 42
    iget-object v0, v0, Lajut;->b:Lajvv;

    .line 44
    invoke-static {p1, v0}, Lacjx;->j(Ljava/lang/String;Lajvv;)V

    .line 47
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 48
    :cond_0
    return-void

    .line 49
    :catch_0
    move-exception v0

    .line 50
    move-object p0, v0

    .line 51
    move-object v6, p0

    .line 52
    sget-object p0, Lacjx;->a:Layxl;

    .line 54
    invoke-virtual {p0}, Layxb;->d()Layxz;

    .line 57
    move-result-object v0

    .line 58
    const/16 v4, 0x1b1

    .line 60
    const-string v5, "VolumeContentStore.java"

    .line 62
    const-string v1, "Error deleting content files"

    .line 64
    const-string v2, "com/google/android/apps/play/books/ebook/data/VolumeContentStore"

    .line 66
    const-string v3, "deleteContentFiles"

    .line 68
    invoke-static/range {v0 .. v6}, La;->A(Layxz;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;CLjava/lang/String;Ljava/lang/Throwable;)V

    .line 71
    return-void
.end method
