.class public final Laaqi;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laaqi;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laaqi;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laaqi;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laaqi;->d:Lbeye;

    .line 12
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, Laaqi;->a:Lbeye;

    .line 3
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lbifb;

    .line 9
    iget-object v1, p0, Laaqi;->b:Lbeye;

    .line 11
    invoke-interface {v1}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Laawv;

    .line 17
    iget-object v2, p0, Laaqi;->c:Lbeye;

    .line 19
    invoke-interface {v2}, Lbeye;->b()Ljava/lang/Object;

    .line 22
    move-result-object v2

    .line 23
    check-cast v2, Lawfx;

    .line 25
    iget-object p0, p0, Laaqi;->d:Lbeye;

    .line 27
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Lappw;

    .line 33
    new-instance v3, Laaqh;

    .line 35
    invoke-direct {v3, v0, v1, v2, p0}, Laaqh;-><init>(Lbifb;Laawv;Lawfx;Lappw;)V

    .line 38
    return-object v3
.end method
