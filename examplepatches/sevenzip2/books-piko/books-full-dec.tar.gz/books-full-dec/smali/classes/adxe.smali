.class public final Ladxe;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 4

    .line 1
    const/4 p0, 0x6

    .line 2
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    move-result-object v0

    .line 6
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    sget-object v0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 11
    new-instance v1, Lalqg;

    .line 13
    const-string v2, "BackgroundData"

    .line 15
    const/4 v3, 0x0

    .line 16
    invoke-direct {v1, v2, v3}, Lalqg;-><init>(Ljava/lang/String;[B)V

    .line 19
    const/4 v2, 0x5

    .line 20
    invoke-static {p0, v2, v0, v1}, Laloe;->a(IILjava/util/concurrent/TimeUnit;Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ThreadPoolExecutor;

    .line 23
    move-result-object p0

    .line 24
    new-instance v0, Ladxg;

    .line 26
    invoke-direct {v0, p0}, Ladxg;-><init>(Ljava/util/concurrent/Executor;)V

    .line 29
    return-object v0
.end method
