.class public final Lachf;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    new-instance p0, Lalnh;

    .line 3
    invoke-direct {p0}, Lalnh;-><init>()V

    .line 6
    return-object p0
.end method
