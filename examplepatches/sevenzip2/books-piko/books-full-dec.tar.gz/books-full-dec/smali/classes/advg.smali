.class public final Ladvg;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Laduz;


# virtual methods
.method public final a(Landroid/view/View;Laduy;Lbhtu;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p2

    .line 3
    new-instance v1, Lbief;

    .line 5
    invoke-static/range {p3 .. p3}, Lbhuh;->c(Lbhtu;)Lbhtu;

    .line 8
    move-result-object v2

    .line 9
    const/4 v3, 0x1

    .line 10
    invoke-direct {v1, v2, v3}, Lbief;-><init>(Lbhtu;I)V

    .line 13
    invoke-virtual {v1}, Lbief;->B()V

    .line 16
    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 19
    move-result-object v2

    .line 20
    new-instance v4, Landroid/view/ContextThemeWrapper;

    .line 22
    const v5, 0x7f140722

    .line 25
    invoke-direct {v4, v2, v5}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    .line 28
    new-instance v2, Ladvx;

    .line 30
    iget-object v5, v0, Laduy;->a:Ljava/lang/String;

    .line 32
    invoke-direct {v2, v4, v5}, Ladvx;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 35
    iget v0, v0, Laduy;->b:I

    .line 37
    add-int/lit8 v0, v0, -0x1

    .line 39
    sget-object v4, Laygr;->a:Laygr;

    .line 41
    if-eqz v0, :cond_0

    .line 43
    const/4 v0, 0x2

    .line 44
    goto :goto_0

    .line 45
    :cond_0
    move v0, v3

    .line 46
    :goto_0
    invoke-virtual {v2}, Ladvx;->getBackgroundColor()I

    .line 49
    move-result v5

    .line 50
    new-instance v6, Ljava/lang/Integer;

    .line 52
    invoke-direct {v6, v5}, Ljava/lang/Integer;-><init>(I)V

    .line 55
    new-instance v5, Layin;

    .line 57
    invoke-direct {v5, v6}, Layin;-><init>(Ljava/lang/Object;)V

    .line 60
    new-instance v6, Ladvj;

    .line 62
    invoke-direct {v6, v5, v4, v2, v0}, Ladvj;-><init>(Layhy;Layhy;Landroid/view/View;I)V

    .line 65
    new-instance v0, Ladve;

    .line 67
    move-object/from16 v4, p1

    .line 69
    invoke-direct {v0, v4}, Ladve;-><init>(Landroid/view/View;)V

    .line 72
    new-instance v4, Ladvm;

    .line 74
    new-instance v5, Ladvf;

    .line 76
    invoke-direct {v5, v1}, Ladvf;-><init>(Lbied;)V

    .line 79
    invoke-direct {v4, v0, v6, v5}, Ladvm;-><init>(Ladve;Ladvn;Landroid/widget/PopupWindow$OnDismissListener;)V

    .line 82
    new-instance v0, Ladva;

    .line 84
    invoke-direct {v0, v4}, Ladva;-><init>(Ladvm;)V

    .line 87
    invoke-virtual {v2, v0}, Ladvx;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 90
    new-instance v0, Ladvb;

    .line 92
    invoke-direct {v0, v4}, Ladvb;-><init>(Ladvm;)V

    .line 95
    invoke-virtual {v2, v0}, Ladvx;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 98
    const v0, 0x7f0a0262

    .line 101
    invoke-virtual {v2, v0}, Ladvx;->findViewById(I)Landroid/view/View;

    .line 104
    move-result-object v0

    .line 105
    check-cast v0, Landroid/widget/Button;

    .line 107
    new-instance v2, Ladvc;

    .line 109
    invoke-direct {v2, v4}, Ladvc;-><init>(Ladvm;)V

    .line 112
    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 115
    iget-object v0, v4, Ladvm;->b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 117
    if-eqz v0, :cond_1

    .line 119
    iget-object v0, v4, Ladvm;->c:Ladve;

    .line 121
    new-instance v2, Ladvk;

    .line 123
    invoke-direct {v2, v4}, Ladvk;-><init>(Ladvm;)V

    .line 126
    new-instance v5, Ladvw;

    .line 128
    iget-object v0, v0, Ladve;->a:Landroid/view/View;

    .line 130
    invoke-direct {v5, v0, v2}, Ladvw;-><init>(Landroid/view/View;Ladvk;)V

    .line 133
    iget-object v0, v4, Ladvm;->b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 135
    new-instance v2, Ladvl;

    .line 137
    invoke-direct {v2, v4, v5}, Ladvl;-><init>(Ladvm;Ladvw;)V

    .line 140
    iget-object v0, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->b:Ladvu;

    .line 142
    invoke-virtual {v0, v2}, Ladvu;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    .line 145
    iget-object v0, v4, Ladvm;->b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 147
    iget-object v2, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->i:Ladve;

    .line 149
    new-instance v5, Landroid/graphics/Rect;

    .line 151
    invoke-direct {v5}, Landroid/graphics/Rect;-><init>()V

    .line 154
    iget-object v2, v2, Ladve;->a:Landroid/view/View;

    .line 156
    invoke-virtual {v2, v5}, Landroid/view/View;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    .line 159
    invoke-virtual {v0, v5}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->c(Landroid/graphics/Rect;)V

    .line 162
    iget-object v5, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->a:Landroid/view/ViewGroup;

    .line 164
    iget-object v6, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->h:Ladvo;

    .line 166
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 169
    iget-object v5, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->b:Ladvu;

    .line 171
    const/4 v6, 0x0

    .line 172
    invoke-virtual {v5, v6}, Ladvu;->setClippingEnabled(Z)V

    .line 175
    invoke-virtual {v5, v6}, Ladvu;->setAnimationStyle(I)V

    .line 178
    invoke-virtual {v5, v3}, Ladvu;->setTouchable(Z)V

    .line 181
    invoke-virtual {v5, v3}, Ladvu;->setFocusable(Z)V

    .line 184
    new-instance v3, Landroid/graphics/drawable/ColorDrawable;

    .line 186
    invoke-direct {v3, v6}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    .line 189
    invoke-virtual {v5, v3}, Ladvu;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 192
    const/4 v3, -0x2

    .line 193
    invoke-virtual {v0, v3, v3}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->measure(II)V

    .line 196
    invoke-virtual {v0}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->e()V

    .line 199
    iget-object v3, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->c:Landroid/view/View;

    .line 201
    const/4 v7, 0x0

    .line 202
    invoke-virtual {v3, v7}, Landroid/view/View;->setAlpha(F)V

    .line 205
    invoke-virtual {v0, v7}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->setBubbleWidthScale(F)V

    .line 208
    invoke-virtual {v0}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->getContext()Landroid/content/Context;

    .line 211
    move-result-object v3

    .line 212
    const v7, 0x7f020006

    .line 215
    invoke-static {v3, v7}, Landroid/animation/AnimatorInflater;->loadAnimator(Landroid/content/Context;I)Landroid/animation/Animator;

    .line 218
    move-result-object v3

    .line 219
    invoke-virtual {v3, v0}, Landroid/animation/Animator;->setTarget(Ljava/lang/Object;)V

    .line 222
    invoke-virtual {v3}, Landroid/animation/Animator;->start()V

    .line 225
    invoke-virtual {v0}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->getContext()Landroid/content/Context;

    .line 228
    move-result-object v3

    .line 229
    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 232
    move-result-object v3

    .line 233
    new-instance v7, Landroid/view/animation/ScaleAnimation;

    .line 235
    iget v8, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->f:I

    .line 237
    iget v9, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->d:I

    .line 239
    sub-int/2addr v8, v9

    .line 240
    iget v9, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->g:I

    .line 242
    iget v10, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->e:I

    .line 244
    sub-int/2addr v9, v10

    .line 245
    int-to-float v12, v8

    .line 246
    int-to-float v13, v9

    .line 247
    const v8, 0x3f547ae1

    .line 250
    const v9, 0x3f866666

    .line 253
    move v10, v8

    .line 254
    move v11, v9

    .line 255
    invoke-direct/range {v7 .. v13}, Landroid/view/animation/ScaleAnimation;-><init>(FFFFFF)V

    .line 258
    const v8, 0x7f0b0027

    .line 261
    invoke-virtual {v3, v8}, Landroid/content/res/Resources;->getInteger(I)I

    .line 264
    move-result v9

    .line 265
    int-to-long v9, v9

    .line 266
    invoke-virtual {v7, v9, v10}, Landroid/view/animation/ScaleAnimation;->setDuration(J)V

    .line 269
    sget-object v9, Laphg;->a:Landroid/view/animation/Interpolator;

    .line 271
    invoke-virtual {v7, v9}, Landroid/view/animation/ScaleAnimation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 274
    new-instance v10, Landroid/view/animation/ScaleAnimation;

    .line 276
    iget v9, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->f:I

    .line 278
    iget v11, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->d:I

    .line 280
    sub-int/2addr v9, v11

    .line 281
    iget v11, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->g:I

    .line 283
    iget v12, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->e:I

    .line 285
    sub-int/2addr v11, v12

    .line 286
    int-to-float v15, v9

    .line 287
    int-to-float v9, v11

    .line 288
    const v11, 0x3f866666

    .line 291
    const/high16 v12, 0x3f800000

    .line 293
    const/high16 v14, 0x3f800000

    .line 295
    move v13, v11

    .line 296
    move/from16 v16, v9

    .line 298
    invoke-direct/range {v10 .. v16}, Landroid/view/animation/ScaleAnimation;-><init>(FFFFFF)V

    .line 301
    invoke-virtual {v3, v8}, Landroid/content/res/Resources;->getInteger(I)I

    .line 304
    move-result v3

    .line 305
    int-to-long v8, v3

    .line 306
    invoke-virtual {v10, v8, v9}, Landroid/view/animation/ScaleAnimation;->setDuration(J)V

    .line 309
    sget-object v3, Laphg;->b:Landroid/view/animation/Interpolator;

    .line 311
    invoke-virtual {v10, v3}, Landroid/view/animation/ScaleAnimation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 314
    new-instance v3, Ladvr;

    .line 316
    invoke-direct {v3, v0}, Ladvr;-><init>(Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;)V

    .line 319
    invoke-virtual {v10, v3}, Landroid/view/animation/ScaleAnimation;->setAnimationListener(Landroid/view/animation/Animation$AnimationListener;)V

    .line 322
    new-instance v3, Ladvs;

    .line 324
    invoke-direct {v3, v0, v10}, Ladvs;-><init>(Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;Landroid/view/animation/ScaleAnimation;)V

    .line 327
    invoke-virtual {v7, v3}, Landroid/view/animation/ScaleAnimation;->setAnimationListener(Landroid/view/animation/Animation$AnimationListener;)V

    .line 330
    invoke-virtual {v0, v7}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->setAnimation(Landroid/view/animation/Animation;)V

    .line 333
    invoke-virtual {v0, v6}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->setClipChildren(Z)V

    .line 336
    invoke-virtual {v0}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->f()Z

    .line 339
    move-result v3

    .line 340
    if-nez v3, :cond_1

    .line 342
    iget v3, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->d:I

    .line 344
    iget v0, v0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->e:I

    .line 346
    invoke-virtual {v5, v2, v6, v3, v0}, Ladvu;->showAtLocation(Landroid/view/View;III)V

    .line 349
    :cond_1
    new-instance v0, Ladvd;

    .line 351
    invoke-direct {v0, v4}, Ladvd;-><init>(Ladvm;)V

    .line 354
    invoke-interface {v1, v0}, Lbied;->d(Lbhwq;)V

    .line 357
    invoke-virtual {v1}, Lbief;->m()Ljava/lang/Object;

    .line 360
    move-result-object v0

    .line 361
    sget-object v1, Lbhug;->a:Lbhug;

    .line 363
    if-ne v0, v1, :cond_2

    .line 365
    return-object v0

    .line 366
    :cond_2
    sget-object v0, Lbhqc;->a:Lbhqc;

    .line 368
    return-object v0
.end method
