.class public interface abstract Ljfp;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract e(Ljkb;)V
.end method

.method public abstract g(Ljkb;)V
.end method
