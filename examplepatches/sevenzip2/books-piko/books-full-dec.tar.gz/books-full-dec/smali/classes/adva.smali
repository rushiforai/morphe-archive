.class final Ladva;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field final synthetic a:Ladvm;


# direct methods
.method public constructor <init>(Ladvm;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ladva;->a:Ladvm;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 0

    .line 1
    iget-object p0, p0, Ladva;->a:Ladvm;

    .line 3
    invoke-virtual {p0}, Ladvm;->a()V

    .line 6
    return-void
.end method
