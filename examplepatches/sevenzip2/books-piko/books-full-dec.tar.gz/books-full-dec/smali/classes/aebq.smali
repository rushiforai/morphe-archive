.class public final Laebq;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field private final a:Landroid/accounts/Account;

.field private final b:Lakwr;

.field private final c:Lalog;

.field private final d:Loxu;


# direct methods
.method public constructor <init>(Landroid/accounts/Account;Lakwr;Loxu;Lalog;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laebq;->a:Landroid/accounts/Account;

    .line 6
    iput-object p2, p0, Laebq;->b:Lakwr;

    .line 8
    iput-object p3, p0, Laebq;->d:Loxu;

    .line 10
    iput-object p4, p0, Laebq;->c:Lalog;

    .line 12
    return-void
.end method

.method private final c(Ljava/lang/String;Landroid/app/Activity;)Lcom/google/android/gms/googlehelp/GoogleHelp;
    .locals 57

    .line 1
    move-object/from16 v0, p2

    .line 3
    new-instance v1, Landroid/content/Intent;

    .line 5
    invoke-static {}, Lahjj;->g()Landroid/net/Uri;

    .line 8
    move-result-object v2

    .line 9
    const-string v3, "android.intent.action.VIEW"

    .line 11
    invoke-direct {v1, v3, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 14
    new-instance v2, Landroid/content/Intent;

    .line 16
    const-string v4, "https://support.google.com/mobile/?p=market_privacy"

    .line 18
    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 21
    move-result-object v4

    .line 22
    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 25
    const-class v3, Lcom/google/android/libraries/social/licenses/LicenseMenuActivity;

    .line 27
    new-instance v4, Landroid/content/Intent;

    .line 29
    invoke-direct {v4, v0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 32
    const-class v3, Lcom/google/android/apps/play/books/help/CopyVersionActivity;

    .line 34
    new-instance v5, Landroid/content/Intent;

    .line 36
    invoke-direct {v5, v0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 39
    new-instance v6, Landroid/os/Bundle;

    .line 41
    invoke-direct {v6}, Landroid/os/Bundle;-><init>()V

    .line 44
    invoke-static {v0}, Lakwi;->a(Landroid/content/Context;)Landroid/content/pm/PackageInfo;

    .line 47
    move-result-object v7

    .line 48
    const-string v8, "????"

    .line 50
    if-nez v7, :cond_0

    .line 52
    move-object v7, v8

    .line 53
    goto :goto_0

    .line 54
    :cond_0
    iget-object v7, v7, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    .line 56
    :goto_0
    const/4 v9, 0x1

    .line 57
    new-array v10, v9, [Ljava/lang/Object;

    .line 59
    const/4 v11, 0x0

    .line 60
    aput-object v7, v10, v11

    .line 62
    const v7, 0x7f130795

    .line 65
    invoke-virtual {v0, v7, v10}, Landroid/app/Activity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 68
    move-result-object v7

    .line 69
    const-string v10, "android.intent.extra.books.VERSION"

    .line 71
    invoke-virtual {v6, v10, v7}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 74
    invoke-virtual {v5, v6}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    .line 77
    invoke-virtual {v0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    .line 80
    move-result-object v6

    .line 81
    new-instance v12, Lcom/google/android/gms/googlehelp/GoogleHelp;

    .line 83
    new-instance v22, Ljava/util/ArrayList;

    .line 85
    invoke-direct/range {v22 .. v22}, Ljava/util/ArrayList;-><init>()V

    .line 88
    new-instance v30, Ljava/util/ArrayList;

    .line 90
    invoke-direct/range {v30 .. v30}, Ljava/util/ArrayList;-><init>()V

    .line 93
    new-instance v33, Ljava/util/ArrayList;

    .line 95
    invoke-direct/range {v33 .. v33}, Ljava/util/ArrayList;-><init>()V

    .line 98
    new-instance v35, Lcom/google/android/gms/feedback/ErrorReport;

    .line 100
    invoke-direct/range {v35 .. v35}, Lcom/google/android/gms/feedback/ErrorReport;-><init>()V

    .line 103
    new-instance v49, Ljava/util/ArrayList;

    .line 105
    invoke-direct/range {v49 .. v49}, Ljava/util/ArrayList;-><init>()V

    .line 108
    new-instance v53, Ljava/util/ArrayList;

    .line 110
    invoke-direct/range {v53 .. v53}, Ljava/util/ArrayList;-><init>()V

    .line 113
    new-instance v56, Ljava/util/ArrayList;

    .line 115
    invoke-direct/range {v56 .. v56}, Ljava/util/ArrayList;-><init>()V

    .line 118
    const/16 v13, 0x17

    .line 120
    const/4 v15, 0x0

    .line 121
    const/16 v16, 0x0

    .line 123
    const/16 v17, 0x0

    .line 125
    const/16 v18, 0x0

    .line 127
    const/16 v19, 0x0

    .line 129
    const/16 v20, 0x1

    .line 131
    const/16 v21, 0x1

    .line 133
    const/16 v23, 0x0

    .line 135
    const/16 v24, 0x0

    .line 137
    const/16 v25, 0x0

    .line 139
    const/16 v26, 0x0

    .line 141
    const/16 v27, 0x0

    .line 143
    const/16 v28, 0x0

    .line 145
    const/16 v29, 0x0

    .line 147
    const/16 v31, 0x3

    .line 149
    const/16 v32, 0x0

    .line 151
    const/16 v34, 0x0

    .line 153
    const/16 v36, 0x0

    .line 155
    const/16 v37, 0x0

    .line 157
    const/16 v38, 0x0

    .line 159
    const/16 v39, -0x1

    .line 161
    const/16 v40, 0x0

    .line 163
    const/16 v41, 0x0

    .line 165
    const/16 v42, 0xc8

    .line 167
    const/16 v43, 0x0

    .line 169
    const/16 v44, 0x0

    .line 171
    const/16 v45, 0x0

    .line 173
    const/16 v46, 0x0

    .line 175
    const/16 v47, 0x0

    .line 177
    const/16 v48, 0x0

    .line 179
    const/16 v50, 0x0

    .line 181
    const/16 v51, 0x0

    .line 183
    const/16 v52, 0x0

    .line 185
    const/16 v54, 0x0

    .line 187
    const/16 v55, 0x0

    .line 189
    move-object/from16 v14, p1

    .line 191
    invoke-direct/range {v12 .. v56}, Lcom/google/android/gms/googlehelp/GoogleHelp;-><init>(ILjava/lang/String;Landroid/accounts/Account;Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/String;Landroid/graphics/Bitmap;ZZLjava/util/List;Landroid/os/Bundle;Landroid/graphics/Bitmap;[BIILjava/lang/String;Landroid/net/Uri;Ljava/util/List;ILcom/google/android/gms/feedback/ThemeSettings;Ljava/util/List;ZLcom/google/android/gms/feedback/ErrorReport;Lcom/google/android/gms/googlehelp/internal/common/TogglingData;ILandroid/app/PendingIntent;IZZILjava/lang/String;ZLjava/lang/String;ZLcom/google/android/gms/googlehelp/ND4CSettings;ZLjava/util/List;Ljava/lang/String;IILjava/util/List;Ljava/lang/String;Landroid/content/Intent;Ljava/util/List;)V

    .line 194
    const v13, 0x7f13072a

    .line 197
    invoke-virtual {v6, v13}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 200
    move-result-object v13

    .line 201
    invoke-virtual {v12, v11, v13, v1}, Lcom/google/android/gms/googlehelp/GoogleHelp;->b(ILjava/lang/String;Landroid/content/Intent;)V

    .line 204
    const v1, 0x7f1305c1

    .line 207
    invoke-virtual {v6, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 210
    move-result-object v1

    .line 211
    invoke-virtual {v12, v9, v1, v2}, Lcom/google/android/gms/googlehelp/GoogleHelp;->b(ILjava/lang/String;Landroid/content/Intent;)V

    .line 214
    const v1, 0x7f13026b

    .line 217
    invoke-virtual {v6, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 220
    move-result-object v1

    .line 221
    const/4 v2, 0x2

    .line 222
    invoke-virtual {v12, v2, v1, v4}, Lcom/google/android/gms/googlehelp/GoogleHelp;->b(ILjava/lang/String;Landroid/content/Intent;)V

    .line 225
    const/4 v1, 0x3

    .line 226
    invoke-virtual {v12, v1, v7, v5}, Lcom/google/android/gms/googlehelp/GoogleHelp;->b(ILjava/lang/String;Landroid/content/Intent;)V

    .line 229
    move-object/from16 v4, p0

    .line 231
    iget-object v4, v4, Laebq;->a:Landroid/accounts/Account;

    .line 233
    iput-object v4, v12, Lcom/google/android/gms/googlehelp/GoogleHelp;->c:Landroid/accounts/Account;

    .line 235
    new-instance v4, Lcom/google/android/gms/feedback/ThemeSettings;

    .line 237
    invoke-direct {v4, v1, v11}, Lcom/google/android/gms/feedback/ThemeSettings;-><init>(II)V

    .line 240
    invoke-static {}, Lakxa;->f()Z

    .line 243
    move-result v5

    .line 244
    if-eqz v5, :cond_1

    .line 246
    move v2, v1

    .line 247
    goto :goto_1

    .line 248
    :cond_1
    invoke-virtual {v0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    .line 251
    move-result-object v1

    .line 252
    const v5, 0x7f050019

    .line 255
    invoke-virtual {v1, v5}, Landroid/content/res/Resources;->getBoolean(I)Z

    .line 258
    move-result v1

    .line 259
    if-eqz v1, :cond_2

    .line 261
    goto :goto_1

    .line 262
    :cond_2
    move v2, v11

    .line 263
    :goto_1
    iput v2, v4, Lcom/google/android/gms/feedback/ThemeSettings;->a:I

    .line 265
    iput-object v4, v12, Lcom/google/android/gms/googlehelp/GoogleHelp;->s:Lcom/google/android/gms/feedback/ThemeSettings;

    .line 267
    const-string v1, "https://support.google.com/mobile/?p=books_androidapp"

    .line 269
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 272
    move-result-object v1

    .line 273
    iput-object v1, v12, Lcom/google/android/gms/googlehelp/GoogleHelp;->q:Landroid/net/Uri;

    .line 275
    invoke-static {v0}, Laltj;->c(Landroid/content/Context;)Ljava/lang/String;

    .line 278
    move-result-object v1

    .line 279
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 282
    move-result v2

    .line 283
    if-ne v9, v2, :cond_3

    .line 285
    goto :goto_2

    .line 286
    :cond_3
    move-object v8, v1

    .line 287
    :goto_2
    new-array v1, v9, [Ljava/lang/Object;

    .line 289
    aput-object v8, v1, v11

    .line 291
    const v2, 0x7f1307a2

    .line 294
    invoke-virtual {v0, v2, v1}, Landroid/app/Activity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 297
    move-result-object v1

    .line 298
    new-instance v2, Landroid/os/Bundle;

    .line 300
    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    .line 303
    invoke-virtual {v2, v10, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 306
    new-instance v4, Landroid/content/Intent;

    .line 308
    invoke-direct {v4, v0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 311
    invoke-virtual {v4, v2}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    .line 314
    const/4 v0, 0x4

    .line 315
    invoke-virtual {v12, v0, v1, v4}, Lcom/google/android/gms/googlehelp/GoogleHelp;->b(ILjava/lang/String;Landroid/content/Intent;)V

    .line 318
    return-object v12
.end method


# virtual methods
.method public final a(Ljava/lang/String;Landroid/app/Activity;Ljava/lang/String;Lanrj;)V
    .locals 8

    .line 1
    if-nez p4, :cond_0

    .line 3
    new-instance p4, Lanrj;

    .line 5
    invoke-virtual {p2}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    .line 8
    move-result-object v0

    .line 9
    invoke-direct {p4, v0}, Lanrj;-><init>(Landroid/content/Context;)V

    .line 12
    :cond_0
    invoke-direct {p0, p1, p2}, Laebq;->c(Ljava/lang/String;Landroid/app/Activity;)Lcom/google/android/gms/googlehelp/GoogleHelp;

    .line 15
    move-result-object v1

    .line 16
    invoke-virtual {p4}, Lanrj;->a()Lcom/google/android/gms/feedback/FeedbackOptions;

    .line 19
    move-result-object p0

    .line 20
    invoke-virtual {p2}, Landroid/app/Activity;->getCacheDir()Ljava/io/File;

    .line 23
    move-result-object p1

    .line 24
    invoke-virtual {v1, p0, p1}, Lcom/google/android/gms/googlehelp/GoogleHelp;->c(Lcom/google/android/gms/feedback/FeedbackOptions;Ljava/io/File;)V

    .line 27
    new-instance v0, Lcom/google/android/gms/googlehelp/InProductHelp;

    .line 29
    const/4 v6, 0x0

    .line 30
    const/4 v7, 0x0

    .line 31
    const/4 v2, 0x0

    .line 32
    const/4 v3, 0x0

    .line 33
    const/4 v4, 0x0

    .line 34
    const/4 v5, 0x0

    .line 35
    invoke-direct/range {v0 .. v7}, Lcom/google/android/gms/googlehelp/InProductHelp;-><init>(Lcom/google/android/gms/googlehelp/GoogleHelp;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;)V

    .line 38
    iput-object p3, v0, Lcom/google/android/gms/googlehelp/InProductHelp;->c:Ljava/lang/String;

    .line 40
    new-instance p0, Lansg;

    .line 42
    invoke-direct {p0, p2}, Lansg;-><init>(Landroid/app/Activity;)V

    .line 45
    iget-object p1, v0, Lcom/google/android/gms/googlehelp/InProductHelp;->c:Ljava/lang/String;

    .line 47
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 50
    move-result p1

    .line 51
    if-nez p1, :cond_2

    .line 53
    invoke-virtual {p0}, Lansg;->a()I

    .line 56
    move-result p1

    .line 57
    if-nez p1, :cond_1

    .line 59
    iget-object p0, p0, Lansg;->b:Layje;

    .line 61
    invoke-interface {p0}, Layje;->fJ()Ljava/lang/Object;

    .line 64
    move-result-object p0

    .line 65
    check-cast p0, Lantb;

    .line 67
    invoke-virtual {p0, v0}, Lantb;->b(Lcom/google/android/gms/googlehelp/InProductHelp;)V

    .line 70
    return-void

    .line 71
    :cond_1
    iget-object p2, v0, Lcom/google/android/gms/googlehelp/InProductHelp;->a:Lcom/google/android/gms/googlehelp/GoogleHelp;

    .line 73
    invoke-virtual {p0, p1, p2}, Lansg;->b(ILcom/google/android/gms/googlehelp/GoogleHelp;)V

    .line 76
    return-void

    .line 77
    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 79
    const-string p1, "The content URL must be non-empty."

    .line 81
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 84
    throw p0
.end method

.method public final b(Ljava/lang/String;Landroid/app/Activity;ZLanrj;)V
    .locals 6

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-static {}, Lakxa;->e()Z

    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_0

    .line 10
    goto/16 :goto_1

    .line 12
    :cond_0
    const-string v0, "usagestats"

    .line 14
    invoke-virtual {p2, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Landroid/app/usage/UsageStatsManager;

    .line 20
    const-string v1, "logStatus"

    .line 22
    const-string v2, "com/google/android/apps/play/books/util/BackgroundRestrictions"

    .line 24
    const-string v3, "BackgroundRestrictions.kt"

    .line 26
    if-eqz v0, :cond_5

    .line 28
    invoke-static {v0}, Laag$$ExternalSyntheticApiModelOutline0;->m(Landroid/app/usage/UsageStatsManager;)I

    .line 31
    move-result v4

    .line 32
    invoke-static {v0}, Laag$$ExternalSyntheticApiModelOutline0;->m(Landroid/app/usage/UsageStatsManager;)I

    .line 35
    move-result v0

    .line 36
    const/16 v5, 0xa

    .line 38
    if-eq v0, v5, :cond_4

    .line 40
    const/16 v5, 0x14

    .line 42
    if-eq v0, v5, :cond_4

    .line 44
    const/16 v4, 0x1e

    .line 46
    if-eq v0, v4, :cond_3

    .line 48
    const/16 v5, 0x28

    .line 50
    if-eq v0, v5, :cond_2

    .line 52
    const/16 v4, 0x2d

    .line 54
    if-eq v0, v4, :cond_1

    .line 56
    goto :goto_0

    .line 57
    :cond_1
    sget-object v0, Lalmm;->a:Layxl;

    .line 59
    invoke-virtual {v0}, Layxb;->d()Layxz;

    .line 62
    move-result-object v0

    .line 63
    const/16 v4, 0x22

    .line 65
    invoke-interface {v0, v2, v1, v4, v3}, Layxz;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Layxi;

    .line 71
    const-string v4, "Books appStandbyBucket = STANDBY_BUCKET_RESTRICTED"

    .line 73
    invoke-interface {v0, v4}, Layxi;->s(Ljava/lang/String;)V

    .line 76
    goto :goto_0

    .line 77
    :cond_2
    sget-object v0, Lalmm;->a:Layxl;

    .line 79
    invoke-virtual {v0}, Layxb;->d()Layxz;

    .line 82
    move-result-object v0

    .line 83
    invoke-interface {v0, v2, v1, v4, v3}, Layxz;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 86
    move-result-object v0

    .line 87
    check-cast v0, Layxi;

    .line 89
    const-string v4, "Books appStandbyBucket = STANDBY_BUCKET_FREQUENT"

    .line 91
    invoke-interface {v0, v4}, Layxi;->s(Ljava/lang/String;)V

    .line 94
    goto :goto_0

    .line 95
    :cond_3
    sget-object v0, Lalmm;->a:Layxl;

    .line 97
    invoke-virtual {v0}, Layxb;->d()Layxz;

    .line 100
    move-result-object v0

    .line 101
    const/16 v4, 0x20

    .line 103
    invoke-interface {v0, v2, v1, v4, v3}, Layxz;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 106
    move-result-object v0

    .line 107
    check-cast v0, Layxi;

    .line 109
    const-string v4, "Books appStandbyBucket = STANDBY_BUCKET_RARE"

    .line 111
    invoke-interface {v0, v4}, Layxi;->s(Ljava/lang/String;)V

    .line 114
    goto :goto_0

    .line 115
    :cond_4
    sget-object v0, Lalmm;->a:Layxl;

    .line 117
    invoke-virtual {v0}, Layxb;->b()Layxz;

    .line 120
    move-result-object v0

    .line 121
    const/16 v5, 0x1c

    .line 123
    invoke-interface {v0, v2, v1, v5, v3}, Layxz;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 126
    move-result-object v0

    .line 127
    check-cast v0, Layxi;

    .line 129
    const-string v5, "Books appStandbyBucket = %s"

    .line 131
    invoke-interface {v0, v5, v4}, Layxi;->t(Ljava/lang/String;I)V

    .line 134
    :cond_5
    :goto_0
    const-string v0, "activity"

    .line 136
    invoke-virtual {p2, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 139
    move-result-object v0

    .line 140
    check-cast v0, Landroid/app/ActivityManager;

    .line 142
    if-eqz v0, :cond_6

    .line 144
    invoke-static {v0}, Laag$$ExternalSyntheticApiModelOutline0;->m(Landroid/app/ActivityManager;)Z

    .line 147
    move-result v0

    .line 148
    if-eqz v0, :cond_6

    .line 150
    sget-object v0, Lalmm;->a:Layxl;

    .line 152
    invoke-virtual {v0}, Layxb;->d()Layxz;

    .line 155
    move-result-object v0

    .line 156
    const/16 v4, 0x29

    .line 158
    invoke-interface {v0, v2, v1, v4, v3}, Layxz;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 161
    move-result-object v0

    .line 162
    check-cast v0, Layxi;

    .line 164
    const-string v1, "Books is background restricted"

    .line 166
    invoke-interface {v0, v1}, Layxi;->s(Ljava/lang/String;)V

    .line 169
    :cond_6
    :goto_1
    if-nez p4, :cond_7

    .line 171
    new-instance p4, Lanrj;

    .line 173
    invoke-virtual {p2}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    .line 176
    move-result-object v0

    .line 177
    invoke-direct {p4, v0}, Lanrj;-><init>(Landroid/content/Context;)V

    .line 180
    :cond_7
    invoke-direct {p0, p1, p2}, Laebq;->c(Ljava/lang/String;Landroid/app/Activity;)Lcom/google/android/gms/googlehelp/GoogleHelp;

    .line 183
    move-result-object p1

    .line 184
    sget-object v0, Lbfqr;->a:Lbfqr;

    .line 186
    invoke-virtual {v0}, Lbfqr;->b()Lbfqs;

    .line 189
    move-result-object v0

    .line 190
    invoke-interface {v0}, Lbfqs;->a()Z

    .line 193
    move-result v0

    .line 194
    if-eqz v0, :cond_8

    .line 196
    iget-object v0, p0, Laebq;->d:Loxu;

    .line 198
    iget-object v1, p0, Laebq;->a:Landroid/accounts/Account;

    .line 200
    invoke-virtual {v0, v1}, Loxu;->a(Landroid/accounts/Account;)Z

    .line 203
    move-result v0

    .line 204
    if-eqz v0, :cond_8

    .line 206
    const-string v0, "android_booknotopening_reason"

    .line 208
    const-string v1, "BOOKS_SERVICE_API_ACCESS_DISABLED"

    .line 210
    invoke-virtual {p4, v0, v1}, Lanrj;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 213
    new-instance v0, Lanri;

    .line 215
    invoke-direct {v0, p2}, Lanri;-><init>(Landroid/content/Context;)V

    .line 218
    invoke-virtual {p4}, Lanrj;->a()Lcom/google/android/gms/feedback/FeedbackOptions;

    .line 221
    move-result-object v1

    .line 222
    invoke-virtual {v0, v1}, Lanri;->c(Lcom/google/android/gms/feedback/FeedbackOptions;)V

    .line 225
    goto :goto_2

    .line 226
    :cond_8
    iget-object v0, p0, Laebq;->c:Lalog;

    .line 228
    invoke-virtual {v0, p4}, Lalog;->a(Lanrj;)V

    .line 231
    :goto_2
    if-nez p3, :cond_9

    .line 233
    invoke-virtual {p4}, Lanrj;->a()Lcom/google/android/gms/feedback/FeedbackOptions;

    .line 236
    move-result-object p0

    .line 237
    invoke-virtual {p2}, Landroid/app/Activity;->getCacheDir()Ljava/io/File;

    .line 240
    move-result-object p3

    .line 241
    invoke-virtual {p1, p0, p3}, Lcom/google/android/gms/googlehelp/GoogleHelp;->c(Lcom/google/android/gms/feedback/FeedbackOptions;Ljava/io/File;)V

    .line 244
    invoke-virtual {p1}, Lcom/google/android/gms/googlehelp/GoogleHelp;->a()Landroid/content/Intent;

    .line 247
    move-result-object p0

    .line 248
    new-instance p1, Lansg;

    .line 250
    invoke-direct {p1, p2}, Lansg;-><init>(Landroid/app/Activity;)V

    .line 253
    invoke-virtual {p1, p0}, Lansg;->c(Landroid/content/Intent;)V

    .line 256
    return-void

    .line 257
    :cond_9
    iget-object p0, p0, Laebq;->b:Lakwr;

    .line 259
    new-instance p3, Laebp;

    .line 261
    invoke-direct {p3, p2, p4, p1}, Laebp;-><init>(Landroid/app/Activity;Lanrj;Lcom/google/android/gms/googlehelp/GoogleHelp;)V

    .line 264
    invoke-virtual {p0, p2, p3}, Lakwr;->b(Landroid/app/Activity;Lakuc;)V

    .line 267
    return-void
.end method
