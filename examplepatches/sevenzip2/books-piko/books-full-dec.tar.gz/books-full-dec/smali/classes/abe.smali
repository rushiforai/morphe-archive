.class public final Labe;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lkcj;


# instance fields
.field final synthetic a:Labl;


# direct methods
.method public constructor <init>(Labl;)V
    .locals 0

    .line 1
    iput-object p1, p0, Labe;->a:Labl;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public final a(Lkcm;Lkby;)V
    .locals 0

    .line 1
    iget-object p1, p0, Labe;->a:Labl;

    .line 3
    invoke-virtual {p1}, Labl;->s()V

    .line 6
    iget-object p1, p1, Lgz;->f:Lkct;

    .line 8
    invoke-virtual {p1, p0}, Lkcb;->d(Lkcl;)V

    .line 11
    return-void
.end method
