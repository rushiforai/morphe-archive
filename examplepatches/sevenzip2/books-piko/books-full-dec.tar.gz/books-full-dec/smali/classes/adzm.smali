.class final Ladzm;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbilc;


# instance fields
.field final synthetic a:Ladzn;

.field final synthetic b:Ljava/lang/Object;

.field final synthetic c:Ldw;


# direct methods
.method public constructor <init>(Ladzn;Ljava/lang/Object;Ldw;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ladzm;->a:Ladzn;

    .line 3
    iput-object p2, p0, Ladzm;->b:Ljava/lang/Object;

    .line 5
    iput-object p3, p0, Ladzm;->c:Ldw;

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Lbhtu;)Ljava/lang/Object;
    .locals 3

    .line 1
    check-cast p1, Lbhqc;

    .line 3
    new-instance p1, Ljava/util/ArrayList;

    .line 5
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 8
    iget-object p2, p0, Ladzm;->a:Ladzn;

    .line 10
    iget-object p2, p2, Ladzn;->a:Ljava/util/List;

    .line 12
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 15
    move-result-object p2

    .line 16
    :cond_0
    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_1

    .line 22
    iget-object v0, p0, Ladzm;->b:Ljava/lang/Object;

    .line 24
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 27
    move-result-object v1

    .line 28
    check-cast v1, Ladzk;

    .line 30
    iget-object v2, v1, Ladzk;->a:Ljava/util/List;

    .line 32
    invoke-interface {v2, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_0

    .line 38
    invoke-interface {p2}, Ljava/util/Iterator;->remove()V

    .line 41
    invoke-interface {p1, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 44
    goto :goto_0

    .line 45
    :cond_1
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 48
    move-result-object p1

    .line 49
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 52
    move-result p2

    .line 53
    if-eqz p2, :cond_2

    .line 55
    iget-object p2, p0, Ladzm;->c:Ldw;

    .line 57
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 60
    move-result-object v0

    .line 61
    check-cast v0, Ladzk;

    .line 63
    iget-object v0, v0, Ladzk;->b:Lbhwq;

    .line 65
    invoke-interface {v0, p2}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    goto :goto_1

    .line 69
    :cond_2
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 71
    return-object p0
.end method
