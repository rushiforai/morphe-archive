.class public final Laavz;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# virtual methods
.method public final synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    new-instance p0, Laavx;

    .line 3
    invoke-direct {p0}, Laavx;-><init>()V

    .line 6
    return-object p0
.end method
