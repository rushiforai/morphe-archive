.class public final Laaxu;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laaxu;->a:Lbeye;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()Lalyv;
    .locals 2

    .line 1
    iget-object p0, p0, Laaxu;->a:Lbeye;

    .line 3
    check-cast p0, Laaxs;

    .line 5
    invoke-virtual {p0}, Laaxs;->a()Laazu;

    .line 8
    move-result-object p0

    .line 9
    new-instance v0, Laaxo;

    .line 11
    invoke-direct {v0, p0}, Laaxo;-><init>(Laazu;)V

    .line 14
    new-instance p0, Lalyv;

    .line 16
    const-class v1, Labae;

    .line 18
    invoke-direct {p0, v1, v0}, Lalyv;-><init>(Ljava/lang/Class;Lbhwq;)V

    .line 21
    return-object p0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Laaxu;->a()Lalyv;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
