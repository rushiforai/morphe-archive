.class public final Lady;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Ladu;

.field public final b:Laeg;


# direct methods
.method public constructor <init>(Ladu;Laeg;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lady;->a:Ladu;

    .line 6
    iput-object p2, p0, Lady;->b:Laeg;

    .line 8
    return-void
.end method
