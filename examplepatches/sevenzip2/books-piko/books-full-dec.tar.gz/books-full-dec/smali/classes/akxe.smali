.class public Lakxe;
.super Llw;
.source "PG"


# instance fields
.field public J:Z

.field private final jj:Ljava/util/Map;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 3
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 6
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Llw;-><init>()V

    .line 4
    sget-object v0, Lautq;->a:Lautq;

    .line 6
    invoke-virtual {v0}, Lautq;->b()V

    .line 9
    new-instance v0, Ljava/util/HashMap;

    .line 11
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 14
    iput-object v0, p0, Lakxe;->jj:Ljava/util/Map;

    .line 16
    return-void
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 2

    .line 1
    const v0, 0xb00c

    .line 4
    if-ge p1, v0, :cond_0

    .line 6
    const/4 v0, 0x0

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    iget-object v0, p0, Lakxe;->jj:Ljava/util/Map;

    .line 10
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 13
    move-result-object v1

    .line 14
    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Ljava/lang/ref/Reference;

    .line 20
    :goto_0
    if-nez v0, :cond_1

    .line 22
    invoke-super {p0, p1, p2, p3}, Llw;->onActivityResult(IILandroid/content/Intent;)V

    .line 25
    return-void

    .line 26
    :cond_1
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 29
    move-result-object p2

    .line 30
    check-cast p2, Lakxd;

    .line 32
    if-eqz p2, :cond_2

    .line 34
    invoke-interface {p2}, Lakxd;->a()V

    .line 37
    return-void

    .line 38
    :cond_2
    iget-object p0, p0, Lakxe;->jj:Ljava/util/Map;

    .line 40
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 43
    move-result-object p1

    .line 44
    invoke-interface {p0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Llw;->onCreate(Landroid/os/Bundle;)V

    .line 4
    new-instance p1, Landroid/app/ActivityManager$TaskDescription;

    .line 6
    const/4 v0, 0x0

    .line 7
    const/4 v1, -0x1

    .line 8
    invoke-direct {p1, v0, v0, v1}, Landroid/app/ActivityManager$TaskDescription;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;I)V

    .line 11
    invoke-virtual {p0, p1}, Lakxe;->setTaskDescription(Landroid/app/ActivityManager$TaskDescription;)V

    .line 14
    return-void
.end method

.method protected final onPostResume()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lakxe;->J:Z

    .line 4
    invoke-super {p0}, Llw;->onPostResume()V

    .line 7
    return-void
.end method

.method protected final onStop()V
    .locals 1

    .line 1
    invoke-super {p0}, Llw;->onStop()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lakxe;->J:Z

    .line 7
    return-void
.end method

.method public setContentView(Landroid/view/View;)V
    .locals 2

    .line 1
    new-instance v0, Landroid/view/ViewGroup$LayoutParams;

    .line 3
    const/4 v1, -0x1

    .line 4
    invoke-direct {v0, v1, v1}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 7
    invoke-virtual {p0, p1, v0}, Labl;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 10
    return-void
.end method
