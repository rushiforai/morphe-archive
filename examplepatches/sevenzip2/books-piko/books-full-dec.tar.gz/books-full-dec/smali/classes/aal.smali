.class public final Laal;
.super Ljava/lang/Object;
.source "PG"


# static fields
.field public static final d:Ljke;


# instance fields
.field public a:I

.field public b:Lww;

.field public c:Lww;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ljke;

    .line 3
    const/16 v1, 0x14

    .line 5
    invoke-direct {v0, v1}, Ljke;-><init>(I)V

    .line 8
    sput-object v0, Laal;->d:Ljke;

    .line 10
    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    return-void
.end method

.method public static a()Laal;
    .locals 1

    .line 1
    sget-object v0, Laal;->d:Ljke;

    .line 3
    invoke-virtual {v0}, Ljke;->a()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Laal;

    .line 9
    if-nez v0, :cond_0

    .line 11
    new-instance v0, Laal;

    .line 13
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 16
    :cond_0
    return-object v0
.end method

.method public static b(Laal;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Laal;->a:I

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Laal;->b:Lww;

    .line 7
    iput-object v0, p0, Laal;->c:Lww;

    .line 9
    sget-object v0, Laal;->d:Ljke;

    .line 11
    invoke-virtual {v0, p0}, Ljke;->b(Ljava/lang/Object;)Z

    .line 14
    return-void
.end method
