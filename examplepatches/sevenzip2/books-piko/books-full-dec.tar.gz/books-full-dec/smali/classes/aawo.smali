.class public final Laawo;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laawo;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laawo;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laawo;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laawo;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laawo;->e:Lbeye;

    .line 14
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 7

    .line 1
    iget-object v0, p0, Laawo;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v2

    .line 9
    iget-object v0, p0, Laawo;->b:Lbeye;

    .line 11
    check-cast v0, Labxb;

    .line 13
    invoke-virtual {v0}, Labxb;->a()Labxa;

    .line 16
    move-result-object v3

    .line 17
    iget-object v0, p0, Laawo;->c:Lbeye;

    .line 19
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 22
    move-result-object v0

    .line 23
    move-object v4, v0

    .line 24
    check-cast v4, Laawx;

    .line 26
    iget-object v0, p0, Laawo;->d:Lbeye;

    .line 28
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 31
    move-result-object v0

    .line 32
    move-object v5, v0

    .line 33
    check-cast v5, Lahic;

    .line 35
    iget-object p0, p0, Laawo;->e:Lbeye;

    .line 37
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 40
    move-result-object p0

    .line 41
    move-object v6, p0

    .line 42
    check-cast v6, Lalnn;

    .line 44
    new-instance v1, Laawn;

    .line 46
    invoke-direct/range {v1 .. v6}, Laawn;-><init>(Ldw;Labxa;Laawx;Lahic;Lalnn;)V

    .line 49
    return-object v1
.end method
