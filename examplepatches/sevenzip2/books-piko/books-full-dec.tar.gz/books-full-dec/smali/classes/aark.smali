.class public final Laark;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laark;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laark;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laark;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laark;->d:Lbeye;

    .line 12
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, Laark;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Laark;->b:Lbeye;

    .line 11
    invoke-static {v1}, Lbexu;->a(Lbeye;)Lbexl;

    .line 14
    move-result-object v1

    .line 15
    iget-object v2, p0, Laark;->c:Lbeye;

    .line 17
    check-cast v2, Laame;

    .line 19
    invoke-virtual {v2}, Laame;->a()Laama;

    .line 22
    move-result-object v2

    .line 23
    iget-object p0, p0, Laark;->d:Lbeye;

    .line 25
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 28
    move-result-object p0

    .line 29
    check-cast p0, Laawv;

    .line 31
    new-instance v3, Laarj;

    .line 33
    invoke-direct {v3, v0, v1, v2, p0}, Laarj;-><init>(Ldw;Lbexl;Laama;Laawv;)V

    .line 36
    return-object v3
.end method
