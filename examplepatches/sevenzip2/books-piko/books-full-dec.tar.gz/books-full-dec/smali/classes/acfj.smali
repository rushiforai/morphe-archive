.class final Lacfj;
.super Lmlc;
.source "PG"


# virtual methods
.method protected final a()Ljava/lang/String;
    .locals 0

    .line 1
    const-string p0, "DELETE FROM `pending_copy_quota_updates` WHERE `updateId` = ?"

    .line 3
    return-object p0
.end method

.method protected final bridge synthetic b(Lmrh;Ljava/lang/Object;)V
    .locals 2

    .line 1
    check-cast p2, Lacgl;

    .line 3
    iget p0, p2, Lacgl;->c:I

    .line 5
    int-to-long v0, p0

    .line 6
    const/4 p0, 0x1

    .line 7
    invoke-interface {p1, p0, v0, v1}, Lmrh;->h(IJ)V

    .line 10
    return-void
.end method
