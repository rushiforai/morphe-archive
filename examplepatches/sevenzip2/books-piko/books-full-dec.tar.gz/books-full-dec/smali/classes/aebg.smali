.class public interface abstract Laebg;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract b(Ljava/lang/String;Ldw;)V
.end method

.method public abstract c(Ldw;J)V
.end method

.method public abstract d(J)V
.end method

.method public abstract e()V
.end method

.method public abstract f(Z)V
.end method

.method public abstract g(J)V
.end method

.method public abstract h(Lbevb;)V
.end method

.method public abstract i()V
.end method

.method public abstract j()V
.end method

.method public abstract k(Ljava/lang/String;Ljava/util/List;)V
.end method

.method public abstract l(Ljava/lang/String;Z)V
.end method
