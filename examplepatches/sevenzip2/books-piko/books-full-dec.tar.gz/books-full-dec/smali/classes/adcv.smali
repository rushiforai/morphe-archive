.class public final Ladcv;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladcv;->a:Lbeye;

    .line 6
    iput-object p2, p0, Ladcv;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final a()Ladcu;
    .locals 2

    .line 1
    iget-object v0, p0, Ladcv;->a:Lbeye;

    .line 3
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lacxt;

    .line 9
    iget-object p0, p0, Ladcv;->b:Lbeye;

    .line 11
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object p0

    .line 15
    check-cast p0, Lych;

    .line 17
    new-instance v1, Ladcu;

    .line 19
    invoke-direct {v1, v0, p0}, Ladcu;-><init>(Lacxt;Lych;)V

    .line 22
    return-object v1
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ladcv;->a()Ladcu;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
