.class final Ladzx;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:I

.field final synthetic b:Ldw;

.field final synthetic c:Laeak;


# direct methods
.method public constructor <init>(Ldw;Laeak;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ladzx;->b:Ldw;

    .line 3
    iput-object p2, p0, Ladzx;->c:Laeak;

    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, Lbhuu;-><init>(ILbhtu;)V

    .line 9
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Ladzx;

    .line 13
    invoke-virtual {p0, p1}, Ladzx;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Ladzx;->a:I

    .line 5
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 8
    if-eqz v1, :cond_0

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object p1, p0, Ladzx;->b:Ldw;

    .line 13
    iget-object v1, p0, Ladzx;->c:Laeak;

    .line 15
    sget-object v2, Lkbz;->e:Lkbz;

    .line 17
    new-instance v3, Ladzw;

    .line 19
    const/4 v4, 0x0

    .line 20
    invoke-direct {v3, v1, p1, v4}, Ladzw;-><init>(Laeak;Ldw;Lbhtu;)V

    .line 23
    const/4 v1, 0x1

    .line 24
    iput v1, p0, Ladzx;->a:I

    .line 26
    invoke-static {p1, v2, v3, p0}, Lkds;->b(Lkcm;Lkbz;Lbhwu;Lbhtu;)Ljava/lang/Object;

    .line 29
    move-result-object p0

    .line 30
    if-ne p0, v0, :cond_1

    .line 32
    return-object v0

    .line 33
    :cond_1
    :goto_0
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 35
    return-object p0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 1

    .line 1
    new-instance p1, Ladzx;

    .line 3
    iget-object v0, p0, Ladzx;->b:Ldw;

    .line 5
    iget-object p0, p0, Ladzx;->c:Laeak;

    .line 7
    invoke-direct {p1, v0, p0, p2}, Ladzx;-><init>(Ldw;Laeak;Lbhtu;)V

    .line 10
    return-object p1
.end method
