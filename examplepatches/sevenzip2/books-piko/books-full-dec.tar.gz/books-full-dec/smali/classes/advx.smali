.class public final Ladvx;
.super Landroidx/constraintlayout/widget/ConstraintLayout;
.source "PG"


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    .line 1
    invoke-direct {p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;-><init>(Landroid/content/Context;)V

    .line 4
    invoke-virtual {p0}, Ladvx;->getContext()Landroid/content/Context;

    .line 7
    move-result-object p1

    .line 8
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 11
    move-result-object v0

    .line 12
    const v1, 0x7f0d00b7

    .line 15
    const/4 v2, 0x1

    .line 16
    invoke-virtual {v0, v1, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 19
    invoke-virtual {p0}, Ladvx;->getResources()Landroid/content/res/Resources;

    .line 22
    move-result-object v0

    .line 23
    const v1, 0x7f0701d0

    .line 26
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 29
    move-result v0

    .line 30
    sget v1, Ljmy;->a:I

    .line 32
    invoke-virtual {p0, v0, v0, v0, v0}, Landroid/view/View;->setPaddingRelative(IIII)V

    .line 35
    invoke-static {p1}, Laktg;->d(Landroid/content/Context;)Z

    .line 38
    move-result v0

    .line 39
    const/4 v1, 0x0

    .line 40
    if-eqz v0, :cond_0

    .line 42
    const v0, 0x7f1301c6

    .line 45
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 48
    move-result-object v0

    .line 49
    goto :goto_0

    .line 50
    :cond_0
    move-object v0, v1

    .line 51
    :goto_0
    const v2, 0x7f0a0264

    .line 54
    invoke-direct {p0, v2, v1}, Ladvx;->e(ILjava/lang/String;)V

    .line 57
    const v1, 0x7f0a0261

    .line 60
    invoke-direct {p0, v1, p2}, Ladvx;->e(ILjava/lang/String;)V

    .line 63
    const v2, 0x7f0a0262

    .line 66
    invoke-direct {p0, v2, v0}, Ladvx;->e(ILjava/lang/String;)V

    .line 69
    invoke-virtual {p0, v1}, Ladvx;->findViewById(I)Landroid/view/View;

    .line 72
    move-result-object v0

    .line 73
    check-cast v0, Landroid/widget/TextView;

    .line 75
    const v1, 0x7f140219

    .line 78
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextAppearance(I)V

    .line 81
    const v1, 0x7f04071e

    .line 84
    invoke-static {p1, v1}, Laoym;->a(Landroid/content/Context;I)I

    .line 87
    move-result p1

    .line 88
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 91
    invoke-virtual {p0, p2}, Ladvx;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 94
    return-void
.end method

.method private final e(ILjava/lang/String;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Ladvx;->findViewById(I)Landroid/view/View;

    .line 4
    move-result-object p0

    .line 5
    check-cast p0, Landroid/widget/TextView;

    .line 7
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 10
    move-result p1

    .line 11
    if-nez p1, :cond_0

    .line 13
    invoke-virtual {p0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 16
    const/4 p1, 0x0

    .line 17
    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 20
    return-void

    .line 21
    :cond_0
    const/16 p1, 0x8

    .line 23
    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 26
    return-void
.end method


# virtual methods
.method public getBackgroundColor()I
    .locals 1

    .line 1
    invoke-virtual {p0}, Ladvx;->getContext()Landroid/content/Context;

    .line 4
    move-result-object p0

    .line 5
    const v0, 0x7f04021b

    .line 8
    invoke-static {p0, v0}, Laoym;->a(Landroid/content/Context;I)I

    .line 11
    move-result p0

    .line 12
    return p0
.end method

.method public getScrimColor()I
    .locals 1

    .line 1
    invoke-virtual {p0}, Ladvx;->getContext()Landroid/content/Context;

    .line 4
    move-result-object p0

    .line 5
    const v0, 0x7f040721

    .line 8
    invoke-static {p0, v0}, Laoym;->a(Landroid/content/Context;I)I

    .line 11
    move-result p0

    .line 12
    return p0
.end method
