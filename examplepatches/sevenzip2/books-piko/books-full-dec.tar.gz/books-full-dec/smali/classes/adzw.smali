.class final Ladzw;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:I

.field final synthetic b:Laeak;

.field final synthetic c:Ldw;

.field private synthetic d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Laeak;Ldw;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ladzw;->b:Laeak;

    .line 3
    iput-object p2, p0, Ladzw;->c:Ldw;

    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, Lbhuu;-><init>(ILbhtu;)V

    .line 9
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Ladzw;

    .line 13
    invoke-virtual {p0, p1}, Ladzw;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Ladzw;->a:I

    .line 5
    const/4 v2, 0x3

    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x1

    .line 8
    const/4 v5, 0x0

    .line 9
    if-eqz v1, :cond_0

    .line 11
    iget-object v0, p0, Ladzw;->d:Ljava/lang/Object;

    .line 13
    check-cast v0, Lbifi;

    .line 15
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 22
    iget-object p1, p0, Ladzw;->d:Ljava/lang/Object;

    .line 24
    check-cast p1, Lbifi;

    .line 26
    iget-object v1, p0, Ladzw;->b:Laeak;

    .line 28
    iget-wide v6, v1, Laeak;->c:J

    .line 30
    iget-wide v8, v1, Laeak;->b:J

    .line 32
    cmp-long v6, v6, v8

    .line 34
    if-lez v6, :cond_1

    .line 36
    iget-boolean v6, v1, Laeak;->d:Z

    .line 38
    if-nez v6, :cond_1

    .line 40
    iput-boolean v4, v1, Laeak;->d:Z

    .line 42
    iget-object v6, p0, Ladzw;->c:Ldw;

    .line 44
    new-instance v7, Ladzs;

    .line 46
    invoke-direct {v7, v1, v6, v5}, Ladzs;-><init>(Laeak;Ldw;Lbhtu;)V

    .line 49
    invoke-static {p1, v5, v3, v7, v2}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 52
    :cond_1
    iget-wide v6, v1, Laeak;->f:J

    .line 54
    iget-wide v8, v1, Laeak;->e:J

    .line 56
    cmp-long v6, v6, v8

    .line 58
    if-lez v6, :cond_2

    .line 60
    iget-boolean v6, v1, Laeak;->g:Z

    .line 62
    if-nez v6, :cond_2

    .line 64
    iput-boolean v4, v1, Laeak;->g:Z

    .line 66
    iget-object v6, p0, Ladzw;->c:Ldw;

    .line 68
    sget-object v7, Lbftp;->a:Lbftp;

    .line 70
    invoke-virtual {v7}, Lbftp;->b()Lbftq;

    .line 73
    move-result-object v7

    .line 74
    invoke-interface {v7}, Lbftq;->c()Ljava/lang/String;

    .line 77
    move-result-object v7

    .line 78
    new-instance v8, Ladzt;

    .line 80
    invoke-direct {v8, v5}, Ladzt;-><init>(Lbhtu;)V

    .line 83
    iput-object p1, p0, Ladzw;->d:Ljava/lang/Object;

    .line 85
    iput v4, p0, Ladzw;->a:I

    .line 87
    invoke-virtual {v1, v6, v7, v8, p0}, Laeak;->a(Ldw;Ljava/lang/String;Lbhwq;Lbhtu;)Ljava/lang/Object;

    .line 90
    move-result-object v1

    .line 91
    if-ne v1, v0, :cond_2

    .line 93
    return-object v0

    .line 94
    :cond_2
    move-object v0, p1

    .line 95
    :goto_0
    iget-object p1, p0, Ladzw;->b:Laeak;

    .line 97
    iget-boolean v1, p1, Laeak;->h:Z

    .line 99
    if-eqz v1, :cond_3

    .line 101
    iget-boolean v1, p1, Laeak;->i:Z

    .line 103
    if-nez v1, :cond_3

    .line 105
    iput-boolean v4, p1, Laeak;->i:Z

    .line 107
    iget-object p0, p0, Ladzw;->c:Ldw;

    .line 109
    new-instance v1, Ladzv;

    .line 111
    invoke-direct {v1, p1, p0, v5}, Ladzv;-><init>(Laeak;Ldw;Lbhtu;)V

    .line 114
    invoke-static {v0, v5, v3, v1, v2}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 117
    :cond_3
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 119
    return-object p0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 2

    .line 1
    new-instance v0, Ladzw;

    .line 3
    iget-object v1, p0, Ladzw;->b:Laeak;

    .line 5
    iget-object p0, p0, Ladzw;->c:Ldw;

    .line 7
    invoke-direct {v0, v1, p0, p2}, Ladzw;-><init>(Laeak;Ldw;Lbhtu;)V

    .line 10
    iput-object p1, v0, Ladzw;->d:Ljava/lang/Object;

    .line 12
    return-object v0
.end method
