.class public final synthetic Lacfg;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwq;


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    check-cast p1, Lmsi;

    .line 3
    const-string p0, "SELECT * FROM pending_copy_quota_updates"

    .line 5
    invoke-virtual {p1, p0}, Lmsi;->a(Ljava/lang/String;)Lmrh;

    .line 8
    move-result-object p0

    .line 9
    :try_start_0
    const-string p1, "volumeId"

    .line 11
    invoke-static {p0, p1}, Lmqb;->b(Lmrh;Ljava/lang/String;)I

    .line 14
    move-result p1

    .line 15
    const-string v0, "copiedCharacterCount"

    .line 17
    invoke-static {p0, v0}, Lmqb;->b(Lmrh;Ljava/lang/String;)I

    .line 20
    move-result v0

    .line 21
    const-string v1, "updateId"

    .line 23
    invoke-static {p0, v1}, Lmqb;->b(Lmrh;Ljava/lang/String;)I

    .line 26
    move-result v1

    .line 27
    new-instance v2, Ljava/util/ArrayList;

    .line 29
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 32
    :goto_0
    invoke-interface {p0}, Lmrh;->m()Z

    .line 35
    move-result v3

    .line 36
    if-eqz v3, :cond_0

    .line 38
    invoke-interface {p0, p1}, Lmrh;->e(I)Ljava/lang/String;

    .line 41
    move-result-object v3

    .line 42
    invoke-interface {p0, v0}, Lmrh;->c(I)J

    .line 45
    move-result-wide v4

    .line 46
    invoke-interface {p0, v1}, Lmrh;->c(I)J

    .line 49
    move-result-wide v6

    .line 50
    long-to-int v6, v6

    .line 51
    new-instance v7, Lacgl;

    .line 53
    invoke-direct {v7, v3, v4, v5, v6}, Lacgl;-><init>(Ljava/lang/String;JI)V

    .line 56
    invoke-interface {v2, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 59
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 60
    :cond_0
    invoke-interface {p0}, Lmrh;->close()V

    .line 63
    return-object v2

    .line 64
    :catchall_0
    move-exception p1

    .line 65
    invoke-interface {p0}, Lmrh;->close()V

    .line 68
    throw p1
.end method
