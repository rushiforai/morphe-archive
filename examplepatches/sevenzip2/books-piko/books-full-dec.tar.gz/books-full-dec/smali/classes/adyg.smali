.class final Ladyg;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:Ljava/lang/Object;

.field b:I

.field final synthetic c:Layhy;

.field final synthetic d:Lalav;

.field final synthetic e:Landroid/accounts/Account;


# direct methods
.method public constructor <init>(Layhy;Lalav;Landroid/accounts/Account;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ladyg;->c:Layhy;

    .line 3
    iput-object p2, p0, Ladyg;->d:Lalav;

    .line 5
    iput-object p3, p0, Ladyg;->e:Landroid/accounts/Account;

    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, Lbhuu;-><init>(ILbhtu;)V

    .line 11
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Ladyg;

    .line 13
    invoke-virtual {p0, p1}, Ladyg;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Ladyg;->b:I

    .line 5
    if-eqz v1, :cond_0

    .line 7
    iget-object p0, p0, Ladyg;->a:Ljava/lang/Object;

    .line 9
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 16
    iget-object p1, p0, Ladyg;->c:Layhy;

    .line 18
    new-instance v1, Lahya;

    .line 20
    sget-object v2, Lahxz;->n:Lahxz;

    .line 22
    invoke-direct {v1, p1, v2}, Lahya;-><init>(Layhy;Lahxz;)V

    .line 25
    iget-object p1, p0, Ladyg;->d:Lalav;

    .line 27
    iget-object v2, p0, Ladyg;->e:Landroid/accounts/Account;

    .line 29
    iput-object v1, p0, Ladyg;->a:Ljava/lang/Object;

    .line 31
    const/4 v3, 0x1

    .line 32
    iput v3, p0, Ladyg;->b:I

    .line 34
    invoke-static {p1, v2, p0}, Lalbj;->a(Lalav;Landroid/accounts/Account;Lbhtu;)Ljava/lang/Object;

    .line 37
    move-result-object p1

    .line 38
    if-eq p1, v0, :cond_1

    .line 40
    move-object p0, v1

    .line 41
    :goto_0
    check-cast p1, Ljava/lang/Boolean;

    .line 43
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 46
    check-cast p0, Lahya;

    .line 48
    invoke-virtual {p0}, Lahya;->b()V

    .line 51
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 53
    return-object p0

    .line 54
    :cond_1
    return-object v0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 2

    .line 1
    new-instance p1, Ladyg;

    .line 3
    iget-object v0, p0, Ladyg;->c:Layhy;

    .line 5
    iget-object v1, p0, Ladyg;->d:Lalav;

    .line 7
    iget-object p0, p0, Ladyg;->e:Landroid/accounts/Account;

    .line 9
    invoke-direct {p1, v0, v1, p0, p2}, Ladyg;-><init>(Layhy;Lalav;Landroid/accounts/Account;Lbhtu;)V

    .line 12
    return-object p1
.end method
