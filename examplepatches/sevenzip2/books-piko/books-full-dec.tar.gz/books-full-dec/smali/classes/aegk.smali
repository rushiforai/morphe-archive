.class public final Laegk;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Lbivm;

.field private b:I

.field private final c:Lbivm;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Lbivq;

    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-direct {v0, v1}, Lbivq;-><init>(Z)V

    .line 10
    iput-object v0, p0, Laegk;->c:Lbivm;

    .line 12
    new-instance v0, Lbivq;

    .line 14
    invoke-direct {v0, v1}, Lbivq;-><init>(Z)V

    .line 17
    iput-object v0, p0, Laegk;->a:Lbivm;

    .line 19
    return-void
.end method


# virtual methods
.method public final a(Lbhtu;)Ljava/lang/Object;
    .locals 4

    .line 1
    instance-of v0, p1, Laegi;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Laegi;

    .line 8
    iget v1, v0, Laegi;->c:I

    .line 10
    const/high16 v2, -0x80000000

    .line 12
    and-int v3, v1, v2

    .line 14
    if-eqz v3, :cond_0

    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Laegi;->c:I

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Laegi;

    .line 22
    invoke-direct {v0, p0, p1}, Laegi;-><init>(Laegk;Lbhtu;)V

    .line 25
    :goto_0
    iget-object p1, v0, Laegi;->a:Ljava/lang/Object;

    .line 27
    sget-object v1, Lbhug;->a:Lbhug;

    .line 29
    iget v2, v0, Laegi;->c:I

    .line 31
    const/4 v3, 0x1

    .line 32
    if-eqz v2, :cond_2

    .line 34
    if-ne v2, v3, :cond_1

    .line 36
    iget-object v0, v0, Laegi;->d:Lbivq;

    .line 38
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 41
    goto :goto_1

    .line 42
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 44
    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 46
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 49
    throw p0

    .line 50
    :cond_2
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 53
    iget-object p1, p0, Laegk;->c:Lbivm;

    .line 55
    move-object v2, p1

    .line 56
    check-cast v2, Lbivq;

    .line 58
    iput-object v2, v0, Laegi;->d:Lbivq;

    .line 60
    iput v3, v0, Laegi;->c:I

    .line 62
    invoke-interface {p1, v0}, Lbivm;->b(Lbhtu;)Ljava/lang/Object;

    .line 65
    move-result-object v0

    .line 66
    if-eq v0, v1, :cond_5

    .line 68
    move-object v0, p1

    .line 69
    :goto_1
    :try_start_0
    iget p1, p0, Laegk;->b:I

    .line 71
    if-ne p1, v3, :cond_3

    .line 73
    iget-object p1, p0, Laegk;->a:Lbivm;

    .line 75
    invoke-interface {p1}, Lbivm;->d()V

    .line 78
    :cond_3
    iget p1, p0, Laegk;->b:I

    .line 80
    add-int/lit8 p1, p1, -0x1

    .line 82
    iput p1, p0, Laegk;->b:I

    .line 84
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-ltz p1, :cond_4

    .line 86
    invoke-interface {v0}, Lbivm;->d()V

    .line 89
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 91
    return-object p0

    .line 92
    :cond_4
    :try_start_1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 94
    const-string p1, "Check failed."

    .line 96
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 99
    throw p0

    .line 100
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p0

    .line 101
    invoke-interface {v0}, Lbivm;->d()V

    .line 104
    throw p0

    .line 105
    :cond_5
    return-object v1
.end method

.method public final b(Lbhtu;)Ljava/lang/Object;
    .locals 6

    .line 1
    instance-of v0, p1, Laegj;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Laegj;

    .line 8
    iget v1, v0, Laegj;->c:I

    .line 10
    const/high16 v2, -0x80000000

    .line 12
    and-int v3, v1, v2

    .line 14
    if-eqz v3, :cond_0

    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Laegj;->c:I

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Laegj;

    .line 22
    invoke-direct {v0, p0, p1}, Laegj;-><init>(Laegk;Lbhtu;)V

    .line 25
    :goto_0
    iget-object p1, v0, Laegj;->a:Ljava/lang/Object;

    .line 27
    sget-object v1, Lbhug;->a:Lbhug;

    .line 29
    iget v2, v0, Laegj;->c:I

    .line 31
    const/4 v3, 0x2

    .line 32
    const/4 v4, 0x1

    .line 33
    if-eqz v2, :cond_3

    .line 35
    if-eq v2, v4, :cond_2

    .line 37
    if-ne v2, v3, :cond_1

    .line 39
    iget-object v0, v0, Laegj;->d:Lbivq;

    .line 41
    :try_start_0
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 44
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    .line 45
    :catchall_0
    move-exception p0

    .line 46
    goto :goto_3

    .line 47
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 49
    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 51
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 54
    throw p0

    .line 55
    :cond_2
    iget-object v2, v0, Laegj;->d:Lbivq;

    .line 57
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 60
    move-object p1, v2

    .line 61
    goto :goto_1

    .line 62
    :cond_3
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 65
    iget-object p1, p0, Laegk;->c:Lbivm;

    .line 67
    move-object v2, p1

    .line 68
    check-cast v2, Lbivq;

    .line 70
    iput-object v2, v0, Laegj;->d:Lbivq;

    .line 72
    iput v4, v0, Laegj;->c:I

    .line 74
    invoke-interface {p1, v0}, Lbivm;->b(Lbhtu;)Ljava/lang/Object;

    .line 77
    move-result-object v2

    .line 78
    if-eq v2, v1, :cond_5

    .line 80
    :goto_1
    :try_start_1
    iget v2, p0, Laegk;->b:I

    .line 82
    if-nez v2, :cond_4

    .line 84
    iget-object v2, p0, Laegk;->a:Lbivm;

    .line 86
    move-object v5, p1

    .line 87
    check-cast v5, Lbivq;

    .line 89
    iput-object v5, v0, Laegj;->d:Lbivq;

    .line 91
    iput v3, v0, Laegj;->c:I

    .line 93
    invoke-interface {v2, v0}, Lbivm;->b(Lbhtu;)Ljava/lang/Object;

    .line 96
    move-result-object v0

    .line 97
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-eq v0, v1, :cond_5

    .line 99
    :cond_4
    move-object v0, p1

    .line 100
    :goto_2
    :try_start_2
    iget p1, p0, Laegk;->b:I

    .line 102
    add-int/2addr p1, v4

    .line 103
    iput p1, p0, Laegk;->b:I

    .line 105
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    invoke-interface {v0}, Lbivm;->d()V

    .line 108
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 110
    return-object p0

    .line 111
    :catchall_1
    move-exception p0

    .line 112
    move-object v0, p1

    .line 113
    :goto_3
    invoke-interface {v0}, Lbivm;->d()V

    .line 116
    throw p0

    .line 117
    :cond_5
    return-object v1
.end method
