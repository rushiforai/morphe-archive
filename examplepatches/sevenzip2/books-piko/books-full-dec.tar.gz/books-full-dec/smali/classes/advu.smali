.class public final Ladvu;
.super Landroid/widget/PopupWindow;
.source "PG"


# instance fields
.field final synthetic a:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;


# direct methods
.method public constructor <init>(Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;Landroid/view/View;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ladvu;->a:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 3
    const/4 p1, -0x2

    .line 4
    invoke-direct {p0, p2, p1, p1}, Landroid/widget/PopupWindow;-><init>(Landroid/view/View;II)V

    .line 7
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 0

    .line 1
    invoke-super {p0}, Landroid/widget/PopupWindow;->dismiss()V

    .line 4
    return-void
.end method

.method public final dismiss()V
    .locals 8

    .line 1
    iget-object p0, p0, Ladvu;->a:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 3
    invoke-virtual {p0}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->getContext()Landroid/content/Context;

    .line 6
    move-result-object v0

    .line 7
    const v1, 0x7f020007

    .line 10
    invoke-static {v0, v1}, Landroid/animation/AnimatorInflater;->loadAnimator(Landroid/content/Context;I)Landroid/animation/Animator;

    .line 13
    move-result-object v0

    .line 14
    new-instance v1, Ladvq;

    .line 16
    invoke-direct {v1, p0}, Ladvq;-><init>(Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;)V

    .line 19
    invoke-virtual {v0, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 22
    invoke-virtual {v0, p0}, Landroid/animation/Animator;->setTarget(Ljava/lang/Object;)V

    .line 25
    invoke-virtual {v0}, Landroid/animation/Animator;->start()V

    .line 28
    invoke-virtual {p0}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->getContext()Landroid/content/Context;

    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 35
    move-result-object v0

    .line 36
    new-instance v1, Landroid/view/animation/ScaleAnimation;

    .line 38
    iget v2, p0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->f:I

    .line 40
    iget v3, p0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->d:I

    .line 42
    sub-int/2addr v2, v3

    .line 43
    iget v3, p0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->g:I

    .line 45
    iget v4, p0, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->e:I

    .line 47
    sub-int/2addr v3, v4

    .line 48
    int-to-float v6, v2

    .line 49
    int-to-float v7, v3

    .line 50
    const/high16 v2, 0x3f800000

    .line 52
    const v3, 0x3f547ae1

    .line 55
    const/high16 v4, 0x3f800000

    .line 57
    move v5, v3

    .line 58
    invoke-direct/range {v1 .. v7}, Landroid/view/animation/ScaleAnimation;-><init>(FFFFFF)V

    .line 61
    const v2, 0x7f0b0027

    .line 64
    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getInteger(I)I

    .line 67
    move-result v2

    .line 68
    int-to-long v2, v2

    .line 69
    invoke-virtual {v1, v2, v3}, Landroid/view/animation/ScaleAnimation;->setDuration(J)V

    .line 72
    const v2, 0x7f0b0020

    .line 75
    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getInteger(I)I

    .line 78
    move-result v0

    .line 79
    int-to-long v2, v0

    .line 80
    invoke-virtual {v1, v2, v3}, Landroid/view/animation/ScaleAnimation;->setStartOffset(J)V

    .line 83
    sget-object v0, Laphg;->a:Landroid/view/animation/Interpolator;

    .line 85
    invoke-virtual {v1, v0}, Landroid/view/animation/ScaleAnimation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 88
    invoke-virtual {p0, v1}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->startAnimation(Landroid/view/animation/Animation;)V

    .line 91
    return-void
.end method
