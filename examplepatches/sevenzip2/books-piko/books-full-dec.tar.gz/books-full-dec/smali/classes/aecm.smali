.class public interface abstract Laecm;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract af(Lcom/google/android/apps/play/books/home/HomeActivity;)V
.end method

.method public abstract ah(Lcom/google/android/apps/play/books/home/BooksShortcutActivity;)V
.end method
