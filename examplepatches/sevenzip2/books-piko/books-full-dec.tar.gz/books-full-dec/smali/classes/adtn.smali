.class public final Ladtn;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Ladsy;

.field public final b:Laduz;

.field public final c:Lavnw;


# direct methods
.method public constructor <init>(Ladsy;Laduz;Lavnw;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    iput-object p1, p0, Ladtn;->a:Ladsy;

    .line 12
    iput-object p2, p0, Ladtn;->b:Laduz;

    .line 14
    iput-object p3, p0, Ladtn;->c:Lavnw;

    .line 16
    return-void
.end method


# virtual methods
.method public final a(Ldw;Lkcm;Ljava/lang/String;Laduy;ILbhwf;Lbhwq;)V
    .locals 11

    .line 1
    invoke-interface {p2}, Lkcm;->N()Lkcb;

    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Lkck;->a(Lkcb;)Lkcf;

    .line 8
    move-result-object v0

    .line 9
    new-instance v1, Ladtm;

    .line 11
    const/4 v10, 0x0

    .line 12
    move-object v2, p0

    .line 13
    move-object v6, p1

    .line 14
    move-object v3, p2

    .line 15
    move-object v4, p3

    .line 16
    move-object v9, p4

    .line 17
    move/from16 v7, p5

    .line 19
    move-object/from16 v8, p6

    .line 21
    move-object/from16 v5, p7

    .line 23
    invoke-direct/range {v1 .. v10}, Ladtm;-><init>(Ladtn;Lkcm;Ljava/lang/String;Lbhwq;Ldw;ILbhwf;Laduy;Lbhtu;)V

    .line 26
    const/4 p0, 0x3

    .line 27
    const/4 p1, 0x0

    .line 28
    const/4 p2, 0x0

    .line 29
    invoke-static {v0, p1, p2, v1, p0}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 32
    return-void
.end method
