.class final Lacex;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:Ljava/lang/Object;

.field b:Ljava/lang/Object;

.field c:I

.field final synthetic d:Lacey;

.field final synthetic e:Lbhwu;


# direct methods
.method public constructor <init>(Lacey;Lbhwu;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lacex;->d:Lacey;

    .line 3
    iput-object p2, p0, Lacex;->e:Lbhwu;

    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, Lbhuu;-><init>(ILbhtu;)V

    .line 9
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Lacex;

    .line 13
    invoke-virtual {p0, p1}, Lacex;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Lacex;->c:I

    .line 5
    const/4 v2, 0x3

    .line 6
    const/4 v3, 0x2

    .line 7
    const/4 v4, 0x1

    .line 8
    const/4 v5, 0x0

    .line 9
    if-eqz v1, :cond_3

    .line 11
    if-eq v1, v4, :cond_2

    .line 13
    if-eq v1, v3, :cond_1

    .line 15
    if-eq v1, v2, :cond_0

    .line 17
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 20
    goto/16 :goto_6

    .line 22
    :cond_0
    iget-object v1, p0, Lacex;->b:Ljava/lang/Object;

    .line 24
    iget-object v2, p0, Lacex;->a:Ljava/lang/Object;

    .line 26
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 29
    goto/16 :goto_3

    .line 31
    :cond_1
    iget-object v1, p0, Lacex;->a:Ljava/lang/Object;

    .line 33
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 36
    goto :goto_2

    .line 37
    :cond_2
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 40
    goto :goto_0

    .line 41
    :cond_3
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 44
    iget-object p1, p0, Lacex;->d:Lacey;

    .line 46
    iput v4, p0, Lacex;->c:I

    .line 48
    new-instance v1, Lacfg;

    .line 50
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 53
    iget-object p1, p1, Lacey;->b:Lacfa;

    .line 55
    check-cast p1, Lacfk;

    .line 57
    iget-object p1, p1, Lacfk;->a:Lmmt;

    .line 59
    const/4 v6, 0x0

    .line 60
    invoke-static {p1, v4, v6, v1, p0}, Lmpv;->d(Lmmt;ZZLbhwq;Lbhtu;)Ljava/lang/Object;

    .line 63
    move-result-object p1

    .line 64
    if-eq p1, v0, :cond_8

    .line 66
    :goto_0
    iget-object v1, p0, Lacex;->e:Lbhwu;

    .line 68
    check-cast p1, Ljava/util/List;

    .line 70
    new-instance v4, Ljava/util/ArrayList;

    .line 72
    invoke-static {p1}, Lbhrc;->p(Ljava/lang/Iterable;)I

    .line 75
    move-result v6

    .line 76
    invoke-direct {v4, v6}, Ljava/util/ArrayList;-><init>(I)V

    .line 79
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 82
    move-result-object v6

    .line 83
    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 86
    move-result v7

    .line 87
    if-eqz v7, :cond_4

    .line 89
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 92
    move-result-object v7

    .line 93
    check-cast v7, Lacgl;

    .line 95
    iget-object v8, v7, Lacgl;->a:Ljava/lang/String;

    .line 97
    iget-wide v9, v7, Lacgl;->b:J

    .line 99
    new-instance v7, Lacej;

    .line 101
    invoke-direct {v7, v8, v9, v10}, Lacej;-><init>(Ljava/lang/String;J)V

    .line 104
    invoke-interface {v4, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 107
    goto :goto_1

    .line 108
    :cond_4
    iput-object p1, p0, Lacex;->a:Ljava/lang/Object;

    .line 110
    iput v3, p0, Lacex;->c:I

    .line 112
    invoke-interface {v1, v4, p0}, Lbhwu;->a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 115
    move-result-object v1

    .line 116
    if-eq v1, v0, :cond_8

    .line 118
    move-object v11, v1

    .line 119
    move-object v1, p1

    .line 120
    move-object p1, v11

    .line 121
    :goto_2
    iget-object v3, p0, Lacex;->d:Lacey;

    .line 123
    check-cast p1, Ljava/util/Collection;

    .line 125
    new-instance v4, Lacew;

    .line 127
    invoke-direct {v4, v3, p1, v1, v5}, Lacew;-><init>(Lacey;Ljava/util/Collection;Ljava/util/List;Lbhtu;)V

    .line 130
    iput-object v1, p0, Lacex;->a:Ljava/lang/Object;

    .line 132
    iput-object p1, p0, Lacex;->b:Ljava/lang/Object;

    .line 134
    iput v2, p0, Lacex;->c:I

    .line 136
    new-instance v2, Lmmw;

    .line 138
    iget-object v3, v3, Lacey;->a:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase;

    .line 140
    invoke-direct {v2, v3, v4, v5}, Lmmw;-><init>(Lmmt;Lbhwq;Lbhtu;)V

    .line 143
    invoke-static {v3, v2, p0}, Lmmy;->c(Lmmt;Lbhwq;Lbhtu;)Ljava/lang/Object;

    .line 146
    move-result-object v2

    .line 147
    if-eq v2, v0, :cond_8

    .line 149
    move-object v2, v1

    .line 150
    move-object v1, p1

    .line 151
    :goto_3
    new-instance p1, Ljava/util/ArrayList;

    .line 153
    invoke-static {v2}, Lbhrc;->p(Ljava/lang/Iterable;)I

    .line 156
    move-result v3

    .line 157
    invoke-direct {p1, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 160
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 163
    move-result-object v2

    .line 164
    :goto_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 167
    move-result v3

    .line 168
    if-eqz v3, :cond_5

    .line 170
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 173
    move-result-object v3

    .line 174
    check-cast v3, Lacgl;

    .line 176
    iget-object v3, v3, Lacgl;->a:Ljava/lang/String;

    .line 178
    invoke-interface {p1, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 181
    goto :goto_4

    .line 182
    :cond_5
    new-instance v2, Ljava/util/ArrayList;

    .line 184
    invoke-static {v1}, Lbhrc;->p(Ljava/lang/Iterable;)I

    .line 187
    move-result v3

    .line 188
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 191
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 194
    move-result-object v1

    .line 195
    :goto_5
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 198
    move-result v3

    .line 199
    if-eqz v3, :cond_6

    .line 201
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 204
    move-result-object v3

    .line 205
    check-cast v3, Lacfo;

    .line 207
    iget-object v3, v3, Lacfo;->a:Ljava/lang/String;

    .line 209
    invoke-interface {v2, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 212
    goto :goto_5

    .line 213
    :cond_6
    invoke-static {p1, v2}, Lbhrc;->T(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    .line 216
    move-result-object p1

    .line 217
    invoke-static {p1}, Lbhrc;->ag(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 220
    move-result-object p1

    .line 221
    iget-object v1, p0, Lacex;->d:Lacey;

    .line 223
    new-instance v2, Lacem;

    .line 225
    invoke-direct {v2, p1}, Lacem;-><init>(Ljava/util/Collection;)V

    .line 228
    iput-object v5, p0, Lacex;->a:Ljava/lang/Object;

    .line 230
    iput-object v5, p0, Lacex;->b:Ljava/lang/Object;

    .line 232
    const/4 p1, 0x4

    .line 233
    iput p1, p0, Lacex;->c:I

    .line 235
    iget-object p1, v1, Lacey;->e:Lbiot;

    .line 237
    invoke-interface {p1, v2, p0}, Lbiot;->a(Ljava/lang/Object;Lbhtu;)Ljava/lang/Object;

    .line 240
    move-result-object p0

    .line 241
    if-ne p0, v0, :cond_7

    .line 243
    goto :goto_7

    .line 244
    :cond_7
    :goto_6
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 246
    return-object p0

    .line 247
    :cond_8
    :goto_7
    return-object v0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 1

    .line 1
    new-instance p1, Lacex;

    .line 3
    iget-object v0, p0, Lacex;->d:Lacey;

    .line 5
    iget-object p0, p0, Lacex;->e:Lbhwu;

    .line 7
    invoke-direct {p1, v0, p0, p2}, Lacex;-><init>(Lacey;Lbhwu;Lbhtu;)V

    .line 10
    return-object p1
.end method
