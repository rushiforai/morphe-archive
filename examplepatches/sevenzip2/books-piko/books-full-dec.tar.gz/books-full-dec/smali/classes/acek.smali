.class public interface abstract Lacek;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract a(Ljava/lang/String;JLbhtu;)Ljava/lang/Object;
.end method

.method public abstract b(Lbhwu;Lbhtu;)Ljava/lang/Object;
.end method

.method public abstract c(Ljava/lang/String;)Lbilb;
.end method
