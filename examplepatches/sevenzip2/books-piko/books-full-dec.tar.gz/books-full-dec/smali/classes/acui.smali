.class public final Lacui;
.super Ljava/lang/Object;
.source "PG"


# static fields
.field public static final a:Lacuj;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lacuj;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    sput-object v0, Lacui;->a:Lacuj;

    .line 8
    return-void
.end method
