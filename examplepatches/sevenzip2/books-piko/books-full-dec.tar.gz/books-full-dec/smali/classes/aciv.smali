.class public final Laciv;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;

.field private final g:Lbeye;

.field private final h:Lbeye;

.field private final i:Lbeye;

.field private final j:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laciv;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laciv;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laciv;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laciv;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laciv;->e:Lbeye;

    .line 14
    iput-object p6, p0, Laciv;->f:Lbeye;

    .line 16
    iput-object p7, p0, Laciv;->g:Lbeye;

    .line 18
    iput-object p8, p0, Laciv;->h:Lbeye;

    .line 20
    iput-object p9, p0, Laciv;->i:Lbeye;

    .line 22
    iput-object p10, p0, Laciv;->j:Lbeye;

    .line 24
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 13

    .line 1
    iget-object v0, p0, Laciv;->a:Lbeye;

    .line 3
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    move-object v2, v0

    .line 8
    check-cast v2, Laktz;

    .line 10
    iget-object v0, p0, Laciv;->b:Lbeye;

    .line 12
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 15
    move-result-object v0

    .line 16
    move-object v3, v0

    .line 17
    check-cast v3, Lachj;

    .line 19
    iget-object v0, p0, Laciv;->c:Lbeye;

    .line 21
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 24
    move-result-object v0

    .line 25
    move-object v4, v0

    .line 26
    check-cast v4, Lyem;

    .line 28
    new-instance v5, Lwvb;

    .line 30
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 33
    iget-object v0, p0, Laciv;->d:Lbeye;

    .line 35
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 38
    move-result-object v0

    .line 39
    move-object v6, v0

    .line 40
    check-cast v6, Lyek;

    .line 42
    iget-object v0, p0, Laciv;->e:Lbeye;

    .line 44
    check-cast v0, Lpxs;

    .line 46
    invoke-virtual {v0}, Lpxs;->a()Lakvn;

    .line 49
    move-result-object v7

    .line 50
    iget-object v0, p0, Laciv;->f:Lbeye;

    .line 52
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 55
    move-result-object v0

    .line 56
    move-object v8, v0

    .line 57
    check-cast v8, Lajet;

    .line 59
    iget-object v0, p0, Laciv;->g:Lbeye;

    .line 61
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 64
    move-result-object v0

    .line 65
    move-object v9, v0

    .line 66
    check-cast v9, Lachb;

    .line 68
    iget-object v0, p0, Laciv;->h:Lbeye;

    .line 70
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 73
    move-result-object v0

    .line 74
    move-object v10, v0

    .line 75
    check-cast v10, Ladqs;

    .line 77
    iget-object v0, p0, Laciv;->i:Lbeye;

    .line 79
    check-cast v0, Lyby;

    .line 81
    invoke-virtual {v0}, Lyby;->a()Lalpu;

    .line 84
    move-result-object v11

    .line 85
    iget-object p0, p0, Laciv;->j:Lbeye;

    .line 87
    check-cast p0, Lahiu;

    .line 89
    invoke-virtual {p0}, Lahiu;->a()Lahit;

    .line 92
    move-result-object v12

    .line 93
    new-instance v1, Laciu;

    .line 95
    invoke-direct/range {v1 .. v12}, Laciu;-><init>(Laktz;Lachj;Lyem;Lwvb;Lyek;Lakvn;Lajet;Lachb;Ladqs;Lalpu;Lahit;)V

    .line 98
    return-object v1
.end method
