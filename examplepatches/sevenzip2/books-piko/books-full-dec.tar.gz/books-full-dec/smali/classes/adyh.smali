.class public final Ladyh;
.super Lket;
.source "PG"


# static fields
.field public static final a:Lj$/time/Duration;


# instance fields
.field public final b:Lbien;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-wide/16 v0, 0x7d0

    .line 3
    invoke-static {v0, v1}, Lj$/time/Duration;->ofMillis(J)Lj$/time/Duration;

    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    sput-object v0, Ladyh;->a:Lj$/time/Duration;

    .line 12
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lbifb;Ladxz;Lalav;Landroid/accounts/Account;Lavnw;Landroid/content/SharedPreferences;Layhy;Ljava/util/Set;Ladyk;Lavkn;)V
    .locals 13

    .line 1
    move-object/from16 v2, p6

    .line 3
    invoke-direct {p0}, Lket;-><init>()V

    .line 6
    new-instance v0, Lbien;

    .line 8
    invoke-direct {v0}, Lbien;-><init>()V

    .line 11
    iput-object v0, p0, Ladyh;->b:Lbien;

    .line 13
    const-string v0, "freshInstallReported"

    .line 15
    move-object/from16 v1, p7

    .line 17
    invoke-interface {v1, v0}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    .line 20
    move-result v3

    .line 21
    if-nez v3, :cond_0

    .line 23
    new-instance v4, Landroid/os/Bundle;

    .line 25
    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    .line 28
    invoke-static {v4}, Lcom/google/android/libraries/play/logging/ulex/LogId;->b(Landroid/os/Bundle;)Lcom/google/android/libraries/play/logging/ulex/LogId;

    .line 31
    move-result-object v4

    .line 32
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    invoke-interface {v2, v4}, Lavnw;->g(Lcom/google/android/libraries/play/logging/ulex/LogId;)Lavoa;

    .line 38
    move-result-object v4

    .line 39
    sget-object v5, Lbesp;->K:Lbesp;

    .line 41
    invoke-interface {v4, v5}, Lavoa;->e(Ljava/lang/Enum;)Ljava/lang/Object;

    .line 44
    move-result-object v4

    .line 45
    check-cast v4, Lavro;

    .line 47
    invoke-virtual {v4}, Lavro;->n()Ljava/lang/Object;

    .line 50
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 53
    move-result-object v1

    .line 54
    const/4 v4, 0x1

    .line 55
    invoke-interface {v1, v0, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 58
    move-result-object v0

    .line 59
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 62
    :cond_0
    invoke-static {p2}, Lbifj;->b(Lbhuc;)Lbifi;

    .line 65
    move-result-object v8

    .line 66
    move-object/from16 v0, p11

    .line 68
    invoke-interface {v2, v0}, Lavnw;->h(Lavkn;)Lavoa;

    .line 71
    move-result-object v0

    .line 72
    sget-object v1, Lbesp;->u:Lbesp;

    .line 74
    invoke-interface {v0, v1}, Lavoa;->e(Ljava/lang/Enum;)Ljava/lang/Object;

    .line 77
    move-result-object v0

    .line 78
    check-cast v0, Lavro;

    .line 80
    invoke-virtual {v0}, Lavro;->n()Ljava/lang/Object;

    .line 83
    move-result-object v0

    .line 84
    move-object v4, v0

    .line 85
    check-cast v4, Lcom/google/android/libraries/play/logging/ulex/LogId;

    .line 87
    sget-object v0, Lbfsr;->a:Lbfsr;

    .line 89
    invoke-virtual {v0}, Lbfsr;->b()Lbfss;

    .line 92
    move-result-object v0

    .line 93
    invoke-interface {v0}, Lbfss;->a()Z

    .line 96
    move-result v0

    .line 97
    const/4 v9, 0x0

    .line 98
    if-nez v0, :cond_4

    .line 100
    if-eqz v3, :cond_1

    .line 102
    goto :goto_0

    .line 103
    :cond_1
    invoke-interface/range {p9 .. p9}, Ljava/util/Set;->isEmpty()Z

    .line 106
    move-result v0

    .line 107
    if-eqz v0, :cond_2

    .line 109
    goto :goto_0

    .line 110
    :cond_2
    sget-object v0, Ladyl;->b:Ladyl;

    .line 112
    move-object/from16 v1, p9

    .line 114
    invoke-interface {v1, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 117
    move-result v1

    .line 118
    if-nez v1, :cond_3

    .line 120
    sget-object v0, Ladyl;->a:Ladyl;

    .line 122
    :cond_3
    move-object v10, v0

    .line 123
    goto :goto_1

    .line 124
    :cond_4
    :goto_0
    move-object v10, v9

    .line 125
    :goto_1
    new-instance v6, Lbien;

    .line 127
    invoke-direct {v6}, Lbien;-><init>()V

    .line 130
    const/4 v11, 0x3

    .line 131
    const/4 v12, 0x0

    .line 132
    if-eqz v10, :cond_5

    .line 134
    new-instance v0, Ladyb;

    .line 136
    const/4 v7, 0x0

    .line 137
    move-object/from16 v1, p8

    .line 139
    move-object/from16 v5, p10

    .line 141
    move-object v3, v4

    .line 142
    move-object v4, v6

    .line 143
    move-object v6, p1

    .line 144
    invoke-direct/range {v0 .. v7}, Ladyb;-><init>(Layhy;Lavnw;Lcom/google/android/libraries/play/logging/ulex/LogId;Lbien;Ladyk;Landroid/content/Context;Lbhtu;)V

    .line 147
    move-object v6, v4

    .line 148
    move-object v4, v3

    .line 149
    invoke-static {v8, v9, v12, v0, v11}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 152
    goto :goto_2

    .line 153
    :cond_5
    invoke-virtual {v6, v9}, Lbihp;->R(Ljava/lang/Object;)Z

    .line 156
    :goto_2
    new-instance p1, Ladyg;

    .line 158
    move-object/from16 v0, p4

    .line 160
    move-object/from16 v1, p5

    .line 162
    move-object/from16 v2, p8

    .line 164
    invoke-direct {p1, v2, v0, v1, v9}, Ladyg;-><init>(Layhy;Lalav;Landroid/accounts/Account;Lbhtu;)V

    .line 167
    invoke-static {v8, v9, v12, p1, v11}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 170
    move-result-object v1

    .line 171
    invoke-static {p0}, Lkeu;->a(Lket;)Lbifi;

    .line 174
    move-result-object p1

    .line 175
    new-instance v0, Ladye;

    .line 177
    const/4 v8, 0x0

    .line 178
    move-object v5, p0

    .line 179
    move-object/from16 v7, p3

    .line 181
    move-object/from16 v3, p6

    .line 183
    move-object v2, v10

    .line 184
    invoke-direct/range {v0 .. v8}, Ladye;-><init>(Lbihc;Ladyl;Lavnw;Lcom/google/android/libraries/play/logging/ulex/LogId;Ladyh;Lbien;Ladxz;Lbhtu;)V

    .line 187
    invoke-static {p1, v9, v12, v0, v11}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 190
    return-void
.end method
