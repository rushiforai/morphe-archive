.class public final Laeeg;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laeeg;->a:Lbeye;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()Laeef;
    .locals 1

    .line 1
    iget-object p0, p0, Laeeg;->a:Lbeye;

    .line 3
    invoke-static {p0}, Lbexu;->a(Lbeye;)Lbexl;

    .line 6
    move-result-object p0

    .line 7
    new-instance v0, Laeef;

    .line 9
    invoke-direct {v0, p0}, Laeef;-><init>(Lbexl;)V

    .line 12
    return-object v0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Laeeg;->a()Laeef;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
