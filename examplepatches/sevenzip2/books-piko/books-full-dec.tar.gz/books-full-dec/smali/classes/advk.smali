.class public final synthetic Ladvk;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final synthetic a:Ladvm;


# direct methods
.method public synthetic constructor <init>(Ladvm;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladvk;->a:Ladvm;

    .line 6
    return-void
.end method
