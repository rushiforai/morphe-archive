.class public final Ladln;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladln;->a:Lbeye;

    .line 6
    iput-object p2, p0, Ladln;->b:Lbeye;

    .line 8
    iput-object p3, p0, Ladln;->c:Lbeye;

    .line 10
    iput-object p4, p0, Ladln;->d:Lbeye;

    .line 12
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, Ladln;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Ladln;->b:Lbeye;

    .line 11
    check-cast v1, Labth;

    .line 13
    invoke-virtual {v1}, Labth;->a()Labtg;

    .line 16
    move-result-object v1

    .line 17
    iget-object v2, p0, Ladln;->c:Lbeye;

    .line 19
    check-cast v2, Labrk;

    .line 21
    invoke-virtual {v2}, Labrk;->a()Labrj;

    .line 24
    move-result-object v2

    .line 25
    iget-object p0, p0, Ladln;->d:Lbeye;

    .line 27
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Lozd;

    .line 33
    new-instance v3, Ladlm;

    .line 35
    invoke-direct {v3, v0, v1, v2, p0}, Ladlm;-><init>(Ldw;Labtg;Labrj;Lozd;)V

    .line 38
    return-object v3
.end method
