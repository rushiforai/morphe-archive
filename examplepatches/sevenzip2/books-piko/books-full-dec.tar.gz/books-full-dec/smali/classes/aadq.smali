.class public final Laadq;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# direct methods
.method public static final a()Lalyv;
    .locals 3

    .line 1
    new-instance v0, Laado;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance v1, Lalyv;

    .line 8
    const-class v2, Laadn;

    .line 10
    invoke-direct {v1, v2, v0}, Lalyv;-><init>(Ljava/lang/Class;Lbhwq;)V

    .line 13
    return-object v1
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {}, Laadq;->a()Lalyv;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
