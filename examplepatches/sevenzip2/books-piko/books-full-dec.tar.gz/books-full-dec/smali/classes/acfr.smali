.class final Lacfr;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:I

.field final synthetic b:Lacft;

.field final synthetic c:Ljava/util/List;


# direct methods
.method public constructor <init>(Lacft;Ljava/util/List;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lacfr;->b:Lacft;

    .line 3
    iput-object p2, p0, Lacfr;->c:Ljava/util/List;

    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, Lbhuu;-><init>(ILbhtu;)V

    .line 9
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Lacfr;

    .line 13
    invoke-virtual {p0, p1}, Lacfr;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Lacfr;->a:I

    .line 5
    const/4 v2, 0x1

    .line 6
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 9
    if-eqz v1, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iget-object p1, p0, Lacfr;->b:Lacft;

    .line 14
    new-instance v1, Lbbbu;

    .line 16
    invoke-virtual {p1}, Lacft;->b()Lbgso;

    .line 19
    move-result-object v3

    .line 20
    sget-object v4, Lbgpq;->a:Lbgpq;

    .line 22
    invoke-virtual {p1}, Lacft;->a()Lbgpn;

    .line 25
    move-result-object v5

    .line 26
    invoke-virtual {v4, v5}, Lbgpq;->b(Lbgpn;)Lbgpq;

    .line 29
    move-result-object v4

    .line 30
    invoke-direct {v1, v3, v4}, Lbbbu;-><init>(Lbgpr;Lbgpq;)V

    .line 33
    iget-object v3, p0, Lacfr;->c:Ljava/util/List;

    .line 35
    sget-object v4, Lbbci;->a:Lbbci;

    .line 37
    invoke-virtual {v4}, Lbdtb;->createBuilder()Lbdst;

    .line 40
    move-result-object v4

    .line 41
    check-cast v4, Lbbch;

    .line 43
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    iget-object p1, p1, Lacft;->b:Lahij;

    .line 48
    invoke-interface {p1}, Lahij;->a()Lbaxk;

    .line 51
    move-result-object p1

    .line 52
    invoke-virtual {v4}, Lbdst;->u()V

    .line 55
    iget-object v5, v4, Lbbch;->b:Lbdtb;

    .line 57
    check-cast v5, Lbbci;

    .line 59
    iput-object p1, v5, Lbbci;->c:Lbaxk;

    .line 61
    iget p1, v5, Lbbci;->b:I

    .line 63
    or-int/2addr p1, v2

    .line 64
    iput p1, v5, Lbbci;->b:I

    .line 66
    new-instance p1, Lbdwi;

    .line 68
    iget-object v5, v5, Lbbci;->d:Lbdts;

    .line 70
    invoke-static {v5}, Lj$/util/DesugarCollections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 73
    move-result-object v5

    .line 74
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 77
    invoke-direct {p1, v5}, Lbdwi;-><init>(Ljava/util/List;)V

    .line 80
    invoke-virtual {v4}, Lbdst;->u()V

    .line 83
    iget-object p1, v4, Lbbch;->b:Lbdtb;

    .line 85
    check-cast p1, Lbbci;

    .line 87
    iget-object v5, p1, Lbbci;->d:Lbdts;

    .line 89
    invoke-interface {v5}, Lbdts;->c()Z

    .line 92
    move-result v6

    .line 93
    if-nez v6, :cond_1

    .line 95
    invoke-static {v5}, Lbdtb;->mutableCopy(Lbdts;)Lbdts;

    .line 98
    move-result-object v5

    .line 99
    iput-object v5, p1, Lbbci;->d:Lbdts;

    .line 101
    :cond_1
    iget-object p1, p1, Lbbci;->d:Lbdts;

    .line 103
    invoke-static {v3, p1}, Lbdrb;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 106
    invoke-virtual {v4}, Lbdst;->q()Lbdtb;

    .line 109
    move-result-object p1

    .line 110
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 113
    check-cast p1, Lbbci;

    .line 115
    iput v2, p0, Lacfr;->a:I

    .line 117
    new-instance v3, Lbgtg;

    .line 119
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 122
    invoke-virtual {v1, p1, v3, p0}, Lbbbu;->g(Lbbci;Lbgtg;Lbhtu;)Ljava/lang/Object;

    .line 125
    move-result-object p1

    .line 126
    if-ne p1, v0, :cond_2

    .line 128
    return-object v0

    .line 129
    :cond_2
    :goto_0
    check-cast p1, Lbbck;

    .line 131
    iget-object p0, p1, Lbbck;->b:Lbdts;

    .line 133
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 136
    new-instance p1, Ljava/util/ArrayList;

    .line 138
    invoke-static {p0}, Lbhrc;->p(Ljava/lang/Iterable;)I

    .line 141
    move-result v0

    .line 142
    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 145
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 148
    move-result-object p0

    .line 149
    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 152
    move-result v0

    .line 153
    if-eqz v0, :cond_4

    .line 155
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 158
    move-result-object v0

    .line 159
    check-cast v0, Lbbaa;

    .line 161
    new-instance v3, Lacfo;

    .line 163
    iget-object v4, v0, Lbbaa;->b:Ljava/lang/String;

    .line 165
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 168
    iget-wide v5, v0, Lbbaa;->c:J

    .line 170
    iget-wide v7, v0, Lbbaa;->d:J

    .line 172
    iget v0, v0, Lbbaa;->e:I

    .line 174
    invoke-static {v0}, Lbbbv;->a(I)I

    .line 177
    move-result v0

    .line 178
    if-nez v0, :cond_3

    .line 180
    move v0, v2

    .line 181
    :cond_3
    invoke-static {v0}, Lacft;->c(I)I

    .line 184
    move-result v9

    .line 185
    invoke-direct/range {v3 .. v9}, Lacfo;-><init>(Ljava/lang/String;JJI)V

    .line 188
    invoke-interface {p1, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 191
    goto :goto_1

    .line 192
    :cond_4
    return-object p1
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 1

    .line 1
    new-instance p1, Lacfr;

    .line 3
    iget-object v0, p0, Lacfr;->b:Lacft;

    .line 5
    iget-object p0, p0, Lacfr;->c:Ljava/util/List;

    .line 7
    invoke-direct {p1, v0, p0, p2}, Lacfr;-><init>(Lacft;Ljava/util/List;Lbhtu;)V

    .line 10
    return-object p1
.end method
