.class public interface abstract Lkcm;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract N()Lkcb;
.end method
