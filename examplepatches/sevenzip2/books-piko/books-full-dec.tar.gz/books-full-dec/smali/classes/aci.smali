.class public final Laci;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Ljava/lang/Runnable;

.field private final b:Lbhph;


# direct methods
.method public constructor <init>()V
    .locals 1

    const/4 v0, 0x0

    .line 19
    invoke-direct {p0, v0}, Laci;-><init>(Ljava/lang/Runnable;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/Runnable;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laci;->a:Ljava/lang/Runnable;

    .line 6
    new-instance p1, Lacd;

    .line 8
    invoke-direct {p1, p0}, Lacd;-><init>(Laci;)V

    .line 11
    new-instance v0, Lbhps;

    .line 13
    invoke-direct {v0, p1}, Lbhps;-><init>(Lbhwf;)V

    .line 16
    iput-object v0, p0, Laci;->b:Lbhph;

    .line 18
    return-void
.end method


# virtual methods
.method public final a()Lacg;
    .locals 0

    .line 1
    iget-object p0, p0, Laci;->b:Lbhph;

    .line 3
    invoke-interface {p0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lacg;

    .line 9
    return-object p0
.end method

.method public final b()Lmjj;
    .locals 0

    .line 1
    invoke-virtual {p0}, Laci;->a()Lacg;

    .line 4
    move-result-object p0

    .line 5
    iget-object p0, p0, Lacg;->a:Lmjj;

    .line 7
    return-object p0
.end method

.method public final c(Lacb;)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    new-instance v0, Lacc;

    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-direct {v0, p1, v1}, Lacc;-><init>(Lacb;Lkcm;)V

    .line 10
    invoke-virtual {p1, v0}, Lacb;->e(Lmjp;)Laca;

    .line 13
    move-result-object p1

    .line 14
    invoke-virtual {p0}, Laci;->a()Lacg;

    .line 17
    move-result-object p0

    .line 18
    iget-object p0, p0, Lacg;->a:Lmjj;

    .line 20
    invoke-virtual {p0, p1}, Lmjj;->e(Lmjm;)V

    .line 23
    return-void
.end method

.method public final d(Lkcm;Lacb;)V
    .locals 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-interface {p1}, Lkcm;->N()Lkcb;

    .line 10
    move-result-object v0

    .line 11
    move-object v1, v0

    .line 12
    check-cast v1, Lkct;

    .line 14
    iget-object v1, v1, Lkct;->e:Lkbz;

    .line 16
    sget-object v2, Lkbz;->a:Lkbz;

    .line 18
    if-ne v1, v2, :cond_0

    .line 20
    return-void

    .line 21
    :cond_0
    new-instance v1, Lacc;

    .line 23
    invoke-direct {v1, p2, p1}, Lacc;-><init>(Lacb;Lkcm;)V

    .line 26
    invoke-virtual {p2, v1}, Lacb;->e(Lmjp;)Laca;

    .line 29
    move-result-object p1

    .line 30
    const/4 v1, 0x0

    .line 31
    invoke-virtual {p1, v1}, Laca;->d(Z)V

    .line 34
    invoke-virtual {p0}, Laci;->a()Lacg;

    .line 37
    move-result-object p0

    .line 38
    iget-object p0, p0, Lacg;->a:Lmjj;

    .line 40
    invoke-virtual {p0, p1}, Lmjj;->e(Lmjm;)V

    .line 43
    new-instance p0, Lach;

    .line 45
    invoke-direct {p0, p1, v0}, Lach;-><init>(Laca;Lkcb;)V

    .line 48
    invoke-virtual {v0, p0}, Lkcb;->c(Lkcl;)V

    .line 51
    new-instance p1, Lace;

    .line 53
    invoke-direct {p1, v0, p0}, Lace;-><init>(Lkcb;Lach;)V

    .line 56
    iget-object p0, p2, Lacb;->c:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 58
    invoke-interface {p0, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 61
    return-void
.end method

.method public final e()V
    .locals 0

    .line 1
    invoke-virtual {p0}, Laci;->a()Lacg;

    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Lmjq;->b()V

    .line 8
    return-void
.end method

.method public final f(Landroid/window/OnBackInvokedDispatcher;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Laci;->a()Lacg;

    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, Lacg;->a:Lmjj;

    .line 7
    new-instance v1, Lmjw;

    .line 9
    invoke-direct {v1, p1}, Lmjw;-><init>(Landroid/window/OnBackInvokedDispatcher;)V

    .line 12
    const/4 v2, 0x1

    .line 13
    invoke-virtual {v0, v1, v2}, Lmjj;->b(Lmjq;I)V

    .line 16
    invoke-virtual {p0}, Laci;->a()Lacg;

    .line 19
    move-result-object p0

    .line 20
    iget-object p0, p0, Lacg;->a:Lmjj;

    .line 22
    new-instance v0, Lmka;

    .line 24
    invoke-direct {v0, p1}, Lmka;-><init>(Landroid/window/OnBackInvokedDispatcher;)V

    .line 27
    const/4 p1, 0x0

    .line 28
    invoke-virtual {p0, v0, p1}, Lmjj;->b(Lmjq;I)V

    .line 31
    return-void
.end method
