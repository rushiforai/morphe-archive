.class final Laedl;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lahgv;


# instance fields
.field final synthetic a:Laedn;


# direct methods
.method public constructor <init>(Laedn;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laedl;->a:Laedn;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 0

    .line 1
    iget-object p0, p0, Laedl;->a:Laedn;

    .line 3
    invoke-virtual {p0}, Lahvs;->x()Lec;

    .line 6
    move-result-object p0

    .line 7
    invoke-virtual {p0}, Labl;->c()Laci;

    .line 10
    move-result-object p0

    .line 11
    invoke-virtual {p0}, Laci;->e()V

    .line 14
    return-void
.end method

.method public final b()V
    .locals 0

    .line 1
    invoke-virtual {p0}, Laedl;->a()V

    .line 4
    return-void
.end method
