.class public final Labyk;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labyk;->a:Lbeye;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()Labyj;
    .locals 1

    .line 1
    new-instance v0, Labyj;

    .line 3
    iget-object p0, p0, Labyk;->a:Lbeye;

    .line 5
    invoke-direct {v0, p0}, Labyj;-><init>(Lbhpa;)V

    .line 8
    return-object v0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Labyk;->a()Labyj;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
