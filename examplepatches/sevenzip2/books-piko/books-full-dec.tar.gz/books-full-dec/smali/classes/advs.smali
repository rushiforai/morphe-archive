.class public final Ladvs;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Landroid/view/animation/Animation$AnimationListener;


# instance fields
.field final synthetic a:Landroid/view/animation/ScaleAnimation;

.field final synthetic b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;


# direct methods
.method public constructor <init>(Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;Landroid/view/animation/ScaleAnimation;)V
    .locals 0

    .line 1
    iput-object p2, p0, Ladvs;->a:Landroid/view/animation/ScaleAnimation;

    .line 3
    iput-object p1, p0, Ladvs;->b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/view/animation/Animation;)V
    .locals 0

    .line 1
    iget-object p1, p0, Ladvs;->b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 3
    iget-object p0, p0, Ladvs;->a:Landroid/view/animation/ScaleAnimation;

    .line 5
    invoke-virtual {p1, p0}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->setAnimation(Landroid/view/animation/Animation;)V

    .line 8
    return-void
.end method

.method public final onAnimationRepeat(Landroid/view/animation/Animation;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final onAnimationStart(Landroid/view/animation/Animation;)V
    .locals 0

    .line 1
    return-void
.end method
