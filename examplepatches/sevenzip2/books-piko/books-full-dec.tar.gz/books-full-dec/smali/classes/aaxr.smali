.class public final Laaxr;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 2

    .line 1
    new-instance p0, Laaxp;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance v0, Lalyv;

    .line 8
    const-class v1, Laaxw;

    .line 10
    invoke-direct {v0, v1, p0}, Lalyv;-><init>(Ljava/lang/Class;Lbhwq;)V

    .line 13
    return-object v0
.end method
