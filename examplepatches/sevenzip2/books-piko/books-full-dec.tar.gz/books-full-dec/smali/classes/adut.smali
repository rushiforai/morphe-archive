.class public final Ladut;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Ladsn;

.field public final b:Z

.field public final c:Z

.field public final d:I

.field public final e:I


# direct methods
.method public constructor <init>(Ladsn;Ljava/util/List;)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladut;->a:Ladsn;

    .line 6
    new-instance p1, Ljava/util/ArrayList;

    .line 8
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 11
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 14
    move-result-object p2

    .line 15
    :cond_0
    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_1

    .line 21
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 24
    move-result-object v0

    .line 25
    move-object v1, v0

    .line 26
    check-cast v1, Ladtf;

    .line 28
    iget-object v1, v1, Ladtf;->c:Ljava/lang/String;

    .line 30
    iget-object v2, p0, Ladut;->a:Ladsn;

    .line 32
    iget-object v2, v2, Ladsn;->a:Ljava/lang/String;

    .line 34
    invoke-static {v1, v2}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 37
    move-result v1

    .line 38
    if-eqz v1, :cond_0

    .line 40
    invoke-interface {p1, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 43
    goto :goto_0

    .line 44
    :cond_1
    invoke-static {p1}, Lbhrc;->K(Ljava/util/List;)Ljava/lang/Object;

    .line 47
    move-result-object p2

    .line 48
    check-cast p2, Ladtf;

    .line 50
    const/4 v0, 0x1

    .line 51
    const/4 v1, 0x0

    .line 52
    if-eqz p2, :cond_3

    .line 54
    iget p2, p2, Ladtf;->b:I

    .line 56
    and-int/lit8 p2, p2, 0x8

    .line 58
    if-eqz p2, :cond_2

    .line 60
    goto :goto_1

    .line 61
    :cond_2
    move p2, v0

    .line 62
    goto :goto_2

    .line 63
    :cond_3
    :goto_1
    move p2, v1

    .line 64
    :goto_2
    iput-boolean p2, p0, Ladut;->b:Z

    .line 66
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 69
    move-result p2

    .line 70
    invoke-interface {p1, p2}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 73
    move-result-object p2

    .line 74
    :cond_4
    invoke-interface {p2}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 77
    move-result v2

    .line 78
    if-eqz v2, :cond_5

    .line 80
    invoke-interface {p2}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 83
    move-result-object v2

    .line 84
    move-object v3, v2

    .line 85
    check-cast v3, Ladtf;

    .line 87
    iget v3, v3, Ladtf;->b:I

    .line 89
    and-int/lit8 v3, v3, 0x8

    .line 91
    if-eqz v3, :cond_4

    .line 93
    goto :goto_3

    .line 94
    :cond_5
    const/4 v2, 0x0

    .line 95
    :goto_3
    check-cast v2, Ladtf;

    .line 97
    if-eqz v2, :cond_7

    .line 99
    iget p2, v2, Ladtf;->f:I

    .line 101
    invoke-static {p2}, Ladtb;->a(I)I

    .line 104
    move-result p2

    .line 105
    if-nez p2, :cond_6

    .line 107
    move p2, v0

    .line 108
    :cond_6
    invoke-static {p2}, Ladux;->a(I)I

    .line 111
    move-result p2

    .line 112
    goto :goto_4

    .line 113
    :cond_7
    move p2, v1

    .line 114
    :goto_4
    iput p2, p0, Ladut;->e:I

    .line 116
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 119
    move-result p2

    .line 120
    if-eqz p2, :cond_8

    .line 122
    move p2, v1

    .line 123
    goto :goto_6

    .line 124
    :cond_8
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 127
    move-result-object p1

    .line 128
    move p2, v1

    .line 129
    :cond_9
    :goto_5
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 132
    move-result v2

    .line 133
    if-eqz v2, :cond_b

    .line 135
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 138
    move-result-object v2

    .line 139
    check-cast v2, Ladtf;

    .line 141
    iget v3, v2, Ladtf;->b:I

    .line 143
    and-int/lit8 v3, v3, 0x8

    .line 145
    if-eqz v3, :cond_9

    .line 147
    iget v2, v2, Ladtf;->f:I

    .line 149
    invoke-static {v2}, Ladtb;->a(I)I

    .line 152
    move-result v2

    .line 153
    if-nez v2, :cond_a

    .line 155
    move v2, v0

    .line 156
    :cond_a
    invoke-static {v2}, Ladux;->a(I)I

    .line 159
    move-result v2

    .line 160
    if-ne v2, v0, :cond_9

    .line 162
    add-int/lit8 p2, p2, 0x1

    .line 164
    if-gez p2, :cond_9

    .line 166
    invoke-static {}, Lbhrc;->k()V

    .line 169
    goto :goto_5

    .line 170
    :cond_b
    :goto_6
    iput p2, p0, Ladut;->d:I

    .line 172
    iget-object p1, p0, Ladut;->a:Ladsn;

    .line 174
    iget p1, p1, Ladsn;->c:I

    .line 176
    if-ltz p1, :cond_c

    .line 178
    if-lt p2, p1, :cond_c

    .line 180
    goto :goto_7

    .line 181
    :cond_c
    move v0, v1

    .line 182
    :goto_7
    iput-boolean v0, p0, Ladut;->c:Z

    .line 184
    return-void
.end method
