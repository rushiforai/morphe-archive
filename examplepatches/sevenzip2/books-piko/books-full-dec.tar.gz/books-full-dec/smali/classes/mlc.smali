.class public abstract Lmlc;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method protected abstract a()Ljava/lang/String;
.end method

.method protected abstract b(Lmrh;Ljava/lang/Object;)V
.end method

.method public final c(Lmsi;Ljava/lang/Iterable;)I
    .locals 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p0}, Lmlc;->a()Ljava/lang/String;

    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lmsi;->a(Ljava/lang/String;)Lmrh;

    .line 11
    move-result-object v0

    .line 12
    :try_start_0
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 15
    move-result-object p2

    .line 16
    const/4 v1, 0x0

    .line 17
    :cond_0
    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    move-result v2

    .line 21
    if-eqz v2, :cond_1

    .line 23
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    move-result-object v2

    .line 27
    if-eqz v2, :cond_0

    .line 29
    invoke-virtual {p0, v0, v2}, Lmlc;->b(Lmrh;Ljava/lang/Object;)V

    .line 32
    invoke-interface {v0}, Lmrh;->m()Z

    .line 35
    invoke-interface {v0}, Lmrh;->k()V

    .line 38
    invoke-static {p1}, Lmqa;->a(Lmsi;)I

    .line 41
    move-result v2

    .line 42
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    add-int/2addr v1, v2

    .line 43
    goto :goto_0

    .line 44
    :cond_1
    invoke-interface {v0}, Ljava/lang/AutoCloseable;->close()V

    .line 47
    return v1

    .line 48
    :catchall_0
    move-exception p0

    .line 49
    :try_start_1
    throw p0

    .line 50
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception p1

    .line 51
    :try_start_2
    invoke-interface {v0}, Ljava/lang/AutoCloseable;->close()V

    .line 54
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    goto :goto_1

    .line 55
    :catchall_2
    move-exception p2

    .line 56
    invoke-static {p0, p2}, Lbhpc;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 59
    :goto_1
    throw p1
.end method

.method public final d(Lmsi;Ljava/lang/Object;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    if-nez p2, :cond_0

    .line 6
    return-void

    .line 7
    :cond_0
    invoke-virtual {p0}, Lmlc;->a()Ljava/lang/String;

    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {p1, v0}, Lmsi;->a(Ljava/lang/String;)Lmrh;

    .line 14
    move-result-object v0

    .line 15
    :try_start_0
    invoke-virtual {p0, v0, p2}, Lmlc;->b(Lmrh;Ljava/lang/Object;)V

    .line 18
    invoke-interface {v0}, Lmrh;->m()Z

    .line 21
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 p0, 0x0

    .line 22
    invoke-static {v0, p0}, Lbhwc;->a(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    .line 25
    invoke-static {p1}, Lmqa;->a(Lmsi;)I

    .line 28
    return-void

    .line 29
    :catchall_0
    move-exception p0

    .line 30
    :try_start_1
    throw p0

    .line 31
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception p1

    .line 32
    invoke-static {v0, p0}, Lbhwc;->a(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    .line 35
    throw p1
.end method
