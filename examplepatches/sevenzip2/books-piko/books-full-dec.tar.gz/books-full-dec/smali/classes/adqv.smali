.class public final Ladqv;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;

.field private final g:Lbeye;

.field private final h:Lbeye;

.field private final i:Lbeye;

.field private final j:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladqv;->a:Lbeye;

    .line 6
    iput-object p2, p0, Ladqv;->b:Lbeye;

    .line 8
    iput-object p3, p0, Ladqv;->c:Lbeye;

    .line 10
    iput-object p4, p0, Ladqv;->d:Lbeye;

    .line 12
    iput-object p5, p0, Ladqv;->e:Lbeye;

    .line 14
    iput-object p6, p0, Ladqv;->f:Lbeye;

    .line 16
    iput-object p7, p0, Ladqv;->g:Lbeye;

    .line 18
    iput-object p8, p0, Ladqv;->h:Lbeye;

    .line 20
    iput-object p9, p0, Ladqv;->i:Lbeye;

    .line 22
    iput-object p10, p0, Ladqv;->j:Lbeye;

    .line 24
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 12

    .line 1
    iget-object v0, p0, Ladqv;->a:Lbeye;

    .line 3
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    move-object v2, v0

    .line 8
    check-cast v2, Lahjo;

    .line 10
    iget-object v0, p0, Ladqv;->b:Lbeye;

    .line 12
    check-cast v0, Lpwn;

    .line 14
    invoke-virtual {v0}, Lpwn;->a()Landroid/accounts/Account;

    .line 17
    move-result-object v3

    .line 18
    iget-object v0, p0, Ladqv;->c:Lbeye;

    .line 20
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 23
    move-result-object v0

    .line 24
    move-object v4, v0

    .line 25
    check-cast v4, Lahjj;

    .line 27
    iget-object v0, p0, Ladqv;->d:Lbeye;

    .line 29
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 32
    move-result-object v0

    .line 33
    move-object v5, v0

    .line 34
    check-cast v5, Ladrb;

    .line 36
    iget-object v0, p0, Ladqv;->e:Lbeye;

    .line 38
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 41
    move-result-object v0

    .line 42
    move-object v6, v0

    .line 43
    check-cast v6, Luxd;

    .line 45
    iget-object v0, p0, Ladqv;->f:Lbeye;

    .line 47
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 50
    move-result-object v0

    .line 51
    move-object v7, v0

    .line 52
    check-cast v7, Lwon;

    .line 54
    iget-object v0, p0, Ladqv;->g:Lbeye;

    .line 56
    check-cast v0, Lpps;

    .line 58
    invoke-virtual {v0}, Lpps;->a()Lppr;

    .line 61
    move-result-object v8

    .line 62
    iget-object v0, p0, Ladqv;->h:Lbeye;

    .line 64
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 67
    move-result-object v0

    .line 68
    move-object v9, v0

    .line 69
    check-cast v9, Layhy;

    .line 71
    iget-object v0, p0, Ladqv;->i:Lbeye;

    .line 73
    check-cast v0, Loxv;

    .line 75
    invoke-virtual {v0}, Loxv;->a()Loxu;

    .line 78
    move-result-object v10

    .line 79
    iget-object p0, p0, Ladqv;->j:Lbeye;

    .line 81
    check-cast p0, Lahkb;

    .line 83
    invoke-virtual {p0}, Lahkb;->a()Lahka;

    .line 86
    move-result-object v11

    .line 87
    new-instance v1, Ladqu;

    .line 89
    invoke-direct/range {v1 .. v11}, Ladqu;-><init>(Lahjo;Landroid/accounts/Account;Lahjj;Ladrb;Luxd;Lwon;Lppr;Layhy;Loxu;Lahka;)V

    .line 92
    return-object v1
.end method
