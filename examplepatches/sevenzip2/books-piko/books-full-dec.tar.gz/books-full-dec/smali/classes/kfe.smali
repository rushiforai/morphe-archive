.class public interface abstract Lkfe;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract Q()Lkfd;
.end method
