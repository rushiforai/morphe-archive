.class public final Ladcx;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladcx;->a:Lbeye;

    .line 6
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object p0, p0, Ladcx;->a:Lbeye;

    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {}, Lbfys;->c()Z

    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_0

    .line 12
    check-cast p0, Ladcg;

    .line 14
    invoke-virtual {p0}, Ladcg;->a()Ladcf;

    .line 17
    move-result-object p0

    .line 18
    invoke-static {p0}, Layhy;->i(Ljava/lang/Object;)Layhy;

    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :cond_0
    sget-object p0, Laygr;->a:Laygr;

    .line 25
    return-object p0
.end method
