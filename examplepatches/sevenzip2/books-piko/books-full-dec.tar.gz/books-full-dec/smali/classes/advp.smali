.class public final synthetic Ladvp;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladvp;->a:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 6
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 1
    iget-object p0, p0, Ladvp;->a:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 3
    invoke-virtual {p0}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->b()V

    .line 6
    return-void
.end method
