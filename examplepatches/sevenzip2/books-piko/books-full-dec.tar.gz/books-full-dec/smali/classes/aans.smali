.class public final Laans;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;

.field private final g:Lbeye;

.field private final h:Lbeye;

.field private final i:Lbeye;

.field private final j:Lbeye;

.field private final k:Lbeye;

.field private final l:Lbeye;

.field private final m:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laans;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laans;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laans;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laans;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laans;->e:Lbeye;

    .line 14
    iput-object p6, p0, Laans;->f:Lbeye;

    .line 16
    iput-object p7, p0, Laans;->g:Lbeye;

    .line 18
    iput-object p8, p0, Laans;->h:Lbeye;

    .line 20
    iput-object p9, p0, Laans;->i:Lbeye;

    .line 22
    iput-object p10, p0, Laans;->j:Lbeye;

    .line 24
    iput-object p11, p0, Laans;->k:Lbeye;

    .line 26
    iput-object p12, p0, Laans;->l:Lbeye;

    .line 28
    iput-object p13, p0, Laans;->m:Lbeye;

    .line 30
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 14

    .line 1
    new-instance v0, Laanr;

    .line 3
    iget-object v1, p0, Laans;->a:Lbeye;

    .line 5
    iget-object v2, p0, Laans;->b:Lbeye;

    .line 7
    iget-object v3, p0, Laans;->c:Lbeye;

    .line 9
    iget-object v4, p0, Laans;->d:Lbeye;

    .line 11
    iget-object v5, p0, Laans;->e:Lbeye;

    .line 13
    iget-object v6, p0, Laans;->f:Lbeye;

    .line 15
    iget-object v7, p0, Laans;->g:Lbeye;

    .line 17
    iget-object v8, p0, Laans;->h:Lbeye;

    .line 19
    iget-object v9, p0, Laans;->i:Lbeye;

    .line 21
    iget-object v10, p0, Laans;->j:Lbeye;

    .line 23
    iget-object v11, p0, Laans;->k:Lbeye;

    .line 25
    iget-object v12, p0, Laans;->l:Lbeye;

    .line 27
    iget-object v13, p0, Laans;->m:Lbeye;

    .line 29
    invoke-direct/range {v0 .. v13}, Laanr;-><init>(Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;)V

    .line 32
    return-object v0
.end method
