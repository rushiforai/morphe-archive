.class public final Laehz;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laehz;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laehz;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laehz;->c:Lbeye;

    .line 10
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, Laehz;->a:Lbeye;

    .line 3
    check-cast v0, Lpwn;

    .line 5
    invoke-virtual {v0}, Lpwn;->a()Landroid/accounts/Account;

    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Laehz;->b:Lbeye;

    .line 11
    invoke-interface {v1}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Landroid/content/SharedPreferences;

    .line 17
    iget-object p0, p0, Laehz;->c:Lbeye;

    .line 19
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 22
    move-result-object p0

    .line 23
    check-cast p0, Laerj;

    .line 25
    sget-object v2, Lwos;->k:Ljava/lang/String;

    .line 27
    invoke-static {v0, v1, v2, p0}, Laerj;->a(Landroid/accounts/Account;Landroid/content/SharedPreferences;Ljava/lang/String;Laerj;)Laoyr;

    .line 30
    move-result-object p0

    .line 31
    return-object p0
.end method
