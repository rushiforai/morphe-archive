.class public final Ladur;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Ladsy;


# static fields
.field public static final a:Layxl;


# instance fields
.field public final b:Lbifi;

.field public final c:Lbifi;

.field private final d:Lbifq;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "com/google/android/apps/play/books/educampaign/manager/EduCampaignManagerProviderImpl"

    .line 3
    invoke-static {v0}, Layxl;->i(Ljava/lang/String;)Layxl;

    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Ladur;->a:Layxl;

    .line 9
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lbifb;Lbifb;Ladtt;)V
    .locals 1

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    invoke-static {p2}, Lbifj;->b(Lbhuc;)Lbifi;

    .line 13
    move-result-object p2

    .line 14
    iput-object p2, p0, Ladur;->b:Lbifi;

    .line 16
    invoke-static {p3}, Lbifj;->b(Lbhuc;)Lbifi;

    .line 19
    move-result-object p2

    .line 20
    iput-object p2, p0, Ladur;->c:Lbifi;

    .line 22
    new-instance p3, Laduq;

    .line 24
    const/4 v0, 0x0

    .line 25
    invoke-direct {p3, p0, p4, p1, v0}, Laduq;-><init>(Ladur;Ladtt;Landroid/content/Context;Lbhtu;)V

    .line 28
    const/4 p1, 0x1

    .line 29
    const/4 p4, 0x2

    .line 30
    invoke-static {p2, v0, p4, p3, p1}, Lbidy;->d(Lbifi;Lbhuc;ILbhwu;I)Lbifq;

    .line 33
    move-result-object p1

    .line 34
    iput-object p1, p0, Ladur;->d:Lbifq;

    .line 36
    return-void
.end method


# virtual methods
.method public final a(Lbhtu;)Ljava/lang/Object;
    .locals 4

    .line 1
    instance-of v0, p1, Laduk;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Laduk;

    .line 8
    iget v1, v0, Laduk;->c:I

    .line 10
    const/high16 v2, -0x80000000

    .line 12
    and-int v3, v1, v2

    .line 14
    if-eqz v3, :cond_0

    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Laduk;->c:I

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Laduk;

    .line 22
    invoke-direct {v0, p0, p1}, Laduk;-><init>(Ladur;Lbhtu;)V

    .line 25
    :goto_0
    iget-object p1, v0, Laduk;->a:Ljava/lang/Object;

    .line 27
    sget-object v1, Lbhug;->a:Lbhug;

    .line 29
    iget v2, v0, Laduk;->c:I

    .line 31
    const/4 v3, 0x1

    .line 32
    if-eqz v2, :cond_2

    .line 34
    if-ne v2, v3, :cond_1

    .line 36
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 39
    goto :goto_1

    .line 40
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 42
    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 44
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 47
    throw p0

    .line 48
    :cond_2
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 51
    iget-object p0, p0, Ladur;->d:Lbifq;

    .line 53
    iput v3, v0, Laduk;->c:I

    .line 55
    invoke-interface {p0, v0}, Lbifq;->a(Lbhtu;)Ljava/lang/Object;

    .line 58
    move-result-object p1

    .line 59
    if-ne p1, v1, :cond_3

    .line 61
    return-object v1

    .line 62
    :cond_3
    :goto_1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 65
    return-object p1
.end method
