.class public final Lacfp;
.super Lmnb;
.source "PG"


# instance fields
.field final synthetic d:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase_Impl;


# direct methods
.method public constructor <init>(Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase_Impl;)V
    .locals 2

    .line 1
    iput-object p1, p0, Lacfp;->d:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase_Impl;

    .line 3
    const-string p1, "a56b42c0715cfc0f63dfa4fc668cc306"

    .line 5
    const-string v0, "b74b6b07b5ff28cbe05ea82d9a876345"

    .line 7
    const/4 v1, 0x1

    .line 8
    invoke-direct {p0, v1, p1, v0}, Lmnb;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 11
    return-void
.end method


# virtual methods
.method public final a(Lmsi;)Lmna;
    .locals 12

    .line 1
    new-instance p0, Ljava/util/HashMap;

    .line 3
    const/4 v0, 0x4

    .line 4
    invoke-direct {p0, v0}, Ljava/util/HashMap;-><init>(I)V

    .line 7
    new-instance v1, Lmqh;

    .line 9
    const/4 v6, 0x0

    .line 10
    const/4 v7, 0x1

    .line 11
    const-string v2, "volumeId"

    .line 13
    const-string v3, "TEXT"

    .line 15
    const/4 v4, 0x1

    .line 16
    const/4 v5, 0x1

    .line 17
    invoke-direct/range {v1 .. v7}, Lmqh;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 20
    const-string v0, "volumeId"

    .line 22
    invoke-interface {p0, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    new-instance v2, Lmqh;

    .line 27
    const/4 v7, 0x0

    .line 28
    const/4 v8, 0x1

    .line 29
    const-string v3, "remainingCharacterCount"

    .line 31
    const-string v4, "INTEGER"

    .line 33
    const/4 v6, 0x0

    .line 34
    invoke-direct/range {v2 .. v8}, Lmqh;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 37
    const-string v1, "remainingCharacterCount"

    .line 39
    invoke-interface {p0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    new-instance v3, Lmqh;

    .line 44
    const/4 v8, 0x0

    .line 45
    const/4 v9, 0x1

    .line 46
    const-string v4, "allowedCharacterCount"

    .line 48
    const-string v5, "INTEGER"

    .line 50
    const/4 v6, 0x1

    .line 51
    const/4 v7, 0x0

    .line 52
    invoke-direct/range {v3 .. v9}, Lmqh;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 55
    const-string v1, "allowedCharacterCount"

    .line 57
    invoke-interface {p0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    new-instance v4, Lmqh;

    .line 62
    const/4 v9, 0x0

    .line 63
    const/4 v10, 0x1

    .line 64
    const-string v5, "limitType"

    .line 66
    const-string v6, "TEXT"

    .line 68
    const/4 v7, 0x1

    .line 69
    const/4 v8, 0x0

    .line 70
    invoke-direct/range {v4 .. v10}, Lmqh;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 73
    const-string v1, "limitType"

    .line 75
    invoke-interface {p0, v1, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 78
    new-instance v1, Ljava/util/HashSet;

    .line 80
    const/4 v2, 0x0

    .line 81
    invoke-direct {v1, v2}, Ljava/util/HashSet;-><init>(I)V

    .line 84
    new-instance v3, Ljava/util/HashSet;

    .line 86
    invoke-direct {v3, v2}, Ljava/util/HashSet;-><init>(I)V

    .line 89
    new-instance v4, Lmqk;

    .line 91
    const-string v5, "copy_quota"

    .line 93
    invoke-direct {v4, v5, p0, v1, v3}, Lmqk;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/Set;Ljava/util/Set;)V

    .line 96
    invoke-static {p1, v5}, Lmqf;->a(Lmsi;Ljava/lang/String;)Lmqk;

    .line 99
    move-result-object p0

    .line 100
    invoke-static {v4, p0}, Lmqn;->f(Lmqk;Ljava/lang/Object;)Z

    .line 103
    move-result v1

    .line 104
    if-nez v1, :cond_0

    .line 106
    new-instance p1, Lmna;

    .line 108
    const-string v0, "copy_quota(com.google.android.apps.play.books.ebook.copyquota.CopyQuotaEntity).\n Expected:\n"

    .line 110
    invoke-static {p0, v4, v0}, La;->C(Lmqk;Lmqk;Ljava/lang/String;)Ljava/lang/String;

    .line 113
    move-result-object p0

    .line 114
    invoke-direct {p1, v2, p0}, Lmna;-><init>(ZLjava/lang/String;)V

    .line 117
    return-object p1

    .line 118
    :cond_0
    new-instance p0, Ljava/util/HashMap;

    .line 120
    const/4 v1, 0x3

    .line 121
    invoke-direct {p0, v1}, Ljava/util/HashMap;-><init>(I)V

    .line 124
    new-instance v3, Lmqh;

    .line 126
    const/4 v8, 0x0

    .line 127
    const/4 v9, 0x1

    .line 128
    const-string v4, "volumeId"

    .line 130
    const-string v5, "TEXT"

    .line 132
    const/4 v6, 0x1

    .line 133
    const/4 v7, 0x0

    .line 134
    invoke-direct/range {v3 .. v9}, Lmqh;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 137
    invoke-interface {p0, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 140
    new-instance v4, Lmqh;

    .line 142
    const/4 v9, 0x0

    .line 143
    const/4 v10, 0x1

    .line 144
    const-string v5, "copiedCharacterCount"

    .line 146
    const-string v6, "INTEGER"

    .line 148
    const/4 v7, 0x1

    .line 149
    const/4 v8, 0x0

    .line 150
    invoke-direct/range {v4 .. v10}, Lmqh;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 153
    const-string v0, "copiedCharacterCount"

    .line 155
    invoke-interface {p0, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 158
    new-instance v5, Lmqh;

    .line 160
    const/4 v10, 0x0

    .line 161
    const/4 v11, 0x1

    .line 162
    const-string v6, "updateId"

    .line 164
    const-string v7, "INTEGER"

    .line 166
    const/4 v8, 0x1

    .line 167
    const/4 v9, 0x1

    .line 168
    invoke-direct/range {v5 .. v11}, Lmqh;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 171
    const-string v0, "updateId"

    .line 173
    invoke-interface {p0, v0, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 176
    new-instance v0, Ljava/util/HashSet;

    .line 178
    invoke-direct {v0, v2}, Ljava/util/HashSet;-><init>(I)V

    .line 181
    new-instance v1, Ljava/util/HashSet;

    .line 183
    invoke-direct {v1, v2}, Ljava/util/HashSet;-><init>(I)V

    .line 186
    new-instance v3, Lmqk;

    .line 188
    const-string v4, "pending_copy_quota_updates"

    .line 190
    invoke-direct {v3, v4, p0, v0, v1}, Lmqk;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/Set;Ljava/util/Set;)V

    .line 193
    invoke-static {p1, v4}, Lmqf;->a(Lmsi;Ljava/lang/String;)Lmqk;

    .line 196
    move-result-object p0

    .line 197
    invoke-static {v3, p0}, Lmqn;->f(Lmqk;Ljava/lang/Object;)Z

    .line 200
    move-result p1

    .line 201
    if-nez p1, :cond_1

    .line 203
    new-instance p1, Lmna;

    .line 205
    const-string v0, "pending_copy_quota_updates(com.google.android.apps.play.books.ebook.copyquota.PendingCopyQuotaUpdateEntity).\n Expected:\n"

    .line 207
    invoke-static {p0, v3, v0}, La;->C(Lmqk;Lmqk;Ljava/lang/String;)Ljava/lang/String;

    .line 210
    move-result-object p0

    .line 211
    invoke-direct {p1, v2, p0}, Lmna;-><init>(ZLjava/lang/String;)V

    .line 214
    return-object p1

    .line 215
    :cond_1
    new-instance p0, Lmna;

    .line 217
    const/4 p1, 0x1

    .line 218
    const/4 v0, 0x0

    .line 219
    invoke-direct {p0, p1, v0}, Lmna;-><init>(ZLjava/lang/String;)V

    .line 222
    return-object p0
.end method

.method public final b(Lmsi;)V
    .locals 0

    .line 1
    const-string p0, "CREATE TABLE IF NOT EXISTS `copy_quota` (`volumeId` TEXT NOT NULL, `remainingCharacterCount` INTEGER NOT NULL, `allowedCharacterCount` INTEGER NOT NULL, `limitType` TEXT NOT NULL, PRIMARY KEY(`volumeId`))"

    .line 3
    invoke-static {p1, p0}, Lmrj;->a(Lmsi;Ljava/lang/String;)V

    .line 6
    const-string p0, "CREATE TABLE IF NOT EXISTS `pending_copy_quota_updates` (`volumeId` TEXT NOT NULL, `copiedCharacterCount` INTEGER NOT NULL, `updateId` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL)"

    .line 8
    invoke-static {p1, p0}, Lmrj;->a(Lmsi;Ljava/lang/String;)V

    .line 11
    const-string p0, "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)"

    .line 13
    invoke-static {p1, p0}, Lmrj;->a(Lmsi;Ljava/lang/String;)V

    .line 16
    const-string p0, "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, \'a56b42c0715cfc0f63dfa4fc668cc306\')"

    .line 18
    invoke-static {p1, p0}, Lmrj;->a(Lmsi;Ljava/lang/String;)V

    .line 21
    return-void
.end method

.method public final c(Lmsi;)V
    .locals 0

    .line 1
    const-string p0, "DROP TABLE IF EXISTS `copy_quota`"

    .line 3
    invoke-static {p1, p0}, Lmrj;->a(Lmsi;Ljava/lang/String;)V

    .line 6
    const-string p0, "DROP TABLE IF EXISTS `pending_copy_quota_updates`"

    .line 8
    invoke-static {p1, p0}, Lmrj;->a(Lmsi;Ljava/lang/String;)V

    .line 11
    return-void
.end method

.method public final d(Lmsi;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lacfp;->d:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase_Impl;

    .line 3
    invoke-virtual {p0, p1}, Lmmt;->w(Lmsi;)V

    .line 6
    return-void
.end method

.method public final e(Lmsi;)V
    .locals 0

    .line 1
    invoke-static {p1}, Lmpf;->a(Lmsi;)V

    .line 4
    return-void
.end method

.method public final f()V
    .locals 0

    .line 1
    return-void
.end method

.method public final g()V
    .locals 0

    .line 1
    return-void
.end method
