.class public final Ladto;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladto;->a:Lbeye;

    .line 6
    iput-object p2, p0, Ladto;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, Ladto;->a:Lbeye;

    .line 3
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ladsy;

    .line 9
    new-instance v1, Ladvg;

    .line 11
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 14
    iget-object p0, p0, Ladto;->b:Lbeye;

    .line 16
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 19
    move-result-object p0

    .line 20
    check-cast p0, Lavnw;

    .line 22
    new-instance v2, Ladtn;

    .line 24
    invoke-direct {v2, v0, v1, p0}, Ladtn;-><init>(Ladsy;Laduz;Lavnw;)V

    .line 27
    return-object v2
.end method
