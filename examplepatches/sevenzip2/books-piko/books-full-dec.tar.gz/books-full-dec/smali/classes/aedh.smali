.class final Laedh;
.super Laedm;
.source "PG"


# instance fields
.field final synthetic a:Laedn;


# direct methods
.method public constructor <init>(Laedn;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laedh;->a:Laedn;

    .line 3
    invoke-direct {p0}, Laedm;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public final b()V
    .locals 1

    .line 1
    iget-object p0, p0, Laedh;->a:Laedn;

    .line 3
    sget-object v0, Laeel;->e:Laeel;

    .line 5
    invoke-virtual {p0, v0}, Laedn;->o(Laeel;)V

    .line 8
    return-void
.end method

.method public final h()V
    .locals 2

    .line 1
    iget-object v0, p0, Laedh;->a:Laedn;

    .line 3
    iget-object v0, v0, Laedn;->p:Laeel;

    .line 5
    sget-object v1, Laeel;->e:Laeel;

    .line 7
    if-eq v0, v1, :cond_0

    .line 9
    const/4 v0, 0x1

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const/4 v0, 0x0

    .line 12
    :goto_0
    invoke-virtual {p0, v0}, Lacb;->g(Z)V

    .line 15
    return-void
.end method
