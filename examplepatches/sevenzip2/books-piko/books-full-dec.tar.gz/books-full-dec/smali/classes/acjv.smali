.class public final synthetic Lacjv;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lyff;


# instance fields
.field public final synthetic a:Lacjx;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Lajut;


# direct methods
.method public synthetic constructor <init>(Lacjx;Lajut;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacjv;->a:Lacjx;

    .line 6
    iput-object p2, p0, Lacjv;->c:Lajut;

    .line 8
    iput-object p3, p0, Lacjv;->b:Ljava/lang/String;

    .line 10
    return-void
.end method


# virtual methods
.method public final a()Ljava/io/File;
    .locals 2

    .line 1
    iget-object v0, p0, Lacjv;->a:Lacjx;

    .line 3
    iget-object v1, p0, Lacjv;->c:Lajut;

    .line 5
    iget-object p0, p0, Lacjv;->b:Ljava/lang/String;

    .line 7
    invoke-virtual {v0, v1, p0}, Lacjx;->q(Lajut;Ljava/lang/String;)Ljava/io/File;

    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method
