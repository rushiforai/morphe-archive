.class public final Labxb;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;

.field private final g:Lbeye;

.field private final h:Lbeye;

.field private final i:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labxb;->a:Lbeye;

    .line 6
    iput-object p2, p0, Labxb;->b:Lbeye;

    .line 8
    iput-object p3, p0, Labxb;->c:Lbeye;

    .line 10
    iput-object p4, p0, Labxb;->d:Lbeye;

    .line 12
    iput-object p5, p0, Labxb;->e:Lbeye;

    .line 14
    iput-object p6, p0, Labxb;->f:Lbeye;

    .line 16
    iput-object p7, p0, Labxb;->g:Lbeye;

    .line 18
    iput-object p8, p0, Labxb;->h:Lbeye;

    .line 20
    iput-object p9, p0, Labxb;->i:Lbeye;

    .line 22
    return-void
.end method


# virtual methods
.method public final a()Labxa;
    .locals 10

    .line 1
    new-instance v0, Labxa;

    .line 3
    iget-object v1, p0, Labxb;->a:Lbeye;

    .line 5
    iget-object v2, p0, Labxb;->b:Lbeye;

    .line 7
    iget-object v3, p0, Labxb;->c:Lbeye;

    .line 9
    iget-object v4, p0, Labxb;->d:Lbeye;

    .line 11
    iget-object v5, p0, Labxb;->e:Lbeye;

    .line 13
    iget-object v6, p0, Labxb;->f:Lbeye;

    .line 15
    iget-object v7, p0, Labxb;->g:Lbeye;

    .line 17
    iget-object v8, p0, Labxb;->h:Lbeye;

    .line 19
    iget-object v9, p0, Labxb;->i:Lbeye;

    .line 21
    invoke-direct/range {v0 .. v9}, Labxa;-><init>(Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;)V

    .line 24
    return-object v0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Labxb;->a()Labxa;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
