.class public final Lacey;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lacek;
.implements Lacfu;


# instance fields
.field public final a:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase;

.field public final b:Lacfa;

.field public final c:Lavnw;

.field public final d:Lbifb;

.field public final e:Lbiot;

.field private final f:Lnfp;

.field private final g:Landroid/accounts/Account;

.field private final h:Lbifi;


# direct methods
.method public constructor <init>(Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase;Lacfa;Lavnw;Lnfp;Landroid/accounts/Account;Lbifb;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    iput-object p1, p0, Lacey;->a:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase;

    .line 15
    iput-object p2, p0, Lacey;->b:Lacfa;

    .line 17
    iput-object p3, p0, Lacey;->c:Lavnw;

    .line 19
    iput-object p4, p0, Lacey;->f:Lnfp;

    .line 21
    iput-object p5, p0, Lacey;->g:Landroid/accounts/Account;

    .line 23
    iput-object p6, p0, Lacey;->d:Lbifb;

    .line 25
    invoke-static {p6}, Lbifj;->b(Lbhuc;)Lbifi;

    .line 28
    move-result-object p1

    .line 29
    iput-object p1, p0, Lacey;->h:Lbifi;

    .line 31
    const/4 p2, 0x6

    .line 32
    const/4 p3, 0x1

    .line 33
    const/4 p4, 0x0

    .line 34
    invoke-static {p3, p4, p4, p2}, Lbipc;->d(IIII)Lbiot;

    .line 37
    move-result-object p2

    .line 38
    iput-object p2, p0, Lacey;->e:Lbiot;

    .line 40
    new-instance p2, Lacel;

    .line 42
    const/4 p3, 0x0

    .line 43
    invoke-direct {p2, p0, p3}, Lacel;-><init>(Lacey;Lbhtu;)V

    .line 46
    const/4 p0, 0x3

    .line 47
    invoke-static {p1, p3, p4, p2, p0}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 50
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;JLbhtu;)Ljava/lang/Object;
    .locals 10

    .line 1
    instance-of v0, p4, Lacen;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    move-object v0, p4

    .line 6
    check-cast v0, Lacen;

    .line 8
    iget v1, v0, Lacen;->c:I

    .line 10
    const/high16 v2, -0x80000000

    .line 12
    and-int v3, v1, v2

    .line 14
    if-eqz v3, :cond_0

    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lacen;->c:I

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lacen;

    .line 22
    invoke-direct {v0, p0, p4}, Lacen;-><init>(Lacey;Lbhtu;)V

    .line 25
    :goto_0
    iget-object p4, v0, Lacen;->a:Ljava/lang/Object;

    .line 27
    sget-object v1, Lbhug;->a:Lbhug;

    .line 29
    iget v2, v0, Lacen;->c:I

    .line 31
    const/4 v3, 0x1

    .line 32
    if-eqz v2, :cond_2

    .line 34
    if-ne v2, v3, :cond_1

    .line 36
    invoke-static {p4}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 39
    goto :goto_1

    .line 40
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 42
    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 44
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 47
    throw p0

    .line 48
    :cond_2
    invoke-static {p4}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 51
    iget-object p4, p0, Lacey;->d:Lbifb;

    .line 53
    new-instance v4, Laceo;

    .line 55
    const/4 v9, 0x0

    .line 56
    move-object v5, p0

    .line 57
    move-object v6, p1

    .line 58
    move-wide v7, p2

    .line 59
    invoke-direct/range {v4 .. v9}, Laceo;-><init>(Lacey;Ljava/lang/String;JLbhtu;)V

    .line 62
    iput v3, v0, Lacen;->c:I

    .line 64
    invoke-static {p4, v4, v0}, Lbidy;->a(Lbhuc;Lbhwu;Lbhtu;)Ljava/lang/Object;

    .line 67
    move-result-object p0

    .line 68
    if-ne p0, v1, :cond_3

    .line 70
    return-object v1

    .line 71
    :cond_3
    :goto_1
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 73
    return-object p0
.end method

.method public final b(Lbhwu;Lbhtu;)Ljava/lang/Object;
    .locals 2

    .line 1
    new-instance v0, Lacex;

    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, p0, p1, v1}, Lacex;-><init>(Lacey;Lbhwu;Lbhtu;)V

    .line 7
    iget-object p0, p0, Lacey;->d:Lbifb;

    .line 9
    invoke-static {p0, v0, p2}, Lbidy;->a(Lbhuc;Lbhwu;Lbhtu;)Ljava/lang/Object;

    .line 12
    move-result-object p0

    .line 13
    sget-object p1, Lbhug;->a:Lbhug;

    .line 15
    if-ne p0, p1, :cond_0

    .line 17
    return-object p0

    .line 18
    :cond_0
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 20
    return-object p0
.end method

.method public final c(Ljava/lang/String;)Lbilb;
    .locals 4

    .line 1
    new-instance v0, Lbhyc;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    const/4 v1, 0x1

    .line 7
    iput-boolean v1, v0, Lbhyc;->a:Z

    .line 9
    new-instance v1, Laceq;

    .line 11
    iget-object v2, p0, Lacey;->e:Lbiot;

    .line 13
    const/4 v3, 0x0

    .line 14
    invoke-direct {v1, v2, v3, v0, p1}, Laceq;-><init>(Lbilb;Lbhtu;Lbhyc;Ljava/lang/String;)V

    .line 17
    new-instance v0, Lbiox;

    .line 19
    invoke-direct {v0, v1}, Lbiox;-><init>(Lbhwu;)V

    .line 22
    new-instance v1, Lacet;

    .line 24
    invoke-direct {v1, v0, p0, p1}, Lacet;-><init>(Lbilb;Lacey;Ljava/lang/String;)V

    .line 27
    return-object v1
.end method

.method public final d()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-virtual {p0, v0}, Lacey;->e(Z)V

    .line 5
    return-void
.end method

.method public final e(Z)V
    .locals 5

    .line 1
    new-instance v0, Lnes;

    .line 3
    const-class v1, Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 5
    invoke-direct {v0, v1}, Lnfq;-><init>(Ljava/lang/Class;)V

    .line 8
    new-instance v1, Lndl;

    .line 10
    invoke-direct {v1}, Lndl;-><init>()V

    .line 13
    const/4 v2, 0x2

    .line 14
    invoke-virtual {v1, v2}, Lndl;->b(I)V

    .line 17
    invoke-virtual {v1}, Lndl;->a()Lndn;

    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v0, v1}, Lnfq;->d(Lndn;)V

    .line 24
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 26
    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 29
    iget-object v2, p0, Lacey;->g:Landroid/accounts/Account;

    .line 31
    iget-object v3, v2, Landroid/accounts/Account;->name:Ljava/lang/String;

    .line 33
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    const-string v4, "accountName"

    .line 38
    invoke-static {v4, v3, v1}, Lnds;->e(Ljava/lang/String;Ljava/lang/Object;Ljava/util/Map;)V

    .line 41
    const-string v3, "fetch_full_library"

    .line 43
    invoke-static {v3, p1, v1}, Lnds;->f(Ljava/lang/String;ZLjava/util/Map;)V

    .line 46
    invoke-static {v1}, Lnds;->a(Ljava/util/Map;)Lndv;

    .line 49
    move-result-object v1

    .line 50
    invoke-virtual {v0, v1}, Lnfq;->g(Lndv;)V

    .line 53
    const-string v1, "copyQuotaSyncWorker"

    .line 55
    invoke-virtual {v0, v1}, Lnfq;->c(Ljava/lang/String;)V

    .line 58
    invoke-virtual {v0}, Lnfq;->b()Lnfr;

    .line 61
    move-result-object v0

    .line 62
    check-cast v0, Lnet;

    .line 64
    if-eqz p1, :cond_0

    .line 66
    const-string p1, "copy_quota_upload_and_fetch_"

    .line 68
    invoke-static {v2, p1}, La;->B(Landroid/accounts/Account;Ljava/lang/String;)Ljava/lang/String;

    .line 71
    move-result-object p1

    .line 72
    goto :goto_0

    .line 73
    :cond_0
    const-string p1, "copy_quota_upload_"

    .line 75
    invoke-static {v2, p1}, La;->B(Landroid/accounts/Account;Ljava/lang/String;)Ljava/lang/String;

    .line 78
    move-result-object p1

    .line 79
    :goto_0
    iget-object p0, p0, Lacey;->f:Lnfp;

    .line 81
    const/4 v1, 0x1

    .line 82
    invoke-virtual {p0, p1, v1, v0}, Lnfp;->d(Ljava/lang/String;ILnet;)Lney;

    .line 85
    return-void
.end method
