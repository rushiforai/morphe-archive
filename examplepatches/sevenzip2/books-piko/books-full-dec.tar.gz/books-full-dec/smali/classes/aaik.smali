.class public final Laaik;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laaik;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laaik;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, Laaik;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v0

    .line 9
    invoke-static {}, Lzvs;->a()Lalyv;

    .line 12
    move-result-object v1

    .line 13
    iget-object p0, p0, Laaik;->b:Lbeye;

    .line 15
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 18
    move-result-object p0

    .line 19
    check-cast p0, Laawx;

    .line 21
    new-instance v2, Laaij;

    .line 23
    invoke-direct {v2, v0, v1, p0}, Laaij;-><init>(Ldw;Lalyv;Laawx;)V

    .line 26
    return-object v2
.end method
