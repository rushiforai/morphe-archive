.class public final synthetic Ladub;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwf;


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 0

    .line 1
    const-string p0, "marking as CRASHED"

    .line 3
    return-object p0
.end method
