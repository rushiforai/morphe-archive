.class public abstract Lmld;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract a()Ljava/lang/String;
.end method

.method public abstract b(Lmrh;Ljava/lang/Object;)V
.end method

.method public final c(Lmsi;Ljava/util/Collection;)Ljava/util/List;
    .locals 4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    new-instance v0, Lbhsr;

    .line 6
    const/16 v1, 0xa

    .line 8
    invoke-direct {v0, v1}, Lbhsr;-><init>(I)V

    .line 11
    invoke-virtual {p0}, Lmld;->a()Ljava/lang/String;

    .line 14
    move-result-object v1

    .line 15
    invoke-virtual {p1, v1}, Lmsi;->a(Ljava/lang/String;)Lmrh;

    .line 18
    move-result-object v1

    .line 19
    :try_start_0
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 22
    move-result-object p2

    .line 23
    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 26
    move-result v2

    .line 27
    if-eqz v2, :cond_1

    .line 29
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 32
    move-result-object v2

    .line 33
    if-eqz v2, :cond_0

    .line 35
    invoke-virtual {p0, v1, v2}, Lmld;->b(Lmrh;Ljava/lang/Object;)V

    .line 38
    invoke-interface {v1}, Lmrh;->m()Z

    .line 41
    invoke-interface {v1}, Lmrh;->k()V

    .line 44
    invoke-static {p1}, Lmqa;->b(Lmsi;)J

    .line 47
    move-result-wide v2

    .line 48
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 51
    move-result-object v2

    .line 52
    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 55
    goto :goto_0

    .line 56
    :cond_0
    const-wide/16 v2, -0x1

    .line 58
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 61
    move-result-object v2

    .line 62
    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 65
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 66
    :cond_1
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 69
    invoke-virtual {v0}, Lbhsr;->f()Ljava/util/List;

    .line 72
    move-result-object p0

    .line 73
    return-object p0

    .line 74
    :catchall_0
    move-exception p0

    .line 75
    :try_start_1
    throw p0

    .line 76
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception p1

    .line 77
    :try_start_2
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 80
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    goto :goto_1

    .line 81
    :catchall_2
    move-exception p2

    .line 82
    invoke-static {p0, p2}, Lbhpc;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 85
    :goto_1
    throw p1
.end method

.method public final d(Lmsi;Ljava/lang/Iterable;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p0}, Lmld;->a()Ljava/lang/String;

    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lmsi;->a(Ljava/lang/String;)Lmrh;

    .line 11
    move-result-object p1

    .line 12
    :try_start_0
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 15
    move-result-object p2

    .line 16
    :cond_0
    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_1

    .line 22
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 25
    move-result-object v0

    .line 26
    if-eqz v0, :cond_0

    .line 28
    invoke-virtual {p0, p1, v0}, Lmld;->b(Lmrh;Ljava/lang/Object;)V

    .line 31
    invoke-interface {p1}, Lmrh;->m()Z

    .line 34
    invoke-interface {p1}, Lmrh;->k()V

    .line 37
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 38
    :cond_1
    invoke-interface {p1}, Ljava/lang/AutoCloseable;->close()V

    .line 41
    return-void

    .line 42
    :catchall_0
    move-exception p0

    .line 43
    :try_start_1
    throw p0

    .line 44
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception p2

    .line 45
    :try_start_2
    invoke-interface {p1}, Ljava/lang/AutoCloseable;->close()V

    .line 48
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    goto :goto_1

    .line 49
    :catchall_2
    move-exception p1

    .line 50
    invoke-static {p0, p1}, Lbhpc;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 53
    :goto_1
    throw p2
.end method

.method public final e(Lmsi;Ljava/lang/Object;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    if-nez p2, :cond_0

    .line 6
    return-void

    .line 7
    :cond_0
    invoke-virtual {p0}, Lmld;->a()Ljava/lang/String;

    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {p1, v0}, Lmsi;->a(Ljava/lang/String;)Lmrh;

    .line 14
    move-result-object p1

    .line 15
    :try_start_0
    invoke-virtual {p0, p1, p2}, Lmld;->b(Lmrh;Ljava/lang/Object;)V

    .line 18
    invoke-interface {p1}, Lmrh;->m()Z

    .line 21
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 p0, 0x0

    .line 22
    invoke-static {p1, p0}, Lbhwc;->a(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    .line 25
    return-void

    .line 26
    :catchall_0
    move-exception p0

    .line 27
    :try_start_1
    throw p0

    .line 28
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception p2

    .line 29
    invoke-static {p1, p0}, Lbhwc;->a(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    .line 32
    throw p2
.end method
