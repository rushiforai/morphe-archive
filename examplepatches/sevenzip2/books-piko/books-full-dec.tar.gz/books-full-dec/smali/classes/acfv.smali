.class public final synthetic Lacfv;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwq;


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lafjv;

    .line 3
    sget p0, Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;->f:I

    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    iget-object p0, p1, Lafjv;->b:Luws;

    .line 10
    invoke-virtual {p0}, Luws;->O()Luxq;

    .line 13
    move-result-object p0

    .line 14
    sget-object p1, Luxq;->a:Luxq;

    .line 16
    if-ne p0, p1, :cond_0

    .line 18
    const/4 p0, 0x1

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 p0, 0x0

    .line 21
    :goto_0
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 24
    move-result-object p0

    .line 25
    return-object p0
.end method
