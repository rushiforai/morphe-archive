.class public final Ladrf;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Loye;


# instance fields
.field private final a:Landroid/database/sqlite/SQLiteOpenHelper;

.field private final b:Layxl;


# direct methods
.method public constructor <init>(Landroid/database/sqlite/SQLiteOpenHelper;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladrf;->a:Landroid/database/sqlite/SQLiteOpenHelper;

    .line 6
    const-string p1, "com/google/android/apps/play/books/ebook/storage/EbookAccountsChangedHandler"

    .line 8
    invoke-static {p1}, Layxl;->i(Ljava/lang/String;)Layxl;

    .line 11
    move-result-object p1

    .line 12
    iput-object p1, p0, Ladrf;->b:Layxl;

    .line 14
    return-void
.end method

.method private static final b(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    .line 1
    const-string v0, "account_name NOT IN ("

    .line 3
    const-string v1, ")"

    .line 5
    invoke-static {p1, v0, v1}, La;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {p0, p3, p1, p2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 12
    return-void
.end method


# virtual methods
.method public final a(Ljava/util/List;)V
    .locals 8

    .line 1
    :try_start_0
    iget-object v0, p0, Ladrf;->a:Landroid/database/sqlite/SQLiteOpenHelper;

    .line 3
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    .line 10
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    const-string v3, ", "

    .line 12
    new-instance v6, Ladre;

    .line 14
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 17
    const/4 v5, 0x0

    .line 18
    const/16 v7, 0x1e

    .line 20
    const/4 v4, 0x0

    .line 21
    move-object v2, p1

    .line 22
    invoke-static/range {v2 .. v7}, Lbhrc;->am(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Lbhwq;I)Ljava/lang/String;

    .line 25
    move-result-object p1

    .line 26
    new-instance v0, Ljava/util/ArrayList;

    .line 28
    invoke-static {v2}, Lbhrc;->p(Ljava/lang/Iterable;)I

    .line 31
    move-result v3

    .line 32
    invoke-direct {v0, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 35
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 38
    move-result-object v2

    .line 39
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 42
    move-result v3

    .line 43
    if-eqz v3, :cond_0

    .line 45
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 48
    move-result-object v3

    .line 49
    check-cast v3, Landroid/accounts/Account;

    .line 51
    iget-object v3, v3, Landroid/accounts/Account;->name:Ljava/lang/String;

    .line 53
    invoke-interface {v0, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 56
    goto :goto_0

    .line 57
    :cond_0
    const/4 v2, 0x0

    .line 58
    new-array v2, v2, [Ljava/lang/String;

    .line 60
    invoke-interface {v0, v2}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 63
    move-result-object v0

    .line 64
    check-cast v0, [Ljava/lang/String;

    .line 66
    const-string v2, "segments"

    .line 68
    invoke-static {v1, p1, v0, v2}, Ladrf;->b(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V

    .line 71
    const-string v2, "chapters"

    .line 73
    invoke-static {v1, p1, v0, v2}, Ladrf;->b(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V

    .line 76
    const-string v2, "resources"

    .line 78
    invoke-static {v1, p1, v0, v2}, Ladrf;->b(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V

    .line 81
    const-string v2, "segment_resources"

    .line 83
    invoke-static {v1, p1, v0, v2}, Ladrf;->b(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V

    .line 86
    const-string v2, "resource_resources"

    .line 88
    invoke-static {v1, p1, v0, v2}, Ladrf;->b(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V

    .line 91
    const-string v2, "pages"

    .line 93
    invoke-static {v1, p1, v0, v2}, Ladrf;->b(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V

    .line 96
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V

    .line 99
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 102
    return-void

    .line 103
    :catchall_0
    move-exception v0

    .line 104
    move-object p1, v0

    .line 105
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 108
    throw p1

    .line 109
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    move-exception v0

    .line 110
    move-object p1, v0

    .line 111
    iget-object p0, p0, Ladrf;->b:Layxl;

    .line 113
    invoke-virtual {p0}, Layxb;->c()Layxz;

    .line 116
    move-result-object p0

    .line 117
    check-cast p0, Layxi;

    .line 119
    invoke-interface {p0, p1}, Layxi;->i(Ljava/lang/Throwable;)Layxz;

    .line 122
    move-result-object p0

    .line 123
    const/16 p1, 0x36

    .line 125
    const-string v0, "EbookAccountsChangedHandler.kt"

    .line 127
    const-string v1, "com/google/android/apps/play/books/ebook/storage/EbookAccountsChangedHandler"

    .line 129
    const-string v2, "onAccountsChanged"

    .line 131
    invoke-interface {p0, v1, v2, p1, v0}, Layxz;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 134
    move-result-object p0

    .line 135
    check-cast p0, Layxi;

    .line 137
    const-string p1, "Error deleting database entries"

    .line 139
    invoke-interface {p0, p1}, Layxi;->s(Ljava/lang/String;)V

    .line 142
    return-void
.end method
