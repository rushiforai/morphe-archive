.class public abstract Lacb;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field private final a:Ljava/util/List;

.field public b:Z

.field public final c:Ljava/util/concurrent/CopyOnWriteArrayList;


# direct methods
.method public constructor <init>(Z)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/ArrayList;

    .line 6
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 9
    iput-object v0, p0, Lacb;->a:Ljava/util/List;

    .line 11
    iput-boolean p1, p0, Lacb;->b:Z

    .line 13
    new-instance p1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 15
    invoke-direct {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 18
    iput-object p1, p0, Lacb;->c:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 20
    return-void
.end method


# virtual methods
.method public a()V
    .locals 0

    .line 1
    return-void
.end method

.method public abstract b()V
.end method

.method public c(Laaq;)V
    .locals 0

    .line 1
    return-void
.end method

.method public d()V
    .locals 0

    .line 1
    return-void
.end method

.method public final e(Lmjp;)Laca;
    .locals 1

    .line 1
    new-instance v0, Laca;

    .line 3
    invoke-direct {v0, p0, p1}, Laca;-><init>(Lacb;Lmjp;)V

    .line 6
    iget-object p0, p0, Lacb;->a:Ljava/util/List;

    .line 8
    invoke-interface {p0, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 11
    return-object v0
.end method

.method public final f()V
    .locals 7

    .line 1
    iget-object v0, p0, Lacb;->c:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_a

    .line 16
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    move-result-object v1

    .line 20
    check-cast v1, Ljava/lang/AutoCloseable;

    .line 22
    instance-of v2, v1, Ljava/lang/AutoCloseable;

    .line 24
    if-eqz v2, :cond_1

    .line 26
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 29
    goto :goto_0

    .line 30
    :cond_1
    instance-of v2, v1, Ljava/util/concurrent/ExecutorService;

    .line 32
    if-eqz v2, :cond_4

    .line 34
    check-cast v1, Ljava/util/concurrent/ExecutorService;

    .line 36
    invoke-static {}, Lhc$$ExternalSyntheticApiModelOutline0;->m()Ljava/util/concurrent/ForkJoinPool;

    .line 39
    move-result-object v2

    .line 40
    if-eq v1, v2, :cond_0

    .line 42
    invoke-interface {v1}, Ljava/util/concurrent/ExecutorService;->isTerminated()Z

    .line 45
    move-result v2

    .line 46
    if-nez v2, :cond_0

    .line 48
    invoke-interface {v1}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    .line 51
    const/4 v2, 0x0

    .line 52
    move v3, v2

    .line 53
    :goto_1
    if-nez v2, :cond_3

    .line 55
    :try_start_0
    sget-object v4, Ljava/util/concurrent/TimeUnit;->DAYS:Ljava/util/concurrent/TimeUnit;

    .line 57
    const-wide/16 v5, 0x1

    .line 59
    invoke-interface {v1, v5, v6, v4}, Ljava/util/concurrent/ExecutorService;->awaitTermination(JLjava/util/concurrent/TimeUnit;)Z

    .line 62
    move-result v2

    .line 63
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    .line 64
    :catch_0
    const/4 v4, 0x1

    .line 65
    if-nez v3, :cond_2

    .line 67
    invoke-interface {v1}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    .line 70
    :cond_2
    move v3, v4

    .line 71
    goto :goto_1

    .line 72
    :cond_3
    if-eqz v3, :cond_0

    .line 74
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 77
    move-result-object v1

    .line 78
    invoke-virtual {v1}, Ljava/lang/Thread;->interrupt()V

    .line 81
    goto :goto_0

    .line 82
    :cond_4
    instance-of v2, v1, Landroid/content/res/TypedArray;

    .line 84
    if-eqz v2, :cond_5

    .line 86
    check-cast v1, Landroid/content/res/TypedArray;

    .line 88
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    .line 91
    goto :goto_0

    .line 92
    :cond_5
    instance-of v2, v1, Landroid/media/MediaMetadataRetriever;

    .line 94
    if-eqz v2, :cond_6

    .line 96
    check-cast v1, Landroid/media/MediaMetadataRetriever;

    .line 98
    invoke-virtual {v1}, Landroid/media/MediaMetadataRetriever;->release()V

    .line 101
    goto :goto_0

    .line 102
    :cond_6
    instance-of v2, v1, Landroid/media/MediaDrm;

    .line 104
    if-eqz v2, :cond_7

    .line 106
    check-cast v1, Landroid/media/MediaDrm;

    .line 108
    invoke-virtual {v1}, Landroid/media/MediaDrm;->release()V

    .line 111
    goto :goto_0

    .line 112
    :cond_7
    instance-of v2, v1, Landroid/drm/DrmManagerClient;

    .line 114
    if-eqz v2, :cond_8

    .line 116
    check-cast v1, Landroid/drm/DrmManagerClient;

    .line 118
    invoke-virtual {v1}, Landroid/drm/DrmManagerClient;->release()V

    .line 121
    goto :goto_0

    .line 122
    :cond_8
    instance-of v2, v1, Landroid/content/ContentProviderClient;

    .line 124
    if-eqz v2, :cond_9

    .line 126
    check-cast v1, Landroid/content/ContentProviderClient;

    .line 128
    invoke-virtual {v1}, Landroid/content/ContentProviderClient;->release()Z

    .line 131
    goto :goto_0

    .line 132
    :cond_9
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 134
    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 137
    throw p0

    .line 138
    :cond_a
    iget-object v0, p0, Lacb;->c:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 140
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->clear()V

    .line 143
    iget-object p0, p0, Lacb;->a:Ljava/util/List;

    .line 145
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 148
    move-result-object v0

    .line 149
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 152
    move-result v1

    .line 153
    if-eqz v1, :cond_b

    .line 155
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 158
    move-result-object v1

    .line 159
    check-cast v1, Laca;

    .line 161
    invoke-virtual {v1}, Lmjm;->f()V

    .line 164
    goto :goto_2

    .line 165
    :cond_b
    invoke-interface {p0}, Ljava/util/List;->clear()V

    .line 168
    return-void
.end method

.method public final g(Z)V
    .locals 3

    .line 1
    iput-boolean p1, p0, Lacb;->b:Z

    .line 3
    iget-object p0, p0, Lacb;->a:Ljava/util/List;

    .line 5
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 8
    move-result-object p0

    .line 9
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_1

    .line 15
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Laca;

    .line 21
    iget-boolean v1, v0, Laca;->a:Z

    .line 23
    const/4 v2, 0x0

    .line 24
    if-eqz v1, :cond_0

    .line 26
    if-eqz p1, :cond_0

    .line 28
    const/4 v2, 0x1

    .line 29
    :cond_0
    invoke-virtual {v0, v2}, Lmjm;->g(Z)V

    .line 32
    goto :goto_0

    .line 33
    :cond_1
    return-void
.end method
