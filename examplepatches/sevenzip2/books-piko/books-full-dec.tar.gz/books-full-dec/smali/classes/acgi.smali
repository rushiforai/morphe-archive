.class public final Lacgi;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacgi;->a:Lbeye;

    .line 6
    iput-object p2, p0, Lacgi;->b:Lbeye;

    .line 8
    iput-object p3, p0, Lacgi;->c:Lbeye;

    .line 10
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, Lacgi;->a:Lbeye;

    .line 3
    check-cast v0, Lpzw;

    .line 5
    invoke-virtual {v0}, Lpzw;->a()Landroid/content/Context;

    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Lacgi;->b:Lbeye;

    .line 11
    check-cast v1, Lajvr;

    .line 13
    invoke-virtual {v1}, Lajvr;->a()Lajvq;

    .line 16
    move-result-object v1

    .line 17
    iget-object p0, p0, Lacgi;->c:Lbeye;

    .line 19
    check-cast p0, Lpwn;

    .line 21
    invoke-virtual {p0}, Lpwn;->a()Landroid/accounts/Account;

    .line 24
    move-result-object p0

    .line 25
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    new-instance v2, Ljava/io/File;

    .line 34
    iget-object p0, p0, Landroid/accounts/Account;->name:Ljava/lang/String;

    .line 36
    invoke-virtual {v1, p0}, Lajvj;->a(Ljava/lang/String;)Ljava/io/File;

    .line 39
    move-result-object p0

    .line 40
    const-string v1, "copy_quota_room_db"

    .line 42
    invoke-direct {v2, p0, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 45
    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 48
    move-result-object p0

    .line 49
    const-class v1, Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase;

    .line 51
    invoke-static {v0, v1, p0}, Lmlz;->a(Landroid/content/Context;Ljava/lang/Class;Ljava/lang/String;)Lmmj;

    .line 54
    move-result-object p0

    .line 55
    invoke-virtual {p0}, Lmmj;->a()Lmmt;

    .line 58
    move-result-object p0

    .line 59
    check-cast p0, Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase;

    .line 61
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    return-object p0
.end method
