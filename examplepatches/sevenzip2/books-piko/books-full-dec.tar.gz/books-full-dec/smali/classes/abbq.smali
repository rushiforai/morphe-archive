.class public interface abstract Labbq;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract o(Labdc;)V
.end method
