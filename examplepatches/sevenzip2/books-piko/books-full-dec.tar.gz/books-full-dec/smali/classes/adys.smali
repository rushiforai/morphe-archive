.class public final Ladys;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladys;->a:Lbeye;

    .line 6
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object p0, p0, Ladys;->a:Lbeye;

    .line 3
    check-cast p0, Lpzw;

    .line 5
    invoke-virtual {p0}, Lpzw;->a()Landroid/content/Context;

    .line 8
    move-result-object p0

    .line 9
    new-instance v0, Ladyr;

    .line 11
    invoke-direct {v0, p0}, Ladyr;-><init>(Landroid/content/Context;)V

    .line 14
    return-object v0
.end method
