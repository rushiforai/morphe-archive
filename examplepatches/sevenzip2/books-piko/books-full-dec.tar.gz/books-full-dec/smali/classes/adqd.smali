.class public final Ladqd;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladqd;->a:Lbeye;

    .line 6
    iput-object p2, p0, Ladqd;->b:Lbeye;

    .line 8
    iput-object p3, p0, Ladqd;->c:Lbeye;

    .line 10
    iput-object p4, p0, Ladqd;->d:Lbeye;

    .line 12
    iput-object p5, p0, Ladqd;->e:Lbeye;

    .line 14
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 7

    .line 1
    iget-object v0, p0, Ladqd;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v2

    .line 9
    iget-object v0, p0, Ladqd;->b:Lbeye;

    .line 11
    check-cast v0, Labth;

    .line 13
    invoke-virtual {v0}, Labth;->a()Labtg;

    .line 16
    move-result-object v3

    .line 17
    iget-object v0, p0, Ladqd;->c:Lbeye;

    .line 19
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 22
    move-result-object v0

    .line 23
    move-object v4, v0

    .line 24
    check-cast v4, Lahic;

    .line 26
    iget-object v0, p0, Ladqd;->d:Lbeye;

    .line 28
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 31
    move-result-object v0

    .line 32
    move-object v5, v0

    .line 33
    check-cast v5, Lozd;

    .line 35
    iget-object p0, p0, Ladqd;->e:Lbeye;

    .line 37
    check-cast p0, Labgn;

    .line 39
    invoke-virtual {p0}, Labgn;->a()Labgm;

    .line 42
    move-result-object v6

    .line 43
    new-instance v1, Ladqc;

    .line 45
    invoke-direct/range {v1 .. v6}, Ladqc;-><init>(Ldw;Labtg;Lahic;Lozd;Labgm;)V

    .line 48
    return-object v1
.end method
