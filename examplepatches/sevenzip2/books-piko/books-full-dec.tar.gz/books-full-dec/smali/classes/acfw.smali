.class public final synthetic Lacfw;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwq;


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lafjv;

    .line 3
    sget p0, Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;->f:I

    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    iget-object p0, p1, Lafhw;->a:Ljava/lang/String;

    .line 10
    return-object p0
.end method
