.class public final synthetic Lacjt;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lyfj;


# instance fields
.field public final synthetic a:Lacjx;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Lacjx;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacjt;->a:Lacjx;

    .line 6
    iput p2, p0, Lacjt;->b:I

    .line 8
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 4

    .line 1
    iget v0, p0, Lacjt;->b:I

    .line 3
    iget-object p0, p0, Lacjt;->a:Lacjx;

    .line 5
    invoke-virtual {p0}, Lacjx;->b()I

    .line 8
    move-result p0

    .line 9
    if-ne v0, p0, :cond_0

    .line 11
    return-void

    .line 12
    :cond_0
    sget-object p0, Lacjx;->a:Layxl;

    .line 14
    invoke-virtual {p0}, Layxb;->d()Layxz;

    .line 17
    move-result-object p0

    .line 18
    check-cast p0, Layxi;

    .line 20
    const/16 v0, 0x2a3

    .line 22
    const-string v1, "VolumeContentStore.java"

    .line 24
    const-string v2, "com/google/android/apps/play/books/ebook/data/VolumeContentStore"

    .line 26
    const-string v3, "preCommitCheck"

    .line 28
    invoke-interface {p0, v2, v3, v0, v1}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 31
    move-result-object p0

    .line 32
    check-cast p0, Layxi;

    .line 34
    const-string v0, "Invalid base directory sequence number"

    .line 36
    invoke-interface {p0, v0}, Layxi;->s(Ljava/lang/String;)V

    .line 39
    new-instance p0, Ljava/io/IOException;

    .line 41
    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 44
    throw p0
.end method
