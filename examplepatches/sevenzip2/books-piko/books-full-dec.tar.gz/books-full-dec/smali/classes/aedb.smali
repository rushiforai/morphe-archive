.class public final synthetic Laedb;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lkdh;


# instance fields
.field public final synthetic a:Laedn;


# direct methods
.method public synthetic constructor <init>(Laedn;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laedb;->a:Laedn;

    .line 6
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .locals 2

    .line 1
    check-cast p1, Ljava/lang/Boolean;

    .line 3
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 6
    move-result p1

    .line 7
    xor-int/lit8 p1, p1, 0x1

    .line 9
    iget-object p0, p0, Laedb;->a:Laedn;

    .line 11
    iget-object v0, p0, Laedn;->k:Laxjc;

    .line 13
    invoke-virtual {v0}, Laxjc;->getMenu()Landroid/view/Menu;

    .line 16
    move-result-object v0

    .line 17
    const v1, 0x7f0a013c

    .line 20
    invoke-interface {v0, v1}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    .line 23
    move-result-object v0

    .line 24
    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    .line 27
    iget-object v0, p0, Laedn;->k:Laxjc;

    .line 29
    invoke-virtual {v0}, Laxjc;->getMenu()Landroid/view/Menu;

    .line 32
    move-result-object v0

    .line 33
    const v1, 0x7f0a013d

    .line 36
    invoke-interface {v0, v1}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    .line 39
    move-result-object v0

    .line 40
    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    .line 43
    iget-object v0, p0, Laedn;->k:Laxjc;

    .line 45
    invoke-virtual {v0}, Laxjc;->getMenu()Landroid/view/Menu;

    .line 48
    move-result-object v0

    .line 49
    const v1, 0x7f0a0143

    .line 52
    invoke-interface {v0, v1}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    .line 55
    move-result-object v0

    .line 56
    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    .line 59
    iget-object p0, p0, Laedn;->k:Laxjc;

    .line 61
    invoke-virtual {p0}, Laxjc;->getMenu()Landroid/view/Menu;

    .line 64
    move-result-object p0

    .line 65
    const v0, 0x7f0a0144

    .line 68
    invoke-interface {p0, v0}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    .line 71
    move-result-object p0

    .line 72
    invoke-interface {p0, p1}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    .line 75
    return-void
.end method
