.class public final Laait;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laait;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laait;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laait;->c:Lbeye;

    .line 10
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, Laait;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Laait;->b:Lbeye;

    .line 11
    check-cast v1, Lzvr;

    .line 13
    invoke-virtual {v1}, Lzvr;->a()Lalyv;

    .line 16
    move-result-object v1

    .line 17
    iget-object p0, p0, Laait;->c:Lbeye;

    .line 19
    check-cast p0, Laaxu;

    .line 21
    invoke-virtual {p0}, Laaxu;->a()Lalyv;

    .line 24
    move-result-object p0

    .line 25
    new-instance v2, Laais;

    .line 27
    invoke-direct {v2, v0, v1, p0}, Laais;-><init>(Ldw;Lalyv;Lalyv;)V

    .line 30
    return-object v2
.end method
