.class public final Lacxi;
.super Ljava/lang/Object;
.source "PG"