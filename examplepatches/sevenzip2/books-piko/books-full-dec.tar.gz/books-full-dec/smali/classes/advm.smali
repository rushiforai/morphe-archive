.class public final Ladvm;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Landroid/widget/PopupWindow$OnDismissListener;

.field public b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

.field public final c:Ladve;


# direct methods
.method public constructor <init>(Ladve;Ladvn;Landroid/widget/PopupWindow$OnDismissListener;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladvm;->c:Ladve;

    .line 6
    iput-object p3, p0, Ladvm;->a:Landroid/widget/PopupWindow$OnDismissListener;

    .line 8
    new-instance p3, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 10
    check-cast p2, Ladvj;

    .line 12
    iget-object v0, p2, Ladvj;->c:Landroid/view/View;

    .line 14
    iget v1, p2, Ladvj;->d:I

    .line 16
    invoke-direct {p3, v0, p1, v1}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;-><init>(Landroid/view/View;Ladve;I)V

    .line 19
    iput-object p3, p0, Ladvm;->b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 21
    iget-object p1, p2, Ladvj;->a:Layhy;

    .line 23
    check-cast p1, Layin;

    .line 25
    iget-object p1, p1, Layin;->a:Ljava/lang/Object;

    .line 27
    check-cast p1, Ljava/lang/Integer;

    .line 29
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 32
    move-result p1

    .line 33
    invoke-virtual {p3, p1}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->d(I)V

    .line 36
    iget-object p0, p0, Ladvm;->b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 38
    iget-object p1, p2, Ladvj;->b:Layhy;

    .line 40
    invoke-virtual {p0, p1}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->setScrimColor(Layhy;)V

    .line 43
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    .line 1
    iget-object v0, p0, Ladvm;->b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->isShown()Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 11
    iget-object v0, p0, Ladvm;->b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 13
    invoke-virtual {v0}, Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;->b()V

    .line 16
    const/4 v0, 0x0

    .line 17
    iput-object v0, p0, Ladvm;->b:Lcom/google/android/apps/play/books/educampaign/ui/tooltip/impl/TooltipView;

    .line 19
    :cond_0
    return-void
.end method
