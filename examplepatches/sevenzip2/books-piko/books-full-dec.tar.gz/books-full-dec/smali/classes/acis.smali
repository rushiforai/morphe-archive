.class interface abstract Lacis;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhpa;