.class public final Ladya;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladya;->a:Lbeye;

    .line 6
    iput-object p2, p0, Ladya;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final synthetic b()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Ladya;->a:Lbeye;

    .line 3
    check-cast v0, Lpzw;

    .line 5
    invoke-virtual {v0}, Lpzw;->a()Landroid/content/Context;

    .line 8
    move-result-object v0

    .line 9
    iget-object p0, p0, Ladya;->b:Lbeye;

    .line 11
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object p0

    .line 15
    check-cast p0, Loyh;

    .line 17
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 19
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 22
    new-instance v1, Ladxz;

    .line 24
    invoke-direct {v1, v0, p0}, Ladxz;-><init>(Landroid/content/Context;Loyh;)V

    .line 27
    return-object v1
.end method
