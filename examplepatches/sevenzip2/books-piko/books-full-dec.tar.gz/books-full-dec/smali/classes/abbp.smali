.class public interface abstract Labbp;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract ad(Lcom/google/android/apps/play/books/ebook/activity/contents/EbookTableOfContentsActivity;)V
.end method
