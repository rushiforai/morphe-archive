.class public final Laduh;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Ladsu;


# static fields
.field public static final a:Layxl;


# instance fields
.field public final b:Lalnn;

.field public c:Ladtd;

.field public final d:Ljava/util/Map;

.field public final e:Ljava/util/Map;

.field public final f:Ljava/util/Map;

.field public final g:Ljava/util/Map;

.field private final h:Lbhwq;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "com/google/android/apps/play/books/educampaign/manager/EduCampaignManagerImpl"

    .line 3
    invoke-static {v0}, Layxl;->i(Ljava/lang/String;)Layxl;

    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Laduh;->a:Layxl;

    .line 9
    return-void
.end method

.method public constructor <init>(Ladug;Lalnn;Ladtd;Lbhwq;)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p2, p0, Laduh;->b:Lalnn;

    .line 6
    iput-object p3, p0, Laduh;->c:Ladtd;

    .line 8
    iput-object p4, p0, Laduh;->h:Lbhwq;

    .line 10
    iget-object p2, p1, Ladug;->a:Ljava/util/Map;

    .line 12
    iput-object p2, p0, Laduh;->d:Ljava/util/Map;

    .line 14
    iget-object p3, p1, Ladug;->b:Ljava/util/Map;

    .line 16
    iput-object p3, p0, Laduh;->e:Ljava/util/Map;

    .line 18
    iget-object p1, p1, Ladug;->c:Ljava/util/Map;

    .line 20
    iput-object p1, p0, Laduh;->f:Ljava/util/Map;

    .line 22
    invoke-interface {p2}, Ljava/util/Map;->values()Ljava/util/Collection;

    .line 25
    move-result-object p1

    .line 26
    new-instance p2, Ljava/util/ArrayList;

    .line 28
    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    .line 31
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 34
    move-result-object p1

    .line 35
    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 38
    move-result p3

    .line 39
    if-eqz p3, :cond_1

    .line 41
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 44
    move-result-object p3

    .line 45
    move-object p4, p3

    .line 46
    check-cast p4, Ladsn;

    .line 48
    iget-object p4, p4, Ladsn;->b:Ljava/lang/String;

    .line 50
    const-string v0, "default"

    .line 52
    invoke-static {p4, v0}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    move-result p4

    .line 56
    if-nez p4, :cond_0

    .line 58
    invoke-interface {p2, p3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 61
    goto :goto_0

    .line 62
    :cond_1
    new-instance p1, Ljava/util/LinkedHashMap;

    .line 64
    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 67
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 70
    move-result-object p2

    .line 71
    :goto_1
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 74
    move-result p3

    .line 75
    const/4 p4, 0x1

    .line 76
    if-eqz p3, :cond_4

    .line 78
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 81
    move-result-object p3

    .line 82
    check-cast p3, Ladsn;

    .line 84
    iget-object v0, p3, Ladsn;->b:Ljava/lang/String;

    .line 86
    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 89
    move-result-object v1

    .line 90
    if-nez v1, :cond_2

    .line 92
    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 95
    :cond_2
    check-cast v1, Ljava/util/Set;

    .line 97
    if-eqz v1, :cond_3

    .line 99
    iget-object p3, p3, Ladsn;->a:Ljava/lang/String;

    .line 101
    invoke-interface {v1, p3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 104
    goto :goto_2

    .line 105
    :cond_3
    iget-object p3, p3, Ladsn;->a:Ljava/lang/String;

    .line 107
    filled-new-array {p3}, [Ljava/lang/String;

    .line 110
    move-result-object p3

    .line 111
    invoke-static {p4}, Lbhry;->b(I)I

    .line 114
    move-result p4

    .line 115
    new-instance v1, Ljava/util/LinkedHashSet;

    .line 117
    invoke-direct {v1, p4}, Ljava/util/LinkedHashSet;-><init>(I)V

    .line 120
    invoke-static {p3, v1}, Lbhqv;->R([Ljava/lang/Object;Ljava/util/Collection;)V

    .line 123
    :goto_2
    invoke-interface {p1, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 126
    goto :goto_1

    .line 127
    :cond_4
    iput-object p1, p0, Laduh;->g:Ljava/util/Map;

    .line 129
    iget-object p1, p0, Laduh;->c:Ladtd;

    .line 131
    iget-object p1, p1, Ladtd;->b:Lbdue;

    .line 133
    invoke-static {p1}, Lj$/util/DesugarCollections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 136
    move-result-object p1

    .line 137
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 140
    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 143
    move-result-object p1

    .line 144
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 147
    new-instance p2, Lbhrn;

    .line 149
    invoke-direct {p2, p1}, Lbhrn;-><init>(Ljava/lang/Iterable;)V

    .line 152
    new-instance p1, Ladue;

    .line 154
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 157
    new-instance p3, Lbibt;

    .line 159
    invoke-direct {p3, p2, p1}, Lbibt;-><init>(Lbiao;Lbhwq;)V

    .line 162
    iget-object p1, p0, Laduh;->c:Ladtd;

    .line 164
    iget-object p1, p1, Ladtd;->c:Lbdts;

    .line 166
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 169
    new-instance p2, Lbhrn;

    .line 171
    invoke-direct {p2, p1}, Lbhrn;-><init>(Ljava/lang/Iterable;)V

    .line 174
    new-instance p1, Laduf;

    .line 176
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 179
    new-instance v0, Lbibt;

    .line 181
    invoke-direct {v0, p2, p1}, Lbibt;-><init>(Lbiao;Lbhwq;)V

    .line 184
    const/4 p1, 0x2

    .line 185
    new-array p2, p1, [Lbiao;

    .line 187
    const/4 v1, 0x0

    .line 188
    aput-object p3, p2, v1

    .line 190
    aput-object v0, p2, p4

    .line 192
    new-instance p3, Lbhra;

    .line 194
    invoke-direct {p3, p2}, Lbhra;-><init>([Ljava/lang/Object;)V

    .line 197
    new-instance p2, Lbiax;

    .line 199
    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    .line 202
    new-instance v0, Lbiaj;

    .line 204
    new-instance v2, Lbiay;

    .line 206
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 209
    invoke-direct {v0, p3, v2, p2}, Lbiaj;-><init>(Lbiao;Lbhwq;Lbhwq;)V

    .line 212
    invoke-static {v0}, Lbiar;->i(Lbiao;)Ljava/util/Set;

    .line 215
    move-result-object p2

    .line 216
    iget-object p3, p0, Laduh;->d:Ljava/util/Map;

    .line 218
    invoke-interface {p3}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 221
    move-result-object p3

    .line 222
    invoke-static {p2, p3}, Lbhrc;->ae(Ljava/lang/Iterable;Ljava/lang/Iterable;)Ljava/util/Set;

    .line 225
    move-result-object p2

    .line 226
    invoke-interface {p2}, Ljava/util/Collection;->isEmpty()Z

    .line 229
    move-result p2

    .line 230
    xor-int/lit8 p3, p2, 0x1

    .line 232
    iget-object v0, p0, Laduh;->c:Ladtd;

    .line 234
    iget-object v0, v0, Ladtd;->c:Lbdts;

    .line 236
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 239
    invoke-static {v0}, Lbhrc;->K(Ljava/util/List;)Ljava/lang/Object;

    .line 242
    move-result-object v0

    .line 243
    check-cast v0, Ladtf;

    .line 245
    if-eqz v0, :cond_9

    .line 247
    iget v2, v0, Ladtf;->b:I

    .line 249
    and-int/lit8 v2, v2, 0x8

    .line 251
    if-eqz v2, :cond_5

    .line 253
    goto :goto_3

    .line 254
    :cond_5
    iget-object v2, p0, Laduh;->d:Ljava/util/Map;

    .line 256
    iget-object v3, v0, Ladtf;->c:Ljava/lang/String;

    .line 258
    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 261
    move-result-object v2

    .line 262
    check-cast v2, Ladsn;

    .line 264
    if-nez v2, :cond_6

    .line 266
    goto :goto_3

    .line 267
    :cond_6
    iget v2, v2, Ladsn;->d:I

    .line 269
    if-eq v2, p4, :cond_8

    .line 271
    iget v2, v0, Ladtf;->b:I

    .line 273
    and-int/2addr p1, v2

    .line 274
    if-eqz p1, :cond_8

    .line 276
    iget-object p1, v0, Ladtf;->d:Lbdvh;

    .line 278
    if-nez p1, :cond_7

    .line 280
    sget-object p1, Lbdvh;->a:Lbdvh;

    .line 282
    :cond_7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 285
    invoke-static {p1}, Lbdwu;->b(Lbdvh;)Lj$/time/Instant;

    .line 288
    move-result-object p1

    .line 289
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 292
    sget-object v0, Lbfyd;->a:Lbfyd;

    .line 294
    invoke-virtual {v0}, Lbfyd;->b()Lbfye;

    .line 297
    move-result-object v0

    .line 298
    invoke-interface {v0}, Lbfye;->a()J

    .line 301
    move-result-wide v2

    .line 302
    invoke-static {v2, v3}, Lj$/time/Duration;->ofSeconds(J)Lj$/time/Duration;

    .line 305
    move-result-object v0

    .line 306
    invoke-virtual {p1, v0}, Lj$/time/Instant;->plus(Lj$/time/temporal/TemporalAmount;)Lj$/time/Instant;

    .line 309
    move-result-object p1

    .line 310
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 313
    iget-object v0, p0, Laduh;->b:Lalnn;

    .line 315
    invoke-interface {v0}, Lalnn;->d()Lj$/time/Instant;

    .line 318
    move-result-object v0

    .line 319
    invoke-virtual {v0, p1}, Lj$/time/Instant;->compareTo(Lj$/time/Instant;)I

    .line 322
    move-result p1

    .line 323
    if-lez p1, :cond_9

    .line 325
    :cond_8
    move v1, p4

    .line 326
    :cond_9
    :goto_3
    if-eqz p2, :cond_b

    .line 328
    if-eqz v1, :cond_a

    .line 330
    goto :goto_4

    .line 331
    :cond_a
    return-void

    .line 332
    :cond_b
    move p4, v1

    .line 333
    :goto_4
    new-instance p1, Ladtw;

    .line 335
    invoke-direct {p1, p4, p3, p0}, Ladtw;-><init>(ZZLaduh;)V

    .line 338
    invoke-direct {p0, p1}, Laduh;->k(Lbhwq;)V

    .line 341
    return-void
.end method

.method private final j(Ljava/lang/String;)Ladsn;
    .locals 2

    .line 1
    iget-object p0, p0, Laduh;->d:Ljava/util/Map;

    .line 3
    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ladsn;

    .line 9
    if-eqz p0, :cond_0

    .line 11
    return-object p0

    .line 12
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 14
    const-string v0, "Campaign `"

    .line 16
    const-string v1, "` is not known (not exported from any module)."

    .line 18
    invoke-static {p1, v0, v1}, La;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 21
    move-result-object p1

    .line 22
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 25
    throw p0
.end method

.method private final k(Lbhwq;)V
    .locals 1

    .line 1
    iget-object v0, p0, Laduh;->c:Ladtd;

    .line 3
    invoke-virtual {v0}, Lbdtb;->toBuilder()Lbdst;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ladtc;

    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    invoke-interface {p1, v0}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    invoke-virtual {v0}, Lbdst;->q()Lbdtb;

    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    check-cast p1, Ladtd;

    .line 24
    iput-object p1, p0, Laduh;->c:Ladtd;

    .line 26
    iget-object p0, p0, Laduh;->h:Lbhwq;

    .line 28
    invoke-interface {p0, p1}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)Lbdrs;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Laduh;->j(Ljava/lang/String;)Ladsn;

    .line 4
    iget-object p0, p0, Laduh;->c:Ladtd;

    .line 6
    iget-object p0, p0, Ladtd;->b:Lbdue;

    .line 8
    invoke-static {p0}, Lj$/util/DesugarCollections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 11
    move-result-object p0

    .line 12
    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lbdrs;

    .line 18
    return-object p0
.end method

.method public final b(Ljava/lang/String;Lbdrs;)V
    .locals 1

    .line 1
    invoke-direct {p0, p1}, Laduh;->j(Ljava/lang/String;)Ladsn;

    .line 4
    new-instance v0, Laduc;

    .line 6
    invoke-direct {v0, p2, p1}, Laduc;-><init>(Lbdrs;Ljava/lang/String;)V

    .line 9
    invoke-direct {p0, v0}, Laduh;->k(Lbhwq;)V

    .line 12
    return-void
.end method

.method public final c(Ljava/lang/String;)Z
    .locals 1

    .line 1
    new-instance v0, Ladua;

    .line 3
    invoke-direct {v0, p0, p1}, Ladua;-><init>(Laduh;Ljava/lang/String;)V

    .line 6
    invoke-interface {v0}, Lbhwf;->a()Ljava/lang/Object;

    .line 9
    move-result-object p0

    .line 10
    new-instance v0, Ladsr;

    .line 12
    invoke-direct {v0, p0}, Ladsr;-><init>(Ljava/lang/Object;)V

    .line 15
    invoke-static {p1, v0}, Ladst;->b(Ljava/lang/String;Lbhwf;)V

    .line 18
    check-cast p0, Ljava/lang/Boolean;

    .line 20
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 23
    move-result p0

    .line 24
    return p0
.end method

.method public final d()Z
    .locals 1

    .line 1
    invoke-virtual {p0}, Laduh;->i()Ljava/lang/String;

    .line 4
    move-result-object v0

    .line 5
    if-nez v0, :cond_0

    .line 7
    const/4 p0, 0x0

    .line 8
    return p0

    .line 9
    :cond_0
    invoke-virtual {p0, v0}, Laduh;->h(Ljava/lang/String;)Ladut;

    .line 12
    move-result-object p0

    .line 13
    iget-boolean p0, p0, Ladut;->b:Z

    .line 15
    return p0
.end method

.method public final e(Ljava/lang/String;Lbhwf;)Z
    .locals 6

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-direct {p0, p1}, Laduh;->j(Ljava/lang/String;)Ladsn;

    .line 10
    invoke-virtual {p0, p1}, Laduh;->c(Ljava/lang/String;)Z

    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 16
    const/4 p0, 0x0

    .line 17
    return p0

    .line 18
    :cond_0
    sget-object v0, Ladtf;->a:Ladtf;

    .line 20
    invoke-virtual {v0}, Lbdtb;->createBuilder()Lbdst;

    .line 23
    move-result-object v0

    .line 24
    check-cast v0, Ladte;

    .line 26
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    invoke-virtual {v0}, Lbdst;->u()V

    .line 32
    iget-object v1, v0, Ladte;->b:Lbdtb;

    .line 34
    check-cast v1, Ladtf;

    .line 36
    iget v2, v1, Ladtf;->b:I

    .line 38
    const/4 v3, 0x1

    .line 39
    or-int/2addr v2, v3

    .line 40
    iput v2, v1, Ladtf;->b:I

    .line 42
    iput-object p1, v1, Ladtf;->c:Ljava/lang/String;

    .line 44
    iget-object v1, p0, Laduh;->b:Lalnn;

    .line 46
    invoke-interface {v1}, Lalnn;->d()Lj$/time/Instant;

    .line 49
    move-result-object v1

    .line 50
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    invoke-virtual {v1}, Lj$/time/Instant;->getEpochSecond()J

    .line 56
    move-result-wide v4

    .line 57
    invoke-virtual {v1}, Lj$/time/Instant;->getNano()I

    .line 60
    move-result v1

    .line 61
    invoke-static {v4, v5, v1}, Lbdxa;->c(JI)Lbdvh;

    .line 64
    move-result-object v1

    .line 65
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 68
    invoke-virtual {v0}, Lbdst;->u()V

    .line 71
    iget-object v2, v0, Ladte;->b:Lbdtb;

    .line 73
    check-cast v2, Ladtf;

    .line 75
    iput-object v1, v2, Ladtf;->d:Lbdvh;

    .line 77
    iget v1, v2, Ladtf;->b:I

    .line 79
    or-int/lit8 v1, v1, 0x2

    .line 81
    iput v1, v2, Ladtf;->b:I

    .line 83
    invoke-virtual {v0}, Lbdst;->q()Lbdtb;

    .line 86
    move-result-object v0

    .line 87
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 90
    check-cast v0, Ladtf;

    .line 92
    new-instance v1, Ladtv;

    .line 94
    invoke-direct {v1, v0}, Ladtv;-><init>(Ladtf;)V

    .line 97
    invoke-direct {p0, v1}, Laduh;->k(Lbhwq;)V

    .line 100
    new-instance p0, Ladtx;

    .line 102
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 105
    invoke-static {p1, p0}, Ladst;->b(Ljava/lang/String;Lbhwf;)V

    .line 108
    invoke-interface {p2}, Lbhwf;->a()Ljava/lang/Object;

    .line 111
    return v3
.end method

.method public final bridge synthetic f(Ljava/lang/String;)Ladut;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Laduh;->h(Ljava/lang/String;)Ladut;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final g(Ljava/lang/String;I)V
    .locals 1

    .line 1
    new-instance v0, Ladty;

    .line 3
    invoke-direct {v0, p2}, Ladty;-><init>(I)V

    .line 6
    invoke-static {p1, v0}, Ladst;->b(Ljava/lang/String;Lbhwf;)V

    .line 9
    new-instance p1, Ladtz;

    .line 11
    invoke-direct {p1, p0, p2}, Ladtz;-><init>(Laduh;I)V

    .line 14
    invoke-direct {p0, p1}, Laduh;->k(Lbhwq;)V

    .line 17
    return-void
.end method

.method public final h(Ljava/lang/String;)Ladut;
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    new-instance v0, Ladut;

    .line 6
    invoke-direct {p0, p1}, Laduh;->j(Ljava/lang/String;)Ladsn;

    .line 9
    move-result-object p1

    .line 10
    iget-object p0, p0, Laduh;->c:Ladtd;

    .line 12
    iget-object p0, p0, Ladtd;->c:Lbdts;

    .line 14
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    invoke-direct {v0, p1, p0}, Ladut;-><init>(Ladsn;Ljava/util/List;)V

    .line 20
    return-object v0
.end method

.method public final i()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Laduh;->c:Ladtd;

    .line 3
    iget-object p0, p0, Ladtd;->c:Lbdts;

    .line 5
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    invoke-static {p0}, Lbhrc;->K(Ljava/util/List;)Ljava/lang/Object;

    .line 11
    move-result-object p0

    .line 12
    check-cast p0, Ladtf;

    .line 14
    if-eqz p0, :cond_0

    .line 16
    iget-object p0, p0, Ladtf;->c:Ljava/lang/String;

    .line 18
    return-object p0

    .line 19
    :cond_0
    const/4 p0, 0x0

    .line 20
    return-object p0
.end method
