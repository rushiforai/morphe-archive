.class public final Laadh;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laadh;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laadh;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Laadh;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v0

    .line 9
    iget-object p0, p0, Laadh;->b:Lbeye;

    .line 11
    check-cast p0, Laaem;

    .line 13
    invoke-virtual {p0}, Laaem;->a()Laael;

    .line 16
    move-result-object p0

    .line 17
    new-instance v1, Laadg;

    .line 19
    invoke-direct {v1, v0, p0}, Laadf;-><init>(Ldw;Laael;)V

    .line 22
    return-object v1
.end method
