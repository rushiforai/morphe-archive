.class public final Lacez;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacez;->a:Lbeye;

    .line 6
    iput-object p2, p0, Lacez;->b:Lbeye;

    .line 8
    iput-object p3, p0, Lacez;->c:Lbeye;

    .line 10
    iput-object p4, p0, Lacez;->d:Lbeye;

    .line 12
    iput-object p5, p0, Lacez;->e:Lbeye;

    .line 14
    iput-object p6, p0, Lacez;->f:Lbeye;

    .line 16
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 8

    .line 1
    iget-object v0, p0, Lacez;->a:Lbeye;

    .line 3
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    move-object v2, v0

    .line 8
    check-cast v2, Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase;

    .line 10
    iget-object v0, p0, Lacez;->b:Lbeye;

    .line 12
    check-cast v0, Lacgh;

    .line 14
    invoke-virtual {v0}, Lacgh;->a()Lacfa;

    .line 17
    move-result-object v3

    .line 18
    iget-object v0, p0, Lacez;->c:Lbeye;

    .line 20
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 23
    move-result-object v0

    .line 24
    move-object v4, v0

    .line 25
    check-cast v4, Lavnw;

    .line 27
    iget-object v0, p0, Lacez;->d:Lbeye;

    .line 29
    check-cast v0, Lqbj;

    .line 31
    invoke-virtual {v0}, Lqbj;->a()Lnfp;

    .line 34
    move-result-object v5

    .line 35
    iget-object v0, p0, Lacez;->e:Lbeye;

    .line 37
    check-cast v0, Lpwn;

    .line 39
    invoke-virtual {v0}, Lpwn;->a()Landroid/accounts/Account;

    .line 42
    move-result-object v6

    .line 43
    iget-object p0, p0, Lacez;->f:Lbeye;

    .line 45
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 48
    move-result-object p0

    .line 49
    move-object v7, p0

    .line 50
    check-cast v7, Lbifb;

    .line 52
    new-instance v1, Lacey;

    .line 54
    invoke-direct/range {v1 .. v7}, Lacey;-><init>(Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase;Lacfa;Lavnw;Lnfp;Landroid/accounts/Account;Lbifb;)V

    .line 57
    return-object v1
.end method
