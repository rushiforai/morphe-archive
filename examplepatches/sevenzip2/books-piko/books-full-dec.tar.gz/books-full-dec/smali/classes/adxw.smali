.class public final synthetic Ladxw;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Ljjq;


# instance fields
.field public final synthetic a:Lcom/google/android/apps/play/books/firstrun/FirstRunActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/apps/play/books/firstrun/FirstRunActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladxw;->a:Lcom/google/android/apps/play/books/firstrun/FirstRunActivity;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()Z
    .locals 0

    .line 1
    iget-object p0, p0, Ladxw;->a:Lcom/google/android/apps/play/books/firstrun/FirstRunActivity;

    .line 3
    invoke-virtual {p0}, Lcom/google/android/apps/play/books/firstrun/FirstRunActivity;->isFinishing()Z

    .line 6
    move-result p0

    .line 7
    if-nez p0, :cond_0

    .line 9
    const/4 p0, 0x1

    .line 10
    return p0

    .line 11
    :cond_0
    const/4 p0, 0x0

    .line 12
    return p0
.end method
