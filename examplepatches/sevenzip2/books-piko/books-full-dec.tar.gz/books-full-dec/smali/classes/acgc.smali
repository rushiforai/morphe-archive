.class public final Lacgc;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:I

.field synthetic b:Ljava/lang/Object;

.field final synthetic c:Ljava/util/List;

.field final synthetic d:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;


# direct methods
.method public constructor <init>(Ljava/util/List;Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lacgc;->c:Ljava/util/List;

    .line 3
    iput-object p2, p0, Lacgc;->d:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, Lbhuu;-><init>(ILbhtu;)V

    .line 9
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Ljava/util/Collection;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Lacgc;

    .line 13
    invoke-virtual {p0, p1}, Lacgc;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Lacgc;->a:I

    .line 5
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 8
    if-eqz v1, :cond_0

    .line 10
    return-object p1

    .line 11
    :cond_0
    iget-object p1, p0, Lacgc;->b:Ljava/lang/Object;

    .line 13
    check-cast p1, Ljava/util/Collection;

    .line 15
    iget-object v1, p0, Lacgc;->c:Ljava/util/List;

    .line 17
    iget-object v2, p0, Lacgc;->d:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 19
    new-instance v3, Lacgb;

    .line 21
    const/4 v4, 0x0

    .line 22
    invoke-direct {v3, p1, v1, v2, v4}, Lacgb;-><init>(Ljava/util/Collection;Ljava/util/List;Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;Lbhtu;)V

    .line 25
    const/4 p1, 0x1

    .line 26
    iput p1, p0, Lacgc;->a:I

    .line 28
    invoke-static {v3, p0}, Lbifj;->a(Lbhwu;Lbhtu;)Ljava/lang/Object;

    .line 31
    move-result-object p0

    .line 32
    if-ne p0, v0, :cond_1

    .line 34
    return-object v0

    .line 35
    :cond_1
    return-object p0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 2

    .line 1
    new-instance v0, Lacgc;

    .line 3
    iget-object v1, p0, Lacgc;->c:Ljava/util/List;

    .line 5
    iget-object p0, p0, Lacgc;->d:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 7
    invoke-direct {v0, v1, p0, p2}, Lacgc;-><init>(Ljava/util/List;Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;Lbhtu;)V

    .line 10
    iput-object p1, v0, Lacgc;->b:Ljava/lang/Object;

    .line 12
    return-object v0
.end method
