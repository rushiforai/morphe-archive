.class public interface abstract Lacfu;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract d()V
.end method
