.class public final Laacb;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;

.field private final g:Lbeye;

.field private final h:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laacb;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laacb;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laacb;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laacb;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laacb;->e:Lbeye;

    .line 14
    iput-object p6, p0, Laacb;->f:Lbeye;

    .line 16
    iput-object p7, p0, Laacb;->g:Lbeye;

    .line 18
    iput-object p8, p0, Laacb;->h:Lbeye;

    .line 20
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 10

    .line 1
    iget-object v0, p0, Laacb;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v2

    .line 9
    iget-object v0, p0, Laacb;->b:Lbeye;

    .line 11
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object v0

    .line 15
    move-object v3, v0

    .line 16
    check-cast v3, Laadi;

    .line 18
    iget-object v0, p0, Laacb;->c:Lbeye;

    .line 20
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 23
    move-result-object v0

    .line 24
    move-object v4, v0

    .line 25
    check-cast v4, Lalls;

    .line 27
    iget-object v0, p0, Laacb;->f:Lbeye;

    .line 29
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 32
    move-result-object v0

    .line 33
    move-object v7, v0

    .line 34
    check-cast v7, Laawh;

    .line 36
    iget-object v0, p0, Laacb;->g:Lbeye;

    .line 38
    check-cast v0, Laanv;

    .line 40
    invoke-virtual {v0}, Laanv;->a()Laanu;

    .line 43
    move-result-object v8

    .line 44
    iget-object v0, p0, Laacb;->h:Lbeye;

    .line 46
    check-cast v0, Laall;

    .line 48
    invoke-virtual {v0}, Laall;->a()Laalk;

    .line 51
    move-result-object v9

    .line 52
    iget-object v5, p0, Laacb;->d:Lbeye;

    .line 54
    iget-object v6, p0, Laacb;->e:Lbeye;

    .line 56
    new-instance v1, Laaca;

    .line 58
    invoke-direct/range {v1 .. v9}, Laaca;-><init>(Ldw;Laadi;Lalls;Lbhpa;Lbhpa;Laawh;Laanu;Laalk;)V

    .line 61
    return-object v1
.end method
