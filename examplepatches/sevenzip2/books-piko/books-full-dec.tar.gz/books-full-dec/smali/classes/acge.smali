.class public final Lacge;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacge;->a:Lbeye;

    .line 6
    iput-object p2, p0, Lacge;->b:Lbeye;

    .line 8
    iput-object p3, p0, Lacge;->c:Lbeye;

    .line 10
    iput-object p4, p0, Lacge;->d:Lbeye;

    .line 12
    iput-object p5, p0, Lacge;->e:Lbeye;

    .line 14
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 7

    .line 1
    iget-object v0, p0, Lacge;->a:Lbeye;

    .line 3
    check-cast v0, Lpwn;

    .line 5
    invoke-virtual {v0}, Lpwn;->a()Landroid/accounts/Account;

    .line 8
    move-result-object v2

    .line 9
    iget-object v0, p0, Lacge;->b:Lbeye;

    .line 11
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object v0

    .line 15
    move-object v3, v0

    .line 16
    check-cast v3, Loyh;

    .line 18
    iget-object v0, p0, Lacge;->d:Lbeye;

    .line 20
    check-cast v0, Lahil;

    .line 22
    invoke-virtual {v0}, Lahil;->a()Lahik;

    .line 25
    move-result-object v5

    .line 26
    iget-object v0, p0, Lacge;->e:Lbeye;

    .line 28
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 31
    move-result-object v0

    .line 32
    move-object v6, v0

    .line 33
    check-cast v6, Lbifb;

    .line 35
    iget-object v4, p0, Lacge;->c:Lbeye;

    .line 37
    new-instance v1, Lacft;

    .line 39
    invoke-direct/range {v1 .. v6}, Lacft;-><init>(Landroid/accounts/Account;Loyh;Lbhpa;Lahij;Lbifb;)V

    .line 42
    return-object v1
.end method
