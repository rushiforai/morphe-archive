.class public final synthetic Lacfe;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwq;


# instance fields
.field public final synthetic a:Lacfk;

.field public final synthetic b:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Lacfk;Ljava/util/List;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacfe;->a:Lacfk;

    .line 6
    iput-object p2, p0, Lacfe;->b:Ljava/util/List;

    .line 8
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lacfe;->a:Lacfk;

    .line 3
    iget-object v0, v0, Lacfk;->d:Lmlc;

    .line 5
    check-cast p1, Lmsi;

    .line 7
    iget-object p0, p0, Lacfe;->b:Ljava/util/List;

    .line 9
    invoke-virtual {v0, p1, p0}, Lmlc;->c(Lmsi;Ljava/lang/Iterable;)I

    .line 12
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 14
    return-object p0
.end method
