.class public final Ladtq;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# virtual methods
.method public final synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    sget-object p0, Ladui;->a:Ladsp;

    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    return-object p0
.end method
