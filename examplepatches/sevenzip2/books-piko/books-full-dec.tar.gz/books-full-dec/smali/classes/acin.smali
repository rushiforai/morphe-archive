.class public final synthetic Lacin;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lacis;


# instance fields
.field public final synthetic a:Laciu;

.field public final synthetic b:Luws;

.field public final synthetic c:Lacps;


# direct methods
.method public synthetic constructor <init>(Laciu;Luws;Lacps;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacin;->a:Laciu;

    .line 6
    iput-object p2, p0, Lacin;->b:Luws;

    .line 8
    iput-object p3, p0, Lacin;->c:Lacps;

    .line 10
    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lacin;->a:Laciu;

    .line 3
    iget-object v1, p0, Lacin;->b:Luws;

    .line 5
    iget-object p0, p0, Lacin;->c:Lacps;

    .line 7
    invoke-virtual {v0, v1, p0}, Laciu;->c(Luws;Lacps;)Ljava/util/List;

    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method
