.class public final Laciy;
.super Ljava/lang/Object;
.source "PG"


# static fields
.field public static final a:Laciz;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Laciz;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    sput-object v0, Laciy;->a:Laciz;

    .line 8
    return-void
.end method
