.class public final Lacjy;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacjy;->a:Lbeye;

    .line 6
    iput-object p2, p0, Lacjy;->b:Lbeye;

    .line 8
    iput-object p3, p0, Lacjy;->c:Lbeye;

    .line 10
    iput-object p4, p0, Lacjy;->d:Lbeye;

    .line 12
    iput-object p5, p0, Lacjy;->e:Lbeye;

    .line 14
    iput-object p6, p0, Lacjy;->f:Lbeye;

    .line 16
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 8

    .line 1
    iget-object v0, p0, Lacjy;->a:Lbeye;

    .line 3
    check-cast v0, Lpzv;

    .line 5
    invoke-virtual {v0}, Lpzv;->a()Landroid/content/ContentResolver;

    .line 8
    move-result-object v2

    .line 9
    iget-object v0, p0, Lacjy;->b:Lbeye;

    .line 11
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object v0

    .line 15
    move-object v3, v0

    .line 16
    check-cast v3, Lajuu;

    .line 18
    iget-object v0, p0, Lacjy;->c:Lbeye;

    .line 20
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 23
    move-result-object v0

    .line 24
    move-object v4, v0

    .line 25
    check-cast v4, Lyev;

    .line 27
    iget-object v0, p0, Lacjy;->d:Lbeye;

    .line 29
    check-cast v0, Lpzk;

    .line 31
    invoke-virtual {v0}, Lpzk;->a()Lalpu;

    .line 34
    move-result-object v5

    .line 35
    iget-object v0, p0, Lacjy;->e:Lbeye;

    .line 37
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 40
    move-result-object v0

    .line 41
    move-object v6, v0

    .line 42
    check-cast v6, Lalpu;

    .line 44
    iget-object p0, p0, Lacjy;->f:Lbeye;

    .line 46
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 49
    move-result-object p0

    .line 50
    move-object v7, p0

    .line 51
    check-cast v7, Lalnh;

    .line 53
    new-instance v1, Lacjx;

    .line 55
    invoke-direct/range {v1 .. v7}, Lacjx;-><init>(Landroid/content/ContentResolver;Lajuu;Lyev;Lalpu;Lalpu;Lalnh;)V

    .line 58
    return-object v1
.end method
