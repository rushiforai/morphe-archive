.class public Laeba;
.super Ljava/lang/Object;
.source "PG"


# static fields
.field public static final k:Ladsp;

.field public static final l:Ladsn;


# instance fields
.field private final a:Landroid/accounts/Account;

.field private final b:Landroid/content/Context;

.field private final c:Lalav;

.field private final d:Ladsy;

.field private final e:Ljava/util/Map;

.field private f:Ladsu;

.field public final m:Layxl;

.field public final n:Lbifi;

.field public final o:Ladzn;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    new-instance v0, Ladsp;

    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x2

    .line 5
    const-string v3, "HaTSLayer"

    .line 7
    invoke-direct {v0, v3, v1, v2}, Ladsp;-><init>(Ljava/lang/String;Ljava/util/List;I)V

    .line 10
    sput-object v0, Laeba;->k:Ladsp;

    .line 12
    new-instance v1, Ladsn;

    .line 14
    iget-object v0, v0, Ladsp;->a:Ljava/lang/String;

    .line 16
    const/4 v2, -0x1

    .line 17
    const/4 v3, 0x1

    .line 18
    const-string v4, "HaTS"

    .line 20
    invoke-direct {v1, v4, v0, v2, v3}, Ladsn;-><init>(Ljava/lang/String;Ljava/lang/String;II)V

    .line 23
    sput-object v1, Laeba;->l:Ladsn;

    .line 25
    return-void
.end method

.method public constructor <init>(Landroid/accounts/Account;Landroid/content/Context;Lalav;Ladsy;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laeba;->a:Landroid/accounts/Account;

    .line 6
    iput-object p2, p0, Laeba;->b:Landroid/content/Context;

    .line 8
    iput-object p3, p0, Laeba;->c:Lalav;

    .line 10
    iput-object p4, p0, Laeba;->d:Ladsy;

    .line 12
    const-string p1, "com/google/android/apps/play/books/happiness/impl/SurveyManager"

    .line 14
    invoke-static {p1}, Layxl;->i(Ljava/lang/String;)Layxl;

    .line 17
    move-result-object p1

    .line 18
    iput-object p1, p0, Laeba;->m:Layxl;

    .line 20
    sget-object p1, Lbigb;->a:Lbifb;

    .line 22
    sget-object p1, Lbitt;->a:Lbiht;

    .line 24
    invoke-static {p1}, Lbifj;->b(Lbhuc;)Lbifi;

    .line 27
    move-result-object p1

    .line 28
    iput-object p1, p0, Laeba;->n:Lbifi;

    .line 30
    new-instance p1, Ladzn;

    .line 32
    invoke-direct {p1}, Ladzn;-><init>()V

    .line 35
    iput-object p1, p0, Laeba;->o:Ladzn;

    .line 37
    new-instance p1, Ljava/util/LinkedHashMap;

    .line 39
    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 42
    iput-object p1, p0, Laeba;->e:Ljava/util/Map;

    .line 44
    return-void
.end method


# virtual methods
.method protected final m(Ljava/lang/String;Lbhtu;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p2

    .line 5
    instance-of v2, v1, Laeay;

    .line 7
    if-eqz v2, :cond_0

    .line 9
    move-object v2, v1

    .line 10
    check-cast v2, Laeay;

    .line 12
    iget v3, v2, Laeay;->d:I

    .line 14
    const/high16 v4, -0x80000000

    .line 16
    and-int v5, v3, v4

    .line 18
    if-eqz v5, :cond_0

    .line 20
    sub-int/2addr v3, v4

    .line 21
    iput v3, v2, Laeay;->d:I

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    new-instance v2, Laeay;

    .line 26
    invoke-direct {v2, v0, v1}, Laeay;-><init>(Laeba;Lbhtu;)V

    .line 29
    :goto_0
    iget-object v1, v2, Laeay;->b:Ljava/lang/Object;

    .line 31
    sget-object v3, Lbhug;->a:Lbhug;

    .line 33
    iget v4, v2, Laeay;->d:I

    .line 35
    const/4 v5, 0x3

    .line 36
    const/4 v6, 0x1

    .line 37
    const/4 v7, 0x2

    .line 38
    const/4 v8, 0x0

    .line 39
    if-eqz v4, :cond_4

    .line 41
    if-eq v4, v6, :cond_3

    .line 43
    if-eq v4, v7, :cond_2

    .line 45
    if-ne v4, v5, :cond_1

    .line 47
    iget-object v2, v2, Laeay;->e:Ljava/lang/String;

    .line 49
    invoke-static {v1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 52
    goto/16 :goto_5

    .line 54
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 56
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 58
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 61
    throw v0

    .line 62
    :cond_2
    iget-object v4, v2, Laeay;->a:Ljava/lang/Object;

    .line 64
    iget-object v6, v2, Laeay;->f:Lbien;

    .line 66
    iget-object v7, v2, Laeay;->e:Ljava/lang/String;

    .line 68
    invoke-static {v1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 71
    goto/16 :goto_3

    .line 73
    :cond_3
    iget-object v4, v2, Laeay;->e:Ljava/lang/String;

    .line 75
    invoke-static {v1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 78
    move-object v11, v4

    .line 79
    goto :goto_1

    .line 80
    :cond_4
    invoke-static {v1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 83
    invoke-interface/range {p1 .. p1}, Ljava/lang/CharSequence;->length()I

    .line 86
    move-result v1

    .line 87
    if-nez v1, :cond_5

    .line 89
    return-object v8

    .line 90
    :cond_5
    iget-object v1, v0, Laeba;->c:Lalav;

    .line 92
    iget-object v4, v0, Laeba;->a:Landroid/accounts/Account;

    .line 94
    move-object/from16 v9, p1

    .line 96
    iput-object v9, v2, Laeay;->e:Ljava/lang/String;

    .line 98
    iput v6, v2, Laeay;->d:I

    .line 100
    invoke-static {v1, v4, v2}, Lalbj;->a(Lalav;Landroid/accounts/Account;Lbhtu;)Ljava/lang/Object;

    .line 103
    move-result-object v1

    .line 104
    if-ne v1, v3, :cond_6

    .line 106
    goto/16 :goto_6

    .line 108
    :cond_6
    move-object v11, v9

    .line 109
    :goto_1
    check-cast v1, Ljava/lang/Boolean;

    .line 111
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 114
    move-result v1

    .line 115
    if-eqz v1, :cond_7

    .line 117
    return-object v8

    .line 118
    :cond_7
    iget-object v1, v0, Laeba;->e:Ljava/util/Map;

    .line 120
    invoke-interface {v1, v11}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 123
    move-result-object v4

    .line 124
    check-cast v4, Lcom/google/android/libraries/surveys/SurveyData;

    .line 126
    if-eqz v4, :cond_9

    .line 128
    sget-object v6, Lawne;->a:Lawne;

    .line 130
    iget-object v6, v6, Lawne;->l:Laoxo;

    .line 132
    move-object v6, v4

    .line 133
    check-cast v6, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;

    .line 135
    iget-wide v9, v6, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->e:J

    .line 137
    invoke-static {v9, v10}, Lawpa;->n(J)Z

    .line 140
    move-result v6

    .line 141
    if-nez v6, :cond_8

    .line 143
    return-object v4

    .line 144
    :cond_8
    invoke-interface {v1, v11}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 147
    move-result-object v1

    .line 148
    check-cast v1, Lcom/google/android/libraries/surveys/SurveyData;

    .line 150
    :cond_9
    new-instance v6, Lbien;

    .line 152
    invoke-direct {v6}, Lbien;-><init>()V

    .line 155
    iget-object v10, v0, Laeba;->b:Landroid/content/Context;

    .line 157
    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 160
    move-result v1

    .line 161
    if-nez v1, :cond_10

    .line 163
    new-instance v12, Laeaz;

    .line 165
    invoke-direct {v12, v6, v0}, Laeaz;-><init>(Lbien;Laeba;)V

    .line 168
    iget-object v14, v0, Laeba;->a:Landroid/accounts/Account;

    .line 170
    const v1, 0x7f130265

    .line 173
    invoke-virtual {v10, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 176
    move-result-object v13

    .line 177
    invoke-static {}, Lbftp;->c()Z

    .line 180
    move-result v15

    .line 181
    new-instance v9, Lawmx;

    .line 183
    invoke-direct/range {v9 .. v15}, Lawmx;-><init>(Landroid/content/Context;Ljava/lang/String;Laeaz;Ljava/lang/String;Landroid/accounts/Account;Z)V

    .line 186
    iget-object v1, v9, Lawmx;->c:Ljava/lang/String;

    .line 188
    sget-object v4, Lawne;->a:Lawne;

    .line 190
    if-nez v1, :cond_a

    .line 192
    const-string v1, ""

    .line 194
    :cond_a
    iput-object v1, v4, Lawne;->h:Ljava/lang/String;

    .line 196
    iget-object v1, v4, Lawne;->h:Ljava/lang/String;

    .line 198
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 201
    move-result v1

    .line 202
    if-eqz v1, :cond_b

    .line 204
    const-string v1, "SurveyController"

    .line 206
    const-string v10, "API key was not set or set empty by the client. API key is needed if survey is targeted for signed out users as well. For surveys targeted for only signin users, api key is not needed."

    .line 208
    invoke-static {v1, v10}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 211
    :cond_b
    iget-object v1, v4, Lawne;->h:Ljava/lang/String;

    .line 213
    invoke-virtual {v4, v9, v1}, Lawne;->a(Lawmx;Ljava/lang/String;)Lawok;

    .line 216
    move-result-object v1

    .line 217
    sget-object v10, Lbeyl;->a:Lbeyl;

    .line 219
    invoke-virtual {v10}, Lbdtb;->createBuilder()Lbdst;

    .line 222
    move-result-object v10

    .line 223
    check-cast v10, Lbeyk;

    .line 225
    iget-object v12, v4, Lawne;->h:Ljava/lang/String;

    .line 227
    invoke-virtual {v10}, Lbdst;->u()V

    .line 230
    iget-object v13, v10, Lbeyk;->b:Lbdtb;

    .line 232
    check-cast v13, Lbeyl;

    .line 234
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 237
    iput-object v12, v13, Lbeyl;->b:Ljava/lang/String;

    .line 239
    invoke-virtual {v10}, Lbdst;->u()V

    .line 242
    iget-object v12, v10, Lbeyk;->b:Lbdtb;

    .line 244
    check-cast v12, Lbeyl;

    .line 246
    iput v7, v12, Lbeyl;->c:I

    .line 248
    invoke-virtual {v10}, Lbdst;->q()Lbdtb;

    .line 251
    move-result-object v10

    .line 252
    check-cast v10, Lbeyl;

    .line 254
    const-string v12, "AIzaSyBmGDOmYcGmylWMKTdQxmf5vXWAuybv7qA"

    .line 256
    invoke-virtual {v4, v9, v12}, Lawne;->a(Lawmx;Ljava/lang/String;)Lawok;

    .line 259
    move-result-object v12

    .line 260
    new-instance v13, Lawnd;

    .line 262
    invoke-direct {v13, v4, v9, v1}, Lawnd;-><init>(Lawne;Lawmx;Lawok;)V

    .line 265
    if-nez v10, :cond_c

    .line 267
    const-string v1, "NetworkCallerGrpc"

    .line 269
    const-string v4, "Survey startup config request was null"

    .line 271
    invoke-static {v1, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 274
    goto :goto_2

    .line 275
    :cond_c
    sget v1, Lawpa;->a:I

    .line 277
    invoke-static {}, Lawnt;->a()Ljava/util/concurrent/Executor;

    .line 280
    move-result-object v1

    .line 281
    new-instance v4, Lawnw;

    .line 283
    check-cast v12, Lawod;

    .line 285
    invoke-direct {v4, v12, v10, v13}, Lawnw;-><init>(Lawod;Lbeyl;Lawnd;)V

    .line 288
    invoke-interface {v1, v4}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 291
    :goto_2
    iget-object v1, v0, Laeba;->f:Ladsu;

    .line 293
    if-nez v1, :cond_d

    .line 295
    iget-object v1, v0, Laeba;->d:Ladsy;

    .line 297
    iput-object v11, v2, Laeay;->e:Ljava/lang/String;

    .line 299
    iput-object v6, v2, Laeay;->f:Lbien;

    .line 301
    iput-object v0, v2, Laeay;->a:Ljava/lang/Object;

    .line 303
    iput v7, v2, Laeay;->d:I

    .line 305
    invoke-interface {v1, v2}, Ladsy;->a(Lbhtu;)Ljava/lang/Object;

    .line 308
    move-result-object v1

    .line 309
    if-eq v1, v3, :cond_f

    .line 311
    move-object v4, v0

    .line 312
    move-object v7, v11

    .line 313
    :goto_3
    check-cast v1, Ladsu;

    .line 315
    check-cast v4, Laeba;

    .line 317
    iput-object v1, v4, Laeba;->f:Ladsu;

    .line 319
    goto :goto_4

    .line 320
    :cond_d
    move-object v7, v11

    .line 321
    :goto_4
    iput-object v7, v2, Laeay;->e:Ljava/lang/String;

    .line 323
    iput-object v8, v2, Laeay;->f:Lbien;

    .line 325
    iput-object v8, v2, Laeay;->a:Ljava/lang/Object;

    .line 327
    iput v5, v2, Laeay;->d:I

    .line 329
    invoke-virtual {v6, v2}, Lbihp;->go(Lbhtu;)Ljava/lang/Object;

    .line 332
    move-result-object v1

    .line 333
    if-eq v1, v3, :cond_f

    .line 335
    move-object v2, v7

    .line 336
    :goto_5
    check-cast v1, Lcom/google/android/libraries/surveys/SurveyData;

    .line 338
    if-eqz v1, :cond_e

    .line 340
    iget-object v0, v0, Laeba;->e:Ljava/util/Map;

    .line 342
    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 345
    :cond_e
    return-object v1

    .line 346
    :cond_f
    :goto_6
    return-object v3

    .line 347
    :cond_10
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 349
    const-string v1, "Trigger ID cannot be null or empty."

    .line 351
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 354
    throw v0
.end method

.method public final n(Laeaq;)V
    .locals 2

    .line 1
    invoke-interface {p1}, Laeaq;->c()Ljava/util/List;

    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Laear;

    .line 7
    invoke-direct {v1, p0, p1}, Laear;-><init>(Laeba;Laeaq;)V

    .line 10
    iget-object p0, p0, Laeba;->o:Ladzn;

    .line 12
    invoke-virtual {p0, v0, v1}, Ladzn;->b(Ljava/util/List;Lbhwq;)V

    .line 15
    return-void
.end method

.method protected final o(Ldw;Lcom/google/android/libraries/surveys/SurveyData;Ljava/util/List;)V
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p2

    .line 5
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    invoke-virtual/range {p1 .. p1}, Ldw;->E()Lec;

    .line 14
    move-result-object v2

    .line 15
    sget-object v3, Lawmt;->b:Lawmt;

    .line 17
    sget-object v4, Lawms;->a:Lawms;

    .line 19
    const/16 v5, 0xc8

    .line 21
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 24
    move-result-object v6

    .line 25
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    iget-object v7, v0, Laeba;->a:Landroid/accounts/Account;

    .line 30
    const/16 v8, 0xc

    .line 32
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 35
    move-result-object v9

    .line 36
    if-nez p3, :cond_0

    .line 38
    const/4 v11, 0x0

    .line 39
    goto :goto_0

    .line 40
    :cond_0
    move-object/from16 v11, p3

    .line 42
    :goto_0
    iget-object v0, v0, Laeba;->f:Ladsu;

    .line 44
    if-eqz v0, :cond_41

    .line 46
    const-string v12, "HaTS"

    .line 48
    invoke-interface {v0, v12}, Ladsu;->c(Ljava/lang/String;)Z

    .line 51
    move-result v12

    .line 52
    if-eqz v12, :cond_40

    .line 54
    new-instance v12, Laeax;

    .line 56
    invoke-direct {v12, v0}, Laeax;-><init>(Ladsu;)V

    .line 59
    sget-object v13, Lawne;->a:Lawne;

    .line 61
    new-instance v14, Lawoy;

    .line 63
    invoke-direct {v14}, Lawoy;-><init>()V

    .line 66
    sget-object v15, Lawne;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 68
    monitor-enter v15

    .line 69
    :try_start_0
    sget-object v0, Lbeib;->a:Lbeib;

    .line 71
    invoke-virtual {v0}, Lbdtb;->createBuilder()Lbdst;

    .line 74
    move-result-object v0

    .line 75
    move-object v8, v0

    .line 76
    check-cast v8, Lbeia;

    .line 78
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 81
    invoke-virtual {v8}, Lbdst;->u()V

    .line 84
    iget-object v0, v8, Lbeia;->b:Lbdtb;

    .line 86
    check-cast v0, Lbeib;

    .line 88
    iget v6, v0, Lbeib;->b:I

    .line 90
    const/4 v10, 0x1

    .line 91
    or-int/2addr v6, v10

    .line 92
    iput v6, v0, Lbeib;->b:I

    .line 94
    iput v5, v0, Lbeib;->c:I

    .line 96
    sget-object v0, Lawov;->c:Lawpf;

    .line 98
    sget-object v0, Lawov;->b:Landroid/content/Context;

    .line 100
    invoke-static {v0}, Lbgou;->c(Landroid/content/Context;)Z

    .line 103
    move-result v0

    .line 104
    invoke-static {v0}, Lawov;->c(Z)Z

    .line 107
    move-result v0

    .line 108
    const/4 v5, 0x4

    .line 109
    const/4 v6, 0x2

    .line 110
    if-eqz v0, :cond_6

    .line 112
    invoke-virtual {v4}, Lawms;->ordinal()I

    .line 115
    move-result v0

    .line 116
    if-eqz v0, :cond_3

    .line 118
    if-eq v0, v10, :cond_2

    .line 120
    if-ne v0, v6, :cond_1

    .line 122
    move v0, v6

    .line 123
    goto :goto_1

    .line 124
    :cond_1
    new-instance v0, Ljava/lang/RuntimeException;

    .line 126
    const/4 v1, 0x0

    .line 127
    invoke-direct {v0, v1, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 130
    throw v0

    .line 131
    :cond_2
    move v0, v5

    .line 132
    goto :goto_1

    .line 133
    :cond_3
    const/4 v0, 0x3

    .line 134
    :goto_1
    invoke-virtual {v8}, Lbdst;->u()V

    .line 137
    move/from16 p3, v6

    .line 139
    iget-object v6, v8, Lbeia;->b:Lbdtb;

    .line 141
    check-cast v6, Lbeib;

    .line 143
    add-int/lit8 v0, v0, -0x2

    .line 145
    iput v0, v6, Lbeib;->e:I

    .line 147
    iget v0, v6, Lbeib;->b:I

    .line 149
    or-int/lit8 v0, v0, 0x2

    .line 151
    iput v0, v6, Lbeib;->b:I

    .line 153
    invoke-virtual {v3}, Lawmt;->ordinal()I

    .line 156
    move-result v0

    .line 157
    if-eqz v0, :cond_5

    .line 159
    if-ne v0, v10, :cond_4

    .line 161
    const/4 v0, 0x3

    .line 162
    goto :goto_2

    .line 163
    :cond_4
    new-instance v0, Ljava/lang/RuntimeException;

    .line 165
    const/4 v1, 0x0

    .line 166
    invoke-direct {v0, v1, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 169
    throw v0

    .line 170
    :cond_5
    move v0, v5

    .line 171
    :goto_2
    invoke-virtual {v8}, Lbdst;->u()V

    .line 174
    iget-object v6, v8, Lbeia;->b:Lbdtb;

    .line 176
    check-cast v6, Lbeib;

    .line 178
    add-int/lit8 v0, v0, -0x2

    .line 180
    iput v0, v6, Lbeib;->f:I

    .line 182
    iget v0, v6, Lbeib;->b:I

    .line 184
    or-int/2addr v0, v5

    .line 185
    iput v0, v6, Lbeib;->b:I

    .line 187
    goto :goto_3

    .line 188
    :cond_6
    move/from16 p3, v6

    .line 190
    :goto_3
    invoke-virtual {v15}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 193
    move-result v0

    .line 194
    if-eqz v0, :cond_8

    .line 196
    sget v0, Lawpa;->a:I

    .line 198
    instance-of v0, v1, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;

    .line 200
    if-eqz v0, :cond_7

    .line 202
    invoke-interface {v1}, Lcom/google/android/libraries/surveys/SurveyData;->a()V

    .line 205
    :cond_7
    const/16 v0, 0x8

    .line 207
    invoke-virtual {v8, v0}, Lbeia;->a(I)V

    .line 210
    invoke-virtual {v8}, Lbdst;->q()Lbdtb;

    .line 213
    move-result-object v0

    .line 214
    check-cast v0, Lbeib;

    .line 216
    invoke-virtual {v13, v0, v14, v2}, Lawne;->d(Lbeib;Lawoy;Landroid/content/Context;)V

    .line 219
    monitor-exit v15

    .line 220
    return-void

    .line 221
    :cond_8
    instance-of v0, v1, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;

    .line 223
    if-eqz v0, :cond_3f

    .line 225
    check-cast v1, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;

    .line 227
    iput-object v1, v13, Lawne;->d:Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;

    .line 229
    sget-object v0, Lawnq;->b:Lawnq;

    .line 231
    iget-object v6, v13, Lawne;->c:Lawnf;

    .line 233
    invoke-virtual {v1}, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->b()Ljava/lang/String;

    .line 236
    move-result-object v17

    .line 237
    if-nez v17, :cond_9

    .line 239
    sget v0, Lawpa;->a:I

    .line 241
    goto :goto_4

    .line 242
    :cond_9
    iget-object v10, v6, Lawnf;->d:Ljava/util/Map;

    .line 244
    invoke-virtual {v1}, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->b()Ljava/lang/String;

    .line 247
    move-result-object v5

    .line 248
    invoke-interface {v10, v5, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 251
    iget-object v5, v6, Lawnf;->e:Ljava/util/Map;

    .line 253
    invoke-virtual {v1}, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->b()Ljava/lang/String;

    .line 256
    move-result-object v10

    .line 257
    invoke-interface {v5, v10, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 260
    :goto_4
    invoke-virtual {v1}, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->b()Ljava/lang/String;

    .line 263
    move-result-object v0

    .line 264
    iget-object v5, v6, Lawnf;->f:Ljava/util/Map;

    .line 266
    invoke-interface {v5, v0, v12}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 269
    iput-object v12, v13, Lawne;->k:Laeax;

    .line 271
    iget-object v0, v13, Lawne;->l:Laoxo;

    .line 273
    move-object v5, v9

    .line 274
    iget-wide v9, v1, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->e:J

    .line 276
    invoke-static {v9, v10}, Lawpa;->n(J)Z

    .line 279
    move-result v0

    .line 280
    const/16 v12, 0x9

    .line 282
    if-eqz v0, :cond_a

    .line 284
    const-string v0, "SurveyController"

    .line 286
    const-string v3, "Cancelling show request since SurveyData was expired."

    .line 288
    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 291
    invoke-virtual {v13, v1}, Lawne;->e(Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;)V

    .line 294
    invoke-virtual {v8, v12}, Lbeia;->a(I)V

    .line 297
    invoke-virtual {v8}, Lbdst;->q()Lbdtb;

    .line 300
    move-result-object v0

    .line 301
    check-cast v0, Lbeib;

    .line 303
    invoke-virtual {v13, v0, v14, v2}, Lawne;->d(Lbeib;Lawoy;Landroid/content/Context;)V

    .line 306
    monitor-exit v15

    .line 307
    return-void

    .line 308
    :cond_a
    invoke-virtual {v2}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;

    .line 311
    move-wide/from16 v18, v9

    .line 313
    iget-wide v9, v13, Lawne;->i:J

    .line 315
    cmp-long v0, v9, v18

    .line 317
    if-gtz v0, :cond_3e

    .line 319
    invoke-virtual {v2}, Landroid/app/Activity;->isFinishing()Z

    .line 322
    move-result v0

    .line 323
    if-eqz v0, :cond_b

    .line 325
    const-string v0, "SurveyController"

    .line 327
    const-string v3, "Cancelling show request since activity was finishing."

    .line 329
    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 332
    invoke-virtual {v13, v1}, Lawne;->e(Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;)V

    .line 335
    const/4 v1, 0x4

    .line 336
    invoke-virtual {v8, v1}, Lbeia;->a(I)V

    .line 339
    invoke-virtual {v8}, Lbdst;->q()Lbdtb;

    .line 342
    move-result-object v0

    .line 343
    check-cast v0, Lbeib;

    .line 345
    invoke-virtual {v13, v0, v14, v2}, Lawne;->d(Lbeib;Lawoy;Landroid/content/Context;)V

    .line 348
    monitor-exit v15

    .line 349
    return-void

    .line 350
    :cond_b
    invoke-virtual {v2}, Landroid/app/Activity;->isDestroyed()Z

    .line 353
    move-result v0

    .line 354
    if-eqz v0, :cond_c

    .line 356
    const-string v0, "SurveyController"

    .line 358
    const-string v3, "Cancelling show request since activity was destroyed."

    .line 360
    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 363
    invoke-virtual {v13, v1}, Lawne;->e(Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;)V

    .line 366
    const/4 v1, 0x3

    .line 367
    invoke-virtual {v8, v1}, Lbeia;->a(I)V

    .line 370
    invoke-virtual {v8}, Lbdst;->q()Lbdtb;

    .line 373
    move-result-object v0

    .line 374
    check-cast v0, Lbeib;

    .line 376
    invoke-virtual {v13, v0, v14, v2}, Lawne;->d(Lbeib;Lawoy;Landroid/content/Context;)V

    .line 379
    monitor-exit v15

    .line 380
    return-void

    .line 381
    :cond_c
    iget-object v9, v1, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->b:Lbenc;

    .line 383
    const/4 v10, 0x7

    .line 384
    if-nez v9, :cond_d

    .line 386
    const-string v0, "SurveyController"

    .line 388
    const-string v3, "Survey payload was null."

    .line 390
    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 393
    goto :goto_5

    .line 394
    :cond_d
    iget-object v0, v9, Lbenc;->g:Lbdts;

    .line 396
    invoke-interface {v0}, Lbdts;->size()I

    .line 399
    move-result v0

    .line 400
    if-nez v0, :cond_10

    .line 402
    const-string v0, "SurveyController"

    .line 404
    iget-object v3, v1, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->a:Ljava/lang/String;

    .line 406
    const-string v4, "Survey contains no questions. Survey trigger id: "

    .line 408
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 411
    move-result-object v3

    .line 412
    invoke-virtual {v4, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 415
    move-result-object v3

    .line 416
    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 419
    iget-object v0, v1, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->d:Ljava/lang/String;

    .line 421
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 424
    move-result v3

    .line 425
    if-nez v3, :cond_e

    .line 427
    const-string v3, "SurveyController"

    .line 429
    const-string v4, "No survey available reason: "

    .line 431
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 434
    move-result-object v0

    .line 435
    invoke-virtual {v4, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 438
    move-result-object v0

    .line 439
    invoke-static {v3, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 442
    :cond_e
    iget-object v0, v1, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->f:Laypd;

    .line 444
    if-eqz v0, :cond_f

    .line 446
    invoke-virtual {v0}, Laypd;->isEmpty()Z

    .line 449
    move-result v3

    .line 450
    if-nez v3, :cond_f

    .line 452
    const-string v3, "SurveyController"

    .line 454
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 457
    move-result-object v0

    .line 458
    const-string v4, "Backend errors are: "

    .line 460
    invoke-virtual {v4, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 463
    move-result-object v0

    .line 464
    invoke-static {v3, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 467
    :cond_f
    :goto_5
    invoke-virtual {v13, v1}, Lawne;->e(Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;)V

    .line 470
    invoke-virtual {v8, v10}, Lbeia;->a(I)V

    .line 473
    invoke-virtual {v8}, Lbdst;->q()Lbdtb;

    .line 476
    move-result-object v0

    .line 477
    check-cast v0, Lbeib;

    .line 479
    invoke-virtual {v13, v0, v14, v2}, Lawne;->d(Lbeib;Lawoy;Landroid/content/Context;)V

    .line 482
    monitor-exit v15

    .line 483
    return-void

    .line 484
    :cond_10
    sget-object v0, Lawov;->c:Lawpf;

    .line 486
    sget-object v0, Lawov;->b:Landroid/content/Context;

    .line 488
    invoke-static {v0}, Lbgou;->c(Landroid/content/Context;)Z

    .line 491
    move-result v0

    .line 492
    invoke-static {v0}, Lawov;->c(Z)Z

    .line 495
    move-result v0

    .line 496
    if-eqz v0, :cond_19

    .line 498
    invoke-static {v2}, Lawpa;->l(Landroid/content/Context;)Z

    .line 501
    move-result v0

    .line 502
    if-nez v0, :cond_19

    .line 504
    iget-object v0, v9, Lbenc;->d:Lbelo;

    .line 506
    if-nez v0, :cond_11

    .line 508
    sget-object v0, Lbelo;->b:Lbelo;

    .line 510
    :cond_11
    new-instance v12, Lbdtl;

    .line 512
    iget-object v0, v0, Lbelo;->f:Lbdtj;

    .line 514
    sget-object v10, Lbelo;->a:Lbdtk;

    .line 516
    invoke-direct {v12, v0, v10}, Lbdtl;-><init>(Lbdtj;Lbdtk;)V

    .line 519
    invoke-virtual {v4}, Lawms;->ordinal()I

    .line 522
    move-result v0

    .line 523
    if-eqz v0, :cond_14

    .line 525
    const/4 v10, 0x1

    .line 526
    if-eq v0, v10, :cond_13

    .line 528
    move/from16 v10, p3

    .line 530
    if-ne v0, v10, :cond_12

    .line 532
    goto :goto_7

    .line 533
    :cond_12
    new-instance v0, Ljava/lang/RuntimeException;

    .line 535
    const/4 v1, 0x0

    .line 536
    invoke-direct {v0, v1, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 539
    throw v0

    .line 540
    :cond_13
    sget-object v0, Lbeln;->c:Lbeln;

    .line 542
    invoke-interface {v12, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 545
    move-result v0

    .line 546
    goto :goto_6

    .line 547
    :cond_14
    sget-object v0, Lbeln;->b:Lbeln;

    .line 549
    invoke-interface {v12, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 552
    move-result v0

    .line 553
    :goto_6
    if-nez v0, :cond_15

    .line 555
    invoke-virtual {v13, v1}, Lawne;->e(Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;)V

    .line 558
    const/16 v0, 0xa

    .line 560
    invoke-virtual {v8, v0}, Lbeia;->a(I)V

    .line 563
    invoke-virtual {v8}, Lbdst;->q()Lbdtb;

    .line 566
    move-result-object v0

    .line 567
    check-cast v0, Lbeib;

    .line 569
    invoke-virtual {v13, v0, v14, v2}, Lawne;->d(Lbeib;Lawoy;Landroid/content/Context;)V

    .line 572
    monitor-exit v15

    .line 573
    return-void

    .line 574
    :cond_15
    :goto_7
    iget-object v0, v9, Lbenc;->e:Lbelu;

    .line 576
    if-nez v0, :cond_16

    .line 578
    sget-object v0, Lbelu;->b:Lbelu;

    .line 580
    :cond_16
    new-instance v10, Lbdtl;

    .line 582
    iget-object v0, v0, Lbelu;->f:Lbdtj;

    .line 584
    sget-object v12, Lbelu;->a:Lbdtk;

    .line 586
    invoke-direct {v10, v0, v12}, Lbdtl;-><init>(Lbdtj;Lbdtk;)V

    .line 589
    invoke-virtual {v3}, Lawmt;->ordinal()I

    .line 592
    move-result v0

    .line 593
    if-eqz v0, :cond_18

    .line 595
    const/4 v12, 0x1

    .line 596
    if-ne v0, v12, :cond_17

    .line 598
    sget-object v0, Lbelt;->b:Lbelt;

    .line 600
    invoke-interface {v10, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 603
    move-result v0

    .line 604
    goto :goto_8

    .line 605
    :cond_17
    new-instance v0, Ljava/lang/RuntimeException;

    .line 607
    const/4 v1, 0x0

    .line 608
    invoke-direct {v0, v1, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 611
    throw v0

    .line 612
    :cond_18
    sget-object v0, Lbelt;->c:Lbelt;

    .line 614
    invoke-interface {v10, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 617
    move-result v0

    .line 618
    :goto_8
    if-nez v0, :cond_19

    .line 620
    invoke-virtual {v13, v1}, Lawne;->e(Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;)V

    .line 623
    const/16 v0, 0xb

    .line 625
    invoke-virtual {v8, v0}, Lbeia;->a(I)V

    .line 628
    invoke-virtual {v8}, Lbdst;->q()Lbdtb;

    .line 631
    move-result-object v0

    .line 632
    check-cast v0, Lbeib;

    .line 634
    invoke-virtual {v13, v0, v14, v2}, Lawne;->d(Lbeib;Lawoy;Landroid/content/Context;)V

    .line 637
    monitor-exit v15

    .line 638
    return-void

    .line 639
    :cond_19
    iget-object v0, v7, Landroid/accounts/Account;->name:Ljava/lang/String;

    .line 641
    iput-object v0, v13, Lawne;->e:Ljava/lang/String;

    .line 643
    if-nez v11, :cond_1a

    .line 645
    sget-object v0, Layux;->a:Laypd;

    .line 647
    goto :goto_9

    .line 648
    :cond_1a
    invoke-static {v11}, Laypd;->o(Ljava/util/Collection;)Laypd;

    .line 651
    move-result-object v0

    .line 652
    :goto_9
    iput-object v0, v13, Lawne;->f:Laypd;

    .line 654
    invoke-virtual {v1}, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->b()Ljava/lang/String;

    .line 657
    move-result-object v0

    .line 658
    iget-object v7, v13, Lawne;->f:Laypd;

    .line 660
    iget-object v6, v6, Lawnf;->b:Ljava/util/Map;

    .line 662
    invoke-interface {v6, v0, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 665
    iget-object v7, v1, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->a:Ljava/lang/String;

    .line 667
    invoke-virtual {v1}, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->b()Ljava/lang/String;

    .line 670
    move-result-object v0

    .line 671
    new-instance v10, Lcom/google/android/libraries/surveys/internal/model/Answer;

    .line 673
    invoke-direct {v10}, Lcom/google/android/libraries/surveys/internal/model/Answer;-><init>()V

    .line 676
    iget-object v11, v13, Lawne;->e:Ljava/lang/String;

    .line 678
    iput-object v11, v10, Lcom/google/android/libraries/surveys/internal/model/Answer;->b:Ljava/lang/String;

    .line 680
    invoke-static {}, Lawov;->d()Z

    .line 683
    move-result v11

    .line 684
    if-eqz v11, :cond_1b

    .line 686
    invoke-interface {v6, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 689
    move-result-object v0

    .line 690
    check-cast v0, Laypd;

    .line 692
    goto :goto_a

    .line 693
    :cond_1b
    iget-object v0, v13, Lawne;->f:Laypd;

    .line 695
    :goto_a
    if-eqz v0, :cond_20

    .line 697
    invoke-virtual {v0}, Laypd;->isEmpty()Z

    .line 700
    move-result v11

    .line 701
    if-nez v11, :cond_20

    .line 703
    sget-object v11, Lbenj;->a:Lbenj;

    .line 705
    invoke-virtual {v11}, Lbdtb;->createBuilder()Lbdst;

    .line 708
    move-result-object v11

    .line 709
    check-cast v11, Lbeng;

    .line 711
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 714
    move-result v12

    .line 715
    const/4 v6, 0x0

    .line 716
    :goto_b
    if-ge v6, v12, :cond_1d

    .line 718
    invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 721
    move-result-object v18

    .line 722
    move-object/from16 v19, v0

    .line 724
    move-object/from16 v0, v18

    .line 726
    check-cast v0, Ljkd;

    .line 728
    sget-object v18, Lbeni;->a:Lbeni;

    .line 730
    invoke-virtual/range {v18 .. v18}, Lbdtb;->createBuilder()Lbdst;

    .line 733
    move-result-object v18

    .line 734
    move-object/from16 v20, v5

    .line 736
    move-object/from16 v5, v18

    .line 738
    check-cast v5, Lbenh;

    .line 740
    move/from16 v18, v6

    .line 742
    iget-object v6, v0, Ljkd;->a:Ljava/lang/Object;

    .line 744
    check-cast v6, Ljava/lang/String;

    .line 746
    invoke-virtual {v5}, Lbdst;->u()V

    .line 749
    move/from16 v21, v12

    .line 751
    iget-object v12, v5, Lbenh;->b:Lbdtb;

    .line 753
    check-cast v12, Lbeni;

    .line 755
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 758
    iput-object v6, v12, Lbeni;->b:Ljava/lang/String;

    .line 760
    iget-object v0, v0, Ljkd;->b:Ljava/lang/Object;

    .line 762
    check-cast v0, Ljava/lang/String;

    .line 764
    invoke-virtual {v5}, Lbdst;->u()V

    .line 767
    iget-object v6, v5, Lbenh;->b:Lbdtb;

    .line 769
    check-cast v6, Lbeni;

    .line 771
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 774
    iput-object v0, v6, Lbeni;->c:Ljava/lang/String;

    .line 776
    invoke-virtual {v5}, Lbdst;->q()Lbdtb;

    .line 779
    move-result-object v0

    .line 780
    check-cast v0, Lbeni;

    .line 782
    invoke-virtual {v11}, Lbdst;->u()V

    .line 785
    iget-object v5, v11, Lbeng;->b:Lbdtb;

    .line 787
    check-cast v5, Lbenj;

    .line 789
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 792
    iget-object v6, v5, Lbenj;->b:Lbdts;

    .line 794
    invoke-interface {v6}, Lbdts;->c()Z

    .line 797
    move-result v12

    .line 798
    if-nez v12, :cond_1c

    .line 800
    invoke-static {v6}, Lbdtb;->mutableCopy(Lbdts;)Lbdts;

    .line 803
    move-result-object v6

    .line 804
    iput-object v6, v5, Lbenj;->b:Lbdts;

    .line 806
    :cond_1c
    iget-object v5, v5, Lbenj;->b:Lbdts;

    .line 808
    invoke-interface {v5, v0}, Lbdts;->add(Ljava/lang/Object;)Z

    .line 811
    add-int/lit8 v6, v18, 0x1

    .line 813
    move-object/from16 v0, v19

    .line 815
    move-object/from16 v5, v20

    .line 817
    move/from16 v12, v21

    .line 819
    goto :goto_b

    .line 820
    :cond_1d
    move-object/from16 v20, v5

    .line 822
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 825
    move-result-object v0

    .line 826
    const-string v5, "Unknown"

    .line 828
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_1f

    .line 830
    :try_start_1
    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 833
    move-result-object v6

    .line 834
    const/4 v12, 0x0

    .line 835
    invoke-virtual {v0, v6, v12}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 838
    move-result-object v0

    .line 839
    if-eqz v0, :cond_1f

    .line 841
    iget-object v6, v0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    .line 843
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 846
    move-result v6

    .line 847
    if-nez v6, :cond_1e

    .line 849
    iget-object v5, v0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    .line 851
    goto :goto_c

    .line 852
    :cond_1e
    iget v0, v0, Landroid/content/pm/PackageInfo;->versionCode:I

    .line 854
    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 857
    move-result-object v5

    .line 858
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_c

    .line 859
    :catch_0
    move-exception v0

    .line 860
    :try_start_2
    const-string v6, "SurveyUtils"

    .line 862
    const-string v12, "Exception while retrieving application information."

    .line 864
    invoke-static {v6, v12, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 867
    :cond_1f
    :goto_c
    sget-object v0, Lbenk;->a:Lbenk;

    .line 869
    invoke-virtual {v0}, Lbdtb;->createBuilder()Lbdst;

    .line 872
    move-result-object v0

    .line 873
    check-cast v0, Lbenf;

    .line 875
    invoke-virtual {v11}, Lbdst;->q()Lbdtb;

    .line 878
    move-result-object v6

    .line 879
    check-cast v6, Lbenj;

    .line 881
    invoke-virtual {v0}, Lbdst;->u()V

    .line 884
    iget-object v11, v0, Lbenf;->b:Lbdtb;

    .line 886
    check-cast v11, Lbenk;

    .line 888
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 891
    iput-object v6, v11, Lbenk;->c:Lbenj;

    .line 893
    iget v6, v11, Lbenk;->b:I

    .line 895
    const/16 v17, 0x1

    .line 897
    or-int/lit8 v6, v6, 0x1

    .line 899
    iput v6, v11, Lbenk;->b:I

    .line 901
    invoke-virtual {v0}, Lbdst;->u()V

    .line 904
    iget-object v6, v0, Lbenf;->b:Lbdtb;

    .line 906
    check-cast v6, Lbenk;

    .line 908
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 911
    iput-object v5, v6, Lbenk;->d:Ljava/lang/String;

    .line 913
    invoke-virtual {v0}, Lbdst;->q()Lbdtb;

    .line 916
    move-result-object v0

    .line 917
    check-cast v0, Lbenk;

    .line 919
    iput-object v0, v10, Lcom/google/android/libraries/surveys/internal/model/Answer;->c:Lbenk;

    .line 921
    goto :goto_d

    .line 922
    :cond_20
    move-object/from16 v20, v5

    .line 924
    :goto_d
    invoke-static {}, Lawov;->d()Z

    .line 927
    move-result v0

    .line 928
    if-eqz v0, :cond_22

    .line 930
    iget-object v0, v13, Lawne;->c:Lawnf;

    .line 932
    iget-object v0, v0, Lawnf;->c:Ljava/util/Map;

    .line 934
    invoke-interface {v0, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 937
    move-result-object v0

    .line 938
    check-cast v0, Ljava/lang/Long;

    .line 940
    if-nez v0, :cond_21

    .line 942
    const-wide/16 v5, 0x0

    .line 944
    goto :goto_e

    .line 945
    :cond_21
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 948
    move-result-wide v5

    .line 949
    goto :goto_e

    .line 950
    :cond_22
    iget-wide v5, v13, Lawne;->g:J

    .line 952
    :goto_e
    iput-wide v5, v10, Lcom/google/android/libraries/surveys/internal/model/Answer;->d:J

    .line 954
    iget-object v0, v13, Lawne;->h:Ljava/lang/String;

    .line 956
    iput-object v0, v10, Lcom/google/android/libraries/surveys/internal/model/Answer;->f:Ljava/lang/String;

    .line 958
    invoke-static {v2}, Lawpa;->l(Landroid/content/Context;)Z

    .line 961
    move-result v0

    .line 962
    if-eqz v0, :cond_3b

    .line 964
    iget-object v0, v9, Lbenc;->c:Lbemu;

    .line 966
    if-nez v0, :cond_23

    .line 968
    sget-object v0, Lbemu;->a:Lbemu;

    .line 970
    :cond_23
    iget-boolean v0, v0, Lbemu;->b:Z

    .line 972
    if-eqz v0, :cond_24

    .line 974
    const-string v0, "WearPayloadValidator"

    .line 976
    const-string v1, "Invitation card is not supported for wear surveys."

    .line 978
    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 981
    :goto_f
    const/4 v3, 0x7

    .line 982
    goto/16 :goto_1b

    .line 984
    :cond_24
    iget-object v0, v9, Lbenc;->g:Lbdts;

    .line 986
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 989
    move-result-object v0

    .line 990
    :cond_25
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 993
    move-result v3

    .line 994
    if-eqz v3, :cond_3a

    .line 996
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 999
    move-result-object v3

    .line 1000
    check-cast v3, Lbenp;

    .line 1002
    iget v4, v3, Lbenp;->i:I

    .line 1004
    invoke-static {v4}, Lbeno;->a(I)I

    .line 1007
    move-result v5

    .line 1008
    const/4 v6, 0x5

    .line 1009
    if-nez v5, :cond_26

    .line 1011
    goto :goto_10

    .line 1012
    :cond_26
    const/4 v7, 0x3

    .line 1013
    if-eq v5, v7, :cond_2f

    .line 1015
    :goto_10
    invoke-static {v4}, Lbeno;->a(I)I

    .line 1018
    move-result v5

    .line 1019
    if-nez v5, :cond_27

    .line 1021
    goto :goto_11

    .line 1022
    :cond_27
    if-ne v5, v6, :cond_28

    .line 1024
    goto :goto_15

    .line 1025
    :cond_28
    :goto_11
    const-string v0, "WearPayloadValidator"

    .line 1027
    const-string v1, "Question type %s is not supported for wear surveys."

    .line 1029
    invoke-static {v4}, Lbeno;->a(I)I

    .line 1032
    move-result v3

    .line 1033
    if-nez v3, :cond_29

    .line 1035
    goto :goto_12

    .line 1036
    :cond_29
    const/4 v10, 0x2

    .line 1037
    if-eq v3, v10, :cond_2e

    .line 1039
    const/4 v7, 0x3

    .line 1040
    if-eq v3, v7, :cond_2d

    .line 1042
    const/4 v4, 0x4

    .line 1043
    if-eq v3, v4, :cond_2c

    .line 1045
    if-eq v3, v6, :cond_2b

    .line 1047
    const/4 v4, 0x6

    .line 1048
    if-eq v3, v4, :cond_2a

    .line 1050
    :goto_12
    const-string v3, "UNRECOGNIZED"

    .line 1052
    :goto_13
    const/4 v12, 0x1

    .line 1053
    goto :goto_14

    .line 1054
    :cond_2a
    const-string v3, "QUESTION_TYPE_OPEN_TEXT"

    .line 1056
    goto :goto_13

    .line 1057
    :cond_2b
    const-string v3, "QUESTION_TYPE_RATING"

    .line 1059
    goto :goto_13

    .line 1060
    :cond_2c
    const-string v3, "QUESTION_TYPE_MULTI_SELECT"

    .line 1062
    goto :goto_13

    .line 1063
    :cond_2d
    const-string v3, "QUESTION_TYPE_SINGLE_SELECT"

    .line 1065
    goto :goto_13

    .line 1066
    :cond_2e
    const-string v3, "QUESTION_TYPE_UNKNOWN"

    .line 1068
    goto :goto_13

    .line 1069
    :goto_14
    new-array v4, v12, [Ljava/lang/Object;

    .line 1071
    const/16 v16, 0x0

    .line 1073
    aput-object v3, v4, v16

    .line 1075
    invoke-static {v1, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 1078
    move-result-object v1

    .line 1079
    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1082
    goto :goto_f

    .line 1083
    :cond_2f
    :goto_15
    invoke-static {v4}, Lbeno;->a(I)I

    .line 1086
    move-result v4

    .line 1087
    if-nez v4, :cond_30

    .line 1089
    const/4 v4, 0x1

    .line 1090
    :cond_30
    if-ne v4, v6, :cond_25

    .line 1092
    iget v4, v3, Lbenp;->c:I

    .line 1094
    const/4 v5, 0x6

    .line 1095
    if-ne v4, v5, :cond_31

    .line 1097
    iget-object v4, v3, Lbenp;->d:Ljava/lang/Object;

    .line 1099
    check-cast v4, Lbenu;

    .line 1101
    goto :goto_16

    .line 1102
    :cond_31
    sget-object v4, Lbenu;->a:Lbenu;

    .line 1104
    :goto_16
    iget v4, v4, Lbenu;->b:I

    .line 1106
    invoke-static {v4}, Lbent;->a(I)I

    .line 1109
    move-result v4

    .line 1110
    if-nez v4, :cond_32

    .line 1112
    const/4 v4, 0x1

    .line 1113
    :cond_32
    const/4 v5, 0x6

    .line 1114
    if-eq v4, v5, :cond_25

    .line 1116
    const-string v0, "WearPayloadValidator"

    .line 1118
    const-string v1, "Rating type %s is not supported for wear surveys."

    .line 1120
    iget v4, v3, Lbenp;->c:I

    .line 1122
    if-ne v4, v5, :cond_33

    .line 1124
    iget-object v3, v3, Lbenp;->d:Ljava/lang/Object;

    .line 1126
    check-cast v3, Lbenu;

    .line 1128
    goto :goto_17

    .line 1129
    :cond_33
    sget-object v3, Lbenu;->a:Lbenu;

    .line 1131
    :goto_17
    iget v3, v3, Lbenu;->b:I

    .line 1133
    invoke-static {v3}, Lbent;->a(I)I

    .line 1136
    move-result v3

    .line 1137
    if-nez v3, :cond_34

    .line 1139
    goto :goto_18

    .line 1140
    :cond_34
    const/4 v10, 0x2

    .line 1141
    if-eq v3, v10, :cond_39

    .line 1143
    const/4 v7, 0x3

    .line 1144
    if-eq v3, v7, :cond_38

    .line 1146
    const/4 v4, 0x4

    .line 1147
    if-eq v3, v4, :cond_37

    .line 1149
    if-eq v3, v6, :cond_36

    .line 1151
    const/4 v5, 0x6

    .line 1152
    if-eq v3, v5, :cond_35

    .line 1154
    :goto_18
    const-string v3, "UNRECOGNIZED"

    .line 1156
    :goto_19
    const/4 v12, 0x1

    .line 1157
    goto :goto_1a

    .line 1158
    :cond_35
    const-string v3, "RATING_TYPE_THUMBS_UP_THUMBS_DOWN"

    .line 1160
    goto :goto_19

    .line 1161
    :cond_36
    const-string v3, "RATING_TYPE_NUMBERS"

    .line 1163
    goto :goto_19

    .line 1164
    :cond_37
    const-string v3, "RATING_TYPE_STARS"

    .line 1166
    goto :goto_19

    .line 1167
    :cond_38
    const-string v3, "RATING_TYPE_SMILEYS"

    .line 1169
    goto :goto_19

    .line 1170
    :cond_39
    const-string v3, "RATING_TYPE_UNKNOWN"

    .line 1172
    goto :goto_19

    .line 1173
    :goto_1a
    new-array v4, v12, [Ljava/lang/Object;

    .line 1175
    const/16 v16, 0x0

    .line 1177
    aput-object v3, v4, v16

    .line 1179
    invoke-static {v1, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 1182
    move-result-object v1

    .line 1183
    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1186
    goto/16 :goto_f

    .line 1188
    :goto_1b
    invoke-virtual {v8, v3}, Lbeia;->a(I)V

    .line 1191
    invoke-virtual {v8}, Lbdst;->q()Lbdtb;

    .line 1194
    move-result-object v0

    .line 1195
    check-cast v0, Lbeib;

    .line 1197
    invoke-virtual {v13, v0, v14, v2}, Lawne;->d(Lbeib;Lawoy;Landroid/content/Context;)V

    .line 1200
    monitor-exit v15

    .line 1201
    goto/16 :goto_1d

    .line 1203
    :cond_3a
    invoke-static {}, Lawne;->c()V

    .line 1206
    iget-object v0, v1, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->a:Ljava/lang/String;

    .line 1208
    iget-object v1, v1, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->c:Lbeoi;

    .line 1210
    new-instance v3, Landroid/content/Intent;

    .line 1212
    invoke-direct {v3}, Landroid/content/Intent;-><init>()V

    .line 1215
    const-string v4, "com.google.android.libraries.surveys.internal.wear.view.SurveyWearActivity"

    .line 1217
    invoke-virtual {v3, v2, v4}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 1220
    const-string v4, "TriggerId"

    .line 1222
    invoke-virtual {v3, v4, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 1225
    const-string v0, "SurveyPayload"

    .line 1227
    invoke-virtual {v9}, Lbdrb;->toByteArray()[B

    .line 1230
    move-result-object v4

    .line 1231
    invoke-virtual {v3, v0, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[B)Landroid/content/Intent;

    .line 1234
    const-string v0, "SurveySession"

    .line 1236
    invoke-virtual {v1}, Lbdrb;->toByteArray()[B

    .line 1239
    move-result-object v1

    .line 1240
    invoke-virtual {v3, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[B)Landroid/content/Intent;

    .line 1243
    const-string v0, "Answer"

    .line 1245
    invoke-virtual {v3, v0, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 1248
    invoke-virtual/range {v20 .. v20}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1251
    const/16 v1, 0xc

    .line 1253
    invoke-virtual {v2, v3, v1}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 1256
    invoke-virtual {v8}, Lbdst;->q()Lbdtb;

    .line 1259
    move-result-object v0

    .line 1260
    check-cast v0, Lbeib;

    .line 1262
    invoke-virtual {v13, v0, v14, v2}, Lawne;->d(Lbeib;Lawoy;Landroid/content/Context;)V

    .line 1265
    monitor-exit v15

    .line 1266
    goto/16 :goto_1d

    .line 1268
    :cond_3b
    const v0, 0x7f0a02e4

    .line 1271
    invoke-virtual {v2, v0}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    .line 1274
    move-result-object v5

    .line 1275
    if-nez v5, :cond_3c

    .line 1277
    const-string v0, "SurveyController"

    .line 1279
    const-string v3, "Cancelling show request since parent view was not found."

    .line 1281
    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 1284
    invoke-virtual {v13, v1}, Lawne;->e(Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;)V

    .line 1287
    const/16 v0, 0x10

    .line 1289
    invoke-virtual {v8, v0}, Lbeia;->a(I)V

    .line 1292
    invoke-virtual {v8}, Lbdst;->q()Lbdtb;

    .line 1295
    move-result-object v0

    .line 1296
    check-cast v0, Lbeib;

    .line 1298
    invoke-virtual {v13, v0, v14, v2}, Lawne;->d(Lbeib;Lawoy;Landroid/content/Context;)V

    .line 1301
    monitor-exit v15

    .line 1302
    goto/16 :goto_1d

    .line 1304
    :cond_3c
    invoke-static {}, Lawne;->c()V

    .line 1307
    iget-object v5, v13, Lawne;->j:Ljava/lang/String;

    .line 1309
    invoke-virtual {v2}, Lec;->a()Lfm;

    .line 1312
    move-result-object v5

    .line 1313
    const-string v6, "com.google.android.libraries.surveys.internal.PromptDialogFragment"

    .line 1315
    invoke-virtual {v5, v6}, Lfm;->e(Ljava/lang/String;)Ldw;

    .line 1318
    move-result-object v6

    .line 1319
    if-nez v6, :cond_3d

    .line 1321
    const-string v6, "com.google.android.libraries.surveys.internal.view.PromptDialogFragment"

    .line 1323
    iget-object v7, v1, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->a:Ljava/lang/String;

    .line 1325
    iget-object v1, v1, Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;->c:Lbeoi;

    .line 1327
    const-string v11, "com.google.android.libraries.surveys.internal.view.SurveyActivity"

    .line 1329
    new-instance v12, Landroid/os/Bundle;

    .line 1331
    invoke-direct {v12}, Landroid/os/Bundle;-><init>()V

    .line 1334
    const-string v0, "TriggerId"

    .line 1336
    invoke-virtual {v12, v0, v7}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 1339
    invoke-virtual {v9}, Lbdrb;->toByteArray()[B

    .line 1342
    move-result-object v0

    .line 1343
    const-string v7, "SurveyPayload"

    .line 1345
    invoke-virtual {v12, v7, v0}, Landroid/os/Bundle;->putByteArray(Ljava/lang/String;[B)V

    .line 1348
    invoke-virtual {v1}, Lbdrb;->toByteArray()[B

    .line 1351
    move-result-object v0

    .line 1352
    const-string v1, "SurveySession"

    .line 1354
    invoke-virtual {v12, v1, v0}, Landroid/os/Bundle;->putByteArray(Ljava/lang/String;[B)V

    .line 1357
    const-string v0, "Answer"

    .line 1359
    invoke-virtual {v12, v0, v10}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 1362
    invoke-virtual/range {v20 .. v20}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1365
    const-string v0, "RequestCode"

    .line 1367
    const/16 v1, 0xc

    .line 1369
    invoke-virtual {v12, v0, v1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 1372
    const-string v0, "LogoResId"

    .line 1374
    const/4 v1, 0x0

    .line 1375
    invoke-virtual {v12, v0, v1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 1378
    const-string v0, "SurveyCompletionCode"

    .line 1380
    invoke-virtual {v12, v0, v4}, Landroid/os/Bundle;->putSerializable(Ljava/lang/String;Ljava/io/Serializable;)V

    .line 1383
    const-string v0, "SurveyPromptCode"

    .line 1385
    invoke-virtual {v12, v0, v3}, Landroid/os/Bundle;->putSerializable(Ljava/lang/String;Ljava/io/Serializable;)V

    .line 1388
    const-string v0, "SurveyActivityClassName"

    .line 1390
    invoke-virtual {v12, v0, v11}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 1393
    const-string v0, "keepNextButtonForLastQuestion"

    .line 1395
    const/4 v1, 0x0

    .line 1396
    invoke-virtual {v12, v0, v1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1399
    const-string v0, "isCarDisplayFullyReachable"

    .line 1401
    const/4 v10, 0x1

    .line 1402
    invoke-virtual {v12, v0, v10}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1405
    const-string v0, "isCarDisplayRightOfUser"

    .line 1407
    invoke-virtual {v12, v0, v10}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1410
    invoke-static {v2, v6, v12}, Ldw;->C(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Ldw;

    .line 1413
    move-result-object v0

    .line 1414
    new-instance v1, Lbd;

    .line 1416
    invoke-direct {v1, v5}, Lbd;-><init>(Lfm;)V

    .line 1419
    const-string v3, "com.google.android.libraries.surveys.internal.PromptDialogFragment"

    .line 1421
    const v4, 0x7f0a02e4

    .line 1424
    const/4 v10, 0x2

    .line 1425
    invoke-virtual {v1, v4, v0, v3, v10}, Lgc;->f(ILdw;Ljava/lang/String;I)V

    .line 1428
    const/4 v12, 0x1

    .line 1429
    invoke-virtual {v1, v12, v12}, Lbd;->a(ZZ)I

    .line 1432
    goto :goto_1c

    .line 1433
    :cond_3d
    const-string v0, "SurveyNavigator"

    .line 1435
    const-string v1, "PromptDialog was already open, bailing out."

    .line 1437
    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 1440
    :goto_1c
    invoke-virtual {v8}, Lbdst;->q()Lbdtb;

    .line 1443
    move-result-object v0

    .line 1444
    check-cast v0, Lbeib;

    .line 1446
    invoke-virtual {v13, v0, v14, v2}, Lawne;->d(Lbeib;Lawoy;Landroid/content/Context;)V

    .line 1449
    monitor-exit v15

    .line 1450
    goto :goto_1d

    .line 1451
    :cond_3e
    sget-object v0, Lawov;->c:Lawpf;

    .line 1453
    sget-object v0, Lawov;->b:Landroid/content/Context;

    .line 1455
    sget-object v3, Lbgox;->a:Lbgox;

    .line 1457
    invoke-virtual {v3}, Lbgox;->b()Lbgoy;

    .line 1460
    move-result-object v3

    .line 1461
    invoke-interface {v3, v0}, Lbgoy;->a(Landroid/content/Context;)Z

    .line 1464
    move-result v0

    .line 1465
    invoke-static {v0}, Lawov;->c(Z)Z

    .line 1468
    const-string v0, "SurveyController"

    .line 1470
    const-string v3, "Cancelling show request since SurveyData was older than oldest valid trigger request."

    .line 1472
    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 1475
    invoke-virtual {v13, v1}, Lawne;->e(Lcom/google/android/libraries/surveys/internal/model/SurveyDataImpl;)V

    .line 1478
    invoke-virtual {v8, v12}, Lbeia;->a(I)V

    .line 1481
    invoke-virtual {v8}, Lbdst;->q()Lbdtb;

    .line 1484
    move-result-object v0

    .line 1485
    check-cast v0, Lbeib;

    .line 1487
    invoke-virtual {v13, v0, v14, v2}, Lawne;->d(Lbeib;Lawoy;Landroid/content/Context;)V

    .line 1490
    monitor-exit v15

    .line 1491
    return-void

    .line 1492
    :cond_3f
    const/4 v5, 0x6

    .line 1493
    invoke-virtual {v8, v5}, Lbeia;->a(I)V

    .line 1496
    invoke-virtual {v8}, Lbdst;->q()Lbdtb;

    .line 1499
    move-result-object v0

    .line 1500
    check-cast v0, Lbeib;

    .line 1502
    invoke-virtual {v13, v0, v14, v2}, Lawne;->d(Lbeib;Lawoy;Landroid/content/Context;)V

    .line 1505
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 1507
    const-string v1, "Survey data is not the correct type."

    .line 1509
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 1512
    throw v0

    .line 1513
    :catchall_0
    move-exception v0

    .line 1514
    monitor-exit v15

    .line 1515
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0

    .line 1516
    :cond_40
    :goto_1d
    return-void

    .line 1517
    :cond_41
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 1519
    const-string v1, "Required value was null."

    .line 1521
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 1524
    throw v0
.end method
