.class final Lacfi;
.super Lmld;
.source "PG"


# virtual methods
.method public final a()Ljava/lang/String;
    .locals 0

    .line 1
    const-string p0, "INSERT OR ABORT INTO `pending_copy_quota_updates` (`volumeId`,`copiedCharacterCount`,`updateId`) VALUES (?,?,nullif(?, 0))"

    .line 3
    return-object p0
.end method

.method public final bridge synthetic b(Lmrh;Ljava/lang/Object;)V
    .locals 2

    .line 1
    check-cast p2, Lacgl;

    .line 3
    iget-object p0, p2, Lacgl;->a:Ljava/lang/String;

    .line 5
    const/4 v0, 0x1

    .line 6
    invoke-interface {p1, v0, p0}, Lmrh;->j(ILjava/lang/String;)V

    .line 9
    iget-wide v0, p2, Lacgl;->b:J

    .line 11
    const/4 p0, 0x2

    .line 12
    invoke-interface {p1, p0, v0, v1}, Lmrh;->h(IJ)V

    .line 15
    iget p0, p2, Lacgl;->c:I

    .line 17
    int-to-long v0, p0

    .line 18
    const/4 p0, 0x3

    .line 19
    invoke-interface {p1, p0, v0, v1}, Lmrh;->h(IJ)V

    .line 22
    return-void
.end method
