.class public final Lacgz;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Lbhpa;

.field public final b:Lbhpa;

.field public final c:Lbhpa;

.field public final d:Lbhpa;

.field public final e:Lbhpa;

.field public final f:Lbhpa;

.field public final g:Lbhpa;

.field public final h:Lbhpa;

.field public final i:Lbhpa;

.field public final j:Lbhpa;


# direct methods
.method public constructor <init>(Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    iput-object p1, p0, Lacgz;->a:Lbhpa;

    .line 9
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    iput-object p2, p0, Lacgz;->b:Lbhpa;

    .line 14
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    iput-object p3, p0, Lacgz;->c:Lbhpa;

    .line 19
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    iput-object p4, p0, Lacgz;->d:Lbhpa;

    .line 24
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    iput-object p5, p0, Lacgz;->e:Lbhpa;

    .line 29
    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    iput-object p6, p0, Lacgz;->f:Lbhpa;

    .line 34
    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    iput-object p7, p0, Lacgz;->g:Lbhpa;

    .line 39
    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    iput-object p8, p0, Lacgz;->h:Lbhpa;

    .line 44
    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    iput-object p9, p0, Lacgz;->i:Lbhpa;

    .line 49
    invoke-virtual {p10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 52
    iput-object p10, p0, Lacgz;->j:Lbhpa;

    .line 54
    return-void
.end method
