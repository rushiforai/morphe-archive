.class public final Ladwg;
.super Ljava/lang/Object;
.source "PG"


# direct methods
.method public static final a(Landroid/view/ViewGroup;Landroid/graphics/RectF;I)Ljava/util/List;
    .locals 8

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 6
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 9
    move-result v1

    .line 10
    :goto_0
    if-ge p2, v1, :cond_9

    .line 12
    invoke-virtual {p0, p2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 15
    move-result-object v2

    .line 16
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    invoke-static {v2}, Ladwg;->b(Landroid/view/View;)Z

    .line 22
    move-result v3

    .line 23
    if-eqz v3, :cond_0

    .line 25
    goto/16 :goto_3

    .line 27
    :cond_0
    instance-of v3, v2, Landroid/view/ViewGroup;

    .line 29
    if-eqz v3, :cond_5

    .line 31
    move-object v3, v2

    .line 32
    check-cast v3, Landroid/view/ViewGroup;

    .line 34
    new-instance v4, Landroid/graphics/RectF;

    .line 36
    invoke-direct {v4, p1}, Landroid/graphics/RectF;-><init>(Landroid/graphics/RectF;)V

    .line 39
    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 42
    move-result-object v5

    .line 43
    instance-of v6, v5, Landroid/view/ViewGroup;

    .line 45
    const/4 v7, 0x0

    .line 46
    if-eqz v6, :cond_1

    .line 48
    check-cast v5, Landroid/view/ViewGroup;

    .line 50
    goto :goto_1

    .line 51
    :cond_1
    move-object v5, v7

    .line 52
    :goto_1
    if-eqz v5, :cond_2

    .line 54
    invoke-virtual {v5}, Landroid/view/ViewGroup;->getScrollX()I

    .line 57
    move-result v6

    .line 58
    int-to-float v6, v6

    .line 59
    invoke-virtual {v5}, Landroid/view/ViewGroup;->getScrollY()I

    .line 62
    move-result v5

    .line 63
    int-to-float v5, v5

    .line 64
    invoke-virtual {v4, v6, v5}, Landroid/graphics/RectF;->offset(FF)V

    .line 67
    :cond_2
    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    .line 70
    move-result v5

    .line 71
    int-to-float v5, v5

    .line 72
    invoke-virtual {v3}, Landroid/view/View;->getTop()I

    .line 75
    move-result v6

    .line 76
    int-to-float v6, v6

    .line 77
    neg-float v5, v5

    .line 78
    neg-float v6, v6

    .line 79
    invoke-virtual {v4, v5, v6}, Landroid/graphics/RectF;->offset(FF)V

    .line 82
    invoke-virtual {v3}, Landroid/view/View;->getMatrix()Landroid/graphics/Matrix;

    .line 85
    move-result-object v5

    .line 86
    invoke-virtual {v5}, Landroid/graphics/Matrix;->isIdentity()Z

    .line 89
    move-result v5

    .line 90
    if-nez v5, :cond_3

    .line 92
    new-instance v5, Landroid/graphics/Matrix;

    .line 94
    invoke-direct {v5}, Landroid/graphics/Matrix;-><init>()V

    .line 97
    invoke-virtual {v3}, Landroid/view/View;->getMatrix()Landroid/graphics/Matrix;

    .line 100
    move-result-object v6

    .line 101
    invoke-virtual {v6, v5}, Landroid/graphics/Matrix;->invert(Landroid/graphics/Matrix;)Z

    .line 104
    move-result v6

    .line 105
    if-eqz v6, :cond_3

    .line 107
    invoke-virtual {v5, v4}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;)Z

    .line 110
    :cond_3
    const/4 v5, 0x0

    .line 111
    invoke-static {v3, v4, v5}, Ladwg;->a(Landroid/view/ViewGroup;Landroid/graphics/RectF;I)Ljava/util/List;

    .line 114
    move-result-object v4

    .line 115
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getClipChildren()Z

    .line 118
    move-result v5

    .line 119
    if-eqz v5, :cond_4

    .line 121
    invoke-static {v3}, Ladwa;->a(Landroid/view/View;)Landroid/graphics/RectF;

    .line 124
    move-result-object v7

    .line 125
    :cond_4
    new-instance v5, Ladwf;

    .line 127
    invoke-direct {v5, v7, v3}, Ladwf;-><init>(Landroid/graphics/RectF;Landroid/view/ViewGroup;)V

    .line 130
    invoke-static {v4, v5}, Lbhrj;->y(Ljava/util/List;Lbhwq;)V

    .line 133
    invoke-static {v0, v4}, Lbhrc;->v(Ljava/util/Collection;Ljava/lang/Iterable;)V

    .line 136
    :cond_5
    invoke-virtual {v2}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 139
    move-result-object v3

    .line 140
    if-eqz v3, :cond_6

    .line 142
    goto :goto_2

    .line 143
    :cond_6
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 146
    move-result-object v3

    .line 147
    const-class v4, Landroid/view/View;

    .line 149
    if-eq v3, v4, :cond_8

    .line 151
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 154
    move-result-object v3

    .line 155
    const-class v4, Landroid/widget/Space;

    .line 157
    if-eq v3, v4, :cond_8

    .line 159
    invoke-virtual {v2}, Landroid/view/View;->willNotDraw()Z

    .line 162
    move-result v3

    .line 163
    if-eqz v3, :cond_7

    .line 165
    goto :goto_3

    .line 166
    :cond_7
    :goto_2
    invoke-static {v2}, Ladwa;->a(Landroid/view/View;)Landroid/graphics/RectF;

    .line 169
    move-result-object v3

    .line 170
    invoke-static {v2, v3}, Ladwa;->b(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 173
    invoke-static {v3, p1}, Ladvz;->a(Landroid/graphics/RectF;Landroid/graphics/RectF;)Z

    .line 176
    move-result v2

    .line 177
    if-eqz v2, :cond_8

    .line 179
    new-instance v2, Lcom/google/android/apps/play/books/educampaign/ui/viewvisibility/RectFWithView;

    .line 181
    invoke-direct {v2, v3}, Landroid/graphics/RectF;-><init>(Landroid/graphics/RectF;)V

    .line 184
    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 187
    :cond_8
    :goto_3
    add-int/lit8 p2, p2, 0x1

    .line 189
    goto/16 :goto_0

    .line 191
    :cond_9
    return-object v0
.end method

.method public static final b(Landroid/view/View;)Z
    .locals 4

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_1

    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getAlpha()F

    .line 10
    move-result p0

    .line 11
    float-to-double v0, p0

    .line 12
    const-wide v2, 0x3f60624dd2f1a9fcL    # 0.002

    .line 17
    cmpg-double p0, v0, v2

    .line 19
    if-gez p0, :cond_0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 p0, 0x0

    .line 23
    return p0

    .line 24
    :cond_1
    :goto_0
    const/4 p0, 0x1

    .line 25
    return p0
.end method
