.class public final Ladxd;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    .line 4
    move-result-object p0

    .line 5
    new-instance v0, Ladxg;

    .line 7
    invoke-direct {v0, p0}, Ladxg;-><init>(Ljava/util/concurrent/Executor;)V

    .line 10
    return-object v0
.end method
