.class public final Laaji;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# direct methods
.method public static final a()Lalyv;
    .locals 3

    .line 1
    new-instance v0, Laajg;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance v1, Lalyv;

    .line 8
    const-class v2, Laakc;

    .line 10
    invoke-direct {v1, v2, v0}, Lalyv;-><init>(Ljava/lang/Class;Lbhwq;)V

    .line 13
    return-object v1
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    throw p0
.end method
