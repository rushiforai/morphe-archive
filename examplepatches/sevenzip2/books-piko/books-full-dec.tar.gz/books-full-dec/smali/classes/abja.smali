.class public interface abstract Labja;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract k(Ljava/lang/String;)V
.end method
