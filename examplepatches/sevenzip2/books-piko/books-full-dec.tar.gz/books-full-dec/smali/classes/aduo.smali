.class final Laduo;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field final synthetic a:Ladtd;


# direct methods
.method public constructor <init>(Ladtd;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laduo;->a:Ladtd;

    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, Lbhuu;-><init>(ILbhtu;)V

    .line 7
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Ladtd;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Laduo;

    .line 13
    invoke-virtual {p0, p1}, Laduo;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 4
    iget-object p0, p0, Laduo;->a:Ladtd;

    .line 6
    return-object p0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 0

    .line 1
    new-instance p1, Laduo;

    .line 3
    iget-object p0, p0, Laduo;->a:Ladtd;

    .line 5
    invoke-direct {p1, p0, p2}, Laduo;-><init>(Ladtd;Lbhtu;)V

    .line 8
    return-object p1
.end method
