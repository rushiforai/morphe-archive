.class public final Lachr;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lachr;->a:Lbeye;

    .line 6
    iput-object p2, p0, Lachr;->b:Lbeye;

    .line 8
    iput-object p3, p0, Lachr;->c:Lbeye;

    .line 10
    iput-object p4, p0, Lachr;->d:Lbeye;

    .line 12
    iput-object p5, p0, Lachr;->e:Lbeye;

    .line 14
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 7

    .line 1
    iget-object v0, p0, Lachr;->a:Lbeye;

    .line 3
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    move-object v2, v0

    .line 8
    check-cast v2, Lacgz;

    .line 10
    iget-object v0, p0, Lachr;->b:Lbeye;

    .line 12
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 15
    move-result-object v0

    .line 16
    move-object v3, v0

    .line 17
    check-cast v3, Lylv;

    .line 19
    iget-object v0, p0, Lachr;->c:Lbeye;

    .line 21
    check-cast v0, Lachg;

    .line 23
    invoke-virtual {v0}, Lachg;->a()Lalpu;

    .line 26
    move-result-object v4

    .line 27
    iget-object v0, p0, Lachr;->d:Lbeye;

    .line 29
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 32
    move-result-object v0

    .line 33
    move-object v5, v0

    .line 34
    check-cast v5, Lakxb;

    .line 36
    iget-object p0, p0, Lachr;->e:Lbeye;

    .line 38
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 41
    move-result-object p0

    .line 42
    move-object v6, p0

    .line 43
    check-cast v6, Lalnh;

    .line 45
    new-instance v1, Lachq;

    .line 47
    invoke-direct/range {v1 .. v6}, Lachq;-><init>(Lacgz;Lylv;Lalpu;Lakxb;Lalnh;)V

    .line 50
    return-object v1
.end method
