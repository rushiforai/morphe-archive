.class public final Laedy;
.super Lket;
.source "PG"


# instance fields
.field public final a:Laewn;

.field public final b:Lkdb;

.field public final c:Lkdb;

.field public final d:Lkdb;

.field private final e:Lbilb;


# direct methods
.method public constructor <init>(Lahtk;Lafkr;Lbifb;Lafjo;Laewn;Lajcd;Lagku;Laign;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    invoke-direct {p0}, Lket;-><init>()V

    .line 19
    iput-object p5, p0, Laedy;->a:Laewn;

    .line 21
    invoke-interface {p1}, Lahtk;->a()Lbioy;

    .line 24
    move-result-object p1

    .line 25
    new-instance p3, Laedt;

    .line 27
    invoke-direct {p3, p1}, Laedt;-><init>(Lbilb;)V

    .line 30
    invoke-static {p3}, Lkbt;->c(Lbilb;)Lkdb;

    .line 33
    move-result-object p1

    .line 34
    iput-object p1, p0, Laedy;->b:Lkdb;

    .line 36
    check-cast p2, Lafsb;

    .line 38
    invoke-virtual {p2}, Lafsb;->a()Lbiou;

    .line 41
    move-result-object p1

    .line 42
    new-instance p2, Laedv;

    .line 44
    invoke-direct {p2, p1}, Laedv;-><init>(Lbilb;)V

    .line 47
    invoke-static {p2}, Lkbt;->c(Lbilb;)Lkdb;

    .line 50
    move-result-object p1

    .line 51
    iput-object p1, p0, Laedy;->c:Lkdb;

    .line 53
    iget-object p1, p4, Lafjo;->d:Lbilb;

    .line 55
    new-instance p2, Laedx;

    .line 57
    invoke-direct {p2, p1}, Laedx;-><init>(Lbilb;)V

    .line 60
    iput-object p2, p0, Laedy;->e:Lbilb;

    .line 62
    check-cast p6, Lajcp;

    .line 64
    iget-object p1, p6, Lajcp;->c:Lbilb;

    .line 66
    invoke-interface {p5}, Laewn;->b()Lbilb;

    .line 69
    move-result-object p3

    .line 70
    invoke-interface {p8}, Laign;->c()Lbilb;

    .line 73
    move-result-object p4

    .line 74
    new-instance p5, Laedr;

    .line 76
    const/4 p6, 0x0

    .line 77
    invoke-direct {p5, p7, p6}, Laedr;-><init>(Lagku;Lbhtu;)V

    .line 80
    invoke-static {p2, p1, p3, p4, p5}, Lbios;->b(Lbilb;Lbilb;Lbilb;Lbilb;Lbhwx;)Lbilb;

    .line 83
    move-result-object p1

    .line 84
    invoke-static {p1}, Lkbt;->c(Lbilb;)Lkdb;

    .line 87
    move-result-object p1

    .line 88
    iput-object p1, p0, Laedy;->d:Lkdb;

    .line 90
    return-void
.end method
