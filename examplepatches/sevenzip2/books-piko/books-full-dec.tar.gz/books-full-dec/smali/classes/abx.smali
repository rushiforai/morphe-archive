.class abstract Labx;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Laby;


# virtual methods
.method public b(Landroid/view/Window;)V
    .locals 0

    .line 1
    return-void
.end method
