.class public final Labwk;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labwk;->a:Lbeye;

    .line 6
    iput-object p2, p0, Labwk;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final a()Lalyv;
    .locals 2

    .line 1
    iget-object v0, p0, Labwk;->a:Lbeye;

    .line 3
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lyfo;

    .line 9
    iget-object p0, p0, Labwk;->b:Lbeye;

    .line 11
    check-cast p0, Labxb;

    .line 13
    invoke-virtual {p0}, Labxb;->a()Labxa;

    .line 16
    move-result-object p0

    .line 17
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    new-instance v1, Labwf;

    .line 22
    invoke-direct {v1, v0, p0}, Labwf;-><init>(Lyfo;Labxa;)V

    .line 25
    new-instance p0, Lalyv;

    .line 27
    const-class v0, Labuk;

    .line 29
    invoke-direct {p0, v0, v1}, Lalyv;-><init>(Ljava/lang/Class;Lbhwq;)V

    .line 32
    return-object p0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Labwk;->a()Lalyv;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
