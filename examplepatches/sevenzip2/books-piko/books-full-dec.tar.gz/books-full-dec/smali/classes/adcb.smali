.class public final Ladcb;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladcb;->a:Lbeye;

    .line 6
    iput-object p2, p0, Ladcb;->b:Lbeye;

    .line 8
    iput-object p3, p0, Ladcb;->c:Lbeye;

    .line 10
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, Ladcb;->a:Lbeye;

    .line 3
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Laddj;

    .line 9
    iget-object v1, p0, Ladcb;->b:Lbeye;

    .line 11
    invoke-interface {v1}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Lajuu;

    .line 17
    iget-object p0, p0, Ladcb;->c:Lbeye;

    .line 19
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 22
    move-result-object p0

    .line 23
    check-cast p0, Laddt;

    .line 25
    new-instance v2, Ladca;

    .line 27
    invoke-direct {v2, v0, v1, p0}, Ladca;-><init>(Laddj;Lajuu;Laddt;)V

    .line 30
    return-object v2
.end method
