.class public final Laber;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laber;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laber;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laber;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laber;->d:Lbeye;

    .line 12
    return-void
.end method


# virtual methods
.method public final a()Labeq;
    .locals 4

    .line 1
    new-instance v0, Labeq;

    .line 3
    iget-object v1, p0, Laber;->a:Lbeye;

    .line 5
    iget-object v2, p0, Laber;->b:Lbeye;

    .line 7
    iget-object v3, p0, Laber;->c:Lbeye;

    .line 9
    iget-object p0, p0, Laber;->d:Lbeye;

    .line 11
    invoke-direct {v0, v1, v2, v3, p0}, Labeq;-><init>(Lbhpa;Lbhpa;Lbhpa;Lbhpa;)V

    .line 14
    return-object v0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Laber;->a()Labeq;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
