.class public final Lacjm;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;

.field private final g:Lbeye;

.field private final h:Lbeye;

.field private final i:Lbeye;

.field private final j:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacjm;->a:Lbeye;

    .line 6
    iput-object p2, p0, Lacjm;->b:Lbeye;

    .line 8
    iput-object p3, p0, Lacjm;->c:Lbeye;

    .line 10
    iput-object p4, p0, Lacjm;->d:Lbeye;

    .line 12
    iput-object p5, p0, Lacjm;->e:Lbeye;

    .line 14
    iput-object p6, p0, Lacjm;->f:Lbeye;

    .line 16
    iput-object p7, p0, Lacjm;->g:Lbeye;

    .line 18
    iput-object p8, p0, Lacjm;->h:Lbeye;

    .line 20
    iput-object p9, p0, Lacjm;->i:Lbeye;

    .line 22
    iput-object p10, p0, Lacjm;->j:Lbeye;

    .line 24
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 12

    .line 1
    iget-object v0, p0, Lacjm;->a:Lbeye;

    .line 3
    check-cast v0, Lpzw;

    .line 5
    invoke-virtual {v0}, Lpzw;->a()Landroid/content/Context;

    .line 8
    move-result-object v2

    .line 9
    iget-object v0, p0, Lacjm;->b:Lbeye;

    .line 11
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object v0

    .line 15
    move-object v3, v0

    .line 16
    check-cast v3, Lyek;

    .line 18
    iget-object v0, p0, Lacjm;->c:Lbeye;

    .line 20
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 23
    move-result-object v0

    .line 24
    move-object v4, v0

    .line 25
    check-cast v4, Lajet;

    .line 27
    iget-object v0, p0, Lacjm;->d:Lbeye;

    .line 29
    check-cast v0, Lpxs;

    .line 31
    invoke-virtual {v0}, Lpxs;->a()Lakvn;

    .line 34
    move-result-object v5

    .line 35
    iget-object v0, p0, Lacjm;->e:Lbeye;

    .line 37
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 40
    move-result-object v0

    .line 41
    move-object v6, v0

    .line 42
    check-cast v6, Ladqs;

    .line 44
    iget-object v0, p0, Lacjm;->f:Lbeye;

    .line 46
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 49
    move-result-object v0

    .line 50
    move-object v7, v0

    .line 51
    check-cast v7, Laktz;

    .line 53
    iget-object v0, p0, Lacjm;->g:Lbeye;

    .line 55
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 58
    move-result-object v0

    .line 59
    move-object v8, v0

    .line 60
    check-cast v8, Lachj;

    .line 62
    iget-object v0, p0, Lacjm;->h:Lbeye;

    .line 64
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 67
    move-result-object v0

    .line 68
    move-object v9, v0

    .line 69
    check-cast v9, Lyem;

    .line 71
    iget-object v0, p0, Lacjm;->i:Lbeye;

    .line 73
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 76
    move-result-object v0

    .line 77
    move-object v10, v0

    .line 78
    check-cast v10, Lachb;

    .line 80
    iget-object p0, p0, Lacjm;->j:Lbeye;

    .line 82
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 85
    move-result-object p0

    .line 86
    move-object v11, p0

    .line 87
    check-cast v11, Lacix;

    .line 89
    new-instance v1, Lacjl;

    .line 91
    invoke-direct/range {v1 .. v11}, Lacjl;-><init>(Landroid/content/Context;Lyek;Lajet;Lakvn;Ladqs;Laktz;Lachj;Lyem;Lachb;Lacix;)V

    .line 94
    return-object v1
.end method
