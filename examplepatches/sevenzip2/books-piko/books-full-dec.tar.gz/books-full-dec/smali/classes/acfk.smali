.class public final Lacfk;
.super Lacfa;
.source "PG"


# instance fields
.field public final a:Lmmt;

.field public final b:Lmld;

.field public final c:Lmld;

.field public final d:Lmlc;


# direct methods
.method public constructor <init>(Lmmt;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lacfa;-><init>()V

    .line 4
    iput-object p1, p0, Lacfk;->a:Lmmt;

    .line 6
    new-instance p1, Lacfh;

    .line 8
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 11
    iput-object p1, p0, Lacfk;->b:Lmld;

    .line 13
    new-instance p1, Lacfi;

    .line 15
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 18
    iput-object p1, p0, Lacfk;->c:Lmld;

    .line 20
    new-instance p1, Lacfj;

    .line 22
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 25
    iput-object p1, p0, Lacfk;->d:Lmlc;

    .line 27
    return-void
.end method
