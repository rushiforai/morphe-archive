.class public final Lacft;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Lbhpa;

.field public final b:Lahij;

.field public final c:Lbifb;

.field private final d:Landroid/accounts/Account;

.field private final e:Loyh;

.field private final f:Lbhph;


# direct methods
.method public constructor <init>(Landroid/accounts/Account;Loyh;Lbhpa;Lahij;Lbifb;)V
    .locals 0

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    iput-object p1, p0, Lacft;->d:Landroid/accounts/Account;

    .line 12
    iput-object p2, p0, Lacft;->e:Loyh;

    .line 14
    iput-object p3, p0, Lacft;->a:Lbhpa;

    .line 16
    iput-object p4, p0, Lacft;->b:Lahij;

    .line 18
    iput-object p5, p0, Lacft;->c:Lbifb;

    .line 20
    new-instance p1, Lacfq;

    .line 22
    invoke-direct {p1, p0}, Lacfq;-><init>(Lacft;)V

    .line 25
    new-instance p2, Lbhps;

    .line 27
    invoke-direct {p2, p1}, Lbhps;-><init>(Lbhwf;)V

    .line 30
    iput-object p2, p0, Lacft;->f:Lbhph;

    .line 32
    return-void
.end method

.method public static final c(I)I
    .locals 1

    .line 1
    add-int/lit8 p0, p0, -0x2

    .line 3
    const/4 v0, 0x2

    .line 4
    if-eq p0, v0, :cond_0

    .line 6
    const/4 p0, 0x1

    .line 7
    return p0

    .line 8
    :cond_0
    return v0
.end method


# virtual methods
.method public final a()Lbgpn;
    .locals 3

    .line 1
    sget-object v0, Lahjq;->a:Lahjq;

    .line 3
    iget-object v0, v0, Lahjq;->c:Ljava/lang/String;

    .line 5
    iget-object v1, p0, Lacft;->e:Loyh;

    .line 7
    iget-object p0, p0, Lacft;->d:Landroid/accounts/Account;

    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-interface {v1, p0, v2, v0}, Loyh;->c(Landroid/accounts/Account;ZLjava/lang/String;)Ljava/lang/String;

    .line 13
    move-result-object p0

    .line 14
    new-instance v0, Layfc;

    .line 16
    invoke-direct {v0, p0}, Layfc;-><init>(Ljava/lang/String;)V

    .line 19
    sget-object p0, Layfn;->d:Lcom/google/common/collect/ImmutableMap;

    .line 21
    new-instance p0, Layfh;

    .line 23
    invoke-direct {p0}, Layfh;-><init>()V

    .line 26
    iput-object v0, p0, Layfh;->a:Layfc;

    .line 28
    invoke-virtual {p0}, Layfh;->a()Layfn;

    .line 31
    move-result-object p0

    .line 32
    new-instance v0, Lbgvi;

    .line 34
    invoke-direct {v0, p0}, Lbgvi;-><init>(Layfa;)V

    .line 37
    return-object v0
.end method

.method public final b()Lbgso;
    .locals 0

    .line 1
    iget-object p0, p0, Lacft;->f:Lbhph;

    .line 3
    invoke-interface {p0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lbgso;

    .line 9
    return-object p0
.end method
