.class public final Labbw;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labbw;->a:Lbeye;

    .line 6
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 1

    .line 1
    new-instance v0, Labbv;

    .line 3
    iget-object p0, p0, Labbw;->a:Lbeye;

    .line 5
    invoke-direct {v0, p0}, Labbv;-><init>(Lbhpa;)V

    .line 8
    return-object v0
.end method
