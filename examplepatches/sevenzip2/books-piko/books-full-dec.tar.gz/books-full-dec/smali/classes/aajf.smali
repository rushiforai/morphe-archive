.class public final Laajf;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laajf;->a:Lbeye;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()Laaje;
    .locals 1

    .line 1
    iget-object p0, p0, Laajf;->a:Lbeye;

    .line 3
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lailw;

    .line 9
    new-instance v0, Laaje;

    .line 11
    invoke-direct {v0, p0}, Laaje;-><init>(Lailw;)V

    .line 14
    return-object v0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Laajf;->a()Laaje;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
