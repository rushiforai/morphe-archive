.class public final Laayf;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laayf;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laayf;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laayf;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laayf;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laayf;->e:Lbeye;

    .line 14
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 6

    .line 1
    new-instance v0, Laaye;

    .line 3
    iget-object v1, p0, Laayf;->a:Lbeye;

    .line 5
    iget-object v2, p0, Laayf;->b:Lbeye;

    .line 7
    iget-object v3, p0, Laayf;->c:Lbeye;

    .line 9
    iget-object v4, p0, Laayf;->d:Lbeye;

    .line 11
    iget-object v5, p0, Laayf;->e:Lbeye;

    .line 13
    invoke-direct/range {v0 .. v5}, Laaye;-><init>(Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;)V

    .line 16
    return-object v0
.end method
