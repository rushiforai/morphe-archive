.class public final Labfc;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labfc;->a:Lbeye;

    .line 6
    iput-object p2, p0, Labfc;->b:Lbeye;

    .line 8
    iput-object p3, p0, Labfc;->c:Lbeye;

    .line 10
    iput-object p4, p0, Labfc;->d:Lbeye;

    .line 12
    iput-object p5, p0, Labfc;->e:Lbeye;

    .line 14
    return-void
.end method


# virtual methods
.method public final a()Lalyv;
    .locals 7

    .line 1
    iget-object v0, p0, Labfc;->a:Lbeye;

    .line 3
    check-cast v0, Lyoc;

    .line 5
    invoke-virtual {v0}, Lyoc;->a()Lyob;

    .line 8
    move-result-object v4

    .line 9
    iget-object v0, p0, Labfc;->b:Lbeye;

    .line 11
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object v0

    .line 15
    move-object v2, v0

    .line 16
    check-cast v2, Lahxx;

    .line 18
    iget-object v0, p0, Labfc;->c:Lbeye;

    .line 20
    check-cast v0, Labxb;

    .line 22
    invoke-virtual {v0}, Labxb;->a()Labxa;

    .line 25
    move-result-object v3

    .line 26
    iget-object v0, p0, Labfc;->d:Lbeye;

    .line 28
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 31
    move-result-object v0

    .line 32
    move-object v5, v0

    .line 33
    check-cast v5, Lahic;

    .line 35
    iget-object p0, p0, Labfc;->e:Lbeye;

    .line 37
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 40
    move-result-object p0

    .line 41
    move-object v6, p0

    .line 42
    check-cast v6, Lahiz;

    .line 44
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    new-instance v1, Labfb;

    .line 55
    invoke-direct/range {v1 .. v6}, Labfb;-><init>(Lahxx;Labxa;Lynp;Lahic;Lahiz;)V

    .line 58
    new-instance p0, Lalyv;

    .line 60
    const-class v0, Labfi;

    .line 62
    invoke-direct {p0, v0, v1}, Lalyv;-><init>(Ljava/lang/Class;Lbhwq;)V

    .line 65
    return-object p0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Labfc;->a()Lalyv;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
