.class public final Laeec;
.super Lppr;
.source "PG"


# direct methods
.method public constructor <init>(Lppu;Lalnn;Lalog;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lppr;-><init>(Lppu;Lalnn;)V

    .line 4
    return-void
.end method
