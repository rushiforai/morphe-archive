.class public final synthetic Ladx;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwf;


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {}, Laec;->d()Ljava/lang/Integer;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
