.class public final Ladug;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Ljava/util/Map;

.field public final b:Ljava/util/Map;

.field public final c:Ljava/util/Map;


# direct methods
.method public constructor <init>(Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladug;->a:Ljava/util/Map;

    .line 6
    iput-object p2, p0, Ladug;->b:Ljava/util/Map;

    .line 8
    iput-object p3, p0, Ladug;->c:Ljava/util/Map;

    .line 10
    return-void
.end method
