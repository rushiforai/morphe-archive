.class public final synthetic Laedc;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lkdh;


# instance fields
.field public final synthetic a:Laedn;


# direct methods
.method public synthetic constructor <init>(Laedn;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laedc;->a:Laedn;

    .line 6
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object p0, p0, Laedc;->a:Laedn;

    .line 3
    check-cast p1, Ljava/lang/Boolean;

    .line 5
    iget-object p0, p0, Laedn;->k:Laxjc;

    .line 7
    const v0, 0x7f0a013c

    .line 10
    invoke-virtual {p0, v0}, Laxjc;->b(I)Lawvf;

    .line 13
    move-result-object p0

    .line 14
    const v0, 0x800035

    .line 17
    invoke-virtual {p0, v0}, Lawvf;->h(I)V

    .line 20
    invoke-virtual {p0}, Lawvf;->o()V

    .line 23
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 26
    move-result p1

    .line 27
    invoke-virtual {p0, p1}, Lawvf;->j(Z)V

    .line 30
    return-void
.end method
