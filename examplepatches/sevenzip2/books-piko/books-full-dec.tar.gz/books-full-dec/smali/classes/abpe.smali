.class public final Labpe;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labpe;->a:Lbeye;

    .line 6
    iput-object p2, p0, Labpe;->b:Lbeye;

    .line 8
    iput-object p3, p0, Labpe;->c:Lbeye;

    .line 10
    iput-object p4, p0, Labpe;->d:Lbeye;

    .line 12
    iput-object p5, p0, Labpe;->e:Lbeye;

    .line 14
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 6

    .line 1
    iget-object v0, p0, Labpe;->a:Lbeye;

    .line 3
    check-cast v0, Lpwn;

    .line 5
    invoke-virtual {v0}, Lpwn;->a()Landroid/accounts/Account;

    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Labpe;->b:Lbeye;

    .line 11
    invoke-interface {v1}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Ljava/util/concurrent/Executor;

    .line 17
    iget-object v2, p0, Labpe;->c:Lbeye;

    .line 19
    invoke-interface {v2}, Lbeye;->b()Ljava/lang/Object;

    .line 22
    move-result-object v2

    .line 23
    check-cast v2, Lalnn;

    .line 25
    iget-object v3, p0, Labpe;->d:Lbeye;

    .line 27
    check-cast v3, Lajvr;

    .line 29
    invoke-virtual {v3}, Lajvr;->a()Lajvq;

    .line 32
    move-result-object v3

    .line 33
    iget-object p0, p0, Labpe;->e:Lbeye;

    .line 35
    check-cast p0, Lajvo;

    .line 37
    invoke-virtual {p0}, Lajvo;->a()Lajvn;

    .line 40
    move-result-object p0

    .line 41
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    iget-object v4, v0, Landroid/accounts/Account;->name:Ljava/lang/String;

    .line 49
    invoke-virtual {v3, v4}, Lajvj;->a(Ljava/lang/String;)Ljava/io/File;

    .line 52
    move-result-object v3

    .line 53
    new-instance v4, Ljava/io/File;

    .line 55
    const-string v5, "psstore_blob_index"

    .line 57
    invoke-direct {v4, v3, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 60
    iget-object v0, v0, Landroid/accounts/Account;->name:Ljava/lang/String;

    .line 62
    invoke-virtual {p0, v0}, Lajvj;->a(Ljava/lang/String;)Ljava/io/File;

    .line 65
    move-result-object p0

    .line 66
    new-instance v0, Ljava/io/File;

    .line 68
    const-string v3, "psstore_blobs"

    .line 70
    invoke-direct {v0, p0, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 73
    new-instance p0, Lajwj;

    .line 75
    const/high16 v3, 0xa00000

    .line 77
    invoke-direct {p0, v4, v0, v3, v2}, Lajwj;-><init>(Ljava/io/File;Ljava/io/File;ILalnn;)V

    .line 80
    new-instance v0, Labpd;

    .line 82
    invoke-direct {v0, p0}, Labpd;-><init>(Lajwj;)V

    .line 85
    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 88
    return-object p0
.end method
