.class public final Lacgh;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacgh;->a:Lbeye;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()Lacfa;
    .locals 0

    .line 1
    iget-object p0, p0, Lacgh;->a:Lbeye;

    .line 3
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase;

    .line 9
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    invoke-virtual {p0}, Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaRoomDatabase;->z()Lacfa;

    .line 15
    move-result-object p0

    .line 16
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    return-object p0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lacgh;->a()Lacfa;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
