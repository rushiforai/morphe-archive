.class public final Lacst;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacst;->a:Lbeye;

    .line 6
    iput-object p2, p0, Lacst;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final a()Lalyv;
    .locals 2

    .line 1
    iget-object v0, p0, Lacst;->a:Lbeye;

    .line 3
    check-cast v0, Ladgj;

    .line 5
    invoke-virtual {v0}, Ladgj;->a()Lalyv;

    .line 8
    move-result-object v0

    .line 9
    iget-object p0, p0, Lacst;->b:Lbeye;

    .line 11
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object p0

    .line 15
    check-cast p0, Lacxt;

    .line 17
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    new-instance v1, Lacss;

    .line 22
    invoke-direct {v1, v0, p0}, Lacss;-><init>(Lalyv;Lacxt;)V

    .line 25
    new-instance p0, Lalyv;

    .line 27
    const-class v0, Lacsy;

    .line 29
    invoke-direct {p0, v0, v1}, Lalyv;-><init>(Ljava/lang/Class;Lbhwq;)V

    .line 32
    return-object p0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lacst;->a()Lalyv;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
