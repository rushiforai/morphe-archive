.class public final Ladgk;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladgk;->a:Lbeye;

    .line 6
    iput-object p2, p0, Ladgk;->b:Lbeye;

    .line 8
    return-void
.end method

.method public static c(Ldw;Lalyv;)Ladgl;
    .locals 0

    .line 1
    invoke-virtual {p1, p0}, Lalyv;->a(Ldw;)Lket;

    .line 4
    move-result-object p0

    .line 5
    check-cast p0, Ladgl;

    .line 7
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    return-object p0
.end method


# virtual methods
.method public final a()Ladgl;
    .locals 1

    .line 1
    iget-object v0, p0, Ladgk;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v0

    .line 9
    iget-object p0, p0, Ladgk;->b:Lbeye;

    .line 11
    check-cast p0, Ladgj;

    .line 13
    invoke-virtual {p0}, Ladgj;->a()Lalyv;

    .line 16
    move-result-object p0

    .line 17
    invoke-static {v0, p0}, Ladgk;->c(Ldw;Lalyv;)Ladgl;

    .line 20
    move-result-object p0

    .line 21
    return-object p0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ladgk;->a()Ladgl;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
