.class public Ldw;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Landroid/content/ComponentCallbacks;
.implements Landroid/view/View$OnCreateContextMenuListener;
.implements Lkcm;
.implements Lkfe;
.implements Lkbv;
.implements Lmqw;


# static fields
.field static final j:Ljava/lang/Object;


# instance fields
.field A:Z

.field public B:Z

.field C:Z

.field D:Z

.field E:I

.field public F:Lfm;

.field G:Lek;

.field H:Lfm;

.field public I:Ldw;

.field public J:I

.field public K:I

.field public L:Ljava/lang/String;

.field public M:Z

.field public N:Z

.field public O:Z

.field P:Z

.field Q:Z

.field R:Z

.field public S:Z

.field T:Landroid/view/ViewGroup;

.field public U:Landroid/view/View;

.field V:Z

.field public W:Z

.field X:Lds;

.field Y:Z

.field Z:Landroid/view/LayoutInflater;

.field private final a:Ldu;

.field aa:Z

.field public ab:Ljava/lang/String;

.field public ac:Lkbz;

.field public ad:Lkct;

.field final ae:Ladr;

.field af:Lgm;

.field public final ag:Lkdg;

.field ah:Lkez;

.field ai:Lmqv;

.field public final aj:Lga;

.field public final ak:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final al:Ljava/util/ArrayList;

.field private final b:Ldu;

.field public k:I

.field public l:Landroid/os/Bundle;

.field m:Landroid/util/SparseArray;

.field n:Landroid/os/Bundle;

.field o:Ljava/lang/Boolean;

.field public p:Ljava/lang/String;

.field public q:Landroid/os/Bundle;

.field r:Ldw;

.field public s:Ljava/lang/String;

.field public t:I

.field public u:Ljava/lang/Boolean;

.field v:Z

.field public w:Z

.field x:Z

.field y:Z

.field public z:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Ljava/lang/Object;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    sput-object v0, Ldw;->j:Ljava/lang/Object;

    .line 8
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, -0x1

    .line 5
    iput v0, p0, Ldw;->k:I

    .line 7
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, Ldw;->p:Ljava/lang/String;

    .line 17
    const/4 v0, 0x0

    .line 18
    iput-object v0, p0, Ldw;->s:Ljava/lang/String;

    .line 20
    iput-object v0, p0, Ldw;->u:Ljava/lang/Boolean;

    .line 22
    new-instance v0, Lfn;

    .line 24
    invoke-direct {v0}, Lfm;-><init>()V

    .line 27
    iput-object v0, p0, Ldw;->H:Lfm;

    .line 29
    const/4 v0, 0x1

    .line 30
    iput-boolean v0, p0, Ldw;->R:Z

    .line 32
    iput-boolean v0, p0, Ldw;->W:Z

    .line 34
    sget-object v0, Lkbz;->e:Lkbz;

    .line 36
    iput-object v0, p0, Ldw;->ac:Lkbz;

    .line 38
    new-instance v0, Ladr;

    .line 40
    invoke-direct {v0}, Ladr;-><init>()V

    .line 43
    iput-object v0, p0, Ldw;->ae:Ladr;

    .line 45
    new-instance v0, Lkdg;

    .line 47
    invoke-direct {v0}, Lkdb;-><init>()V

    .line 50
    iput-object v0, p0, Ldw;->ag:Lkdg;

    .line 52
    new-instance v0, Lga;

    .line 54
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 57
    iput-object v0, p0, Ldw;->aj:Lga;

    .line 59
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 61
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 64
    iput-object v0, p0, Ldw;->ak:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 66
    new-instance v0, Ljava/util/ArrayList;

    .line 68
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 71
    iput-object v0, p0, Ldw;->al:Ljava/util/ArrayList;

    .line 73
    new-instance v0, Ldm;

    .line 75
    invoke-direct {v0, p0}, Ldm;-><init>(Ldw;)V

    .line 78
    iput-object v0, p0, Ldw;->a:Ldu;

    .line 80
    new-instance v0, Ldn;

    .line 82
    invoke-direct {v0, p0}, Ldn;-><init>(Ldw;)V

    .line 85
    iput-object v0, p0, Ldw;->b:Ldu;

    .line 87
    invoke-direct {p0}, Ldw;->n()V

    .line 90
    return-void
.end method

.method public static C(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Ldw;
    .locals 4
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    const-string v0, ": make sure class name exists, is public, and has an empty constructor that is public"

    .line 3
    const-string v1, "Unable to instantiate fragment "

    .line 5
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    .line 8
    move-result-object p0

    .line 9
    sget v2, Lej;->a:I

    .line 11
    :try_end_0
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_5
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_2

    :try_start_1
    invoke-static {p0, p1}, Lej;->a(Ljava/lang/ClassLoader;Ljava/lang/String;)Ljava/lang/Class;

    .line 14
    move-result-object p0

    .line 15
    :try_end_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/ClassCastException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/InstantiationException; {:try_start_1 .. :try_end_1} :catch_5
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_1} :catch_4
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1 .. :try_end_1} :catch_3
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_1} :catch_2

    const/4 v2, 0x0

    .line 16
    :try_start_2
    invoke-virtual {p0, v2}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 19
    move-result-object p0

    .line 20
    invoke-virtual {p0, v2}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    move-result-object p0

    .line 24
    check-cast p0, Ldw;

    .line 26
    if-eqz p2, :cond_0

    .line 28
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    move-result-object v2

    .line 32
    invoke-virtual {v2}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 35
    move-result-object v2

    .line 36
    invoke-virtual {p2, v2}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    .line 39
    invoke-virtual {p0, p2}, Ldw;->an(Landroid/os/Bundle;)V

    .line 42
    :cond_0
    return-object p0

    .line 43
    :catch_0
    move-exception p0

    .line 44
    new-instance p2, Ldt;

    .line 46
    new-instance v2, Ljava/lang/StringBuilder;

    .line 48
    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 51
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    const-string v3, ": make sure class is a valid subclass of Fragment"

    .line 56
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 62
    move-result-object v2

    .line 63
    invoke-direct {p2, v2, p0}, Ldt;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 66
    throw p2

    .line 67
    :catch_1
    move-exception p0

    .line 68
    new-instance p2, Ldt;

    .line 70
    new-instance v2, Ljava/lang/StringBuilder;

    .line 72
    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 75
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 78
    const-string v3, ": make sure class name exists"

    .line 80
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 83
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 86
    move-result-object v2

    .line 87
    invoke-direct {p2, v2, p0}, Ldt;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 90
    throw p2

    .line 91
    :try_end_2
    .catch Ljava/lang/InstantiationException; {:try_start_2 .. :try_end_2} :catch_5
    .catch Ljava/lang/IllegalAccessException; {:try_start_2 .. :try_end_2} :catch_4
    .catch Ljava/lang/NoSuchMethodException; {:try_start_2 .. :try_end_2} :catch_3
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    move-exception p0

    .line 92
    new-instance p2, Ldt;

    .line 94
    const-string v0, ": calling Fragment constructor caused an exception"

    .line 96
    invoke-static {p1, v1, v0}, La;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 99
    move-result-object p1

    .line 100
    invoke-direct {p2, p1, p0}, Ldt;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 103
    throw p2

    .line 104
    :catch_3
    move-exception p0

    .line 105
    new-instance p2, Ldt;

    .line 107
    const-string v0, ": could not find Fragment constructor"

    .line 109
    invoke-static {p1, v1, v0}, La;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 112
    move-result-object p1

    .line 113
    invoke-direct {p2, p1, p0}, Ldt;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 116
    throw p2

    .line 117
    :catch_4
    move-exception p0

    .line 118
    new-instance p2, Ldt;

    .line 120
    invoke-static {p1, v1, v0}, La;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 123
    move-result-object p1

    .line 124
    invoke-direct {p2, p1, p0}, Ldt;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 127
    throw p2

    .line 128
    :catch_5
    move-exception p0

    .line 129
    new-instance p2, Ldt;

    .line 131
    invoke-static {p1, v1, v0}, La;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 134
    move-result-object p1

    .line 135
    invoke-direct {p2, p1, p0}, Ldt;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 138
    throw p2
.end method

.method private final a()I
    .locals 2

    .line 1
    iget-object v0, p0, Ldw;->ac:Lkbz;

    .line 3
    sget-object v1, Lkbz;->b:Lkbz;

    .line 5
    if-eq v0, v1, :cond_1

    .line 7
    iget-object v1, p0, Ldw;->I:Ldw;

    .line 9
    if-nez v1, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-virtual {v0}, Lkbz;->ordinal()I

    .line 15
    move-result v0

    .line 16
    iget-object p0, p0, Ldw;->I:Ldw;

    .line 18
    invoke-direct {p0}, Ldw;->a()I

    .line 21
    move-result p0

    .line 22
    invoke-static {v0, p0}, Ljava/lang/Math;->min(II)I

    .line 25
    move-result p0

    .line 26
    return p0

    .line 27
    :cond_1
    :goto_0
    invoke-virtual {v0}, Lkbz;->ordinal()I

    .line 30
    move-result p0

    .line 31
    return p0
.end method

.method private final d(Laeg;Laey;Ladu;)Ladv;
    .locals 8

    .line 1
    iget v0, p0, Ldw;->k:I

    .line 3
    const/4 v1, 0x1

    .line 4
    if-gt v0, v1, :cond_0

    .line 6
    new-instance v5, Ljava/util/concurrent/atomic/AtomicReference;

    .line 8
    invoke-direct {v5}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    .line 11
    new-instance v2, Ldk;

    .line 13
    move-object v3, p0

    .line 14
    move-object v6, p1

    .line 15
    move-object v4, p2

    .line 16
    move-object v7, p3

    .line 17
    invoke-direct/range {v2 .. v7}, Ldk;-><init>(Ldw;Laey;Ljava/util/concurrent/atomic/AtomicReference;Laeg;Ladu;)V

    .line 20
    invoke-direct {v3, v2}, Ldw;->o(Ldu;)V

    .line 23
    new-instance p0, Ldl;

    .line 25
    invoke-direct {p0, v5}, Ldl;-><init>(Ljava/util/concurrent/atomic/AtomicReference;)V

    .line 28
    return-object p0

    .line 29
    :cond_0
    move-object v3, p0

    .line 30
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 32
    const-string p1, "Fragment "

    .line 34
    const-string p2, " is attempting to registerForActivityResult after being created. Fragments must call registerForActivityResult() before they are created (i.e. initialization, onAttach(), or onCreate())."

    .line 36
    invoke-static {v3, p1, p2}, La;->e(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 39
    move-result-object p1

    .line 40
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    throw p0
.end method

.method private final n()V
    .locals 3

    .line 1
    new-instance v0, Lkct;

    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, p0, v1}, Lkct;-><init>(Lkcm;Z)V

    .line 7
    iput-object v0, p0, Ldw;->ad:Lkct;

    .line 9
    invoke-static {p0}, Lmqu;->a(Lmqw;)Lmqv;

    .line 12
    move-result-object v0

    .line 13
    iput-object v0, p0, Ldw;->ai:Lmqv;

    .line 15
    const/4 v0, 0x0

    .line 16
    iput-object v0, p0, Ldw;->ah:Lkez;

    .line 18
    iget-object v0, p0, Ldw;->al:Ljava/util/ArrayList;

    .line 20
    iget-object v1, p0, Ldw;->a:Ldu;

    .line 22
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 25
    move-result v2

    .line 26
    if-nez v2, :cond_0

    .line 28
    invoke-direct {p0, v1}, Ldw;->o(Ldu;)V

    .line 31
    :cond_0
    iget-object v1, p0, Ldw;->b:Ldu;

    .line 33
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 36
    move-result v0

    .line 37
    if-nez v0, :cond_1

    .line 39
    invoke-direct {p0, v1}, Ldw;->o(Ldu;)V

    .line 42
    :cond_1
    return-void
.end method

.method private final o(Ldu;)V
    .locals 1

    .line 1
    iget v0, p0, Ldw;->k:I

    .line 3
    if-ltz v0, :cond_0

    .line 5
    invoke-virtual {p1}, Ldu;->a()V

    .line 8
    return-void

    .line 9
    :cond_0
    iget-object p0, p0, Ldw;->al:Ljava/util/ArrayList;

    .line 11
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 14
    return-void
.end method


# virtual methods
.method public final A()Landroid/os/Bundle;
    .locals 3

    .line 1
    iget-object v0, p0, Ldw;->q:Landroid/os/Bundle;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-object v0

    .line 6
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 8
    const-string v1, "Fragment "

    .line 10
    const-string v2, " does not have any arguments."

    .line 12
    invoke-static {p0, v1, v2}, La;->e(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 15
    move-result-object p0

    .line 16
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    throw v0
.end method

.method public final B()Lds;
    .locals 1

    .line 1
    iget-object v0, p0, Ldw;->X:Lds;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, Lds;

    .line 7
    invoke-direct {v0}, Lds;-><init>()V

    .line 10
    iput-object v0, p0, Ldw;->X:Lds;

    .line 12
    :cond_0
    return-object v0
.end method

.method public final D()Lec;
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->G:Lek;

    .line 3
    if-nez p0, :cond_0

    .line 5
    const/4 p0, 0x0

    .line 6
    return-object p0

    .line 7
    :cond_0
    iget-object p0, p0, Lek;->b:Landroid/app/Activity;

    .line 9
    check-cast p0, Lec;

    .line 11
    return-object p0
.end method

.method public final E()Lec;
    .locals 3

    .line 1
    invoke-virtual {p0}, Ldw;->D()Lec;

    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    return-object v0

    .line 8
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 10
    const-string v1, "Fragment "

    .line 12
    const-string v2, " not attached to an activity."

    .line 14
    invoke-static {p0, v1, v2}, La;->e(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 17
    move-result-object p0

    .line 18
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    throw v0
.end method

.method public final F()Lfm;
    .locals 3

    .line 1
    iget-object v0, p0, Ldw;->G:Lek;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object p0, p0, Ldw;->H:Lfm;

    .line 7
    return-object p0

    .line 8
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 10
    const-string v1, "Fragment "

    .line 12
    const-string v2, " has not been attached yet."

    .line 14
    invoke-static {p0, v1, v2}, La;->e(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 17
    move-result-object p0

    .line 18
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    throw v0
.end method

.method public final G()Lfm;
    .locals 3

    .line 1
    iget-object v0, p0, Ldw;->F:Lfm;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-object v0

    .line 6
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 8
    const-string v1, "Fragment "

    .line 10
    const-string v2, " not associated with a fragment manager."

    .line 12
    invoke-static {p0, v1, v2}, La;->e(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 15
    move-result-object p0

    .line 16
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    throw v0
.end method

.method public final H()Landroid/view/LayoutInflater;
    .locals 1

    .line 1
    iget-object v0, p0, Ldw;->Z:Landroid/view/LayoutInflater;

    .line 3
    if-nez v0, :cond_0

    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-virtual {p0, v0}, Ldw;->I(Landroid/os/Bundle;)Landroid/view/LayoutInflater;

    .line 9
    move-result-object p0

    .line 10
    return-object p0

    .line 11
    :cond_0
    return-object v0
.end method

.method final I(Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Ldw;->fC(Landroid/os/Bundle;)Landroid/view/LayoutInflater;

    .line 4
    move-result-object p1

    .line 5
    iput-object p1, p0, Ldw;->Z:Landroid/view/LayoutInflater;

    .line 7
    return-object p1
.end method

.method public J(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final K()Landroid/view/View;
    .locals 3

    .line 1
    iget-object v0, p0, Ldw;->U:Landroid/view/View;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-object v0

    .line 6
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 8
    const-string v1, "Fragment "

    .line 10
    const-string v2, " did not return a View from onCreateView() or this was called before onCreateView()."

    .line 12
    invoke-static {p0, v1, v2}, La;->e(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 15
    move-result-object p0

    .line 16
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    throw v0
.end method

.method public final L(Laeg;Ladu;)Ladv;
    .locals 1

    .line 1
    new-instance v0, Ldq;

    .line 3
    invoke-direct {v0, p0}, Ldq;-><init>(Ldw;)V

    .line 6
    invoke-direct {p0, p1, v0, p2}, Ldw;->d(Laeg;Laey;Ladu;)Ladv;

    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method

.method public final M(Laeg;Laec;Ladu;)Ladv;
    .locals 1

    .line 1
    new-instance v0, Ldr;

    .line 3
    invoke-direct {v0, p2}, Ldr;-><init>(Laec;)V

    .line 6
    invoke-direct {p0, p1, v0, p3}, Ldw;->d(Laeg;Laey;Ladu;)Ladv;

    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method

.method public final N()Lkcb;
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->ad:Lkct;

    .line 3
    return-object p0
.end method

.method public final O()Lkcm;
    .locals 3

    .line 1
    iget-object v0, p0, Ldw;->af:Lgm;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-object v0

    .line 6
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 8
    const-string v1, "Can\'t access the Fragment View\'s LifecycleOwner for "

    .line 10
    const-string v2, " when getView() is null i.e., before onCreateView() or after onDestroyView()"

    .line 12
    invoke-static {p0, v1, v2}, La;->e(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 15
    move-result-object p0

    .line 16
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    throw v0
.end method

.method public final P()Lkez;
    .locals 3

    .line 1
    iget-object v0, p0, Ldw;->F:Lfm;

    .line 3
    if-eqz v0, :cond_4

    .line 5
    iget-object v0, p0, Ldw;->ah:Lkez;

    .line 7
    if-nez v0, :cond_3

    .line 9
    invoke-virtual {p0}, Ldw;->y()Landroid/content/Context;

    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 16
    move-result-object v0

    .line 17
    :goto_0
    instance-of v1, v0, Landroid/content/ContextWrapper;

    .line 19
    if-eqz v1, :cond_1

    .line 21
    instance-of v1, v0, Landroid/app/Application;

    .line 23
    if-eqz v1, :cond_0

    .line 25
    check-cast v0, Landroid/app/Application;

    .line 27
    goto :goto_1

    .line 28
    :cond_0
    check-cast v0, Landroid/content/ContextWrapper;

    .line 30
    invoke-virtual {v0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 33
    move-result-object v0

    .line 34
    goto :goto_0

    .line 35
    :cond_1
    const/4 v0, 0x0

    .line 36
    :goto_1
    if-nez v0, :cond_2

    .line 38
    const/4 v1, 0x3

    .line 39
    invoke-static {v1}, Lfm;->ad(I)Z

    .line 42
    move-result v1

    .line 43
    if-eqz v1, :cond_2

    .line 45
    new-instance v1, Ljava/lang/StringBuilder;

    .line 47
    const-string v2, "Could not find Application instance from Context "

    .line 49
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 52
    invoke-virtual {p0}, Ldw;->y()Landroid/content/Context;

    .line 55
    move-result-object v2

    .line 56
    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 59
    move-result-object v2

    .line 60
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 63
    const-string v2, ", you will need CreationExtras to use AndroidViewModel with the default ViewModelProvider.Factory"

    .line 65
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 71
    move-result-object v1

    .line 72
    const-string v2, "FragmentManager"

    .line 74
    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 77
    :cond_2
    new-instance v1, Lkek;

    .line 79
    iget-object v2, p0, Ldw;->q:Landroid/os/Bundle;

    .line 81
    invoke-direct {v1, v0, p0, v2}, Lkek;-><init>(Landroid/app/Application;Lmqw;Landroid/os/Bundle;)V

    .line 84
    iput-object v1, p0, Ldw;->ah:Lkez;

    .line 86
    :cond_3
    iget-object p0, p0, Ldw;->ah:Lkez;

    .line 88
    return-object p0

    .line 89
    :cond_4
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 91
    const-string v0, "Can\'t access ViewModels from detached fragment"

    .line 93
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 96
    throw p0
.end method

.method public final Q()Lkfd;
    .locals 2

    .line 1
    iget-object v0, p0, Ldw;->F:Lfm;

    .line 3
    if-eqz v0, :cond_2

    .line 5
    invoke-direct {p0}, Ldw;->a()I

    .line 8
    move-result v0

    .line 9
    sget-object v1, Lkbz;->b:Lkbz;

    .line 11
    invoke-virtual {v1}, Lkbz;->ordinal()I

    .line 14
    move-result v1

    .line 15
    if-eq v0, v1, :cond_1

    .line 17
    iget-object v0, p0, Ldw;->F:Lfm;

    .line 19
    iget-object v0, v0, Lfm;->z:Lfq;

    .line 21
    iget-object v0, v0, Lfq;->d:Ljava/util/HashMap;

    .line 23
    iget-object v1, p0, Ldw;->p:Ljava/lang/String;

    .line 25
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    move-result-object v1

    .line 29
    check-cast v1, Lkfd;

    .line 31
    if-nez v1, :cond_0

    .line 33
    new-instance v1, Lkfd;

    .line 35
    invoke-direct {v1}, Lkfd;-><init>()V

    .line 38
    iget-object p0, p0, Ldw;->p:Ljava/lang/String;

    .line 40
    invoke-virtual {v0, p0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    :cond_0
    return-object v1

    .line 44
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 46
    const-string v0, "Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported"

    .line 48
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 51
    throw p0

    .line 52
    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 54
    const-string v0, "Can\'t access ViewModels from detached fragment"

    .line 56
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 59
    throw p0
.end method

.method public final R()Lkgj;
    .locals 4

    .line 1
    invoke-virtual {p0}, Ldw;->y()Landroid/content/Context;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 8
    move-result-object v0

    .line 9
    :goto_0
    instance-of v1, v0, Landroid/content/ContextWrapper;

    .line 11
    const/4 v2, 0x0

    .line 12
    if-eqz v1, :cond_1

    .line 14
    instance-of v1, v0, Landroid/app/Application;

    .line 16
    if-eqz v1, :cond_0

    .line 18
    check-cast v0, Landroid/app/Application;

    .line 20
    goto :goto_1

    .line 21
    :cond_0
    check-cast v0, Landroid/content/ContextWrapper;

    .line 23
    invoke-virtual {v0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 26
    move-result-object v0

    .line 27
    goto :goto_0

    .line 28
    :cond_1
    move-object v0, v2

    .line 29
    :goto_1
    if-nez v0, :cond_2

    .line 31
    const/4 v1, 0x3

    .line 32
    invoke-static {v1}, Lfm;->ad(I)Z

    .line 35
    move-result v1

    .line 36
    if-eqz v1, :cond_2

    .line 38
    new-instance v1, Ljava/lang/StringBuilder;

    .line 40
    const-string v3, "Could not find Application instance from Context "

    .line 42
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 45
    invoke-virtual {p0}, Ldw;->y()Landroid/content/Context;

    .line 48
    move-result-object v3

    .line 49
    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 52
    move-result-object v3

    .line 53
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 56
    const-string v3, ", you will not be able to use AndroidViewModel with the default ViewModelProvider.Factory"

    .line 58
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 61
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 64
    move-result-object v1

    .line 65
    const-string v3, "FragmentManager"

    .line 67
    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 70
    :cond_2
    new-instance v1, Lkgl;

    .line 72
    invoke-direct {v1, v2}, Lkgl;-><init>([B)V

    .line 75
    if-eqz v0, :cond_3

    .line 77
    sget-object v2, Lkex;->b:Lkgi;

    .line 79
    invoke-virtual {v1, v2, v0}, Lkgl;->b(Lkgi;Ljava/lang/Object;)V

    .line 82
    :cond_3
    sget-object v0, Lkei;->a:Lkgi;

    .line 84
    invoke-virtual {v1, v0, p0}, Lkgl;->b(Lkgi;Ljava/lang/Object;)V

    .line 87
    sget-object v0, Lkei;->b:Lkgi;

    .line 89
    invoke-virtual {v1, v0, p0}, Lkgl;->b(Lkgi;Ljava/lang/Object;)V

    .line 92
    iget-object p0, p0, Ldw;->q:Landroid/os/Bundle;

    .line 94
    if-eqz p0, :cond_4

    .line 96
    sget-object v0, Lkei;->c:Lkgi;

    .line 98
    invoke-virtual {v1, v0, p0}, Lkgl;->b(Lkgi;Ljava/lang/Object;)V

    .line 101
    :cond_4
    return-object v1
.end method

.method public final S()Lmqs;
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->ai:Lmqv;

    .line 3
    invoke-virtual {p0}, Lmqv;->a()Lmqs;

    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final T(I)Ljava/lang/CharSequence;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ldw;->z()Landroid/content/res/Resources;

    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;

    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final U()Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->X:Lds;

    .line 3
    if-nez p0, :cond_0

    .line 5
    const/4 p0, 0x0

    .line 6
    return-object p0

    .line 7
    :cond_0
    iget-object p0, p0, Lds;->i:Ljava/lang/Object;

    .line 9
    return-object p0
.end method

.method public final V()Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->X:Lds;

    .line 3
    if-nez p0, :cond_0

    .line 5
    const/4 p0, 0x0

    .line 6
    return-object p0

    .line 7
    :cond_0
    iget-object p0, p0, Lds;->k:Ljava/lang/Object;

    .line 9
    return-object p0
.end method

.method public final W(I)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ldw;->z()Landroid/content/res/Resources;

    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final varargs X(I[Ljava/lang/Object;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ldw;->z()Landroid/content/res/Resources;

    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0, p1, p2}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method final Y()Ljava/util/ArrayList;
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->X:Lds;

    .line 3
    if-eqz p0, :cond_1

    .line 5
    iget-object p0, p0, Lds;->g:Ljava/util/ArrayList;

    .line 7
    if-nez p0, :cond_0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    return-object p0

    .line 11
    :cond_1
    :goto_0
    new-instance p0, Ljava/util/ArrayList;

    .line 13
    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    .line 16
    return-object p0
.end method

.method final Z()Ljava/util/ArrayList;
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->X:Lds;

    .line 3
    if-eqz p0, :cond_1

    .line 5
    iget-object p0, p0, Lds;->h:Ljava/util/ArrayList;

    .line 7
    if-nez p0, :cond_0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    return-object p0

    .line 11
    :cond_1
    :goto_0
    new-instance p0, Ljava/util/ArrayList;

    .line 13
    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    .line 16
    return-object p0
.end method

.method public final aA()Z
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->F:Lfm;

    .line 3
    if-nez p0, :cond_0

    .line 5
    const/4 p0, 0x0

    .line 6
    return p0

    .line 7
    :cond_0
    invoke-virtual {p0}, Lfm;->ag()Z

    .line 10
    move-result p0

    .line 11
    return p0
.end method

.method public aB(Landroid/view/MenuItem;)Z
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final aC()Landroid/view/LayoutInflater;
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    iget-object v0, p0, Ldw;->G:Lek;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    check-cast v0, Leb;

    .line 7
    iget-object v0, v0, Leb;->a:Lec;

    .line 9
    invoke-virtual {v0}, Lec;->getLayoutInflater()Landroid/view/LayoutInflater;

    .line 12
    move-result-object v1

    .line 13
    invoke-virtual {v1, v0}, Landroid/view/LayoutInflater;->cloneInContext(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 16
    move-result-object v0

    .line 17
    iget-object p0, p0, Ldw;->H:Lfm;

    .line 19
    iget-object p0, p0, Lfm;->d:Lem;

    .line 21
    invoke-virtual {v0, p0}, Landroid/view/LayoutInflater;->setFactory2(Landroid/view/LayoutInflater$Factory2;)V

    .line 24
    return-object v0

    .line 25
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 27
    const-string v0, "onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager."

    .line 29
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 32
    throw p0
.end method

.method public final aD()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Ldw;->S:Z

    .line 4
    return-void
.end method

.method public final aE()V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    iget-boolean v0, p0, Ldw;->Q:Z

    .line 3
    const/4 v1, 0x1

    .line 4
    if-eq v0, v1, :cond_0

    .line 6
    iput-boolean v1, p0, Ldw;->Q:Z

    .line 8
    invoke-virtual {p0}, Ldw;->ax()Z

    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 14
    invoke-virtual {p0}, Ldw;->ay()Z

    .line 17
    move-result v0

    .line 18
    if-nez v0, :cond_0

    .line 20
    iget-object p0, p0, Ldw;->G:Lek;

    .line 22
    invoke-virtual {p0}, Lek;->f()V

    .line 25
    :cond_0
    return-void
.end method

.method public final aF(Landroid/content/Intent;)V
    .locals 2

    .line 1
    iget-object v0, p0, Ldw;->G:Lek;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    const/4 p0, -0x1

    .line 6
    invoke-virtual {v0, p1, p0}, Lek;->i(Landroid/content/Intent;I)V

    .line 9
    return-void

    .line 10
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 12
    const-string v0, "Fragment "

    .line 14
    const-string v1, " not attached to Activity"

    .line 16
    invoke-static {p0, v0, v1}, La;->e(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 19
    move-result-object p0

    .line 20
    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 23
    throw p1
.end method

.method public final aG(Landroid/content/Intent;I)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    iget-object v0, p0, Ldw;->G:Lek;

    .line 3
    if-eqz v0, :cond_1

    .line 5
    invoke-virtual {p0}, Ldw;->G()Lfm;

    .line 8
    move-result-object v0

    .line 9
    iget-object v1, v0, Lfm;->t:Ladv;

    .line 11
    if-eqz v1, :cond_0

    .line 13
    new-instance v1, Landroid/support/v4/app/FragmentManager$LaunchedFragmentInfo;

    .line 15
    iget-object p0, p0, Ldw;->p:Ljava/lang/String;

    .line 17
    invoke-direct {v1, p0, p2}, Landroid/support/v4/app/FragmentManager$LaunchedFragmentInfo;-><init>(Ljava/lang/String;I)V

    .line 20
    iget-object p0, v0, Lfm;->u:Ljava/util/ArrayDeque;

    .line 22
    invoke-virtual {p0, v1}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    .line 25
    iget-object p0, v0, Lfm;->t:Ladv;

    .line 27
    const/4 p2, 0x0

    .line 28
    invoke-virtual {p0, p1, p2}, Ladv;->a(Ljava/lang/Object;Ljck;)V

    .line 31
    return-void

    .line 32
    :cond_0
    iget-object p0, v0, Lfm;->p:Lek;

    .line 34
    invoke-virtual {p0, p1, p2}, Lek;->i(Landroid/content/Intent;I)V

    .line 37
    return-void

    .line 38
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 40
    const-string p2, "Fragment "

    .line 42
    const-string v0, " not attached to Activity"

    .line 44
    invoke-static {p0, p2, v0}, La;->e(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 47
    move-result-object p0

    .line 48
    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 51
    throw p1
.end method

.method public aH()V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    return-void
.end method

.method public final aI()V
    .locals 4
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    sget v0, Ljyx;->a:I

    .line 3
    new-instance v0, Ljzb;

    .line 5
    invoke-direct {v0, p0}, Ljzb;-><init>(Ldw;)V

    .line 8
    invoke-static {v0}, Ljyx;->d(Ljzd;)V

    .line 11
    invoke-static {p0}, Ljyx;->b(Ldw;)Ljyw;

    .line 14
    move-result-object v1

    .line 15
    iget-object v2, v1, Ljyw;->b:Ljava/util/Set;

    .line 17
    sget-object v3, Ljyv;->f:Ljyv;

    .line 19
    invoke-interface {v2, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 22
    move-result v2

    .line 23
    if-eqz v2, :cond_0

    .line 25
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    move-result-object v2

    .line 29
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    move-result-object v3

    .line 33
    invoke-static {v1, v2, v3}, Ljyx;->e(Ljyw;Ljava/lang/Class;Ljava/lang/Class;)Z

    .line 36
    move-result v2

    .line 37
    if-eqz v2, :cond_0

    .line 39
    invoke-static {v1, v0}, Ljyx;->c(Ljyw;Ljzd;)V

    .line 42
    :cond_0
    const/4 v0, 0x1

    .line 43
    iput-boolean v0, p0, Ldw;->O:Z

    .line 45
    iget-object v1, p0, Ldw;->F:Lfm;

    .line 47
    if-eqz v1, :cond_1

    .line 49
    iget-object v0, v1, Lfm;->z:Lfq;

    .line 51
    invoke-virtual {v0, p0}, Lfq;->a(Ldw;)V

    .line 54
    return-void

    .line 55
    :cond_1
    iput-boolean v0, p0, Ldw;->P:Z

    .line 57
    return-void
.end method

.method public aa(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .locals 3

    .line 1
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 4
    const-string v0, "mFragmentId=#"

    .line 6
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 9
    iget v0, p0, Ldw;->J:I

    .line 11
    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 18
    const-string v0, " mContainerId=#"

    .line 20
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 23
    iget v0, p0, Ldw;->K:I

    .line 25
    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 32
    const-string v0, " mTag="

    .line 34
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 37
    iget-object v0, p0, Ldw;->L:Ljava/lang/String;

    .line 39
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 42
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 45
    const-string v0, "mState="

    .line 47
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 50
    iget v0, p0, Ldw;->k:I

    .line 52
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(I)V

    .line 55
    const-string v0, " mWho="

    .line 57
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 60
    iget-object v0, p0, Ldw;->p:Ljava/lang/String;

    .line 62
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 65
    const-string v0, " mBackStackNesting="

    .line 67
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 70
    iget v0, p0, Ldw;->E:I

    .line 72
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(I)V

    .line 75
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 78
    const-string v0, "mAdded="

    .line 80
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 83
    iget-boolean v0, p0, Ldw;->v:Z

    .line 85
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 88
    const-string v0, " mRemoving="

    .line 90
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 93
    iget-boolean v0, p0, Ldw;->w:Z

    .line 95
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 98
    const-string v0, " mFromLayout="

    .line 100
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 103
    iget-boolean v0, p0, Ldw;->z:Z

    .line 105
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 108
    const-string v0, " mInLayout="

    .line 110
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 113
    iget-boolean v0, p0, Ldw;->A:Z

    .line 115
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    .line 118
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 121
    const-string v0, "mHidden="

    .line 123
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 126
    iget-boolean v0, p0, Ldw;->M:Z

    .line 128
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 131
    const-string v0, " mDetached="

    .line 133
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 136
    iget-boolean v0, p0, Ldw;->N:Z

    .line 138
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 141
    const-string v0, " mMenuVisible="

    .line 143
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 146
    iget-boolean v0, p0, Ldw;->R:Z

    .line 148
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 151
    const-string v0, " mHasMenu="

    .line 153
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 156
    iget-boolean v0, p0, Ldw;->Q:Z

    .line 158
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    .line 161
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 164
    const-string v0, "mRetainInstance="

    .line 166
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 169
    iget-boolean v0, p0, Ldw;->O:Z

    .line 171
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 174
    const-string v0, " mUserVisibleHint="

    .line 176
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 179
    iget-boolean v0, p0, Ldw;->W:Z

    .line 181
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    .line 184
    iget-object v0, p0, Ldw;->F:Lfm;

    .line 186
    if-eqz v0, :cond_0

    .line 188
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 191
    const-string v0, "mFragmentManager="

    .line 193
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 196
    iget-object v0, p0, Ldw;->F:Lfm;

    .line 198
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 201
    :cond_0
    iget-object v0, p0, Ldw;->G:Lek;

    .line 203
    if-eqz v0, :cond_1

    .line 205
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 208
    const-string v0, "mHost="

    .line 210
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 213
    iget-object v0, p0, Ldw;->G:Lek;

    .line 215
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 218
    :cond_1
    iget-object v0, p0, Ldw;->I:Ldw;

    .line 220
    if-eqz v0, :cond_2

    .line 222
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 225
    const-string v0, "mParentFragment="

    .line 227
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 230
    iget-object v0, p0, Ldw;->I:Ldw;

    .line 232
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 235
    :cond_2
    iget-object v0, p0, Ldw;->q:Landroid/os/Bundle;

    .line 237
    if-eqz v0, :cond_3

    .line 239
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 242
    const-string v0, "mArguments="

    .line 244
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 247
    iget-object v0, p0, Ldw;->q:Landroid/os/Bundle;

    .line 249
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 252
    :cond_3
    iget-object v0, p0, Ldw;->l:Landroid/os/Bundle;

    .line 254
    if-eqz v0, :cond_4

    .line 256
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 259
    const-string v0, "mSavedFragmentState="

    .line 261
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 264
    iget-object v0, p0, Ldw;->l:Landroid/os/Bundle;

    .line 266
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 269
    :cond_4
    iget-object v0, p0, Ldw;->m:Landroid/util/SparseArray;

    .line 271
    if-eqz v0, :cond_5

    .line 273
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 276
    const-string v0, "mSavedViewState="

    .line 278
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 281
    iget-object v0, p0, Ldw;->m:Landroid/util/SparseArray;

    .line 283
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 286
    :cond_5
    iget-object v0, p0, Ldw;->n:Landroid/os/Bundle;

    .line 288
    if-eqz v0, :cond_6

    .line 290
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 293
    const-string v0, "mSavedViewRegistryState="

    .line 295
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 298
    iget-object v0, p0, Ldw;->n:Landroid/os/Bundle;

    .line 300
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 303
    :cond_6
    iget-object v0, p0, Ldw;->r:Ldw;

    .line 305
    if-nez v0, :cond_8

    .line 307
    iget-object v0, p0, Ldw;->F:Lfm;

    .line 309
    const/4 v1, 0x0

    .line 310
    if-eqz v0, :cond_7

    .line 312
    iget-object v2, p0, Ldw;->s:Ljava/lang/String;

    .line 314
    if-eqz v2, :cond_7

    .line 316
    invoke-virtual {v0, v2}, Lfm;->c(Ljava/lang/String;)Ldw;

    .line 319
    move-result-object v0

    .line 320
    goto :goto_0

    .line 321
    :cond_7
    move-object v0, v1

    .line 322
    :cond_8
    :goto_0
    if-eqz v0, :cond_9

    .line 324
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 327
    const-string v1, "mTarget="

    .line 329
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 332
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/Object;)V

    .line 335
    const-string v0, " mTargetRequestCode="

    .line 337
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 340
    iget v0, p0, Ldw;->t:I

    .line 342
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(I)V

    .line 345
    :cond_9
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 348
    const-string v0, "mPopDirection="

    .line 350
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 353
    invoke-virtual {p0}, Ldw;->av()Z

    .line 356
    move-result v0

    .line 357
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    .line 360
    invoke-virtual {p0}, Ldw;->t()I

    .line 363
    move-result v0

    .line 364
    if-eqz v0, :cond_a

    .line 366
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 369
    const-string v0, "getEnterAnim="

    .line 371
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 374
    invoke-virtual {p0}, Ldw;->t()I

    .line 377
    move-result v0

    .line 378
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(I)V

    .line 381
    :cond_a
    invoke-virtual {p0}, Ldw;->u()I

    .line 384
    move-result v0

    .line 385
    if-eqz v0, :cond_b

    .line 387
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 390
    const-string v0, "getExitAnim="

    .line 392
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 395
    invoke-virtual {p0}, Ldw;->u()I

    .line 398
    move-result v0

    .line 399
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(I)V

    .line 402
    :cond_b
    invoke-virtual {p0}, Ldw;->v()I

    .line 405
    move-result v0

    .line 406
    if-eqz v0, :cond_c

    .line 408
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 411
    const-string v0, "getPopEnterAnim="

    .line 413
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 416
    invoke-virtual {p0}, Ldw;->v()I

    .line 419
    move-result v0

    .line 420
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(I)V

    .line 423
    :cond_c
    invoke-virtual {p0}, Ldw;->w()I

    .line 426
    move-result v0

    .line 427
    if-eqz v0, :cond_d

    .line 429
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 432
    const-string v0, "getPopExitAnim="

    .line 434
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 437
    invoke-virtual {p0}, Ldw;->w()I

    .line 440
    move-result v0

    .line 441
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(I)V

    .line 444
    :cond_d
    iget-object v0, p0, Ldw;->T:Landroid/view/ViewGroup;

    .line 446
    if-eqz v0, :cond_e

    .line 448
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 451
    const-string v0, "mContainer="

    .line 453
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 456
    iget-object v0, p0, Ldw;->T:Landroid/view/ViewGroup;

    .line 458
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 461
    :cond_e
    iget-object v0, p0, Ldw;->U:Landroid/view/View;

    .line 463
    if-eqz v0, :cond_f

    .line 465
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 468
    const-string v0, "mView="

    .line 470
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 473
    iget-object v0, p0, Ldw;->U:Landroid/view/View;

    .line 475
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 478
    :cond_f
    invoke-virtual {p0}, Ldw;->x()Landroid/content/Context;

    .line 481
    move-result-object v0

    .line 482
    if-eqz v0, :cond_10

    .line 484
    invoke-static {p0}, Lkgv;->a(Lkcm;)Lkgv;

    .line 487
    move-result-object v0

    .line 488
    invoke-virtual {v0, p1, p3}, Lkgv;->b(Ljava/lang/String;Ljava/io/PrintWriter;)V

    .line 491
    :cond_10
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 494
    new-instance v0, Ljava/lang/StringBuilder;

    .line 496
    const-string v1, "Child "

    .line 498
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 501
    iget-object v1, p0, Ldw;->H:Lfm;

    .line 503
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 506
    const-string v1, ":"

    .line 508
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 511
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 514
    move-result-object v0

    .line 515
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 518
    iget-object p0, p0, Ldw;->H:Lfm;

    .line 520
    const-string v0, "  "

    .line 522
    invoke-virtual {p1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 525
    move-result-object p1

    .line 526
    invoke-virtual {p0, p1, p2, p3, p4}, Lfm;->H(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    .line 529
    return-void
.end method

.method final ab()V
    .locals 3

    .line 1
    invoke-direct {p0}, Ldw;->n()V

    .line 4
    iget-object v0, p0, Ldw;->p:Ljava/lang/String;

    .line 6
    iput-object v0, p0, Ldw;->ab:Ljava/lang/String;

    .line 8
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 15
    move-result-object v0

    .line 16
    iput-object v0, p0, Ldw;->p:Ljava/lang/String;

    .line 18
    const/4 v0, 0x0

    .line 19
    iput-boolean v0, p0, Ldw;->v:Z

    .line 21
    iput-boolean v0, p0, Ldw;->w:Z

    .line 23
    iput-boolean v0, p0, Ldw;->z:Z

    .line 25
    iput-boolean v0, p0, Ldw;->A:Z

    .line 27
    iput-boolean v0, p0, Ldw;->C:Z

    .line 29
    iput v0, p0, Ldw;->E:I

    .line 31
    const/4 v1, 0x0

    .line 32
    iput-object v1, p0, Ldw;->F:Lfm;

    .line 34
    new-instance v2, Lfn;

    .line 36
    invoke-direct {v2}, Lfm;-><init>()V

    .line 39
    iput-object v2, p0, Ldw;->H:Lfm;

    .line 41
    iput-object v1, p0, Ldw;->G:Lek;

    .line 43
    iput v0, p0, Ldw;->J:I

    .line 45
    iput v0, p0, Ldw;->K:I

    .line 47
    iput-object v1, p0, Ldw;->L:Ljava/lang/String;

    .line 49
    iput-boolean v0, p0, Ldw;->M:Z

    .line 51
    iput-boolean v0, p0, Ldw;->N:Z

    .line 53
    return-void
.end method

.method public ac(Landroid/os/Bundle;)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    const/4 p1, 0x1

    .line 2
    iput-boolean p1, p0, Ldw;->S:Z

    .line 4
    return-void
.end method

.method public ad(IILandroid/content/Intent;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    const/4 v0, 0x2

    .line 2
    invoke-static {v0}, Lfm;->ad(I)Z

    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 8
    new-instance v0, Ljava/lang/StringBuilder;

    .line 10
    const-string v1, "Fragment "

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 15
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 18
    const-string p0, " received the following in onActivityResult(): requestCode: "

    .line 20
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 26
    const-string p0, " resultCode: "

    .line 28
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 31
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 34
    const-string p0, " data: "

    .line 36
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 42
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 45
    move-result-object p0

    .line 46
    const-string p1, "FragmentManager"

    .line 48
    invoke-static {p1, p0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 51
    :cond_0
    return-void
.end method

.method public ae(Landroid/view/Menu;Landroid/view/MenuInflater;)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    return-void
.end method

.method public af()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Ldw;->S:Z

    .line 4
    return-void
.end method

.method public ag()V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    return-void
.end method

.method public ah()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Ldw;->S:Z

    .line 4
    return-void
.end method

.method public ai()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Ldw;->S:Z

    .line 4
    return-void
.end method

.method public aj(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 0

    .line 1
    return-void
.end method

.method final ak()V
    .locals 2

    .line 1
    iget-object v0, p0, Ldw;->l:Landroid/os/Bundle;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    const-string v1, "savedInstanceState"

    .line 7
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 10
    move-result-object v0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 v0, 0x0

    .line 13
    :goto_0
    new-instance v1, Ldb;

    .line 15
    invoke-direct {v1, p0, v0}, Ldb;-><init>(Ldw;Landroid/os/Bundle;)V

    .line 18
    invoke-static {v1}, Lga;->a(Ljava/lang/Runnable;)V

    .line 21
    iget-object p0, p0, Ldw;->H:Lfm;

    .line 23
    const/4 v0, 0x2

    .line 24
    invoke-virtual {p0, v0}, Lfm;->F(I)V

    .line 27
    return-void
.end method

.method final al()V
    .locals 2

    .line 1
    iget-object v0, p0, Ldw;->l:Landroid/os/Bundle;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    const-string v1, "childFragmentManager"

    .line 7
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 10
    move-result-object v0

    .line 11
    if-eqz v0, :cond_0

    .line 13
    iget-object v1, p0, Ldw;->H:Lfm;

    .line 15
    invoke-virtual {v1, v0}, Lfm;->R(Landroid/os/Parcelable;)V

    .line 18
    iget-object p0, p0, Ldw;->H:Lfm;

    .line 20
    invoke-virtual {p0}, Lfm;->u()V

    .line 23
    :cond_0
    return-void
.end method

.method final am(IIII)V
    .locals 1

    .line 1
    iget-object v0, p0, Ldw;->X:Lds;

    .line 3
    if-nez v0, :cond_2

    .line 5
    if-nez p1, :cond_2

    .line 7
    const/4 p1, 0x0

    .line 8
    if-nez p2, :cond_2

    .line 10
    if-nez p3, :cond_1

    .line 12
    if-eqz p4, :cond_0

    .line 14
    move p2, p1

    .line 15
    move p3, p2

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    return-void

    .line 18
    :cond_1
    move p2, p1

    .line 19
    :cond_2
    :goto_0
    invoke-virtual {p0}, Ldw;->B()Lds;

    .line 22
    move-result-object v0

    .line 23
    iput p1, v0, Lds;->b:I

    .line 25
    invoke-virtual {p0}, Ldw;->B()Lds;

    .line 28
    move-result-object p1

    .line 29
    iput p2, p1, Lds;->c:I

    .line 31
    invoke-virtual {p0}, Ldw;->B()Lds;

    .line 34
    move-result-object p1

    .line 35
    iput p3, p1, Lds;->d:I

    .line 37
    invoke-virtual {p0}, Ldw;->B()Lds;

    .line 40
    move-result-object p0

    .line 41
    iput p4, p0, Lds;->e:I

    .line 43
    return-void
.end method

.method public final an(Landroid/os/Bundle;)V
    .locals 1

    .line 1
    iget-object v0, p0, Ldw;->F:Lfm;

    .line 3
    if-eqz v0, :cond_1

    .line 5
    invoke-virtual {p0}, Ldw;->aA()Z

    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 14
    const-string p1, "Fragment already added and state has been saved"

    .line 16
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    throw p0

    .line 20
    :cond_1
    :goto_0
    iput-object p1, p0, Ldw;->q:Landroid/os/Bundle;

    .line 22
    return-void
.end method

.method public final ao(Ljava/lang/Object;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Ldw;->B()Lds;

    .line 4
    move-result-object p0

    .line 5
    iput-object p1, p0, Lds;->k:Ljava/lang/Object;

    .line 7
    return-void
.end method

.method final ap(Landroid/view/View;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Ldw;->B()Lds;

    .line 4
    move-result-object p0

    .line 5
    iput-object p1, p0, Lds;->o:Landroid/view/View;

    .line 7
    return-void
.end method

.method public final aq(Z)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Ldw;->R:Z

    .line 3
    if-eq v0, p1, :cond_0

    .line 5
    iput-boolean p1, p0, Ldw;->R:Z

    .line 7
    iget-boolean p1, p0, Ldw;->Q:Z

    .line 9
    if-eqz p1, :cond_0

    .line 11
    invoke-virtual {p0}, Ldw;->ax()Z

    .line 14
    move-result p1

    .line 15
    if-eqz p1, :cond_0

    .line 17
    invoke-virtual {p0}, Ldw;->ay()Z

    .line 20
    move-result p1

    .line 21
    if-nez p1, :cond_0

    .line 23
    iget-object p0, p0, Ldw;->G:Lek;

    .line 25
    invoke-virtual {p0}, Lek;->f()V

    .line 28
    :cond_0
    return-void
.end method

.method final ar(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Ldw;->X:Lds;

    .line 3
    if-nez v0, :cond_0

    .line 5
    if-nez p1, :cond_0

    .line 7
    return-void

    .line 8
    :cond_0
    invoke-virtual {p0}, Ldw;->B()Lds;

    .line 11
    iget-object p0, p0, Ldw;->X:Lds;

    .line 13
    iput p1, p0, Lds;->f:I

    .line 15
    return-void
.end method

.method final as(Z)V
    .locals 1

    .line 1
    iget-object v0, p0, Ldw;->X:Lds;

    .line 3
    if-nez v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    invoke-virtual {p0}, Ldw;->B()Lds;

    .line 9
    move-result-object p0

    .line 10
    iput-boolean p1, p0, Lds;->a:Z

    .line 12
    return-void
.end method

.method final at(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Ldw;->B()Lds;

    .line 4
    iget-object p0, p0, Ldw;->X:Lds;

    .line 6
    iput-object p1, p0, Lds;->g:Ljava/util/ArrayList;

    .line 8
    iput-object p2, p0, Lds;->h:Ljava/util/ArrayList;

    .line 10
    return-void
.end method

.method public au(Z)V
    .locals 4
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    sget v0, Ljyx;->a:I

    .line 3
    new-instance v0, Ljzc;

    .line 5
    invoke-direct {v0, p0, p1}, Ljzc;-><init>(Ldw;Z)V

    .line 8
    invoke-static {v0}, Ljyx;->d(Ljzd;)V

    .line 11
    invoke-static {p0}, Ljyx;->b(Ldw;)Ljyw;

    .line 14
    move-result-object v1

    .line 15
    iget-object v2, v1, Ljyw;->b:Ljava/util/Set;

    .line 17
    sget-object v3, Ljyv;->g:Ljyv;

    .line 19
    invoke-interface {v2, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 22
    move-result v2

    .line 23
    if-eqz v2, :cond_0

    .line 25
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    move-result-object v2

    .line 29
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    move-result-object v3

    .line 33
    invoke-static {v1, v2, v3}, Ljyx;->e(Ljyw;Ljava/lang/Class;Ljava/lang/Class;)Z

    .line 36
    move-result v2

    .line 37
    if-eqz v2, :cond_0

    .line 39
    invoke-static {v1, v0}, Ljyx;->c(Ljyw;Ljzd;)V

    .line 42
    :cond_0
    iget-boolean v0, p0, Ldw;->W:Z

    .line 44
    const/4 v1, 0x5

    .line 45
    if-nez v0, :cond_1

    .line 47
    if-eqz p1, :cond_1

    .line 49
    iget v0, p0, Ldw;->k:I

    .line 51
    if-ge v0, v1, :cond_1

    .line 53
    iget-object v0, p0, Ldw;->F:Lfm;

    .line 55
    if-eqz v0, :cond_1

    .line 57
    invoke-virtual {p0}, Ldw;->ax()Z

    .line 60
    move-result v2

    .line 61
    if-eqz v2, :cond_1

    .line 63
    iget-boolean v2, p0, Ldw;->aa:Z

    .line 65
    if-eqz v2, :cond_1

    .line 67
    invoke-virtual {v0, p0}, Lfm;->k(Ldw;)Lfw;

    .line 70
    move-result-object v2

    .line 71
    invoke-virtual {v0, v2}, Lfm;->P(Lfw;)V

    .line 74
    :cond_1
    iput-boolean p1, p0, Ldw;->W:Z

    .line 76
    iget v0, p0, Ldw;->k:I

    .line 78
    const/4 v2, 0x0

    .line 79
    if-ge v0, v1, :cond_2

    .line 81
    if-nez p1, :cond_2

    .line 83
    const/4 v2, 0x1

    .line 84
    :cond_2
    iput-boolean v2, p0, Ldw;->V:Z

    .line 86
    iget-object v0, p0, Ldw;->l:Landroid/os/Bundle;

    .line 88
    if-eqz v0, :cond_3

    .line 90
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 93
    move-result-object p1

    .line 94
    iput-object p1, p0, Ldw;->o:Ljava/lang/Boolean;

    .line 96
    :cond_3
    return-void
.end method

.method final av()Z
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->X:Lds;

    .line 3
    if-nez p0, :cond_0

    .line 5
    const/4 p0, 0x0

    .line 6
    return p0

    .line 7
    :cond_0
    iget-boolean p0, p0, Lds;->a:Z

    .line 9
    return p0
.end method

.method public final aw()Z
    .locals 4
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    sget v0, Ljyx;->a:I

    .line 3
    new-instance v0, Ljyz;

    .line 5
    invoke-direct {v0, p0}, Ljyz;-><init>(Ldw;)V

    .line 8
    invoke-static {v0}, Ljyx;->d(Ljzd;)V

    .line 11
    invoke-static {p0}, Ljyx;->b(Ldw;)Ljyw;

    .line 14
    move-result-object v1

    .line 15
    iget-object v2, v1, Ljyw;->b:Ljava/util/Set;

    .line 17
    sget-object v3, Ljyv;->f:Ljyv;

    .line 19
    invoke-interface {v2, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 22
    move-result v2

    .line 23
    if-eqz v2, :cond_0

    .line 25
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    move-result-object v2

    .line 29
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    move-result-object v3

    .line 33
    invoke-static {v1, v2, v3}, Ljyx;->e(Ljyw;Ljava/lang/Class;Ljava/lang/Class;)Z

    .line 36
    move-result v2

    .line 37
    if-eqz v2, :cond_0

    .line 39
    invoke-static {v1, v0}, Ljyx;->c(Ljyw;Ljzd;)V

    .line 42
    :cond_0
    iget-boolean p0, p0, Ldw;->O:Z

    .line 44
    return p0
.end method

.method public final ax()Z
    .locals 1

    .line 1
    iget-object v0, p0, Ldw;->G:Lek;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-boolean p0, p0, Ldw;->v:Z

    .line 7
    if-eqz p0, :cond_0

    .line 9
    const/4 p0, 0x1

    .line 10
    return p0

    .line 11
    :cond_0
    const/4 p0, 0x0

    .line 12
    return p0
.end method

.method public final ay()Z
    .locals 3

    .line 1
    iget-boolean v0, p0, Ldw;->M:Z

    .line 3
    const/4 v1, 0x1

    .line 4
    if-nez v0, :cond_2

    .line 6
    iget-object v0, p0, Ldw;->F:Lfm;

    .line 8
    const/4 v2, 0x0

    .line 9
    if-eqz v0, :cond_1

    .line 11
    iget-object p0, p0, Ldw;->I:Ldw;

    .line 13
    if-nez p0, :cond_0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    invoke-virtual {p0}, Ldw;->ay()Z

    .line 19
    move-result p0

    .line 20
    if-eqz p0, :cond_1

    .line 22
    return v1

    .line 23
    :cond_1
    :goto_0
    return v2

    .line 24
    :cond_2
    return v1
.end method

.method final az()Z
    .locals 0

    .line 1
    iget p0, p0, Ldw;->E:I

    .line 3
    if-lez p0, :cond_0

    .line 5
    const/4 p0, 0x1

    .line 6
    return p0

    .line 7
    :cond_0
    const/4 p0, 0x0

    .line 8
    return p0
.end method

.method public e(Landroid/content/Context;)V
    .locals 0

    .line 1
    const/4 p1, 0x1

    .line 2
    iput-boolean p1, p0, Ldw;->S:Z

    .line 4
    return-void
.end method

.method public f(Landroid/os/Bundle;)V
    .locals 0

    .line 1
    const/4 p1, 0x1

    .line 2
    iput-boolean p1, p0, Ldw;->S:Z

    .line 4
    invoke-virtual {p0}, Ldw;->al()V

    .line 7
    iget-object p0, p0, Ldw;->H:Lfm;

    .line 9
    iget p1, p0, Lfm;->o:I

    .line 11
    if-lez p1, :cond_0

    .line 13
    return-void

    .line 14
    :cond_0
    invoke-virtual {p0}, Lfm;->u()V

    .line 17
    return-void
.end method

.method public fB()Leg;
    .locals 1

    .line 1
    new-instance v0, Ldo;

    .line 3
    invoke-direct {v0, p0}, Ldo;-><init>(Ldw;)V

    .line 6
    return-object v0
.end method

.method public fC(Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ldw;->aC()Landroid/view/LayoutInflater;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public g()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Ldw;->S:Z

    .line 4
    return-void
.end method

.method public final getArguments()Landroid/os/Bundle;
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->q:Landroid/os/Bundle;

    .line 3
    return-object p0
.end method

.method public h()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Ldw;->S:Z

    .line 4
    return-void
.end method

.method public i(Landroid/os/Bundle;)V
    .locals 0

    .line 1
    return-void
.end method

.method public j()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Ldw;->S:Z

    .line 4
    return-void
.end method

.method public k()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Ldw;->S:Z

    .line 4
    return-void
.end method

.method public l(Landroid/os/Bundle;)V
    .locals 0

    .line 1
    const/4 p1, 0x1

    .line 2
    iput-boolean p1, p0, Ldw;->S:Z

    .line 4
    return-void
.end method

.method public m(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    .locals 3

    .line 1
    iget-object v0, p0, Ldw;->H:Lfm;

    .line 3
    invoke-virtual {v0}, Lfm;->N()V

    .line 6
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, Ldw;->D:Z

    .line 9
    new-instance v0, Lgm;

    .line 11
    invoke-virtual {p0}, Ldw;->Q()Lkfd;

    .line 14
    move-result-object v1

    .line 15
    new-instance v2, Lcq;

    .line 17
    invoke-direct {v2, p0}, Lcq;-><init>(Ldw;)V

    .line 20
    invoke-direct {v0, p0, v1, v2}, Lgm;-><init>(Ldw;Lkfd;Ljava/lang/Runnable;)V

    .line 23
    iput-object v0, p0, Ldw;->af:Lgm;

    .line 25
    new-instance v0, Lcr;

    .line 27
    invoke-direct {v0, p0, p1, p2, p3}, Lcr;-><init>(Ldw;Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V

    .line 30
    invoke-static {v0}, Lga;->a(Ljava/lang/Runnable;)V

    .line 33
    iget-object p1, p0, Ldw;->U:Landroid/view/View;

    .line 35
    iget-object p2, p0, Ldw;->af:Lgm;

    .line 37
    if-eqz p1, :cond_1

    .line 39
    invoke-virtual {p2}, Lgm;->b()V

    .line 42
    const/4 p1, 0x3

    .line 43
    invoke-static {p1}, Lfm;->ad(I)Z

    .line 46
    move-result p1

    .line 47
    if-eqz p1, :cond_0

    .line 49
    new-instance p1, Ljava/lang/StringBuilder;

    .line 51
    const-string p2, "Setting ViewLifecycleOwner on View "

    .line 53
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 56
    iget-object p2, p0, Ldw;->U:Landroid/view/View;

    .line 58
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 61
    const-string p2, " for Fragment "

    .line 63
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 69
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 72
    move-result-object p1

    .line 73
    const-string p2, "FragmentManager"

    .line 75
    invoke-static {p2, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 78
    :cond_0
    iget-object p1, p0, Ldw;->U:Landroid/view/View;

    .line 80
    iget-object p2, p0, Ldw;->af:Lgm;

    .line 82
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    const p3, 0x7f0a07a8

    .line 88
    invoke-virtual {p1, p3, p2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 91
    iget-object p1, p0, Ldw;->U:Landroid/view/View;

    .line 93
    iget-object p2, p0, Ldw;->af:Lgm;

    .line 95
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 98
    const p3, 0x7f0a07ac

    .line 101
    invoke-virtual {p1, p3, p2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 104
    iget-object p1, p0, Ldw;->U:Landroid/view/View;

    .line 106
    iget-object p2, p0, Ldw;->af:Lgm;

    .line 108
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 111
    const p3, 0x7f0a07ab

    .line 114
    invoke-virtual {p1, p3, p2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 117
    iget-object p1, p0, Ldw;->ag:Lkdg;

    .line 119
    iget-object p0, p0, Ldw;->af:Lgm;

    .line 121
    invoke-virtual {p1, p0}, Lkdg;->k(Ljava/lang/Object;)V

    .line 124
    return-void

    .line 125
    :cond_1
    iget-object p1, p2, Lgm;->a:Lkct;

    .line 127
    if-nez p1, :cond_2

    .line 129
    const/4 p1, 0x0

    .line 130
    iput-object p1, p0, Ldw;->af:Lgm;

    .line 132
    return-void

    .line 133
    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 135
    const-string p1, "Called getViewLifecycleOwner() but onCreateView() returned null"

    .line 137
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 140
    throw p0
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    .line 1
    const/4 p1, 0x1

    .line 2
    iput-boolean p1, p0, Ldw;->S:Z

    .line 4
    return-void
.end method

.method public final onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Ldw;->E()Lec;

    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0, p1, p2, p3}, Lec;->onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V

    .line 8
    return-void
.end method

.method public final onLowMemory()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Ldw;->S:Z

    .line 4
    return-void
.end method

.method final s()F
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->X:Lds;

    .line 3
    if-nez p0, :cond_0

    .line 5
    const/high16 p0, 0x3f800000    # 1.0f

    .line 7
    return p0

    .line 8
    :cond_0
    iget p0, p0, Lds;->n:F

    .line 10
    return p0
.end method

.method public final startActivityForResult(Landroid/content/Intent;I)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    invoke-virtual {p0, p1, p2}, Ldw;->aG(Landroid/content/Intent;I)V

    .line 4
    return-void
.end method

.method final t()I
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->X:Lds;

    .line 3
    if-nez p0, :cond_0

    .line 5
    const/4 p0, 0x0

    .line 6
    return p0

    .line 7
    :cond_0
    iget p0, p0, Lds;->b:I

    .line 9
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    const/16 v1, 0x80

    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 8
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    move-result-object v1

    .line 12
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 15
    move-result-object v1

    .line 16
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    const-string v1, "{"

    .line 21
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 24
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 27
    move-result v1

    .line 28
    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 31
    move-result-object v1

    .line 32
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 35
    const-string v1, "} ("

    .line 37
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    iget-object v1, p0, Ldw;->p:Ljava/lang/String;

    .line 42
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    iget v1, p0, Ldw;->J:I

    .line 47
    if-eqz v1, :cond_0

    .line 49
    const-string v1, " id=0x"

    .line 51
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    iget v1, p0, Ldw;->J:I

    .line 56
    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 59
    move-result-object v1

    .line 60
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    :cond_0
    iget-object v1, p0, Ldw;->L:Ljava/lang/String;

    .line 65
    if-eqz v1, :cond_1

    .line 67
    const-string v1, " tag="

    .line 69
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    iget-object p0, p0, Ldw;->L:Ljava/lang/String;

    .line 74
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 77
    :cond_1
    const-string p0, ")"

    .line 79
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 82
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 85
    move-result-object p0

    .line 86
    return-object p0
.end method

.method final u()I
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->X:Lds;

    .line 3
    if-nez p0, :cond_0

    .line 5
    const/4 p0, 0x0

    .line 6
    return p0

    .line 7
    :cond_0
    iget p0, p0, Lds;->c:I

    .line 9
    return p0
.end method

.method final v()I
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->X:Lds;

    .line 3
    if-nez p0, :cond_0

    .line 5
    const/4 p0, 0x0

    .line 6
    return p0

    .line 7
    :cond_0
    iget p0, p0, Lds;->d:I

    .line 9
    return p0
.end method

.method final w()I
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->X:Lds;

    .line 3
    if-nez p0, :cond_0

    .line 5
    const/4 p0, 0x0

    .line 6
    return p0

    .line 7
    :cond_0
    iget p0, p0, Lds;->e:I

    .line 9
    return p0
.end method

.method public final x()Landroid/content/Context;
    .locals 0

    .line 1
    iget-object p0, p0, Ldw;->G:Lek;

    .line 3
    if-nez p0, :cond_0

    .line 5
    const/4 p0, 0x0

    .line 6
    return-object p0

    .line 7
    :cond_0
    iget-object p0, p0, Lek;->c:Landroid/content/Context;

    .line 9
    return-object p0
.end method

.method public final y()Landroid/content/Context;
    .locals 3

    .line 1
    invoke-virtual {p0}, Ldw;->x()Landroid/content/Context;

    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    return-object v0

    .line 8
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 10
    const-string v1, "Fragment "

    .line 12
    const-string v2, " not attached to a context."

    .line 14
    invoke-static {p0, v1, v2}, La;->e(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 17
    move-result-object p0

    .line 18
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    throw v0
.end method

.method public final z()Landroid/content/res/Resources;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ldw;->y()Landroid/content/Context;

    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method
