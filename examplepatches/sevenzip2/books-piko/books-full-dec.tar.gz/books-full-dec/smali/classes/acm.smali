.class public final Lacm;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:I

.field public final b:Lbhwq;

.field private final c:I


# direct methods
.method public constructor <init>(IILbhwq;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, Lacm;->c:I

    .line 6
    iput p2, p0, Lacm;->a:I

    .line 8
    iput-object p3, p0, Lacm;->b:Lbhwq;

    .line 10
    return-void
.end method


# virtual methods
.method public final a(Z)I
    .locals 0

    .line 1
    if-eqz p1, :cond_0

    .line 3
    iget p0, p0, Lacm;->a:I

    .line 5
    return p0

    .line 6
    :cond_0
    iget p0, p0, Lacm;->c:I

    .line 8
    return p0
.end method
