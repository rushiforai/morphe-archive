.class public final Laehs;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwv;


# instance fields
.field a:I

.field synthetic b:Ljava/lang/Object;

.field final synthetic c:Lbhwz;

.field private synthetic d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lbhtu;Lbhwz;)V
    .locals 0

    .line 1
    iput-object p2, p0, Laehs;->c:Lbhwz;

    .line 3
    const/4 p2, 0x3

    .line 4
    invoke-direct {p0, p2, p1}, Lbhuu;-><init>(ILbhtu;)V

    .line 7
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, Lbilc;

    .line 3
    check-cast p2, [Ljava/lang/Object;

    .line 5
    check-cast p3, Lbhtu;

    .line 7
    iget-object p0, p0, Laehs;->c:Lbhwz;

    .line 9
    new-instance v0, Laehs;

    .line 11
    invoke-direct {v0, p3, p0}, Laehs;-><init>(Lbhtu;Lbhwz;)V

    .line 14
    iput-object p1, v0, Laehs;->d:Ljava/lang/Object;

    .line 16
    iput-object p2, v0, Laehs;->b:Ljava/lang/Object;

    .line 18
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 20
    invoke-virtual {v0, p0}, Laehs;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    move-result-object p0

    .line 24
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Laehs;->a:I

    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v3, 0x1

    .line 7
    if-eqz v1, :cond_1

    .line 9
    if-eq v1, v3, :cond_0

    .line 11
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 14
    goto :goto_1

    .line 15
    :cond_0
    iget-object v1, p0, Laehs;->d:Ljava/lang/Object;

    .line 17
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 20
    goto :goto_0

    .line 21
    :cond_1
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 24
    iget-object v1, p0, Laehs;->d:Ljava/lang/Object;

    .line 26
    iget-object p1, p0, Laehs;->b:Ljava/lang/Object;

    .line 28
    iget-object v4, p0, Laehs;->c:Lbhwz;

    .line 30
    check-cast p1, [Ljava/lang/Object;

    .line 32
    const/4 v5, 0x0

    .line 33
    aget-object v5, p1, v5

    .line 35
    aget-object v6, p1, v3

    .line 37
    aget-object v7, p1, v2

    .line 39
    const/4 v8, 0x3

    .line 40
    aget-object v8, p1, v8

    .line 42
    const/4 v9, 0x4

    .line 43
    aget-object v9, p1, v9

    .line 45
    const/4 v10, 0x5

    .line 46
    aget-object p1, p1, v10

    .line 48
    iput v3, p0, Laehs;->a:I

    .line 50
    check-cast v5, Ljava/util/List;

    .line 52
    check-cast v6, Ljava/util/List;

    .line 54
    check-cast v7, Ljava/util/List;

    .line 56
    check-cast v8, Ljava/util/List;

    .line 58
    check-cast v9, Lxkz;

    .line 60
    check-cast p1, Ljava/lang/Boolean;

    .line 62
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 65
    move-result p1

    .line 66
    new-instance v3, Lwxz;

    .line 68
    check-cast v4, Lwxz;

    .line 70
    iget-object v10, v4, Lwxz;->g:Lwyd;

    .line 72
    iget-object v11, v4, Lwxz;->h:Lwzl;

    .line 74
    iget v4, v4, Lwxz;->i:I

    .line 76
    invoke-direct {v3, v10, v11, v4, p0}, Lwxz;-><init>(Lwyd;Lwzl;ILbhtu;)V

    .line 79
    iput-object v5, v3, Lwxz;->a:Ljava/lang/Object;

    .line 81
    iput-object v6, v3, Lwxz;->b:Ljava/lang/Object;

    .line 83
    iput-object v7, v3, Lwxz;->c:Ljava/lang/Object;

    .line 85
    iput-object v8, v3, Lwxz;->d:Ljava/lang/Object;

    .line 87
    iput-object v9, v3, Lwxz;->e:Ljava/lang/Object;

    .line 89
    iput-boolean p1, v3, Lwxz;->f:Z

    .line 91
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 93
    invoke-virtual {v3, p1}, Lwxz;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 96
    move-result-object p1

    .line 97
    if-eq p1, v0, :cond_3

    .line 99
    :goto_0
    const/4 v3, 0x0

    .line 100
    iput-object v3, p0, Laehs;->d:Ljava/lang/Object;

    .line 102
    iput v2, p0, Laehs;->a:I

    .line 104
    invoke-interface {v1, p1, p0}, Lbilc;->a(Ljava/lang/Object;Lbhtu;)Ljava/lang/Object;

    .line 107
    move-result-object p0

    .line 108
    if-ne p0, v0, :cond_2

    .line 110
    goto :goto_2

    .line 111
    :cond_2
    :goto_1
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 113
    return-object p0

    .line 114
    :cond_3
    :goto_2
    return-object v0
.end method
