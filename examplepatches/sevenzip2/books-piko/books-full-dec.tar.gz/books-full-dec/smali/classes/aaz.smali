.class public final synthetic Laaz;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lkcj;


# instance fields
.field public final synthetic a:Labl;


# direct methods
.method public synthetic constructor <init>(Labl;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laaz;->a:Labl;

    .line 6
    return-void
.end method


# virtual methods
.method public final a(Lkcm;Lkby;)V
    .locals 0

    .line 1
    sget-object p1, Lkby;->ON_DESTROY:Lkby;

    .line 3
    if-ne p2, p1, :cond_1

    .line 5
    iget-object p0, p0, Laaz;->a:Labl;

    .line 7
    iget-object p1, p0, Labl;->g:Ladr;

    .line 9
    invoke-virtual {p1}, Ladr;->a()V

    .line 12
    invoke-virtual {p0}, Labl;->isChangingConfigurations()Z

    .line 15
    move-result p1

    .line 16
    if-nez p1, :cond_0

    .line 18
    invoke-virtual {p0}, Labl;->Q()Lkfd;

    .line 21
    move-result-object p1

    .line 22
    invoke-virtual {p1}, Lkfd;->a()V

    .line 25
    :cond_0
    iget-object p0, p0, Labl;->n:Labh;

    .line 27
    iget-object p1, p0, Labh;->b:Labl;

    .line 29
    invoke-virtual {p1}, Labl;->getWindow()Landroid/view/Window;

    .line 32
    move-result-object p2

    .line 33
    invoke-virtual {p2}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 36
    move-result-object p2

    .line 37
    invoke-virtual {p2, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 40
    invoke-virtual {p1}, Labl;->getWindow()Landroid/view/Window;

    .line 43
    move-result-object p1

    .line 44
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 47
    move-result-object p1

    .line 48
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 51
    move-result-object p1

    .line 52
    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->removeOnDrawListener(Landroid/view/ViewTreeObserver$OnDrawListener;)V

    .line 55
    :cond_1
    return-void
.end method
