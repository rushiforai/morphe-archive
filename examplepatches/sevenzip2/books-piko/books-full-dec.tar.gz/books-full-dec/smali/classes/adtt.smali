.class public final Ladtt;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Lbhpa;

.field public final b:Lbhpa;

.field public final c:Lbhpa;


# direct methods
.method public constructor <init>(Lbhpa;Lbhpa;Lbhpa;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    iput-object p1, p0, Ladtt;->a:Lbhpa;

    .line 9
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    iput-object p2, p0, Ladtt;->b:Lbhpa;

    .line 14
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    iput-object p3, p0, Ladtt;->c:Lbhpa;

    .line 19
    return-void
.end method
