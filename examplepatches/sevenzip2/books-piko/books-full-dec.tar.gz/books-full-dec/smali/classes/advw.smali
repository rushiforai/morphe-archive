.class public final Ladvw;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Landroid/view/ViewTreeObserver$OnPreDrawListener;

.field public final b:Landroid/view/View;

.field public final c:Landroid/view/View;

.field public final d:Landroid/graphics/Rect;

.field public final e:Ladvk;


# direct methods
.method public constructor <init>(Landroid/view/View;Ladvk;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladvw;->c:Landroid/view/View;

    .line 6
    invoke-virtual {p1}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 9
    move-result-object v0

    .line 10
    iput-object v0, p0, Ladvw;->b:Landroid/view/View;

    .line 12
    invoke-static {p1}, Ladvw;->a(Landroid/view/View;)Landroid/graphics/Rect;

    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, Ladvw;->d:Landroid/graphics/Rect;

    .line 18
    iput-object p2, p0, Ladvw;->e:Ladvk;

    .line 20
    new-instance p1, Ladvv;

    .line 22
    invoke-direct {p1, p0}, Ladvv;-><init>(Ladvw;)V

    .line 25
    iput-object p1, p0, Ladvw;->a:Landroid/view/ViewTreeObserver$OnPreDrawListener;

    .line 27
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 30
    move-result-object p0

    .line 31
    invoke-virtual {p0}, Landroid/view/ViewTreeObserver;->isAlive()Z

    .line 34
    move-result p2

    .line 35
    if-eqz p2, :cond_0

    .line 37
    invoke-virtual {p0, p1}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 40
    :cond_0
    return-void
.end method

.method public static a(Landroid/view/View;)Landroid/graphics/Rect;
    .locals 5

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Landroid/graphics/Rect;

    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 10
    move-result v2

    .line 11
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 14
    move-result v3

    .line 15
    const/4 v4, 0x0

    .line 16
    invoke-direct {v1, v4, v4, v2, v3}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 19
    :goto_0
    if-eq p0, v0, :cond_0

    .line 21
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 24
    move-result-object v2

    .line 25
    check-cast v2, Landroid/view/View;

    .line 27
    invoke-virtual {p0}, Landroid/view/View;->getLeft()I

    .line 30
    move-result v3

    .line 31
    invoke-virtual {v2}, Landroid/view/View;->getScrollX()I

    .line 34
    move-result v4

    .line 35
    sub-int/2addr v3, v4

    .line 36
    invoke-virtual {p0}, Landroid/view/View;->getTop()I

    .line 39
    move-result p0

    .line 40
    invoke-virtual {v2}, Landroid/view/View;->getScrollY()I

    .line 43
    move-result v4

    .line 44
    sub-int/2addr p0, v4

    .line 45
    invoke-virtual {v1, v3, p0}, Landroid/graphics/Rect;->offset(II)V

    .line 48
    move-object p0, v2

    .line 49
    goto :goto_0

    .line 50
    :cond_0
    return-object v1
.end method
