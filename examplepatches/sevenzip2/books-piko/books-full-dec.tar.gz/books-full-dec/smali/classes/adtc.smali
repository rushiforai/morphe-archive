.class public final Ladtc;
.super Lbdst;
.source "PG"

# interfaces
.implements Lbduj;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    sget-object v0, Ladtd;->a:Ladtd;

    .line 3
    invoke-direct {p0, v0}, Lbdst;-><init>(Lbdtb;)V

    .line 6
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p0}, Lbdst;->u()V

    .line 7
    iget-object p0, p0, Ladtc;->b:Lbdtb;

    .line 9
    check-cast p0, Ladtd;

    .line 11
    sget-object v0, Ladtd;->a:Ladtd;

    .line 13
    invoke-virtual {p0}, Ladtd;->a()Lbdue;

    .line 16
    move-result-object p0

    .line 17
    invoke-interface {p0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    return-void
.end method

.method public final b(ILadtf;)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Lbdst;->u()V

    .line 4
    iget-object p0, p0, Ladtc;->b:Lbdtb;

    .line 6
    check-cast p0, Ladtd;

    .line 8
    sget-object v0, Ladtd;->a:Ladtd;

    .line 10
    invoke-virtual {p0}, Ladtd;->b()V

    .line 13
    iget-object p0, p0, Ladtd;->c:Lbdts;

    .line 15
    invoke-interface {p0, p1, p2}, Lbdts;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 18
    return-void
.end method
