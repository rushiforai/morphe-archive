.class public final synthetic Ladw;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lkcj;


# instance fields
.field public final synthetic a:Laec;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Ladu;

.field public final synthetic d:Laeg;


# direct methods
.method public synthetic constructor <init>(Laec;Ljava/lang/String;Ladu;Laeg;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladw;->a:Laec;

    .line 6
    iput-object p2, p0, Ladw;->b:Ljava/lang/String;

    .line 8
    iput-object p3, p0, Ladw;->c:Ladu;

    .line 10
    iput-object p4, p0, Ladw;->d:Laeg;

    .line 12
    return-void
.end method


# virtual methods
.method public final a(Lkcm;Lkby;)V
    .locals 3

    .line 1
    iget-object p1, p0, Ladw;->a:Laec;

    .line 3
    iget-object v0, p0, Ladw;->b:Ljava/lang/String;

    .line 5
    sget-object v1, Lkby;->ON_START:Lkby;

    .line 7
    if-ne v1, p2, :cond_1

    .line 9
    iget-object p2, p0, Ladw;->d:Laeg;

    .line 11
    iget-object p0, p0, Ladw;->c:Ladu;

    .line 13
    iget-object v1, p1, Laec;->e:Ljava/util/Map;

    .line 15
    new-instance v2, Lady;

    .line 17
    invoke-direct {v2, p0, p2}, Lady;-><init>(Ladu;Laeg;)V

    .line 20
    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    iget-object v1, p1, Laec;->f:Ljava/util/Map;

    .line 25
    invoke-interface {v1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 28
    move-result v2

    .line 29
    if-eqz v2, :cond_0

    .line 31
    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    move-result-object v2

    .line 35
    invoke-interface {v1, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    invoke-interface {p0, v2}, Ladu;->a(Ljava/lang/Object;)V

    .line 41
    :cond_0
    iget-object p1, p1, Laec;->g:Landroid/os/Bundle;

    .line 43
    const-class v1, Landroidx/activity/result/ActivityResult;

    .line 45
    invoke-static {p1, v0, v1}, Ljhx;->b(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 48
    move-result-object v1

    .line 49
    check-cast v1, Landroidx/activity/result/ActivityResult;

    .line 51
    if-eqz v1, :cond_3

    .line 53
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 56
    iget p1, v1, Landroidx/activity/result/ActivityResult;->a:I

    .line 58
    iget-object v0, v1, Landroidx/activity/result/ActivityResult;->b:Landroid/content/Intent;

    .line 60
    invoke-virtual {p2, p1, v0}, Laeg;->a(ILandroid/content/Intent;)Ljava/lang/Object;

    .line 63
    move-result-object p1

    .line 64
    invoke-interface {p0, p1}, Ladu;->a(Ljava/lang/Object;)V

    .line 67
    return-void

    .line 68
    :cond_1
    sget-object p0, Lkby;->ON_STOP:Lkby;

    .line 70
    if-ne p0, p2, :cond_2

    .line 72
    iget-object p0, p1, Laec;->e:Ljava/util/Map;

    .line 74
    invoke-interface {p0, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 77
    return-void

    .line 78
    :cond_2
    sget-object p0, Lkby;->ON_DESTROY:Lkby;

    .line 80
    if-ne p0, p2, :cond_3

    .line 82
    invoke-virtual {p1, v0}, Laec;->f(Ljava/lang/String;)V

    .line 85
    :cond_3
    return-void
.end method
