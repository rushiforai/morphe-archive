.class public final Ladkg;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladkg;->a:Lbeye;

    .line 6
    iput-object p2, p0, Ladkg;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Ladkg;->a:Lbeye;

    .line 3
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Laktz;

    .line 9
    iget-object p0, p0, Ladkg;->b:Lbeye;

    .line 11
    invoke-interface {p0}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object p0

    .line 15
    check-cast p0, Ladkh;

    .line 17
    new-instance v1, Ladkf;

    .line 19
    invoke-direct {v1, v0, p0}, Ladkf;-><init>(Laktz;Ladkh;)V

    .line 22
    return-object v1
.end method
