.class public final Labyz;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labyz;->a:Lbeye;

    .line 6
    iput-object p2, p0, Labyz;->b:Lbeye;

    .line 8
    iput-object p3, p0, Labyz;->c:Lbeye;

    .line 10
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 3

    .line 1
    new-instance v0, Labyy;

    .line 3
    iget-object v1, p0, Labyz;->a:Lbeye;

    .line 5
    iget-object v2, p0, Labyz;->b:Lbeye;

    .line 7
    iget-object p0, p0, Labyz;->c:Lbeye;

    .line 9
    invoke-direct {v0, v1, v2, p0}, Labyy;-><init>(Lbhpa;Lbhpa;Lbhpa;)V

    .line 12
    return-object v0
.end method
