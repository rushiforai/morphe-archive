.class final Ladtl;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:I

.field final synthetic b:Ladsu;

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Lbhwq;

.field final synthetic e:Ldw;

.field final synthetic f:I

.field final synthetic g:Lbhwf;

.field final synthetic h:Ladtn;

.field final synthetic i:Laduy;

.field private synthetic j:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ladsu;Ljava/lang/String;Lbhwq;Ldw;ILbhwf;Ladtn;Laduy;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ladtl;->b:Ladsu;

    .line 3
    iput-object p2, p0, Ladtl;->c:Ljava/lang/String;

    .line 5
    iput-object p3, p0, Ladtl;->d:Lbhwq;

    .line 7
    iput-object p4, p0, Ladtl;->e:Ldw;

    .line 9
    iput p5, p0, Ladtl;->f:I

    .line 11
    iput-object p6, p0, Ladtl;->g:Lbhwf;

    .line 13
    iput-object p7, p0, Ladtl;->h:Ladtn;

    .line 15
    iput-object p8, p0, Ladtl;->i:Laduy;

    .line 17
    const/4 p1, 0x2

    .line 18
    invoke-direct {p0, p1, p9}, Lbhuu;-><init>(ILbhtu;)V

    .line 21
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Ladtl;

    .line 13
    invoke-virtual {p0, p1}, Ladtl;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Ladtl;->a:I

    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v1, :cond_0

    .line 8
    iget-object v3, p0, Ladtl;->j:Ljava/lang/Object;

    .line 10
    check-cast v3, Lbifi;

    .line 12
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 15
    if-eq v1, v2, :cond_1

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 21
    iget-object p1, p0, Ladtl;->j:Ljava/lang/Object;

    .line 23
    check-cast p1, Lbifi;

    .line 25
    iget-object v1, p0, Ladtl;->b:Ladsu;

    .line 27
    iget-object v3, p0, Ladtl;->c:Ljava/lang/String;

    .line 29
    invoke-interface {v1, v3}, Ladsu;->c(Ljava/lang/String;)Z

    .line 32
    move-result v1

    .line 33
    if-eqz v1, :cond_5

    .line 35
    iget-object v1, p0, Ladtl;->d:Lbhwq;

    .line 37
    iput-object p1, p0, Ladtl;->j:Ljava/lang/Object;

    .line 39
    iput v2, p0, Ladtl;->a:I

    .line 41
    invoke-interface {v1, p0}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    move-result-object v1

    .line 45
    if-eq v1, v0, :cond_4

    .line 47
    move-object v3, p1

    .line 48
    move-object p1, v1

    .line 49
    :cond_1
    check-cast p1, Ljava/lang/Boolean;

    .line 51
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 54
    move-result p1

    .line 55
    if-eqz p1, :cond_5

    .line 57
    iget-object p1, p0, Ladtl;->e:Ldw;

    .line 59
    iget-object p1, p1, Ldw;->U:Landroid/view/View;

    .line 61
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    iget v1, p0, Ladtl;->f:I

    .line 66
    check-cast p1, Landroid/view/ViewGroup;

    .line 68
    iput-object v3, p0, Ladtl;->j:Ljava/lang/Object;

    .line 70
    const/4 v2, 0x2

    .line 71
    iput v2, p0, Ladtl;->a:I

    .line 73
    invoke-static {p1, v1, p0}, Ladwj;->b(Landroid/view/ViewGroup;ILbhtu;)Ljava/lang/Object;

    .line 76
    move-result-object p1

    .line 77
    if-ne p1, v0, :cond_2

    .line 79
    goto :goto_1

    .line 80
    :cond_2
    :goto_0
    iget-object v0, p0, Ladtl;->g:Lbhwf;

    .line 82
    move-object v7, p1

    .line 83
    check-cast v7, Landroid/view/View;

    .line 85
    invoke-interface {v0}, Lbhwf;->a()Ljava/lang/Object;

    .line 88
    move-result-object p1

    .line 89
    move-object v5, p1

    .line 90
    check-cast v5, Ladti;

    .line 92
    if-nez v5, :cond_3

    .line 94
    goto :goto_2

    .line 95
    :cond_3
    iget-object p1, p0, Ladtl;->b:Ladsu;

    .line 97
    iget-object v0, p0, Ladtl;->c:Ljava/lang/String;

    .line 99
    iget-object v6, p0, Ladtl;->h:Ladtn;

    .line 101
    iget-object v8, p0, Ladtl;->i:Laduy;

    .line 103
    new-instance v4, Ladtk;

    .line 105
    const/4 v9, 0x0

    .line 106
    invoke-direct/range {v4 .. v9}, Ladtk;-><init>(Ladti;Ladtn;Landroid/view/View;Laduy;Lbhtu;)V

    .line 109
    invoke-static {v3, p1, v0, v4}, Ladsx;->a(Lbifi;Ladsu;Ljava/lang/String;Lbhwq;)V

    .line 112
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 114
    return-object p0

    .line 115
    :cond_4
    :goto_1
    return-object v0

    .line 116
    :cond_5
    :goto_2
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 118
    return-object p0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 10

    .line 1
    new-instance v0, Ladtl;

    .line 3
    iget-object v1, p0, Ladtl;->b:Ladsu;

    .line 5
    iget-object v2, p0, Ladtl;->c:Ljava/lang/String;

    .line 7
    iget-object v3, p0, Ladtl;->d:Lbhwq;

    .line 9
    iget-object v4, p0, Ladtl;->e:Ldw;

    .line 11
    iget v5, p0, Ladtl;->f:I

    .line 13
    iget-object v6, p0, Ladtl;->g:Lbhwf;

    .line 15
    iget-object v7, p0, Ladtl;->h:Ladtn;

    .line 17
    iget-object v8, p0, Ladtl;->i:Laduy;

    .line 19
    move-object v9, p2

    .line 20
    invoke-direct/range {v0 .. v9}, Ladtl;-><init>(Ladsu;Ljava/lang/String;Lbhwq;Ldw;ILbhwf;Ladtn;Laduy;Lbhtu;)V

    .line 23
    iput-object p1, v0, Ladtl;->j:Ljava/lang/Object;

    .line 25
    return-object v0
.end method
