.class public interface abstract Lmqw;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lkcm;


# virtual methods
.method public abstract S()Lmqs;
.end method
