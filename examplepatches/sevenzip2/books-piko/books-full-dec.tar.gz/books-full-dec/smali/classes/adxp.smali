.class public final Ladxp;
.super Landroid/content/BroadcastReceiver;
.source "PG"


# instance fields
.field final synthetic a:Ladxt;


# direct methods
.method public constructor <init>(Ladxt;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ladxp;->a:Ladxt;

    .line 3
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    sget-wide p1, Ladxt;->a:J

    .line 9
    iget-object p0, p0, Ladxp;->a:Ladxt;

    .line 11
    iget-object p1, p0, Ladxt;->b:Lbifb;

    .line 13
    invoke-static {p1}, Lbifj;->b(Lbhuc;)Lbifi;

    .line 16
    move-result-object p1

    .line 17
    new-instance p2, Ladxo;

    .line 19
    const/4 v0, 0x0

    .line 20
    invoke-direct {p2, p0, v0}, Ladxo;-><init>(Ladxt;Lbhtu;)V

    .line 23
    const/4 p0, 0x3

    .line 24
    const/4 v1, 0x0

    .line 25
    invoke-static {p1, v0, v1, p2, p0}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 28
    return-void
.end method
