.class public final Labk;
.super Laec;
.source "PG"


# instance fields
.field final synthetic a:Labl;


# direct methods
.method public constructor <init>(Labl;)V
    .locals 0

    .line 1
    iput-object p1, p0, Labk;->a:Labl;

    .line 3
    invoke-direct {p0}, Laec;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public final a(ILaeg;Ljava/lang/Object;Ljck;)V
    .locals 8

    .line 1
    iget-object v0, p0, Labk;->a:Labl;

    .line 3
    invoke-virtual {p2, v0, p3}, Laeg;->c(Landroid/content/Context;Ljava/lang/Object;)Laef;

    .line 6
    move-result-object v1

    .line 7
    if-eqz v1, :cond_0

    .line 9
    new-instance p2, Landroid/os/Handler;

    .line 11
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 14
    move-result-object p3

    .line 15
    invoke-direct {p2, p3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 18
    new-instance p3, Labi;

    .line 20
    invoke-direct {p3, p0, p1, v1}, Labi;-><init>(Labk;ILaef;)V

    .line 23
    invoke-virtual {p2, p3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 26
    return-void

    .line 27
    :cond_0
    invoke-virtual {p2, p3}, Laeg;->b(Ljava/lang/Object;)Landroid/content/Intent;

    .line 30
    move-result-object p2

    .line 31
    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 34
    move-result-object p3

    .line 35
    if-eqz p3, :cond_1

    .line 37
    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 40
    move-result-object p3

    .line 41
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    invoke-virtual {p3}, Landroid/os/Bundle;->getClassLoader()Ljava/lang/ClassLoader;

    .line 47
    move-result-object p3

    .line 48
    if-nez p3, :cond_1

    .line 50
    invoke-virtual {v0}, Labl;->getClassLoader()Ljava/lang/ClassLoader;

    .line 53
    move-result-object p3

    .line 54
    invoke-virtual {p2, p3}, Landroid/content/Intent;->setExtrasClassLoader(Ljava/lang/ClassLoader;)V

    .line 57
    :cond_1
    const-string p3, "androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE"

    .line 59
    invoke-virtual {p2, p3}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    .line 62
    move-result v1

    .line 63
    if-eqz v1, :cond_2

    .line 65
    invoke-virtual {p2, p3}, Landroid/content/Intent;->getBundleExtra(Ljava/lang/String;)Landroid/os/Bundle;

    .line 68
    move-result-object p4

    .line 69
    invoke-virtual {p2, p3}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    .line 72
    :goto_0
    move-object v7, p4

    .line 73
    goto :goto_1

    .line 74
    :cond_2
    if-eqz p4, :cond_3

    .line 76
    check-cast p4, Ljcj;

    .line 78
    iget-object p3, p4, Ljcj;->a:Landroid/app/ActivityOptions;

    .line 80
    invoke-virtual {p3}, Landroid/app/ActivityOptions;->toBundle()Landroid/os/Bundle;

    .line 83
    move-result-object p4

    .line 84
    goto :goto_0

    .line 85
    :cond_3
    const/4 p4, 0x0

    .line 86
    goto :goto_0

    .line 87
    :goto_1
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 90
    move-result-object p3

    .line 91
    const-string p4, "androidx.activity.result.contract.action.REQUEST_PERMISSIONS"

    .line 93
    invoke-static {p4, p3}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 96
    move-result p3

    .line 97
    if-eqz p3, :cond_5

    .line 99
    const-string p0, "androidx.activity.result.contract.extra.PERMISSIONS"

    .line 101
    invoke-virtual {p2, p0}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;

    .line 104
    move-result-object p0

    .line 105
    if-nez p0, :cond_4

    .line 107
    const/4 p0, 0x0

    .line 108
    new-array p0, p0, [Ljava/lang/String;

    .line 110
    :cond_4
    invoke-static {v0, p0, p1}, Ljci;->a(Landroid/app/Activity;[Ljava/lang/String;I)V

    .line 113
    return-void

    .line 114
    :cond_5
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 117
    move-result-object p3

    .line 118
    const-string p4, "androidx.activity.result.contract.action.INTENT_SENDER_REQUEST"

    .line 120
    invoke-static {p4, p3}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 123
    move-result p3

    .line 124
    if-eqz p3, :cond_6

    .line 126
    const-string p3, "androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST"

    .line 128
    invoke-virtual {p2, p3}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 131
    move-result-object p2

    .line 132
    check-cast p2, Landroidx/activity/result/IntentSenderRequest;

    .line 134
    :try_start_0
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 137
    iget-object v1, p2, Landroidx/activity/result/IntentSenderRequest;->a:Landroid/content/IntentSender;

    .line 139
    iget-object v3, p2, Landroidx/activity/result/IntentSenderRequest;->b:Landroid/content/Intent;

    .line 141
    iget v4, p2, Landroidx/activity/result/IntentSenderRequest;->c:I

    .line 143
    iget v5, p2, Landroidx/activity/result/IntentSenderRequest;->d:I

    .line 145
    :try_end_0
    .catch Landroid/content/IntentSender$SendIntentException; {:try_start_0 .. :try_end_0} :catch_1

    const/4 v6, 0x0

    .line 146
    move v2, p1

    .line 147
    :try_start_1
    invoke-virtual/range {v0 .. v7}, Landroid/app/Activity;->startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V

    .line 150
    :try_end_1
    .catch Landroid/content/IntentSender$SendIntentException; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    .line 151
    :catch_0
    move-exception v0

    .line 152
    goto :goto_2

    .line 153
    :catch_1
    move-exception v0

    .line 154
    move v2, p1

    .line 155
    :goto_2
    move-object p1, v0

    .line 156
    new-instance p2, Landroid/os/Handler;

    .line 158
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 161
    move-result-object p3

    .line 162
    invoke-direct {p2, p3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 165
    new-instance p3, Labj;

    .line 167
    invoke-direct {p3, p0, v2, p1}, Labj;-><init>(Labk;ILandroid/content/IntentSender$SendIntentException;)V

    .line 170
    invoke-virtual {p2, p3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 173
    return-void

    .line 174
    :cond_6
    move v2, p1

    .line 175
    invoke-virtual {v0, p2, v2, v7}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;ILandroid/os/Bundle;)V

    .line 178
    return-void
.end method
