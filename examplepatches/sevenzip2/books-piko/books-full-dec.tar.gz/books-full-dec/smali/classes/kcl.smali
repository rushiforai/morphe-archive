.class public interface abstract Lkcl;
.super Ljava/lang/Object;
.source "PG"