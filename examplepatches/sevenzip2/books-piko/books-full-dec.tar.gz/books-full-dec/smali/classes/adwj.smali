.class public final Ladwj;
.super Ljava/lang/Object;
.source "PG"


# direct methods
.method public static final a(Landroid/view/ViewGroup;IILj$/time/Duration;Lbhtu;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p4

    .line 3
    instance-of v1, v0, Ladwi;

    .line 5
    if-eqz v1, :cond_0

    .line 7
    move-object v1, v0

    .line 8
    check-cast v1, Ladwi;

    .line 10
    iget v2, v1, Ladwi;->e:I

    .line 12
    const/high16 v3, -0x80000000

    .line 14
    and-int v4, v2, v3

    .line 16
    if-eqz v4, :cond_0

    .line 18
    sub-int/2addr v2, v3

    .line 19
    iput v2, v1, Ladwi;->e:I

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    new-instance v1, Ladwi;

    .line 24
    invoke-direct {v1, v0}, Lbhuq;-><init>(Lbhtu;)V

    .line 27
    :goto_0
    iget-object v0, v1, Ladwi;->d:Ljava/lang/Object;

    .line 29
    sget-object v2, Lbhug;->a:Lbhug;

    .line 31
    iget v3, v1, Ladwi;->e:I

    .line 33
    const/4 v4, 0x1

    .line 34
    if-eqz v3, :cond_2

    .line 36
    if-ne v3, v4, :cond_1

    .line 38
    iget v3, v1, Ladwi;->c:I

    .line 40
    iget v5, v1, Ladwi;->b:I

    .line 42
    iget-object v6, v1, Ladwi;->f:Lj$/time/Duration;

    .line 44
    iget-object v7, v1, Ladwi;->a:Ljava/lang/Object;

    .line 46
    invoke-static {v0}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 49
    goto :goto_1

    .line 50
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 52
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 54
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 57
    throw v0

    .line 58
    :cond_2
    invoke-static {v0}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 61
    move-object/from16 v7, p0

    .line 63
    move/from16 v5, p1

    .line 65
    move/from16 v3, p2

    .line 67
    move-object/from16 v6, p3

    .line 69
    :goto_1
    sget v0, Ljmy;->a:I

    .line 71
    move-object v0, v7

    .line 72
    check-cast v0, Landroid/view/View;

    .line 74
    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_17

    .line 80
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 83
    new-instance v0, Ljng;

    .line 85
    move-object v8, v7

    .line 86
    check-cast v8, Landroid/view/ViewGroup;

    .line 88
    invoke-direct {v0, v8}, Ljng;-><init>(Landroid/view/ViewGroup;)V

    .line 91
    new-instance v8, Ladwh;

    .line 93
    invoke-direct {v8, v5}, Ladwh;-><init>(I)V

    .line 96
    new-instance v9, Lbiah;

    .line 98
    invoke-direct {v9, v0, v4, v8}, Lbiah;-><init>(Lbiao;ZLbhwq;)V

    .line 101
    new-instance v0, Lbiag;

    .line 103
    invoke-direct {v0, v9}, Lbiag;-><init>(Lbiah;)V

    .line 106
    const/4 v9, 0x0

    .line 107
    const/4 v10, 0x0

    .line 108
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 111
    move-result v11

    .line 112
    if-eqz v11, :cond_15

    .line 114
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 117
    move-result-object v11

    .line 118
    check-cast v11, Landroid/view/View;

    .line 120
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 123
    invoke-static {v11}, Ladwg;->b(Landroid/view/View;)Z

    .line 126
    move-result v12

    .line 127
    if-eqz v12, :cond_3

    .line 129
    new-instance v12, Ladwb;

    .line 131
    const-string v13, "target not visible"

    .line 133
    invoke-direct {v12, v13}, Ladwb;-><init>(Ljava/lang/String;)V

    .line 136
    :goto_3
    move-object/from16 p1, v0

    .line 138
    move/from16 p4, v4

    .line 140
    :goto_4
    move-object/from16 p2, v10

    .line 142
    move-object/from16 p3, v11

    .line 144
    goto/16 :goto_d

    .line 146
    :cond_3
    invoke-virtual {v11}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 149
    move-result-object v12

    .line 150
    instance-of v13, v12, Landroid/view/ViewGroup;

    .line 152
    if-eqz v13, :cond_4

    .line 154
    check-cast v12, Landroid/view/ViewGroup;

    .line 156
    goto :goto_5

    .line 157
    :cond_4
    const/4 v12, 0x0

    .line 158
    :goto_5
    if-nez v12, :cond_5

    .line 160
    new-instance v12, Ladwc;

    .line 162
    const/16 v13, 0x64

    .line 164
    invoke-direct {v12, v13}, Ladwc;-><init>(I)V

    .line 167
    goto :goto_3

    .line 168
    :cond_5
    invoke-static {v11}, Ladwa;->a(Landroid/view/View;)Landroid/graphics/RectF;

    .line 171
    move-result-object v13

    .line 172
    invoke-static {v11, v13}, Ladwa;->b(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 175
    new-instance v14, Ljava/util/ArrayList;

    .line 177
    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    .line 180
    new-instance v15, Lbhyh;

    .line 182
    invoke-direct {v15}, Ljava/lang/Object;-><init>()V

    .line 185
    move/from16 p4, v4

    .line 187
    move-object v4, v11

    .line 188
    :goto_6
    invoke-static {v12}, Ladwg;->b(Landroid/view/View;)Z

    .line 191
    move-result v16

    .line 192
    if-eqz v16, :cond_6

    .line 194
    new-instance v12, Ladwb;

    .line 196
    const-string v4, "parent not visible"

    .line 198
    invoke-direct {v12, v4}, Ladwb;-><init>(Ljava/lang/String;)V

    .line 201
    move-object/from16 p1, v0

    .line 203
    goto :goto_4

    .line 204
    :cond_6
    invoke-virtual {v12, v4}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 207
    move-result v4

    .line 208
    add-int/lit8 v4, v4, 0x1

    .line 210
    invoke-static {v12, v13, v4}, Ladwg;->a(Landroid/view/ViewGroup;Landroid/graphics/RectF;I)Ljava/util/List;

    .line 213
    move-result-object v4

    .line 214
    invoke-static {v14, v4}, Lbhrc;->v(Ljava/util/Collection;Ljava/lang/Iterable;)V

    .line 217
    invoke-virtual {v12}, Landroid/view/ViewGroup;->getParent()Landroid/view/ViewParent;

    .line 220
    move-result-object v4

    .line 221
    instance-of v8, v4, Landroid/view/ViewGroup;

    .line 223
    if-eqz v8, :cond_7

    .line 225
    check-cast v4, Landroid/view/ViewGroup;

    .line 227
    goto :goto_7

    .line 228
    :cond_7
    const/4 v4, 0x0

    .line 229
    :goto_7
    if-eqz v4, :cond_9

    .line 231
    invoke-virtual {v4}, Landroid/view/ViewGroup;->getClipChildren()Z

    .line 234
    move-result v8

    .line 235
    if-eqz v8, :cond_8

    .line 237
    goto :goto_8

    .line 238
    :cond_8
    move-object/from16 p1, v0

    .line 240
    goto :goto_a

    .line 241
    :cond_9
    :goto_8
    invoke-static {v12}, Ladwa;->a(Landroid/view/View;)Landroid/graphics/RectF;

    .line 244
    move-result-object v8

    .line 245
    move-object/from16 p1, v0

    .line 247
    iget-object v0, v15, Lbhyh;->a:Ljava/lang/Object;

    .line 249
    if-nez v0, :cond_a

    .line 251
    iput-object v8, v15, Lbhyh;->a:Ljava/lang/Object;

    .line 253
    goto :goto_9

    .line 254
    :cond_a
    check-cast v0, Landroid/graphics/RectF;

    .line 256
    invoke-virtual {v0, v8}, Landroid/graphics/RectF;->intersect(Landroid/graphics/RectF;)Z

    .line 259
    move-result v0

    .line 260
    if-nez v0, :cond_b

    .line 262
    new-instance v12, Ladwb;

    .line 264
    const-string v0, "clipped out by parent"

    .line 266
    invoke-direct {v12, v0}, Ladwb;-><init>(Ljava/lang/String;)V

    .line 269
    goto/16 :goto_4

    .line 271
    :cond_b
    :goto_9
    iget-object v0, v15, Lbhyh;->a:Ljava/lang/Object;

    .line 273
    check-cast v0, Landroid/graphics/RectF;

    .line 275
    invoke-static {v13, v0}, Ladvz;->a(Landroid/graphics/RectF;Landroid/graphics/RectF;)Z

    .line 278
    move-result v0

    .line 279
    if-nez v0, :cond_c

    .line 281
    new-instance v12, Ladwb;

    .line 283
    const-string v0, "clipped out"

    .line 285
    invoke-direct {v12, v0}, Ladwb;-><init>(Ljava/lang/String;)V

    .line 288
    goto/16 :goto_4

    .line 290
    :cond_c
    new-instance v0, Ladwe;

    .line 292
    invoke-direct {v0, v15}, Ladwe;-><init>(Lbhyh;)V

    .line 295
    invoke-static {v14, v0}, Lbhrj;->y(Ljava/util/List;Lbhwq;)V

    .line 298
    :goto_a
    if-nez v4, :cond_12

    .line 300
    new-instance v0, Landroid/graphics/Region;

    .line 302
    new-instance v4, Landroid/graphics/Rect;

    .line 304
    invoke-direct {v4}, Landroid/graphics/Rect;-><init>()V

    .line 307
    invoke-virtual {v13, v4}, Landroid/graphics/RectF;->roundOut(Landroid/graphics/Rect;)V

    .line 310
    invoke-direct {v0, v4}, Landroid/graphics/Region;-><init>(Landroid/graphics/Rect;)V

    .line 313
    iget-object v4, v15, Lbhyh;->a:Ljava/lang/Object;

    .line 315
    check-cast v4, Landroid/graphics/RectF;

    .line 317
    if-eqz v4, :cond_d

    .line 319
    new-instance v8, Landroid/graphics/Rect;

    .line 321
    invoke-direct {v8}, Landroid/graphics/Rect;-><init>()V

    .line 324
    invoke-virtual {v4, v8}, Landroid/graphics/RectF;->roundOut(Landroid/graphics/Rect;)V

    .line 327
    sget-object v4, Landroid/graphics/Region$Op;->INTERSECT:Landroid/graphics/Region$Op;

    .line 329
    invoke-virtual {v0, v8, v4}, Landroid/graphics/Region;->op(Landroid/graphics/Rect;Landroid/graphics/Region$Op;)Z

    .line 332
    :cond_d
    invoke-interface {v14}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 335
    move-result-object v4

    .line 336
    :goto_b
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 339
    move-result v8

    .line 340
    if-eqz v8, :cond_e

    .line 342
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 345
    move-result-object v8

    .line 346
    check-cast v8, Lcom/google/android/apps/play/books/educampaign/ui/viewvisibility/RectFWithView;

    .line 348
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 351
    new-instance v12, Landroid/graphics/Rect;

    .line 353
    invoke-direct {v12}, Landroid/graphics/Rect;-><init>()V

    .line 356
    invoke-virtual {v8, v12}, Landroid/graphics/RectF;->roundOut(Landroid/graphics/Rect;)V

    .line 359
    sget-object v8, Landroid/graphics/Region$Op;->DIFFERENCE:Landroid/graphics/Region$Op;

    .line 361
    invoke-virtual {v0, v12, v8}, Landroid/graphics/Region;->op(Landroid/graphics/Rect;Landroid/graphics/Region$Op;)Z

    .line 364
    goto :goto_b

    .line 365
    :cond_e
    new-instance v4, Landroid/graphics/Rect;

    .line 367
    invoke-direct {v4}, Landroid/graphics/Rect;-><init>()V

    .line 370
    new-instance v8, Landroid/graphics/RegionIterator;

    .line 372
    invoke-direct {v8, v0}, Landroid/graphics/RegionIterator;-><init>(Landroid/graphics/Region;)V

    .line 375
    new-instance v0, Ladvy;

    .line 377
    const/4 v12, 0x0

    .line 378
    invoke-direct {v0, v8, v4, v12}, Ladvy;-><init>(Landroid/graphics/RegionIterator;Landroid/graphics/Rect;Lbhtu;)V

    .line 381
    new-instance v4, Lbias;

    .line 383
    invoke-direct {v4, v0}, Lbias;-><init>(Lbhwu;)V

    .line 386
    invoke-interface {v4}, Lbiao;->a()Ljava/util/Iterator;

    .line 389
    move-result-object v0

    .line 390
    const-wide/16 v14, 0x0

    .line 392
    :goto_c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 395
    move-result v4

    .line 396
    if-eqz v4, :cond_f

    .line 398
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 401
    move-result-object v4

    .line 402
    check-cast v4, Landroid/graphics/Rect;

    .line 404
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 407
    invoke-virtual {v4}, Landroid/graphics/Rect;->width()I

    .line 410
    move-result v8

    .line 411
    move-object/from16 p0, v13

    .line 413
    int-to-long v12, v8

    .line 414
    invoke-virtual {v4}, Landroid/graphics/Rect;->height()I

    .line 417
    move-result v4

    .line 418
    move-object/from16 p2, v10

    .line 420
    move-object/from16 p3, v11

    .line 422
    int-to-long v10, v4

    .line 423
    mul-long/2addr v12, v10

    .line 424
    add-long/2addr v14, v12

    .line 425
    move-object/from16 v13, p0

    .line 427
    move-object/from16 v10, p2

    .line 429
    move-object/from16 v11, p3

    .line 431
    const/4 v12, 0x0

    .line 432
    goto :goto_c

    .line 433
    :cond_f
    move-object/from16 p2, v10

    .line 435
    move-object/from16 p3, v11

    .line 437
    move-object/from16 p0, v13

    .line 439
    const-wide/16 v10, 0x64

    .line 441
    mul-long/2addr v14, v10

    .line 442
    new-instance v0, Landroid/graphics/Rect;

    .line 444
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 447
    move-object/from16 v8, p0

    .line 449
    invoke-virtual {v8, v0}, Landroid/graphics/RectF;->roundOut(Landroid/graphics/Rect;)V

    .line 452
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    .line 455
    move-result v4

    .line 456
    int-to-long v12, v4

    .line 457
    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    .line 460
    move-result v0

    .line 461
    int-to-long v10, v0

    .line 462
    mul-long/2addr v12, v10

    .line 463
    div-long/2addr v14, v12

    .line 464
    const-wide/16 v10, 0x64

    .line 466
    invoke-static {v14, v15, v10, v11}, Ljava/lang/Math;->min(JJ)J

    .line 469
    move-result-wide v10

    .line 470
    long-to-int v0, v10

    .line 471
    if-nez v0, :cond_10

    .line 473
    new-instance v12, Ladwb;

    .line 475
    const-string v0, "completely obscured"

    .line 477
    invoke-direct {v12, v0}, Ladwb;-><init>(Ljava/lang/String;)V

    .line 480
    goto :goto_d

    .line 481
    :cond_10
    new-instance v12, Ladwc;

    .line 483
    invoke-direct {v12, v0}, Ladwc;-><init>(I)V

    .line 486
    :goto_d
    instance-of v0, v12, Ladwc;

    .line 488
    if-eqz v0, :cond_11

    .line 490
    check-cast v12, Ladwc;

    .line 492
    iget v0, v12, Ladwc;->a:I

    .line 494
    if-le v0, v9, :cond_11

    .line 496
    move-object/from16 v10, p3

    .line 498
    move/from16 v4, p4

    .line 500
    move v9, v0

    .line 501
    move-object/from16 v0, p1

    .line 503
    goto/16 :goto_2

    .line 505
    :cond_11
    move-object/from16 v0, p1

    .line 507
    move-object/from16 v10, p2

    .line 509
    move/from16 v4, p4

    .line 511
    goto/16 :goto_2

    .line 513
    :cond_12
    move-object/from16 p2, v10

    .line 515
    move-object/from16 p3, v11

    .line 517
    move-object v8, v13

    .line 518
    const/16 v16, 0x0

    .line 520
    invoke-static {v12, v8}, Ladwa;->b(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 523
    iget-object v0, v15, Lbhyh;->a:Ljava/lang/Object;

    .line 525
    check-cast v0, Landroid/graphics/RectF;

    .line 527
    if-eqz v0, :cond_13

    .line 529
    invoke-static {v12, v0}, Ladwa;->b(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 532
    :cond_13
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 535
    move-result-object v0

    .line 536
    :goto_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 539
    move-result v10

    .line 540
    if-eqz v10, :cond_14

    .line 542
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 545
    move-result-object v10

    .line 546
    check-cast v10, Lcom/google/android/apps/play/books/educampaign/ui/viewvisibility/RectFWithView;

    .line 548
    invoke-static {v12, v10}, Ladwa;->b(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 551
    goto :goto_e

    .line 552
    :cond_14
    move-object v0, v12

    .line 553
    move-object v12, v4

    .line 554
    move-object v4, v0

    .line 555
    move-object/from16 v0, p1

    .line 557
    move-object/from16 v10, p2

    .line 559
    move-object/from16 v11, p3

    .line 561
    move-object v13, v8

    .line 562
    goto/16 :goto_6

    .line 564
    :cond_15
    move/from16 p4, v4

    .line 566
    move-object/from16 p2, v10

    .line 568
    if-eqz p2, :cond_18

    .line 570
    if-ge v9, v3, :cond_16

    .line 572
    goto :goto_f

    .line 573
    :cond_16
    return-object p2

    .line 574
    :cond_17
    move/from16 p4, v4

    .line 576
    :cond_18
    :goto_f
    iput-object v7, v1, Ladwi;->a:Ljava/lang/Object;

    .line 578
    iput-object v6, v1, Ladwi;->f:Lj$/time/Duration;

    .line 580
    iput v5, v1, Ladwi;->b:I

    .line 582
    iput v3, v1, Ladwi;->c:I

    .line 584
    move/from16 v0, p4

    .line 586
    iput v0, v1, Ladwi;->e:I

    .line 588
    invoke-static {v6, v1}, Lazrf;->a(Lj$/time/Duration;Lbhtu;)Ljava/lang/Object;

    .line 591
    move-result-object v4

    .line 592
    if-ne v4, v2, :cond_19

    .line 594
    return-object v2

    .line 595
    :cond_19
    move v4, v0

    .line 596
    goto/16 :goto_1
.end method

.method public static synthetic b(Landroid/view/ViewGroup;ILbhtu;)Ljava/lang/Object;
    .locals 2

    .line 1
    const-wide/16 v0, 0xc8

    .line 3
    invoke-static {v0, v1}, Lj$/time/Duration;->ofMillis(J)Lj$/time/Duration;

    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    const/16 v1, 0x5a

    .line 12
    invoke-static {p0, p1, v1, v0, p2}, Ladwj;->a(Landroid/view/ViewGroup;IILj$/time/Duration;Lbhtu;)Ljava/lang/Object;

    .line 15
    move-result-object p0

    .line 16
    return-object p0
.end method
