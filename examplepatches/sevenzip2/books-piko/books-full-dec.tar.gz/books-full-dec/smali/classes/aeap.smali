.class public final Laeap;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Laeaq;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/util/List;

.field private final c:Lbhwq;

.field private final d:Lbhwq;

.field private e:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/util/List;Lbhwq;Lbhwq;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laeap;->a:Ljava/lang/String;

    .line 6
    iput-object p2, p0, Laeap;->b:Ljava/util/List;

    .line 8
    iput-object p3, p0, Laeap;->c:Lbhwq;

    .line 10
    iput-object p4, p0, Laeap;->d:Lbhwq;

    .line 12
    return-void
.end method


# virtual methods
.method public final a(Lbhtu;)Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Laeap;->c:Lbhwq;

    .line 3
    invoke-interface {p0, p1}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final b()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Laeap;->a:Ljava/lang/String;

    .line 3
    return-object p0
.end method

.method public final c()Ljava/util/List;
    .locals 0

    .line 1
    iget-object p0, p0, Laeap;->b:Ljava/util/List;

    .line 3
    return-object p0
.end method

.method public final d()V
    .locals 1

    .line 1
    iget-boolean v0, p0, Laeap;->e:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    const/4 v0, 0x1

    .line 6
    iput-boolean v0, p0, Laeap;->e:Z

    .line 8
    iget-object v0, p0, Laeap;->d:Lbhwq;

    .line 10
    invoke-interface {v0, p0}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    :cond_0
    return-void
.end method
