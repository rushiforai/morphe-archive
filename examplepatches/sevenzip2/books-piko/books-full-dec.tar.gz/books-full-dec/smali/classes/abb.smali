.class public final synthetic Labb;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lads;


# instance fields
.field public final synthetic a:Labl;


# direct methods
.method public synthetic constructor <init>(Labl;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labb;->a:Labl;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 7

    .line 1
    iget-object p0, p0, Labb;->a:Labl;

    .line 3
    invoke-virtual {p0}, Labl;->S()Lmqs;

    .line 6
    move-result-object v0

    .line 7
    const-string v1, "android:support:activity-result"

    .line 9
    invoke-virtual {v0, v1}, Lmqs;->a(Ljava/lang/String;)Landroid/os/Bundle;

    .line 12
    move-result-object v0

    .line 13
    if-eqz v0, :cond_4

    .line 15
    iget-object p0, p0, Labl;->i:Laec;

    .line 17
    const-string v1, "KEY_COMPONENT_ACTIVITY_REGISTERED_RCS"

    .line 19
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getIntegerArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 22
    move-result-object v1

    .line 23
    const-string v2, "KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS"

    .line 25
    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 28
    move-result-object v2

    .line 29
    if-eqz v2, :cond_4

    .line 31
    if-nez v1, :cond_0

    .line 33
    goto :goto_1

    .line 34
    :cond_0
    const-string v3, "KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS"

    .line 36
    invoke-virtual {v0, v3}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 39
    move-result-object v3

    .line 40
    if-eqz v3, :cond_1

    .line 42
    iget-object v4, p0, Laec;->d:Ljava/util/List;

    .line 44
    invoke-interface {v4, v3}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 47
    :cond_1
    const-string v3, "KEY_COMPONENT_ACTIVITY_PENDING_RESULT"

    .line 49
    invoke-virtual {v0, v3}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 52
    move-result-object v0

    .line 53
    if-eqz v0, :cond_2

    .line 55
    iget-object v3, p0, Laec;->g:Landroid/os/Bundle;

    .line 57
    invoke-virtual {v3, v0}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    .line 60
    :cond_2
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 63
    move-result v0

    .line 64
    const/4 v3, 0x0

    .line 65
    :goto_0
    if-ge v3, v0, :cond_4

    .line 67
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 70
    move-result-object v4

    .line 71
    check-cast v4, Ljava/lang/String;

    .line 73
    iget-object v5, p0, Laec;->c:Ljava/util/Map;

    .line 75
    invoke-interface {v5, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 78
    move-result v6

    .line 79
    if-eqz v6, :cond_3

    .line 81
    invoke-interface {v5, v4}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    move-result-object v5

    .line 85
    check-cast v5, Ljava/lang/Integer;

    .line 87
    iget-object v6, p0, Laec;->g:Landroid/os/Bundle;

    .line 89
    invoke-virtual {v6, v4}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    .line 92
    move-result v4

    .line 93
    if-nez v4, :cond_3

    .line 95
    iget-object v4, p0, Laec;->b:Ljava/util/Map;

    .line 97
    invoke-static {v4}, Lbhyk;->b(Ljava/lang/Object;)Ljava/util/Map;

    .line 100
    move-result-object v4

    .line 101
    invoke-interface {v4, v5}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 104
    :cond_3
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 107
    move-result-object v4

    .line 108
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 111
    check-cast v4, Ljava/lang/Number;

    .line 113
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 116
    move-result v4

    .line 117
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 120
    move-result-object v5

    .line 121
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 124
    check-cast v5, Ljava/lang/String;

    .line 126
    invoke-virtual {p0, v4, v5}, Laec;->e(ILjava/lang/String;)V

    .line 129
    add-int/lit8 v3, v3, 0x1

    .line 131
    goto :goto_0

    .line 132
    :cond_4
    :goto_1
    return-void
.end method
