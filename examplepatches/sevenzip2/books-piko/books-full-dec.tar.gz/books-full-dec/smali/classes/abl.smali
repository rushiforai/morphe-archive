.class public Labl;
.super Lgz;
.source "PG"

# interfaces
.implements Lkcm;
.implements Lkfe;
.implements Lkbv;
.implements Lmqw;
.implements Lack;
.implements Lmjl;
.implements Laed;
.implements Ljfp;
.implements Ljfq;
.implements Ljeo;
.implements Ljep;
.implements Ljld;


# instance fields
.field private final a:Lmqv;

.field private b:Lkfd;

.field private final c:Lbhph;

.field private final d:Ljava/util/concurrent/atomic/AtomicInteger;

.field private final e:Ljava/util/concurrent/CopyOnWriteArrayList;

.field public final g:Ladr;

.field public final h:Ljlf;

.field public final i:Laec;

.field public final j:Ljava/util/concurrent/CopyOnWriteArrayList;

.field private final jh:Ljava/util/concurrent/CopyOnWriteArrayList;

.field public final k:Ljava/util/concurrent/CopyOnWriteArrayList;

.field public final l:Ljava/util/concurrent/CopyOnWriteArrayList;

.field public final m:Ljava/util/concurrent/CopyOnWriteArrayList;

.field public final n:Labh;

.field private final p:Ljava/util/concurrent/CopyOnWriteArrayList;

.field private q:Z

.field private r:Z

.field private final s:Lbhph;

.field private final t:Lbhph;

.field private final u:Lbhph;

.field private final v:Lbhph;


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Lgz;-><init>()V

    .line 4
    new-instance v0, Ladr;

    .line 6
    invoke-direct {v0}, Ladr;-><init>()V

    .line 9
    iput-object v0, p0, Labl;->g:Ladr;

    .line 11
    new-instance v0, Ljlf;

    .line 13
    new-instance v1, Laar;

    .line 15
    invoke-direct {v1, p0}, Laar;-><init>(Labl;)V

    .line 18
    invoke-direct {v0, v1}, Ljlf;-><init>(Ljava/lang/Runnable;)V

    .line 21
    iput-object v0, p0, Labl;->h:Ljlf;

    .line 23
    invoke-static {p0}, Lmqu;->a(Lmqw;)Lmqv;

    .line 26
    move-result-object v0

    .line 27
    iput-object v0, p0, Labl;->a:Lmqv;

    .line 29
    new-instance v1, Labh;

    .line 31
    invoke-direct {v1, p0}, Labh;-><init>(Labl;)V

    .line 34
    iput-object v1, p0, Labl;->n:Labh;

    .line 36
    new-instance v1, Laav;

    .line 38
    invoke-direct {v1, p0}, Laav;-><init>(Labl;)V

    .line 41
    new-instance v2, Lbhps;

    .line 43
    invoke-direct {v2, v1}, Lbhps;-><init>(Lbhwf;)V

    .line 46
    iput-object v2, p0, Labl;->c:Lbhph;

    .line 48
    new-instance v1, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 50
    invoke-direct {v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 53
    iput-object v1, p0, Labl;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 55
    new-instance v1, Labk;

    .line 57
    invoke-direct {v1, p0}, Labk;-><init>(Labl;)V

    .line 60
    iput-object v1, p0, Labl;->i:Laec;

    .line 62
    new-instance v1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 64
    invoke-direct {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 67
    iput-object v1, p0, Labl;->e:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 69
    new-instance v1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 71
    invoke-direct {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 74
    iput-object v1, p0, Labl;->j:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 76
    new-instance v1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 78
    invoke-direct {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 81
    iput-object v1, p0, Labl;->k:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 83
    new-instance v1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 85
    invoke-direct {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 88
    iput-object v1, p0, Labl;->l:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 90
    new-instance v1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 92
    invoke-direct {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 95
    iput-object v1, p0, Labl;->m:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 97
    new-instance v1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 99
    invoke-direct {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 102
    iput-object v1, p0, Labl;->jh:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 104
    new-instance v1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 106
    invoke-direct {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 109
    iput-object v1, p0, Labl;->p:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 111
    new-instance v1, Laaw;

    .line 113
    invoke-direct {v1, p0}, Laaw;-><init>(Labl;)V

    .line 116
    new-instance v2, Lbhps;

    .line 118
    invoke-direct {v2, v1}, Lbhps;-><init>(Lbhwf;)V

    .line 121
    iput-object v2, p0, Labl;->s:Lbhph;

    .line 123
    new-instance v1, Laax;

    .line 125
    invoke-direct {v1, p0}, Laax;-><init>(Labl;)V

    .line 128
    new-instance v2, Lbhps;

    .line 130
    invoke-direct {v2, v1}, Lbhps;-><init>(Lbhwf;)V

    .line 133
    iput-object v2, p0, Labl;->t:Lbhph;

    .line 135
    iget-object v1, p0, Lgz;->f:Lkct;

    .line 137
    if-eqz v1, :cond_0

    .line 139
    new-instance v2, Laay;

    .line 141
    invoke-direct {v2, p0}, Laay;-><init>(Labl;)V

    .line 144
    invoke-virtual {v1, v2}, Lkcb;->c(Lkcl;)V

    .line 147
    iget-object v1, p0, Lgz;->f:Lkct;

    .line 149
    new-instance v2, Laaz;

    .line 151
    invoke-direct {v2, p0}, Laaz;-><init>(Labl;)V

    .line 154
    invoke-virtual {v1, v2}, Lkcb;->c(Lkcl;)V

    .line 157
    iget-object v1, p0, Lgz;->f:Lkct;

    .line 159
    new-instance v2, Labe;

    .line 161
    invoke-direct {v2, p0}, Labe;-><init>(Labl;)V

    .line 164
    invoke-virtual {v1, v2}, Lkcb;->c(Lkcl;)V

    .line 167
    invoke-virtual {v0}, Lmqv;->b()V

    .line 170
    invoke-static {p0}, Lkei;->b(Lmqw;)V

    .line 173
    invoke-virtual {p0}, Labl;->S()Lmqs;

    .line 176
    move-result-object v0

    .line 177
    new-instance v1, Laba;

    .line 179
    invoke-direct {v1, p0}, Laba;-><init>(Labl;)V

    .line 182
    const-string v2, "android:support:activity-result"

    .line 184
    invoke-virtual {v0, v2, v1}, Lmqs;->c(Ljava/lang/String;Lmqr;)V

    .line 187
    new-instance v0, Labb;

    .line 189
    invoke-direct {v0, p0}, Labb;-><init>(Labl;)V

    .line 192
    invoke-virtual {p0, v0}, Labl;->r(Lads;)V

    .line 195
    new-instance v0, Labc;

    .line 197
    invoke-direct {v0, p0}, Labc;-><init>(Labl;)V

    .line 200
    new-instance v1, Lbhps;

    .line 202
    invoke-direct {v1, v0}, Lbhps;-><init>(Lbhwf;)V

    .line 205
    iput-object v1, p0, Labl;->u:Lbhph;

    .line 207
    new-instance v0, Labd;

    .line 209
    invoke-direct {v0, p0}, Labd;-><init>(Labl;)V

    .line 212
    new-instance v1, Lbhps;

    .line 214
    invoke-direct {v1, v0}, Lbhps;-><init>(Lbhwf;)V

    .line 217
    iput-object v1, p0, Labl;->v:Lbhph;

    .line 219
    return-void

    .line 220
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 222
    const-string v0, "getLifecycle() returned null in ComponentActivity\'s constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization."

    .line 224
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 227
    throw p0
.end method

.method public static final u(Labl;)V
    .locals 2

    .line 1
    :try_start_0
    invoke-super {p0}, Lgz;->onBackPressed()V

    .line 4
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 5
    :catch_0
    move-exception p0

    .line 6
    invoke-virtual {p0}, Ljava/lang/NullPointerException;->getMessage()Ljava/lang/String;

    .line 9
    move-result-object v0

    .line 10
    const-string v1, "Attempt to invoke virtual method \'android.os.Handler android.app.FragmentHostCallback.getHandler()\' on a null object reference"

    .line 12
    invoke-static {v0, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    throw p0

    .line 20
    :catch_1
    move-exception p0

    .line 21
    invoke-virtual {p0}, Ljava/lang/IllegalStateException;->getMessage()Ljava/lang/String;

    .line 24
    move-result-object v0

    .line 25
    const-string v1, "Can not perform this action after onSaveInstanceState"

    .line 27
    invoke-static {v0, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_1

    .line 33
    :goto_0
    return-void

    .line 34
    :cond_1
    throw p0
.end method


# virtual methods
.method public final P()Lkez;
    .locals 0

    .line 1
    iget-object p0, p0, Labl;->u:Lbhph;

    .line 3
    invoke-interface {p0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lkez;

    .line 9
    return-object p0
.end method

.method public final Q()Lkfd;
    .locals 1

    .line 1
    invoke-virtual {p0}, Labl;->getApplication()Landroid/app/Application;

    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-virtual {p0}, Labl;->s()V

    .line 10
    iget-object p0, p0, Labl;->b:Lkfd;

    .line 12
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    return-object p0

    .line 16
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 18
    const-string v0, "Your activity is not yet attached to the Application instance. You can\'t request ViewModel before onCreate call."

    .line 20
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 23
    throw p0
.end method

.method public final R()Lkgj;
    .locals 3

    .line 1
    new-instance v0, Lkgl;

    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lkgl;-><init>([B)V

    .line 7
    invoke-virtual {p0}, Labl;->getApplication()Landroid/app/Application;

    .line 10
    move-result-object v1

    .line 11
    if-eqz v1, :cond_0

    .line 13
    sget-object v1, Lkex;->b:Lkgi;

    .line 15
    invoke-virtual {p0}, Labl;->getApplication()Landroid/app/Application;

    .line 18
    move-result-object v2

    .line 19
    invoke-virtual {v0, v1, v2}, Lkgl;->b(Lkgi;Ljava/lang/Object;)V

    .line 22
    :cond_0
    sget-object v1, Lkei;->a:Lkgi;

    .line 24
    invoke-virtual {v0, v1, p0}, Lkgl;->b(Lkgi;Ljava/lang/Object;)V

    .line 27
    sget-object v1, Lkei;->b:Lkgi;

    .line 29
    invoke-virtual {v0, v1, p0}, Lkgl;->b(Lkgi;Ljava/lang/Object;)V

    .line 32
    invoke-virtual {p0}, Labl;->fP()Landroid/os/Bundle;

    .line 35
    move-result-object p0

    .line 36
    if-eqz p0, :cond_1

    .line 38
    sget-object v1, Lkei;->c:Lkgi;

    .line 40
    invoke-virtual {v0, v1, p0}, Lkgl;->b(Lkgi;Ljava/lang/Object;)V

    .line 43
    :cond_1
    return-object v0
.end method

.method public final S()Lmqs;
    .locals 0

    .line 1
    iget-object p0, p0, Labl;->a:Lmqv;

    .line 3
    invoke-virtual {p0}, Lmqv;->a()Lmqs;

    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Labl;->t()V

    .line 4
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    iget-object v1, p0, Labl;->n:Labh;

    .line 17
    invoke-virtual {v1, v0}, Labh;->a(Landroid/view/View;)V

    .line 20
    invoke-super {p0, p1, p2}, Lgz;->addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 23
    return-void
.end method

.method public final c()Laci;
    .locals 0

    .line 1
    iget-object p0, p0, Labl;->v:Lbhph;

    .line 3
    invoke-interface {p0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Laci;

    .line 9
    return-object p0
.end method

.method public final e(Ljkb;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    iget-object p0, p0, Labl;->e:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 6
    invoke-virtual {p0, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 9
    return-void
.end method

.method public final fP()Landroid/os/Bundle;
    .locals 1

    .line 1
    iget-object v0, p0, Labl;->t:Lbhph;

    .line 3
    invoke-interface {v0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/lang/Boolean;

    .line 9
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    invoke-virtual {p0}, Labl;->getIntent()Landroid/content/Intent;

    .line 19
    move-result-object p0

    .line 20
    if-eqz p0, :cond_1

    .line 22
    invoke-virtual {p0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 25
    move-result-object p0

    .line 26
    return-object p0

    .line 27
    :cond_1
    :goto_0
    const/4 p0, 0x0

    .line 28
    return-object p0
.end method

.method public final fQ()Labz;
    .locals 0

    .line 1
    iget-object p0, p0, Labl;->c:Lbhph;

    .line 3
    invoke-interface {p0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Labz;

    .line 9
    return-object p0
.end method

.method public final fR(Laeg;Ladu;)Ladv;
    .locals 4

    .line 1
    iget-object v0, p0, Labl;->i:Laec;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    iget-object v1, p0, Labl;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 8
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 11
    move-result v1

    .line 12
    new-instance v2, Ljava/lang/StringBuilder;

    .line 14
    const-string v3, "activity_rq#"

    .line 16
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 19
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 22
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 25
    move-result-object v1

    .line 26
    invoke-virtual {v0, v1, p0, p1, p2}, Laec;->c(Ljava/lang/String;Lkcm;Laeg;Ladu;)Ladv;

    .line 29
    move-result-object p0

    .line 30
    return-object p0
.end method

.method public final fS()Laec;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    throw p0
.end method

.method public final fT(Laci;)V
    .locals 1

    .line 1
    new-instance v0, Laau;

    .line 3
    invoke-direct {v0, p1, p0}, Laau;-><init>(Laci;Labl;)V

    .line 6
    iget-object p0, p0, Lgz;->f:Lkct;

    .line 8
    invoke-virtual {p0, v0}, Lkcb;->c(Lkcl;)V

    .line 11
    return-void
.end method

.method public final g(Ljkb;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    iget-object p0, p0, Labl;->e:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 6
    invoke-virtual {p0, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    .line 9
    return-void
.end method

.method public final getNavigationEventDispatcher()Lmjj;
    .locals 0

    .line 1
    invoke-virtual {p0}, Labl;->c()Laci;

    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Laci;->b()Lmjj;

    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 1

    .line 1
    iget-object v0, p0, Labl;->i:Laec;

    .line 3
    invoke-virtual {v0, p1, p2, p3}, Laec;->g(IILandroid/content/Intent;)Z

    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 9
    invoke-super {p0, p1, p2, p3}, Lgz;->onActivityResult(IILandroid/content/Intent;)V

    .line 12
    :cond_0
    return-void
.end method

.method public onBackPressed()V
    .locals 0

    .line 1
    iget-object p0, p0, Labl;->s:Lbhph;

    .line 3
    invoke-interface {p0}, Lbhph;->b()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lmjh;

    .line 9
    invoke-virtual {p0}, Lmjq;->b()V

    .line 12
    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-super {p0, p1}, Lgz;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 7
    iget-object p0, p0, Labl;->e:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 9
    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 12
    move-result-object p0

    .line 13
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_0

    .line 22
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 25
    move-result-object v0

    .line 26
    check-cast v0, Ljkb;

    .line 28
    invoke-interface {v0, p1}, Ljkb;->accept(Ljava/lang/Object;)V

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    .line 1
    iget-object v0, p0, Labl;->a:Lmqv;

    .line 3
    invoke-virtual {v0, p1}, Lmqv;->c(Landroid/os/Bundle;)V

    .line 6
    iget-object v0, p0, Labl;->g:Ladr;

    .line 8
    invoke-virtual {v0, p0}, Ladr;->b(Landroid/content/Context;)V

    .line 11
    invoke-super {p0, p1}, Lgz;->onCreate(Landroid/os/Bundle;)V

    .line 14
    sget p1, Lkdw;->a:I

    .line 16
    invoke-static {p0}, Lkdt;->b(Landroid/app/Activity;)V

    .line 19
    invoke-virtual {p0}, Labl;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 22
    move-result-object p0

    .line 23
    const-string p1, "android.software.picture_in_picture"

    .line 25
    invoke-virtual {p0, p1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 28
    return-void
.end method

.method public final onCreatePanelMenu(ILandroid/view/Menu;)Z
    .locals 0

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    if-nez p1, :cond_0

    .line 6
    const/4 p1, 0x0

    .line 7
    invoke-super {p0, p1, p2}, Lgz;->onCreatePanelMenu(ILandroid/view/Menu;)Z

    .line 10
    iget-object p1, p0, Labl;->h:Ljlf;

    .line 12
    invoke-virtual {p0}, Labl;->getMenuInflater()Landroid/view/MenuInflater;

    .line 15
    move-result-object p0

    .line 16
    invoke-virtual {p1, p2, p0}, Ljlf;->a(Landroid/view/Menu;Landroid/view/MenuInflater;)V

    .line 19
    :cond_0
    const/4 p0, 0x1

    .line 20
    return p0
.end method

.method public onMenuItemSelected(ILandroid/view/MenuItem;)Z
    .locals 1

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-super {p0, p1, p2}, Lgz;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 10
    const/4 p0, 0x1

    .line 11
    return p0

    .line 12
    :cond_0
    if-nez p1, :cond_1

    .line 14
    iget-object p0, p0, Labl;->h:Ljlf;

    .line 16
    invoke-virtual {p0, p2}, Ljlf;->c(Landroid/view/MenuItem;)Z

    .line 19
    move-result p0

    .line 20
    return p0

    .line 21
    :cond_1
    const/4 p0, 0x0

    .line 22
    return p0
.end method

.method public onMultiWindowModeChanged(Z)V
    .locals 2

    .line 48
    iget-boolean v0, p0, Labl;->q:Z

    if-eqz v0, :cond_0

    goto :goto_1

    :cond_0
    iget-object p0, p0, Labl;->l:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    .line 49
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljkb;

    new-instance v1, Ljcv;

    invoke-direct {v1, p1}, Ljcv;-><init>(Z)V

    .line 51
    invoke-interface {v0, v1}, Ljkb;->accept(Ljava/lang/Object;)V

    goto :goto_0

    :cond_1
    :goto_1
    return-void
.end method

.method public final onMultiWindowModeChanged(ZLandroid/content/res/Configuration;)V
    .locals 1

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Labl;->q:Z

    .line 7
    const/4 v0, 0x0

    .line 8
    :try_start_0
    invoke-super {p0, p1, p2}, Lgz;->onMultiWindowModeChanged(ZLandroid/content/res/Configuration;)V

    .line 11
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iput-boolean v0, p0, Labl;->q:Z

    .line 13
    iget-object p0, p0, Labl;->l:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 15
    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 18
    move-result-object p0

    .line 19
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 25
    move-result p2

    .line 26
    if-eqz p2, :cond_0

    .line 28
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 31
    move-result-object p2

    .line 32
    check-cast p2, Ljkb;

    .line 34
    new-instance v0, Ljcv;

    .line 36
    invoke-direct {v0, p1}, Ljcv;-><init>(Z)V

    .line 39
    invoke-interface {p2, v0}, Ljkb;->accept(Ljava/lang/Object;)V

    .line 42
    goto :goto_0

    .line 43
    :cond_0
    return-void

    .line 44
    :catchall_0
    move-exception p1

    .line 45
    iput-boolean v0, p0, Labl;->q:Z

    .line 47
    throw p1
.end method

.method protected onNewIntent(Landroid/content/Intent;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-super {p0, p1}, Lgz;->onNewIntent(Landroid/content/Intent;)V

    .line 7
    iget-object p0, p0, Labl;->k:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 9
    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 12
    move-result-object p0

    .line 13
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_0

    .line 22
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 25
    move-result-object v0

    .line 26
    check-cast v0, Ljkb;

    .line 28
    invoke-interface {v0, p1}, Ljkb;->accept(Ljava/lang/Object;)V

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    return-void
.end method

.method public final onPanelClosed(ILandroid/view/Menu;)V
    .locals 2

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    iget-object v0, p0, Labl;->h:Ljlf;

    .line 6
    iget-object v0, v0, Ljlf;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 8
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 11
    move-result-object v0

    .line 12
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_0

    .line 18
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Lex;

    .line 24
    iget-object v1, v1, Lex;->a:Lfm;

    .line 26
    invoke-virtual {v1, p2}, Lfm;->z(Landroid/view/Menu;)V

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    invoke-super {p0, p1, p2}, Lgz;->onPanelClosed(ILandroid/view/Menu;)V

    .line 33
    return-void
.end method

.method public final onPictureInPictureModeChanged(Z)V
    .locals 2

    .line 48
    iget-boolean v0, p0, Labl;->r:Z

    if-eqz v0, :cond_0

    goto :goto_1

    :cond_0
    iget-object p0, p0, Labl;->m:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    .line 49
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljkb;

    new-instance v1, Ljet;

    invoke-direct {v1, p1}, Ljet;-><init>(Z)V

    .line 51
    invoke-interface {v0, v1}, Ljkb;->accept(Ljava/lang/Object;)V

    goto :goto_0

    :cond_1
    :goto_1
    return-void
.end method

.method public final onPictureInPictureModeChanged(ZLandroid/content/res/Configuration;)V
    .locals 1

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Labl;->r:Z

    .line 7
    const/4 v0, 0x0

    .line 8
    :try_start_0
    invoke-super {p0, p1, p2}, Lgz;->onPictureInPictureModeChanged(ZLandroid/content/res/Configuration;)V

    .line 11
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iput-boolean v0, p0, Labl;->r:Z

    .line 13
    iget-object p0, p0, Labl;->m:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 15
    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 18
    move-result-object p0

    .line 19
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 25
    move-result p2

    .line 26
    if-eqz p2, :cond_0

    .line 28
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 31
    move-result-object p2

    .line 32
    check-cast p2, Ljkb;

    .line 34
    new-instance v0, Ljet;

    .line 36
    invoke-direct {v0, p1}, Ljet;-><init>(Z)V

    .line 39
    invoke-interface {p2, v0}, Ljkb;->accept(Ljava/lang/Object;)V

    .line 42
    goto :goto_0

    .line 43
    :cond_0
    return-void

    .line 44
    :catchall_0
    move-exception p1

    .line 45
    iput-boolean v0, p0, Labl;->r:Z

    .line 47
    throw p1
.end method

.method public final onPictureInPictureUiStateChanged(Landroid/app/PictureInPictureUiState;)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-super {p0, p1}, Lgz;->onPictureInPictureUiStateChanged(Landroid/app/PictureInPictureUiState;)V

    .line 7
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    const/16 v1, 0x23

    .line 11
    if-lt v0, v1, :cond_0

    .line 13
    new-instance v0, Ljeu;

    .line 15
    invoke-static {p1}, Labl$$ExternalSyntheticApiModelOutline0;->m(Landroid/app/PictureInPictureUiState;)Z

    .line 18
    invoke-static {p1}, Labl$$ExternalSyntheticApiModelOutline1;->m(Landroid/app/PictureInPictureUiState;)Z

    .line 21
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 24
    goto :goto_0

    .line 25
    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 27
    const/16 v1, 0x1f

    .line 29
    if-lt v0, v1, :cond_1

    .line 31
    new-instance v0, Ljeu;

    .line 33
    invoke-static {p1}, Labl$$ExternalSyntheticApiModelOutline0;->m(Landroid/app/PictureInPictureUiState;)Z

    .line 36
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 39
    goto :goto_0

    .line 40
    :cond_1
    new-instance v0, Ljeu;

    .line 42
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 45
    :goto_0
    iget-object p0, p0, Labl;->jh:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 47
    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 50
    move-result-object p0

    .line 51
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 54
    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 57
    move-result p1

    .line 58
    if-eqz p1, :cond_2

    .line 60
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 63
    move-result-object p1

    .line 64
    check-cast p1, Ljkb;

    .line 66
    invoke-interface {p1, v0}, Ljkb;->accept(Ljava/lang/Object;)V

    .line 69
    goto :goto_1

    .line 70
    :cond_2
    return-void
.end method

.method public final onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z
    .locals 0

    .line 1
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    if-nez p1, :cond_0

    .line 6
    const/4 p1, 0x0

    .line 7
    invoke-super {p0, p1, p2, p3}, Lgz;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z

    .line 10
    iget-object p0, p0, Labl;->h:Ljlf;

    .line 12
    invoke-virtual {p0, p3}, Ljlf;->b(Landroid/view/Menu;)V

    .line 15
    :cond_0
    const/4 p0, 0x1

    .line 16
    return p0
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 3

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    new-instance v0, Landroid/content/Intent;

    .line 9
    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 12
    const-string v1, "androidx.activity.result.contract.extra.PERMISSIONS"

    .line 14
    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    .line 17
    move-result-object v0

    .line 18
    const-string v1, "androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS"

    .line 20
    invoke-virtual {v0, v1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[I)Landroid/content/Intent;

    .line 23
    move-result-object v0

    .line 24
    iget-object v1, p0, Labl;->i:Laec;

    .line 26
    const/4 v2, -0x1

    .line 27
    invoke-virtual {v1, p1, v2, v0}, Laec;->g(IILandroid/content/Intent;)Z

    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_0

    .line 33
    invoke-super {p0, p1, p2, p3}, Lgz;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    .line 36
    :cond_0
    return-void
.end method

.method public final onRetainNonConfigurationInstance()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Labl;->b:Lkfd;

    .line 3
    if-nez v0, :cond_0

    .line 5
    invoke-virtual {p0}, Labl;->getLastNonConfigurationInstance()Ljava/lang/Object;

    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Labf;

    .line 11
    if-eqz p0, :cond_0

    .line 13
    iget-object v0, p0, Labf;->a:Lkfd;

    .line 15
    :cond_0
    if-nez v0, :cond_1

    .line 17
    const/4 p0, 0x0

    .line 18
    return-object p0

    .line 19
    :cond_1
    new-instance p0, Labf;

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    iput-object v0, p0, Labf;->a:Lkfd;

    .line 26
    return-object p0
.end method

.method protected onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    iget-object v0, p0, Lgz;->f:Lkct;

    .line 6
    instance-of v1, v0, Lkct;

    .line 8
    if-eqz v1, :cond_0

    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    sget-object v1, Lkbz;->c:Lkbz;

    .line 15
    invoke-virtual {v0, v1}, Lkct;->f(Lkbz;)V

    .line 18
    :cond_0
    invoke-super {p0, p1}, Lgz;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 21
    iget-object p0, p0, Labl;->a:Lmqv;

    .line 23
    invoke-virtual {p0, p1}, Lmqv;->d(Landroid/os/Bundle;)V

    .line 26
    return-void
.end method

.method public final onTrimMemory(I)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Lgz;->onTrimMemory(I)V

    .line 4
    iget-object p0, p0, Labl;->j:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 6
    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 9
    move-result-object p0

    .line 10
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 19
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Ljkb;

    .line 25
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 28
    move-result-object v1

    .line 29
    invoke-interface {v0, v1}, Ljkb;->accept(Ljava/lang/Object;)V

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    return-void
.end method

.method protected final onUserLeaveHint()V
    .locals 1

    .line 1
    invoke-super {p0}, Lgz;->onUserLeaveHint()V

    .line 4
    iget-object p0, p0, Labl;->p:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 6
    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 9
    move-result-object p0

    .line 10
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 19
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Ljava/lang/Runnable;

    .line 25
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    return-void
.end method

.method public final r(Lads;)V
    .locals 1

    .line 1
    iget-object p0, p0, Labl;->g:Ladr;

    .line 3
    iget-object v0, p0, Ladr;->b:Landroid/content/Context;

    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-interface {p1}, Lads;->a()V

    .line 10
    :cond_0
    iget-object p0, p0, Ladr;->a:Ljava/util/Set;

    .line 12
    invoke-interface {p0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 15
    return-void
.end method

.method public final reportFullyDrawn()V
    .locals 3

    .line 1
    :try_start_0
    invoke-static {}, Lmua;->b()Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    const-string v0, "reportFullyDrawn() for ComponentActivity"

    .line 9
    invoke-static {v0}, Lmua;->a(Ljava/lang/String;)V

    .line 12
    :cond_0
    invoke-super {p0}, Lgz;->reportFullyDrawn()V

    .line 15
    invoke-virtual {p0}, Labl;->fQ()Labz;

    .line 18
    move-result-object p0

    .line 19
    iget-object v0, p0, Labz;->a:Ljava/lang/Object;

    .line 21
    monitor-enter v0

    .line 22
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v1, 0x1

    .line 23
    :try_start_1
    iput-boolean v1, p0, Labz;->b:Z

    .line 25
    iget-object p0, p0, Labz;->c:Ljava/util/List;

    .line 27
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 30
    move-result-object v1

    .line 31
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 34
    move-result v2

    .line 35
    if-eqz v2, :cond_1

    .line 37
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 40
    move-result-object v2

    .line 41
    check-cast v2, Lbhwf;

    .line 43
    invoke-interface {v2}, Lbhwf;->a()Ljava/lang/Object;

    .line 46
    goto :goto_0

    .line 47
    :cond_1
    invoke-interface {p0}, Ljava/util/List;->clear()V

    .line 50
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    monitor-exit v0

    .line 51
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 54
    return-void

    .line 55
    :catchall_0
    move-exception p0

    .line 56
    :try_start_3
    monitor-exit v0

    .line 57
    throw p0

    .line 58
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :catchall_1
    move-exception p0

    .line 59
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 62
    throw p0
.end method

.method public final s()V
    .locals 1

    .line 1
    iget-object v0, p0, Labl;->b:Lkfd;

    .line 3
    if-nez v0, :cond_1

    .line 5
    invoke-virtual {p0}, Labl;->getLastNonConfigurationInstance()Ljava/lang/Object;

    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Labf;

    .line 11
    if-eqz v0, :cond_0

    .line 13
    iget-object v0, v0, Labf;->a:Lkfd;

    .line 15
    iput-object v0, p0, Labl;->b:Lkfd;

    .line 17
    :cond_0
    iget-object v0, p0, Labl;->b:Lkfd;

    .line 19
    if-nez v0, :cond_1

    .line 21
    new-instance v0, Lkfd;

    .line 23
    invoke-direct {v0}, Lkfd;-><init>()V

    .line 26
    iput-object v0, p0, Labl;->b:Lkfd;

    .line 28
    :cond_1
    return-void
.end method

.method public setContentView(I)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Labl;->t()V

    .line 4
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    iget-object v1, p0, Labl;->n:Labh;

    .line 17
    invoke-virtual {v1, v0}, Labh;->a(Landroid/view/View;)V

    .line 20
    invoke-super {p0, p1}, Lgz;->setContentView(I)V

    .line 23
    return-void
.end method

.method public setContentView(Landroid/view/View;)V
    .locals 2

    .line 24
    invoke-virtual {p0}, Labl;->t()V

    .line 25
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    .line 26
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Labl;->n:Labh;

    .line 27
    invoke-virtual {v1, v0}, Labh;->a(Landroid/view/View;)V

    .line 28
    invoke-super {p0, p1}, Lgz;->setContentView(Landroid/view/View;)V

    return-void
.end method

.method public setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .locals 2

    .line 29
    invoke-virtual {p0}, Labl;->t()V

    .line 30
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    .line 31
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Labl;->n:Labh;

    .line 32
    invoke-virtual {v1, v0}, Labh;->a(Landroid/view/View;)V

    .line 33
    invoke-super {p0, p1, p2}, Lgz;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public final startActivityForResult(Landroid/content/Intent;I)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-super {p0, p1, p2}, Lgz;->startActivityForResult(Landroid/content/Intent;I)V

    .line 7
    return-void
.end method

.method public final startActivityForResult(Landroid/content/Intent;ILandroid/os/Bundle;)V
    .locals 0

    .line 8
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    invoke-super {p0, p1, p2, p3}, Lgz;->startActivityForResult(Landroid/content/Intent;ILandroid/os/Bundle;)V

    return-void
.end method

.method public final startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;III)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-super/range {p0 .. p6}, Lgz;->startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;III)V

    .line 7
    return-void
.end method

.method public final startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V
    .locals 0

    .line 8
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    invoke-super/range {p0 .. p7}, Lgz;->startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V

    return-void
.end method

.method public final t()V
    .locals 2

    .line 1
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    invoke-static {v0, p0}, Lkfg;->b(Landroid/view/View;Lkcm;)V

    .line 15
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    invoke-static {v0, p0}, Lkfh;->b(Landroid/view/View;Lkfe;)V

    .line 29
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    .line 32
    move-result-object v0

    .line 33
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 36
    move-result-object v0

    .line 37
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    invoke-static {v0, p0}, Lmqy;->b(Landroid/view/View;Lmqw;)V

    .line 43
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    .line 46
    move-result-object v0

    .line 47
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 50
    move-result-object v0

    .line 51
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 54
    const v1, 0x7f0a07aa

    .line 57
    invoke-virtual {v0, v1, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 60
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    .line 63
    move-result-object v0

    .line 64
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 67
    move-result-object v0

    .line 68
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 71
    const v1, 0x7f0a05f9

    .line 74
    invoke-virtual {v0, v1, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 77
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    .line 80
    move-result-object v0

    .line 81
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 84
    move-result-object v0

    .line 85
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 88
    const v1, 0x7f0a07a9

    .line 91
    invoke-virtual {v0, v1, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 94
    return-void
.end method
