.class public final Labkr;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labkr;->a:Lbeye;

    .line 6
    iput-object p2, p0, Labkr;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Labkr;->a:Lbeye;

    .line 3
    check-cast v0, Labpx;

    .line 5
    invoke-virtual {v0}, Labpx;->a()Labpw;

    .line 8
    move-result-object v0

    .line 9
    iget-object p0, p0, Labkr;->b:Lbeye;

    .line 11
    check-cast p0, Labna;

    .line 13
    invoke-virtual {p0}, Labna;->a()Labmz;

    .line 16
    move-result-object p0

    .line 17
    new-instance v1, Labkq;

    .line 19
    invoke-direct {v1, v0, p0}, Labkq;-><init>(Labpw;Labmz;)V

    .line 22
    return-object v1
.end method
