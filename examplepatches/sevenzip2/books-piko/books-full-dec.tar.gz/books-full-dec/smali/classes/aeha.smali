.class public final synthetic Laeha;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwq;


# instance fields
.field public final synthetic a:Lbhyc;

.field public final synthetic b:Lbhwq;


# direct methods
.method public synthetic constructor <init>(Lbhyc;Lbhwq;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laeha;->a:Lbhyc;

    .line 6
    iput-object p2, p0, Laeha;->b:Lbhwq;

    .line 8
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Laeha;->b:Lbhwq;

    .line 3
    iget-object p0, p0, Laeha;->a:Lbhyc;

    .line 5
    iget-boolean v1, p0, Lbhyc;->a:Z

    .line 7
    invoke-interface {v0, p1}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    move-result-object p1

    .line 11
    check-cast p1, Ljava/lang/Boolean;

    .line 13
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 16
    move-result p1

    .line 17
    iput-boolean p1, p0, Lbhyc;->a:Z

    .line 19
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 22
    move-result-object p0

    .line 23
    return-object p0
.end method
