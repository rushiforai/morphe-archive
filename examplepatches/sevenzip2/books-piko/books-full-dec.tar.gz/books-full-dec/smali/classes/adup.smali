.class final Ladup;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:I

.field final synthetic b:Ljss;

.field final synthetic c:Ladtd;


# direct methods
.method public constructor <init>(Ljss;Ladtd;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ladup;->b:Ljss;

    .line 3
    iput-object p2, p0, Ladup;->c:Ladtd;

    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, Lbhuu;-><init>(ILbhtu;)V

    .line 9
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Ladup;

    .line 13
    invoke-virtual {p0, p1}, Ladup;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Ladup;->a:I

    .line 5
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 8
    if-eqz v1, :cond_0

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object p1, p0, Ladup;->b:Ljss;

    .line 13
    iget-object v1, p0, Ladup;->c:Ladtd;

    .line 15
    new-instance v2, Laduo;

    .line 17
    const/4 v3, 0x0

    .line 18
    invoke-direct {v2, v1, v3}, Laduo;-><init>(Ladtd;Lbhtu;)V

    .line 21
    const/4 v1, 0x1

    .line 22
    iput v1, p0, Ladup;->a:I

    .line 24
    invoke-interface {p1, v2, p0}, Ljss;->a(Lbhwu;Lbhtu;)Ljava/lang/Object;

    .line 27
    move-result-object p0

    .line 28
    if-ne p0, v0, :cond_1

    .line 30
    return-object v0

    .line 31
    :cond_1
    :goto_0
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 33
    return-object p0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 1

    .line 1
    new-instance p1, Ladup;

    .line 3
    iget-object v0, p0, Ladup;->b:Ljss;

    .line 5
    iget-object p0, p0, Ladup;->c:Ladtd;

    .line 7
    invoke-direct {p1, v0, p0, p2}, Ladup;-><init>(Ljss;Ladtd;Lbhtu;)V

    .line 10
    return-object p1
.end method
