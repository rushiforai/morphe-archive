.class public final Lacvj;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacvj;->a:Lbeye;

    .line 6
    iput-object p2, p0, Lacvj;->b:Lbeye;

    .line 8
    iput-object p3, p0, Lacvj;->c:Lbeye;

    .line 10
    iput-object p4, p0, Lacvj;->d:Lbeye;

    .line 12
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, Lacvj;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Lacvj;->b:Lbeye;

    .line 11
    check-cast v1, Lacxj;

    .line 13
    invoke-virtual {v1}, Lacxj;->a()Lacwy;

    .line 16
    move-result-object v1

    .line 17
    iget-object v2, p0, Lacvj;->c:Lbeye;

    .line 19
    check-cast v2, Ladgk;

    .line 21
    invoke-virtual {v2}, Ladgk;->a()Ladgl;

    .line 24
    move-result-object v2

    .line 25
    iget-object p0, p0, Lacvj;->d:Lbeye;

    .line 27
    check-cast p0, Lzul;

    .line 29
    invoke-virtual {p0}, Lzul;->a()Lzuk;

    .line 32
    move-result-object p0

    .line 33
    new-instance v3, Lacvi;

    .line 35
    invoke-direct {v3, v0, v1, v2, p0}, Lacvi;-><init>(Ldw;Lacwy;Ladgl;Lzuk;)V

    .line 38
    return-object v3
.end method
