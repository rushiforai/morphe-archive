.class public final synthetic Laav;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwf;


# instance fields
.field public final synthetic a:Labl;


# direct methods
.method public synthetic constructor <init>(Labl;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laav;->a:Labl;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object p0, p0, Laav;->a:Labl;

    .line 3
    new-instance v0, Labz;

    .line 5
    iget-object p0, p0, Labl;->n:Labh;

    .line 7
    invoke-direct {v0, p0}, Labz;-><init>(Ljava/util/concurrent/Executor;)V

    .line 10
    return-object v0
.end method
