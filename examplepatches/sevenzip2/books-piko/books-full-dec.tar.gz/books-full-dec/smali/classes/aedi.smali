.class public final Laedi;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final synthetic a:Laedn;


# direct methods
.method public constructor <init>(Laedn;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laedi;->a:Laedn;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    return-void
.end method
