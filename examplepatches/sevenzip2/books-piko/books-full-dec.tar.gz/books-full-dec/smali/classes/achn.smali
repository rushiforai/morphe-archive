.class public final synthetic Lachn;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lakuc;


# instance fields
.field public final synthetic a:Lachq;


# direct methods
.method public synthetic constructor <init>(Lachq;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lachn;->a:Lachq;

    .line 6
    return-void
.end method


# virtual methods
.method public final fu(Ljava/lang/Object;)V
    .locals 6

    .line 1
    iget-object p0, p0, Lachn;->a:Lachq;

    .line 3
    iget-object v0, p0, Lachq;->b:Lakxb;

    .line 5
    check-cast p1, Lachk;

    .line 7
    invoke-interface {v0}, Lakxb;->a()V

    .line 10
    new-instance v0, Ljava/util/HashMap;

    .line 12
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 15
    iget-object v1, p0, Lachq;->a:Lylv;

    .line 17
    invoke-virtual {v1}, Lylv;->h()Layqk;

    .line 20
    move-result-object v2

    .line 21
    invoke-virtual {v2}, Layqk;->e()Laywp;

    .line 24
    move-result-object v2

    .line 25
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 28
    move-result v3

    .line 29
    if-eqz v3, :cond_1

    .line 31
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 34
    move-result-object v3

    .line 35
    check-cast v3, Ljava/lang/String;

    .line 37
    invoke-virtual {v1, v3}, Lylv;->m(Ljava/lang/String;)Layos;

    .line 40
    move-result-object v4

    .line 41
    invoke-static {v4}, Laynq;->b(Ljava/lang/Iterable;)Laynq;

    .line 44
    move-result-object v4

    .line 45
    new-instance v5, Lacho;

    .line 47
    invoke-direct {v5, p1}, Lacho;-><init>(Lachk;)V

    .line 50
    invoke-virtual {v4, v5}, Laynq;->e(Lcom/google/common/base/Predicate;)Z

    .line 53
    move-result v4

    .line 54
    if-eqz v4, :cond_0

    .line 56
    invoke-virtual {p0, v3}, Lachq;->b(Ljava/lang/String;)Lacgo;

    .line 59
    move-result-object v4

    .line 60
    invoke-interface {v4}, Lacgo;->h()V

    .line 63
    const/4 v4, 0x0

    .line 64
    const/4 v5, 0x1

    .line 65
    invoke-static {v5, v4, v5, v5}, Lajvi;->e(ZZZZ)Lajvi;

    .line 68
    move-result-object v4

    .line 69
    invoke-interface {v0, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    goto :goto_0

    .line 73
    :cond_1
    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    .line 76
    move-result p1

    .line 77
    if-nez p1, :cond_2

    .line 79
    iget-object p0, p0, Lachq;->c:Lalnh;

    .line 81
    invoke-virtual {p0, v0}, Lalnh;->f(Ljava/lang/Object;)V

    .line 84
    :cond_2
    return-void
.end method
