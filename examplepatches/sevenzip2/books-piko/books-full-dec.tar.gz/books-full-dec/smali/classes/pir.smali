.class public abstract Lpir;
.super Lakxe;
.source "PG"

# interfaces
.implements Lpjg;


# static fields
.field public static final o:Layxl;


# instance fields
.field private A:Landroid/accounts/Account;

.field private final B:Lbhph;

.field private C:Z

.field public p:Z

.field public q:Loyh;

.field public r:Lbhpa;

.field public s:Lahxx;

.field public t:Ladxt;

.field public u:Layhy;

.field public v:Lppr;

.field public w:Lbifb;

.field public x:Z

.field public y:Landroid/accounts/Account;

.field public z:Ladxz;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "com/google/android/apps/play/books/activity/BaseBooksActivity"

    .line 3
    invoke-static {v0}, Layxl;->i(Ljava/lang/String;)Layxl;

    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Lpir;->o:Layxl;

    .line 9
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Lakxe;-><init>()V

    .line 4
    new-instance v0, Lpij;

    .line 6
    invoke-direct {v0, p0}, Lpij;-><init>(Lpir;)V

    .line 9
    new-instance v1, Lbhps;

    .line 11
    invoke-direct {v1, v0}, Lbhps;-><init>(Lbhwf;)V

    .line 14
    iput-object v1, p0, Lpir;->B:Lbhph;

    .line 16
    const/4 v0, 0x1

    .line 17
    iput-boolean v0, p0, Lpir;->C:Z

    .line 19
    return-void
.end method


# virtual methods
.method public final A(Lcom/google/android/gms/common/GooglePlayServicesRepairableException;)V
    .locals 3

    .line 1
    iget p1, p1, Lcom/google/android/gms/common/GooglePlayServicesRepairableException;->a:I

    .line 3
    sget-object v0, Lanfg;->a:Lanfg;

    .line 5
    const/4 v1, 0x6

    .line 6
    const/4 v2, 0x0

    .line 7
    invoke-virtual {v0, p0, p1, v1, v2}, Lanfg;->a(Landroid/app/Activity;IILandroid/content/DialogInterface$OnCancelListener;)Landroid/app/Dialog;

    .line 10
    move-result-object p0

    .line 11
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    invoke-virtual {p0}, Landroid/app/Dialog;->show()V

    .line 17
    return-void
.end method

.method protected abstract B(Landroid/accounts/Account;)V
.end method

.method public final C(Landroid/accounts/Account;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lpir;->y:Landroid/accounts/Account;

    .line 3
    if-nez v0, :cond_0

    .line 5
    iput-object p1, p0, Lpir;->y:Landroid/accounts/Account;

    .line 7
    invoke-virtual {p0}, Lpir;->w()Loyh;

    .line 10
    move-result-object v0

    .line 11
    invoke-interface {v0, p1}, Loyh;->n(Landroid/accounts/Account;)V

    .line 14
    invoke-virtual {p0, p1}, Lpir;->B(Landroid/accounts/Account;)V

    .line 17
    iget-object v0, p0, Lpir;->B:Lbhph;

    .line 19
    invoke-interface {v0}, Lbhph;->b()Ljava/lang/Object;

    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Lbifi;

    .line 25
    new-instance v1, Lpik;

    .line 27
    const/4 v2, 0x0

    .line 28
    invoke-direct {v1, p0, p1, v2}, Lpik;-><init>(Lpir;Landroid/accounts/Account;Lbhtu;)V

    .line 31
    const/4 p0, 0x3

    .line 32
    const/4 p1, 0x0

    .line 33
    invoke-static {v0, v2, p1, v1, p0}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 36
    return-void

    .line 37
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 39
    const-string p1, "Check failed."

    .line 41
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 44
    throw p0
.end method

.method public final D()Z
    .locals 3

    .line 1
    invoke-virtual {p0}, Lpir;->getIntent()Landroid/content/Intent;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/content/Intent;->getCategories()Ljava/util/Set;

    .line 8
    move-result-object v0

    .line 9
    const/4 v1, 0x1

    .line 10
    if-eqz v0, :cond_1

    .line 12
    const-string v2, "android.intent.category.BROWSABLE"

    .line 14
    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 17
    move-result v0

    .line 18
    if-eq v0, v1, :cond_0

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    return v1

    .line 22
    :cond_1
    :goto_0
    invoke-virtual {p0}, Landroid/app/Activity;->getReferrer()Landroid/net/Uri;

    .line 25
    move-result-object v0

    .line 26
    if-nez v0, :cond_2

    .line 28
    return v1

    .line 29
    :cond_2
    invoke-virtual {v0}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    .line 32
    move-result-object v0

    .line 33
    if-nez v0, :cond_3

    .line 35
    return v1

    .line 36
    :cond_3
    invoke-virtual {p0}, Lpir;->getPackageName()Ljava/lang/String;

    .line 39
    move-result-object p0

    .line 40
    invoke-static {v0, p0}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 43
    move-result p0

    .line 44
    if-nez p0, :cond_5

    .line 46
    const-string p0, "com.google.android.packageinstaller"

    .line 48
    invoke-static {v0, p0}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    move-result p0

    .line 52
    if-eqz p0, :cond_4

    .line 54
    goto :goto_1

    .line 55
    :cond_4
    return v1

    .line 56
    :cond_5
    :goto_1
    const/4 p0, 0x0

    .line 57
    return p0
.end method

.method protected E(Ladxz;Landroid/accounts/Account;)Z
    .locals 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    iget-boolean v0, p1, Ladxz;->c:Z

    .line 6
    if-eqz v0, :cond_0

    .line 8
    goto :goto_1

    .line 9
    :cond_0
    if-nez p2, :cond_1

    .line 11
    iget-object v0, p1, Ladxz;->b:Loyh;

    .line 13
    invoke-interface {v0}, Loyh;->k()Landroid/accounts/Account;

    .line 16
    move-result-object v0

    .line 17
    if-nez v0, :cond_2

    .line 19
    goto :goto_0

    .line 20
    :cond_1
    move-object v0, p2

    .line 21
    :cond_2
    iget-object p1, p1, Ladxz;->a:Landroid/content/Context;

    .line 23
    const-class v1, Ladxv;

    .line 25
    invoke-static {p1, v0, v1}, Lxzg;->c(Landroid/content/Context;Landroid/accounts/Account;Ljava/lang/Class;)Ljava/lang/Object;

    .line 28
    move-result-object p1

    .line 29
    check-cast p1, Ladxv;

    .line 31
    invoke-interface {p1}, Ladxv;->B()Lalav;

    .line 34
    move-result-object p1

    .line 35
    invoke-interface {p1}, Lalav;->d()Z

    .line 38
    move-result p1

    .line 39
    if-nez p1, :cond_5

    .line 41
    :goto_0
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 44
    move-result-object p1

    .line 45
    const-class v0, Lcom/google/android/apps/play/books/firstrun/FirstRunActivity;

    .line 47
    new-instance v1, Landroid/content/Intent;

    .line 49
    invoke-direct {v1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 52
    const-string v0, "continuationIntent"

    .line 54
    invoke-virtual {v1, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 57
    if-eqz p2, :cond_3

    .line 59
    const-string v0, "authAccount"

    .line 61
    iget-object p2, p2, Landroid/accounts/Account;->name:Ljava/lang/String;

    .line 63
    invoke-virtual {v1, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 66
    :cond_3
    instance-of p2, p0, Lcom/google/android/apps/play/books/home/BooksShortcutActivity;

    .line 68
    if-eqz p2, :cond_4

    .line 70
    invoke-static {p1}, Lajtz;->b(Landroid/content/Intent;)Z

    .line 73
    move-result p2

    .line 74
    if-eqz p2, :cond_4

    .line 76
    const/high16 p2, 0x2000000

    .line 78
    invoke-virtual {p1, p2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 81
    const-class v0, Lcom/google/android/apps/play/books/home/BooksShortcutActivity;

    .line 83
    new-instance v2, Landroid/content/ComponentName;

    .line 85
    invoke-direct {v2, p0, v0}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 88
    invoke-virtual {p1, v2}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 91
    invoke-virtual {v1, p2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 94
    :cond_4
    invoke-virtual {p0, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 97
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 100
    const/4 p0, 0x1

    .line 101
    return p0

    .line 102
    :cond_5
    :goto_1
    const/4 p0, 0x0

    .line 103
    return p0
.end method

.method public final onActivityResult(IILandroid/content/Intent;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3}, Lakxe;->onActivityResult(IILandroid/content/Intent;)V

    .line 4
    const/4 p2, 0x1

    .line 5
    if-eq p1, p2, :cond_0

    .line 7
    return-void

    .line 8
    :cond_0
    const/4 p1, 0x0

    .line 9
    iput-boolean p1, p0, Lpir;->p:Z

    .line 11
    if-eqz p3, :cond_1

    .line 13
    const-string p1, "authAccount"

    .line 15
    invoke-virtual {p3, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 18
    move-result-object p1

    .line 19
    goto :goto_0

    .line 20
    :cond_1
    const/4 p1, 0x0

    .line 21
    :goto_0
    if-nez p1, :cond_2

    .line 23
    invoke-virtual {p0}, Lpir;->finish()V

    .line 26
    return-void

    .line 27
    :cond_2
    new-instance p2, Landroid/accounts/Account;

    .line 29
    const-string p3, "app.revanced"

    .line 31
    invoke-direct {p2, p1, p3}, Landroid/accounts/Account;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 34
    invoke-virtual {p0, p2}, Lpir;->C(Landroid/accounts/Account;)V

    .line 37
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3

    .line 1
    invoke-super {p0, p1}, Lakxe;->onCreate(Landroid/os/Bundle;)V

    .line 4
    if-eqz p1, :cond_0

    .line 6
    const-string v0, "BaseBooksActivity.account"

    .line 8
    const-class v1, Landroid/accounts/Account;

    .line 10
    invoke-static {p1, v0, v1}, Ljhx;->b(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Landroid/accounts/Account;

    .line 16
    iput-object v0, p0, Lpir;->A:Landroid/accounts/Account;

    .line 18
    const-string v0, "BaseBooksActivity.accountSelectionInProgress"

    .line 20
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    .line 23
    move-result v0

    .line 24
    iput-boolean v0, p0, Lpir;->p:Z

    .line 26
    const-string v0, "BaseBooksActivity.shouldRunUnsupportedCountryCheck"

    .line 28
    const/4 v1, 0x1

    .line 29
    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z

    .line 32
    move-result v0

    .line 33
    iput-boolean v0, p0, Lpir;->C:Z

    .line 35
    :cond_0
    iget-object v0, p0, Lpir;->A:Landroid/accounts/Account;

    .line 37
    if-nez v0, :cond_1

    .line 39
    invoke-virtual {p0}, Lpir;->getIntent()Landroid/content/Intent;

    .line 42
    move-result-object v0

    .line 43
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    invoke-virtual {p0, v0}, Lpir;->v(Landroid/content/Intent;)Landroid/accounts/Account;

    .line 49
    move-result-object v0

    .line 50
    iput-object v0, p0, Lpir;->A:Landroid/accounts/Account;

    .line 52
    :cond_1
    iget-object v0, p0, Lpir;->z:Ladxz;

    .line 54
    const/4 v1, 0x0

    .line 55
    if-nez v0, :cond_2

    .line 57
    const-string v0, "firstRunActivityLauncher"

    .line 59
    invoke-static {v0}, Lbhxq;->c(Ljava/lang/String;)V

    .line 62
    move-object v0, v1

    .line 63
    :cond_2
    iget-object v2, p0, Lpir;->A:Landroid/accounts/Account;

    .line 65
    invoke-virtual {p0, v0, v2}, Lpir;->E(Ladxz;Landroid/accounts/Account;)Z

    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_3

    .line 71
    return-void

    .line 72
    :cond_3
    if-nez p1, :cond_4

    .line 74
    sget-object p1, Laotm;->a:Lj$/util/concurrent/ConcurrentHashMap;

    .line 76
    invoke-virtual {p0}, Lpir;->getIntent()Landroid/content/Intent;

    .line 79
    move-result-object p1

    .line 80
    invoke-static {p0, p1}, Laotl;->c(Landroid/content/Context;Landroid/content/Intent;)V

    .line 83
    :cond_4
    invoke-static {}, Lbfrq;->c()Z

    .line 86
    move-result p1

    .line 87
    if-eqz p1, :cond_5

    .line 89
    invoke-static {p0}, Labq;->a(Labl;)V

    .line 92
    :cond_5
    invoke-interface {p0}, Lkcm;->N()Lkcb;

    .line 95
    move-result-object p1

    .line 96
    invoke-static {p1}, Lkck;->a(Lkcb;)Lkcf;

    .line 99
    move-result-object p1

    .line 100
    new-instance v0, Lpiq;

    .line 102
    invoke-direct {v0, p0, v1}, Lpiq;-><init>(Lpir;Lbhtu;)V

    .line 105
    const/4 p0, 0x3

    .line 106
    const/4 v2, 0x0

    .line 107
    invoke-static {p1, v1, v2, v0, p0}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 110
    return-void
.end method

.method protected onNewIntent(Landroid/content/Intent;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-super {p0, p1}, Lakxe;->onNewIntent(Landroid/content/Intent;)V

    .line 7
    sget-object v0, Laotm;->a:Lj$/util/concurrent/ConcurrentHashMap;

    .line 9
    invoke-static {p0, p1}, Laotl;->c(Landroid/content/Context;Landroid/content/Intent;)V

    .line 12
    return-void
.end method

.method public onResume()V
    .locals 11

    .line 1
    invoke-super {p0}, Lakxe;->onResume()V

    .line 4
    sget-object v0, Lanfg;->a:Lanfg;

    .line 6
    const v1, 0xc35000

    .line 9
    invoke-virtual {v0, p0, v1}, Lanfh;->m(Landroid/content/Context;I)I

    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_1

    .line 15
    invoke-static {v1}, Langb;->e(I)Z

    .line 18
    move-result v2

    .line 19
    const-string v3, "checkPlayServices"

    .line 21
    const-string v4, "com/google/android/apps/play/books/gcore/GooglePlayServicesUtil"

    .line 23
    const-string v5, "GooglePlayServicesUtil.java"

    .line 25
    if-eqz v2, :cond_0

    .line 27
    sget-object v2, Ladyq;->a:Layxl;

    .line 29
    invoke-virtual {v2}, Layxb;->d()Layxz;

    .line 32
    move-result-object v2

    .line 33
    check-cast v2, Layxi;

    .line 35
    const/16 v6, 0x33

    .line 37
    invoke-interface {v2, v4, v3, v6, v5}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 40
    move-result-object v2

    .line 41
    check-cast v2, Layxi;

    .line 43
    const-string v3, "GMSCore check: resolvable error %s"

    .line 45
    invoke-interface {v2, v3, v1}, Layxi;->t(Ljava/lang/String;I)V

    .line 48
    new-instance v2, Ladyp;

    .line 50
    invoke-direct {v2, p0}, Ladyp;-><init>(Landroid/app/Activity;)V

    .line 53
    const/16 v3, 0x2328

    .line 55
    invoke-virtual {v0, p0, v1, v3, v2}, Lanfg;->a(Landroid/app/Activity;IILandroid/content/DialogInterface$OnCancelListener;)Landroid/app/Dialog;

    .line 58
    move-result-object v0

    .line 59
    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    .line 62
    goto :goto_0

    .line 63
    :cond_0
    sget-object v0, Ladyq;->a:Layxl;

    .line 65
    invoke-virtual {v0}, Layxb;->d()Layxz;

    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Layxi;

    .line 71
    const/16 v2, 0x3d

    .line 73
    invoke-interface {v0, v4, v3, v2, v5}, Layxi;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 76
    move-result-object v0

    .line 77
    check-cast v0, Layxi;

    .line 79
    const-string v2, "GMSCore check: unresolvable error %s"

    .line 81
    invoke-interface {v0, v2, v1}, Layxi;->t(Ljava/lang/String;I)V

    .line 84
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 87
    :cond_1
    :goto_0
    iget-object v0, p0, Lpir;->y:Landroid/accounts/Account;

    .line 89
    const/4 v1, 0x0

    .line 90
    if-eqz v0, :cond_2

    .line 92
    goto/16 :goto_2

    .line 94
    :cond_2
    invoke-virtual {p0}, Lpir;->getIntent()Landroid/content/Intent;

    .line 97
    move-result-object v0

    .line 98
    invoke-virtual {v0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 101
    move-result-object v0

    .line 102
    const/4 v2, 0x1

    .line 103
    const/4 v3, 0x0

    .line 104
    if-eqz v0, :cond_4

    .line 106
    const-string v4, "login_hint"

    .line 108
    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 111
    move-result-object v0

    .line 112
    if-eqz v0, :cond_4

    .line 114
    new-instance v4, Lpil;

    .line 116
    invoke-direct {v4, p0}, Lpil;-><init>(Ljava/lang/Object;)V

    .line 119
    new-instance v5, Lkfc;

    .line 121
    invoke-direct {v5, p0}, Lkfc;-><init>(Lkfe;)V

    .line 124
    const-class v6, Loyt;

    .line 126
    invoke-virtual {v5, v6}, Lkfc;->a(Ljava/lang/Class;)Lket;

    .line 129
    move-result-object v5

    .line 130
    check-cast v5, Loyt;

    .line 132
    invoke-interface {p0}, Lkcm;->N()Lkcb;

    .line 135
    move-result-object v6

    .line 136
    invoke-static {v6}, Lkck;->a(Lkcb;)Lkcf;

    .line 139
    move-result-object v6

    .line 140
    new-instance v7, Loys;

    .line 142
    invoke-direct {v7, p0, v4, v5, v1}, Loys;-><init>(Lkcm;Lbhwq;Loyt;Lbhtu;)V

    .line 145
    const/4 v4, 0x3

    .line 146
    invoke-static {v6, v1, v3, v7, v4}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 149
    iget-boolean v6, p0, Lpir;->p:Z

    .line 151
    if-nez v6, :cond_9

    .line 153
    iput-boolean v2, p0, Lpir;->p:Z

    .line 155
    iget-object v2, p0, Lpir;->r:Lbhpa;

    .line 157
    if-nez v2, :cond_3

    .line 159
    const-string v2, "loginHintHandlerProvider"

    .line 161
    invoke-static {v2}, Lbhxq;->c(Ljava/lang/String;)V

    .line 164
    move-object v2, v1

    .line 165
    :cond_3
    invoke-interface {v2}, Lbhpa;->b()Ljava/lang/Object;

    .line 168
    move-result-object v2

    .line 169
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 172
    invoke-static {v5}, Lkeu;->a(Lket;)Lbifi;

    .line 175
    move-result-object v6

    .line 176
    new-instance v7, Loyo;

    .line 178
    check-cast v2, Loyp;

    .line 180
    invoke-direct {v7, v2, v0, v5, v1}, Loyo;-><init>(Loyp;Ljava/lang/String;Loyt;Lbhtu;)V

    .line 183
    invoke-static {v6, v1, v3, v7, v4}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 186
    goto/16 :goto_2

    .line 188
    :cond_4
    iget-boolean v0, p0, Lpir;->p:Z

    .line 190
    if-nez v0, :cond_9

    .line 192
    :try_start_0
    invoke-virtual {p0}, Lpir;->w()Loyh;

    .line 195
    move-result-object v0

    .line 196
    invoke-interface {v0}, Loyh;->h()[Landroid/accounts/Account;

    .line 199
    move-result-object v0

    .line 200
    :try_end_0
    .catch Lcom/google/android/gms/common/GooglePlayServicesRepairableException; {:try_start_0 .. :try_end_0} :catch_0

    array-length v0, v0

    .line 201
    if-nez v0, :cond_5

    .line 203
    invoke-virtual {p0}, Lpir;->w()Loyh;

    .line 206
    move-result-object v0

    .line 207
    new-instance v2, Lpii;

    .line 209
    invoke-direct {v2, p0}, Lpii;-><init>(Lpir;)V

    .line 212
    const v3, 0x7f130264

    .line 215
    invoke-virtual {p0, v3}, Lpir;->getText(I)Ljava/lang/CharSequence;

    .line 218
    move-result-object v3

    .line 219
    invoke-interface {v0, p0, v2, v3}, Loyh;->f(Landroid/app/Activity;Landroid/accounts/AccountManagerCallback;Ljava/lang/CharSequence;)V

    .line 222
    goto :goto_2

    .line 223
    :cond_5
    invoke-virtual {p0}, Lpir;->w()Loyh;

    .line 226
    move-result-object v0

    .line 227
    iget-object v4, p0, Lpir;->A:Landroid/accounts/Account;

    .line 229
    invoke-interface {v0, v4, v3}, Loyh;->a(Landroid/accounts/Account;Z)Loyg;

    .line 232
    move-result-object v0

    .line 233
    iget-object v0, v0, Loyg;->a:Landroid/accounts/Account;

    .line 235
    if-eqz v0, :cond_6

    .line 237
    invoke-virtual {p0, v0}, Lpir;->C(Landroid/accounts/Account;)V

    .line 240
    goto :goto_2

    .line 241
    :cond_6
    iget-object v0, p0, Lpir;->v:Lppr;

    .line 243
    if-nez v0, :cond_7

    .line 245
    const-string v0, "accountTracker"

    .line 247
    invoke-static {v0}, Lbhxq;->c(Ljava/lang/String;)V

    .line 250
    move-object v0, v1

    .line 251
    :cond_7
    const-string v4, "home_settings_action"

    .line 253
    invoke-virtual {v0, v4}, Lppr;->a(Ljava/lang/String;)V

    .line 256
    iput-boolean v2, p0, Lpir;->p:Z

    .line 258
    iget-boolean v0, p0, Lpir;->x:Z

    .line 260
    const-string v4, "app.revanced"

    .line 262
    if-eqz v0, :cond_8

    .line 264
    new-instance v0, Lanew;

    .line 266
    invoke-direct {v0}, Lanew;-><init>()V

    .line 269
    invoke-static {v4}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 272
    move-result-object v3

    .line 273
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 276
    invoke-virtual {v0, v3}, Lanew;->b(Ljava/util/List;)V

    .line 279
    invoke-virtual {v0}, Lanew;->d()V

    .line 282
    invoke-virtual {v0}, Lanew;->e()V

    .line 285
    invoke-virtual {v0}, Lanew;->c()V

    .line 288
    invoke-virtual {v0}, Lanew;->a()Lanex;

    .line 291
    move-result-object v0

    .line 292
    invoke-static {v0}, Laney;->a(Lanex;)Landroid/content/Intent;

    .line 295
    move-result-object v0

    .line 296
    goto :goto_1

    .line 297
    :cond_8
    filled-new-array {v4}, [Ljava/lang/String;

    .line 300
    move-result-object v5

    .line 301
    new-array v9, v3, [Ljava/lang/String;

    .line 303
    const/4 v10, 0x0

    .line 304
    const/4 v3, 0x0

    .line 305
    const/4 v4, 0x0

    .line 306
    const/4 v6, 0x1

    .line 307
    const/4 v7, 0x0

    .line 308
    const/4 v8, 0x0

    .line 309
    invoke-static/range {v3 .. v10}, Landroid/accounts/AccountManager;->newChooseAccountIntent(Landroid/accounts/Account;Ljava/util/ArrayList;[Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;[Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    .line 312
    move-result-object v0

    .line 313
    :goto_1
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 316
    invoke-virtual {p0, v0, v2}, Labl;->startActivityForResult(Landroid/content/Intent;I)V

    .line 319
    goto :goto_2

    .line 320
    :catch_0
    move-exception v0

    .line 321
    invoke-virtual {p0, v0}, Lpir;->A(Lcom/google/android/gms/common/GooglePlayServicesRepairableException;)V

    .line 324
    :cond_9
    :goto_2
    iget-object p0, p0, Lpir;->t:Ladxt;

    .line 326
    if-nez p0, :cond_a

    .line 328
    const-string p0, "phoneskyFilterHelper"

    .line 330
    invoke-static {p0}, Lbhxq;->c(Ljava/lang/String;)V

    .line 333
    goto :goto_3

    .line 334
    :cond_a
    move-object v1, p0

    .line 335
    :goto_3
    invoke-virtual {v1}, Ladxt;->d()V

    .line 338
    return-void
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-super {p0, p1}, Lakxe;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 7
    const-string v0, "BaseBooksActivity.account"

    .line 9
    iget-object v1, p0, Lpir;->y:Landroid/accounts/Account;

    .line 11
    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 14
    const-string v0, "BaseBooksActivity.accountSelectionInProgress"

    .line 16
    iget-boolean v1, p0, Lpir;->p:Z

    .line 18
    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 21
    const-string v0, "BaseBooksActivity.shouldRunUnsupportedCountryCheck"

    .line 23
    iget-boolean p0, p0, Lpir;->C:Z

    .line 25
    invoke-virtual {p1, v0, p0}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 28
    return-void
.end method

.method public final onStart()V
    .locals 5

    .line 1
    invoke-super {p0}, Lakxe;->onStart()V

    .line 4
    invoke-virtual {p0}, Lpir;->x()Layhy;

    .line 7
    iget-boolean v0, p0, Lpir;->C:Z

    .line 9
    if-eqz v0, :cond_1

    .line 11
    iget-object v0, p0, Lpir;->y:Landroid/accounts/Account;

    .line 13
    if-nez v0, :cond_0

    .line 15
    iget-object v0, p0, Lpir;->A:Landroid/accounts/Account;

    .line 17
    :cond_0
    if-eqz v0, :cond_1

    .line 19
    const/4 v1, 0x0

    .line 20
    iput-boolean v1, p0, Lpir;->C:Z

    .line 22
    invoke-virtual {p0}, Lpir;->x()Layhy;

    .line 25
    move-result-object v2

    .line 26
    check-cast v2, Layin;

    .line 28
    iget-object v2, v2, Layin;->a:Ljava/lang/Object;

    .line 30
    check-cast v2, Lpja;

    .line 32
    iget-object v3, v2, Lpja;->b:Lbifb;

    .line 34
    iget-object v2, v2, Lpja;->a:Lahxx;

    .line 36
    new-instance v4, Lpiz;

    .line 38
    invoke-direct {v4, v2, v3, p0, v0}, Lpiz;-><init>(Lahxx;Lbifb;Lec;Landroid/accounts/Account;)V

    .line 41
    iget-object p0, v4, Lpiz;->c:Lec;

    .line 43
    invoke-interface {p0}, Lkcm;->N()Lkcb;

    .line 46
    move-result-object p0

    .line 47
    invoke-static {p0}, Lkck;->a(Lkcb;)Lkcf;

    .line 50
    move-result-object p0

    .line 51
    new-instance v0, Lpix;

    .line 53
    const/4 v2, 0x0

    .line 54
    invoke-direct {v0, v4, v2}, Lpix;-><init>(Lpiz;Lbhtu;)V

    .line 57
    const/4 v3, 0x3

    .line 58
    invoke-static {p0, v2, v1, v0, v3}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 61
    :cond_1
    return-void
.end method

.method protected final v(Landroid/content/Intent;)Landroid/accounts/Account;
    .locals 4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 7
    move-result-object v0

    .line 8
    const-string v1, "authAccount"

    .line 10
    invoke-virtual {p1, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    .line 13
    move-result v2

    .line 14
    const/4 v3, 0x0

    .line 15
    if-eqz v2, :cond_0

    .line 17
    invoke-virtual {p1, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 20
    move-result-object v0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    if-eqz v0, :cond_1

    .line 24
    const-string v1, "email"

    .line 26
    invoke-virtual {v0, v1}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 29
    move-result-object v0

    .line 30
    goto :goto_0

    .line 31
    :cond_1
    move-object v0, v3

    .line 32
    :goto_0
    if-nez v0, :cond_2

    .line 34
    invoke-static {p0, p1}, Lantp;->a(Landroid/content/Context;Landroid/content/Intent;)Lcom/google/android/gms/identity/accounts/api/AccountData;

    .line 37
    move-result-object p0

    .line 38
    if-eqz p0, :cond_2

    .line 40
    iget-object v0, p0, Lcom/google/android/gms/identity/accounts/api/AccountData;->a:Ljava/lang/String;

    .line 42
    :cond_2
    if-eqz v0, :cond_3

    .line 44
    new-instance p0, Landroid/accounts/Account;

    .line 46
    const-string p1, "app.revanced"

    .line 48
    invoke-direct {p0, v0, p1}, Landroid/accounts/Account;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    return-object p0

    .line 52
    :cond_3
    return-object v3
.end method

.method public final w()Loyh;
    .locals 0

    .line 1
    iget-object p0, p0, Lpir;->q:Loyh;

    .line 3
    if-eqz p0, :cond_0

    .line 5
    return-object p0

    .line 6
    :cond_0
    const-string p0, "accountManager"

    .line 8
    invoke-static {p0}, Lbhxq;->c(Ljava/lang/String;)V

    .line 11
    const/4 p0, 0x0

    .line 12
    return-object p0
.end method

.method public final x()Layhy;
    .locals 0

    .line 1
    iget-object p0, p0, Lpir;->u:Layhy;

    .line 3
    if-eqz p0, :cond_0

    .line 5
    return-object p0

    .line 6
    :cond_0
    const-string p0, "checkForUnsupportedCountryFactory"

    .line 8
    invoke-static {p0}, Lbhxq;->c(Ljava/lang/String;)V

    .line 11
    const/4 p0, 0x0

    .line 12
    return-object p0
.end method

.method public final y()Lbifb;
    .locals 0

    .line 1
    iget-object p0, p0, Lpir;->w:Lbifb;

    .line 3
    if-eqz p0, :cond_0

    .line 5
    return-object p0

    .line 6
    :cond_0
    const-string p0, "backgroundDispatcher"

    .line 8
    invoke-static {p0}, Lbhxq;->c(Ljava/lang/String;)V

    .line 11
    const/4 p0, 0x0

    .line 12
    return-object p0
.end method

.method protected final z()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lpir;->C:Z

    .line 4
    return-void
.end method
