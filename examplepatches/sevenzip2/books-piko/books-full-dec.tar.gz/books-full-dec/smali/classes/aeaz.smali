.class public final Laeaz;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field final synthetic a:Laeba;

.field final synthetic b:Lbien;


# direct methods
.method public constructor <init>(Lbien;Laeba;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laeaz;->b:Lbien;

    .line 3
    iput-object p2, p0, Laeaz;->a:Laeba;

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;Lawmw;)V
    .locals 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    iget-object v0, p0, Laeaz;->a:Laeba;

    .line 6
    iget-object v0, v0, Laeba;->m:Layxl;

    .line 8
    invoke-virtual {v0}, Layxb;->d()Layxz;

    .line 11
    move-result-object v0

    .line 12
    const/16 v1, 0x60

    .line 14
    const-string v2, "SurveyManager.kt"

    .line 16
    const-string v3, "com/google/android/apps/play/books/happiness/impl/SurveyManager$requestSurvey$<anonymous>"

    .line 18
    const-string v4, "onRequestFailed"

    .line 20
    invoke-interface {v0, v3, v4, v1, v2}, Layxz;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 23
    move-result-object v0

    .line 24
    check-cast v0, Layxi;

    .line 26
    const-string v1, "Failed to fetch survey (trigger id: %s, error: %s)"

    .line 28
    invoke-interface {v0, v1, p1, p2}, Layxi;->A(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 31
    iget-object p0, p0, Laeaz;->b:Lbien;

    .line 33
    const/4 p1, 0x0

    .line 34
    invoke-virtual {p0, p1}, Lbihp;->R(Ljava/lang/Object;)Z

    .line 37
    return-void
.end method

.method public final b(Lcom/google/android/libraries/surveys/SurveyData;)V
    .locals 0

    .line 1
    iget-object p0, p0, Laeaz;->b:Lbien;

    .line 3
    invoke-virtual {p0, p1}, Lbihp;->R(Ljava/lang/Object;)Z

    .line 6
    return-void
.end method
