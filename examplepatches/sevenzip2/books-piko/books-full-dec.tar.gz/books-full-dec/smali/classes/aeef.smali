.class public final Laeef;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Lbexl;


# direct methods
.method public constructor <init>(Lbexl;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laeef;->a:Lbexl;

    .line 6
    return-void
.end method
