.class Labs;
.super Labx;
.source "PG"


# virtual methods
.method public a(Lacm;Lacm;Landroid/view/Window;Landroid/view/View;ZZ)V
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    invoke-static {p3, p0}, Ljnr;->a(Landroid/view/Window;Z)V

    .line 5
    invoke-virtual {p1, p5}, Lacm;->a(Z)I

    .line 8
    move-result p0

    .line 9
    invoke-virtual {p3, p0}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 12
    invoke-virtual {p2, p6}, Lacm;->a(Z)I

    .line 15
    move-result p0

    .line 16
    invoke-virtual {p3, p0}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 19
    new-instance p0, Ljpf;

    .line 21
    invoke-direct {p0, p3, p4}, Ljpf;-><init>(Landroid/view/Window;Landroid/view/View;)V

    .line 24
    xor-int/lit8 p1, p5, 0x1

    .line 26
    invoke-virtual {p0, p1}, Ljpf;->c(Z)V

    .line 29
    xor-int/lit8 p1, p6, 0x1

    .line 31
    invoke-virtual {p0, p1}, Ljpf;->b(Z)V

    .line 34
    return-void
.end method
