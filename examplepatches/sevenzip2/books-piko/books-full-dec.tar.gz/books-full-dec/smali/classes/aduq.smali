.class final Laduq;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:Ljava/lang/Object;

.field b:I

.field final synthetic c:Ladur;

.field final synthetic d:Ladtt;

.field final synthetic e:Landroid/content/Context;


# direct methods
.method public constructor <init>(Ladur;Ladtt;Landroid/content/Context;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laduq;->c:Ladur;

    .line 3
    iput-object p2, p0, Laduq;->d:Ladtt;

    .line 5
    iput-object p3, p0, Laduq;->e:Landroid/content/Context;

    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, Lbhuu;-><init>(ILbhtu;)V

    .line 11
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Laduq;

    .line 13
    invoke-virtual {p0, p1}, Laduq;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Laduq;->b:I

    .line 5
    if-eqz v1, :cond_0

    .line 7
    iget-object v0, p0, Laduq;->a:Ljava/lang/Object;

    .line 9
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 16
    sget-object p1, Laduj;->a:Laduj;

    .line 18
    new-instance v1, Ljwp;

    .line 20
    new-instance v2, Ladul;

    .line 22
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 25
    invoke-direct {v1, v2}, Ljwp;-><init>(Lbhwq;)V

    .line 28
    iget-object v2, p0, Laduq;->c:Ladur;

    .line 30
    iget-object v3, p0, Laduq;->e:Landroid/content/Context;

    .line 32
    new-instance v4, Ladum;

    .line 34
    invoke-direct {v4, v3}, Ladum;-><init>(Landroid/content/Context;)V

    .line 37
    iget-object v2, v2, Ladur;->c:Lbifi;

    .line 39
    const/4 v3, 0x4

    .line 40
    invoke-static {p1, v1, v2, v4, v3}, Ljst;->b(Ljvy;Ljwp;Lbifi;Lbhwf;I)Ljss;

    .line 43
    move-result-object p1

    .line 44
    move-object v1, p1

    .line 45
    check-cast v1, Ljuu;

    .line 47
    iget-object v1, v1, Ljuu;->d:Lbilb;

    .line 49
    iput-object p1, p0, Laduq;->a:Ljava/lang/Object;

    .line 51
    const/4 v2, 0x1

    .line 52
    iput v2, p0, Laduq;->b:I

    .line 54
    invoke-static {v1, p0}, Lbinz;->a(Lbilb;Lbhtu;)Ljava/lang/Object;

    .line 57
    move-result-object v1

    .line 58
    if-eq v1, v0, :cond_9

    .line 60
    move-object v0, p1

    .line 61
    move-object p1, v1

    .line 62
    :goto_0
    iget-object v1, p0, Laduq;->c:Ladur;

    .line 64
    check-cast p1, Ladtd;

    .line 66
    new-instance v2, Ladun;

    .line 68
    invoke-direct {v2, v1, v0}, Ladun;-><init>(Ladur;Ljss;)V

    .line 71
    iget-object p0, p0, Laduq;->d:Ladtt;

    .line 73
    new-instance v0, Laduh;

    .line 75
    iget-object v1, p0, Ladtt;->a:Lbhpa;

    .line 77
    check-cast v1, Lbeyg;

    .line 79
    invoke-virtual {v1}, Lbeyg;->a()Ljava/util/Set;

    .line 82
    move-result-object v1

    .line 83
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    iget-object v3, p0, Ladtt;->b:Lbhpa;

    .line 88
    check-cast v3, Lbeyg;

    .line 90
    invoke-virtual {v3}, Lbeyg;->a()Ljava/util/Set;

    .line 93
    move-result-object v3

    .line 94
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 97
    iget-object p0, p0, Ladtt;->c:Lbhpa;

    .line 99
    invoke-interface {p0}, Lbhpa;->b()Ljava/lang/Object;

    .line 102
    move-result-object p0

    .line 103
    check-cast p0, Lalnn;

    .line 105
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 108
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 111
    new-instance v4, Ljava/util/LinkedHashMap;

    .line 113
    invoke-direct {v4}, Ljava/util/LinkedHashMap;-><init>()V

    .line 116
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 119
    move-result-object v5

    .line 120
    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 123
    move-result v6

    .line 124
    const-string v7, "\' is not unique."

    .line 126
    if-eqz v6, :cond_2

    .line 128
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 131
    move-result-object v6

    .line 132
    move-object v8, v6

    .line 133
    check-cast v8, Ladsp;

    .line 135
    iget-object v8, v8, Ladsp;->a:Ljava/lang/String;

    .line 137
    invoke-interface {v4, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 140
    move-result-object v9

    .line 141
    if-nez v9, :cond_1

    .line 143
    invoke-interface {v4, v8}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 146
    move-result v10

    .line 147
    if-nez v10, :cond_1

    .line 149
    invoke-interface {v4, v8, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 152
    goto :goto_1

    .line 153
    :cond_1
    check-cast v9, Ladsp;

    .line 155
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 157
    const-string p1, "Campaign layer id \'"

    .line 159
    invoke-static {v8, p1, v7}, La;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 162
    move-result-object p1

    .line 163
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 166
    throw p0

    .line 167
    :cond_2
    new-instance v5, Ljava/util/LinkedHashMap;

    .line 169
    invoke-direct {v5}, Ljava/util/LinkedHashMap;-><init>()V

    .line 172
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 175
    move-result-object v1

    .line 176
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 179
    move-result v6

    .line 180
    if-eqz v6, :cond_4

    .line 182
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 185
    move-result-object v6

    .line 186
    move-object v8, v6

    .line 187
    check-cast v8, Ladsn;

    .line 189
    iget-object v8, v8, Ladsn;->a:Ljava/lang/String;

    .line 191
    invoke-interface {v5, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 194
    move-result-object v9

    .line 195
    if-nez v9, :cond_3

    .line 197
    invoke-interface {v5, v8}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 200
    move-result v10

    .line 201
    if-nez v10, :cond_3

    .line 203
    invoke-interface {v5, v8, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 206
    goto :goto_2

    .line 207
    :cond_3
    check-cast v9, Ladsn;

    .line 209
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 211
    const-string p1, "Campaign id \'"

    .line 213
    invoke-static {v8, p1, v7}, La;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 216
    move-result-object p1

    .line 217
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 220
    throw p0

    .line 221
    :cond_4
    invoke-interface {v5}, Ljava/util/Map;->values()Ljava/util/Collection;

    .line 224
    move-result-object v1

    .line 225
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 228
    move-result-object v1

    .line 229
    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 232
    move-result v6

    .line 233
    if-eqz v6, :cond_6

    .line 235
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 238
    move-result-object v6

    .line 239
    check-cast v6, Ladsn;

    .line 241
    invoke-interface {v4}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 244
    move-result-object v7

    .line 245
    iget-object v8, v6, Ladsn;->b:Ljava/lang/String;

    .line 247
    invoke-interface {v7, v8}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 250
    move-result v7

    .line 251
    if-eqz v7, :cond_5

    .line 253
    goto :goto_3

    .line 254
    :cond_5
    iget-object p0, v6, Ladsn;->a:Ljava/lang/String;

    .line 256
    new-instance p1, Ljava/lang/StringBuilder;

    .line 258
    const-string v0, "Campaign \'"

    .line 260
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 263
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 266
    const-string p0, "\' references layer \'"

    .line 268
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 271
    invoke-virtual {p1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 274
    const-string p0, "\' that doesn\'t have a corresponding layer config."

    .line 276
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 279
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 282
    move-result-object p0

    .line 283
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 285
    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 288
    throw p1

    .line 289
    :cond_6
    invoke-static {v3}, Lbhrc;->p(Ljava/lang/Iterable;)I

    .line 292
    move-result v1

    .line 293
    invoke-static {v1}, Lbhry;->b(I)I

    .line 296
    move-result v1

    .line 297
    const/16 v6, 0x10

    .line 299
    if-ge v1, v6, :cond_7

    .line 301
    move v1, v6

    .line 302
    :cond_7
    new-instance v6, Ljava/util/LinkedHashMap;

    .line 304
    invoke-direct {v6, v1}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 307
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 310
    move-result-object v1

    .line 311
    :goto_4
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 314
    move-result v3

    .line 315
    if-eqz v3, :cond_8

    .line 317
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 320
    move-result-object v3

    .line 321
    check-cast v3, Ladsp;

    .line 323
    iget-object v7, v3, Ladsp;->a:Ljava/lang/String;

    .line 325
    iget-object v3, v3, Ladsp;->b:Ljava/util/List;

    .line 327
    new-instance v8, Laduw;

    .line 329
    new-instance v9, Laduv;

    .line 331
    invoke-direct {v9, v3}, Laduv;-><init>(Ljava/util/List;)V

    .line 334
    invoke-direct {v8, v9}, Laduw;-><init>(Laduv;)V

    .line 337
    new-instance v3, Lbhpn;

    .line 339
    invoke-direct {v3, v7, v8}, Lbhpn;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 342
    iget-object v7, v3, Lbhpn;->a:Ljava/lang/Object;

    .line 344
    iget-object v3, v3, Lbhpn;->b:Ljava/lang/Object;

    .line 346
    invoke-interface {v6, v7, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 349
    goto :goto_4

    .line 350
    :cond_8
    new-instance v1, Ladug;

    .line 352
    invoke-direct {v1, v5, v4, v6}, Ladug;-><init>(Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)V

    .line 355
    invoke-direct {v0, v1, p0, p1, v2}, Laduh;-><init>(Ladug;Lalnn;Ladtd;Lbhwq;)V

    .line 358
    :cond_9
    return-object v0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 2

    .line 1
    new-instance p1, Laduq;

    .line 3
    iget-object v0, p0, Laduq;->c:Ladur;

    .line 5
    iget-object v1, p0, Laduq;->d:Ladtt;

    .line 7
    iget-object p0, p0, Laduq;->e:Landroid/content/Context;

    .line 9
    invoke-direct {p1, v0, v1, p0, p2}, Laduq;-><init>(Ladur;Ladtt;Landroid/content/Context;Lbhtu;)V

    .line 12
    return-object p1
.end method
