.class public final Laehr;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwf;


# virtual methods
.method public final bridge synthetic a()Ljava/lang/Object;
    .locals 0

    .line 1
    const/4 p0, 0x6

    .line 2
    new-array p0, p0, [Ljava/lang/Object;

    .line 4
    return-object p0
.end method
