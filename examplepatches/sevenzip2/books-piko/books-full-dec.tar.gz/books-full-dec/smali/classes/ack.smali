.class public interface abstract Lack;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lkcm;


# virtual methods
.method public abstract c()Laci;
.end method
