.class final Lacel;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:I

.field final synthetic b:Lacey;


# direct methods
.method public constructor <init>(Lacey;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lacel;->b:Lacey;

    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, Lbhuu;-><init>(ILbhtu;)V

    .line 7
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Lacel;

    .line 13
    invoke-virtual {p0, p1}, Lacel;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Lacel;->a:I

    .line 5
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 8
    if-eqz v1, :cond_0

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object p1, p0, Lacel;->b:Lacey;

    .line 13
    new-instance v1, Lacem;

    .line 15
    sget-object v2, Lbhrs;->a:Lbhrs;

    .line 17
    invoke-direct {v1, v2}, Lacem;-><init>(Ljava/util/Collection;)V

    .line 20
    const/4 v2, 0x1

    .line 21
    iput v2, p0, Lacel;->a:I

    .line 23
    iget-object p1, p1, Lacey;->e:Lbiot;

    .line 25
    invoke-interface {p1, v1, p0}, Lbiot;->a(Ljava/lang/Object;Lbhtu;)Ljava/lang/Object;

    .line 28
    move-result-object p0

    .line 29
    if-ne p0, v0, :cond_1

    .line 31
    return-object v0

    .line 32
    :cond_1
    :goto_0
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 34
    return-object p0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 0

    .line 1
    new-instance p1, Lacel;

    .line 3
    iget-object p0, p0, Lacel;->b:Lacey;

    .line 5
    invoke-direct {p1, p0, p2}, Lacel;-><init>(Lacey;Lbhtu;)V

    .line 8
    return-object p1
.end method
