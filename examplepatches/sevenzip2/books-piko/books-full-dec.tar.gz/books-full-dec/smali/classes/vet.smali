.class public interface abstract Lvet;
.super Ljava/lang/Object;
.source "PG"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T::",
        "Lveu;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract d(Ljava/lang/String;)Lveu;
.end method

.method public abstract e(Luws;)Lajvi;
.end method

.method public abstract f()V
.end method

.method public abstract j(Luws;Lver;)Luwv;
.end method
