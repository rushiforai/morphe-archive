.class public final Lacgk;
.super Ljava/lang/Object;
.source "PG"


# direct methods
.method public static synthetic a(I)Ljava/lang/String;
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    if-eq p0, v0, :cond_0

    .line 4
    const-string p0, "UNLIMITED"

    .line 6
    return-object p0

    .line 7
    :cond_0
    const-string p0, "LIMITED"

    .line 9
    return-object p0
.end method
