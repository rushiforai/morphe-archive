.class final Lacgb;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:Ljava/lang/Object;

.field b:Ljava/lang/Object;

.field c:Ljava/lang/Object;

.field d:I

.field final synthetic e:Ljava/util/Collection;

.field final synthetic f:Ljava/util/List;

.field final synthetic g:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

.field private synthetic h:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/util/Collection;Ljava/util/List;Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lacgb;->e:Ljava/util/Collection;

    .line 3
    iput-object p2, p0, Lacgb;->f:Ljava/util/List;

    .line 5
    iput-object p3, p0, Lacgb;->g:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, Lbhuu;-><init>(ILbhtu;)V

    .line 11
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Lacgb;

    .line 13
    invoke-virtual {p0, p1}, Lacgb;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Lacgb;->d:I

    .line 5
    const/4 v2, 0x1

    .line 6
    const/4 v3, 0x0

    .line 7
    if-eqz v1, :cond_1

    .line 9
    if-eq v1, v2, :cond_0

    .line 11
    iget-object v0, p0, Lacgb;->a:Ljava/lang/Object;

    .line 13
    iget-object p0, p0, Lacgb;->h:Ljava/lang/Object;

    .line 15
    check-cast p0, Ljava/util/List;

    .line 17
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 20
    goto/16 :goto_8

    .line 22
    :cond_0
    iget-object v1, p0, Lacgb;->c:Ljava/lang/Object;

    .line 24
    iget-object v2, p0, Lacgb;->b:Ljava/lang/Object;

    .line 26
    iget-object v4, p0, Lacgb;->a:Ljava/lang/Object;

    .line 28
    iget-object v5, p0, Lacgb;->h:Ljava/lang/Object;

    .line 30
    check-cast v5, Lbifq;

    .line 32
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 35
    goto/16 :goto_6

    .line 37
    :cond_1
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 40
    iget-object p1, p0, Lacgb;->h:Ljava/lang/Object;

    .line 42
    check-cast p1, Lbifi;

    .line 44
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 46
    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 49
    iget-object v4, p0, Lacgb;->e:Ljava/util/Collection;

    .line 51
    invoke-interface {v4}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 54
    move-result-object v4

    .line 55
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 58
    move-result v5

    .line 59
    if-eqz v5, :cond_3

    .line 61
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 64
    move-result-object v5

    .line 65
    check-cast v5, Lacej;

    .line 67
    iget-object v6, v5, Lacej;->a:Ljava/lang/String;

    .line 69
    invoke-interface {v1, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    move-result-object v7

    .line 73
    check-cast v7, Ljava/lang/Long;

    .line 75
    if-eqz v7, :cond_2

    .line 77
    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    .line 80
    move-result-wide v7

    .line 81
    goto :goto_1

    .line 82
    :cond_2
    const-wide/16 v7, 0x0

    .line 84
    :goto_1
    iget-wide v9, v5, Lacej;->b:J

    .line 86
    add-long/2addr v7, v9

    .line 87
    new-instance v5, Ljava/lang/Long;

    .line 89
    invoke-direct {v5, v7, v8}, Ljava/lang/Long;-><init>(J)V

    .line 92
    invoke-interface {v1, v6, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 95
    goto :goto_0

    .line 96
    :cond_3
    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 99
    move-result-object v4

    .line 100
    new-instance v5, Ljava/util/ArrayList;

    .line 102
    invoke-static {v4}, Lbhrc;->p(Ljava/lang/Iterable;)I

    .line 105
    move-result v6

    .line 106
    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V

    .line 109
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 112
    move-result-object v4

    .line 113
    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 116
    move-result v6

    .line 117
    if-eqz v6, :cond_4

    .line 119
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 122
    move-result-object v6

    .line 123
    check-cast v6, Ljava/util/Map$Entry;

    .line 125
    new-instance v7, Lacej;

    .line 127
    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 130
    move-result-object v8

    .line 131
    check-cast v8, Ljava/lang/String;

    .line 133
    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 136
    move-result-object v6

    .line 137
    check-cast v6, Ljava/lang/Number;

    .line 139
    invoke-virtual {v6}, Ljava/lang/Number;->longValue()J

    .line 142
    move-result-wide v9

    .line 143
    invoke-direct {v7, v8, v9, v10}, Lacej;-><init>(Ljava/lang/String;J)V

    .line 146
    invoke-interface {v5, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 149
    goto :goto_2

    .line 150
    :cond_4
    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    .line 153
    move-result v4

    .line 154
    if-eq v2, v4, :cond_5

    .line 156
    goto :goto_3

    .line 157
    :cond_5
    move-object v5, v3

    .line 158
    :goto_3
    const/4 v4, 0x3

    .line 159
    const/4 v6, 0x0

    .line 160
    if-eqz v5, :cond_6

    .line 162
    iget-object v7, p0, Lacgb;->g:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 164
    new-instance v8, Lacga;

    .line 166
    invoke-direct {v8, v7, v5, v3}, Lacga;-><init>(Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;Ljava/util/List;Lbhtu;)V

    .line 169
    invoke-static {p1, v3, v6, v8, v4}, Lbidy;->d(Lbifi;Lbhuc;ILbhwu;I)Lbifq;

    .line 172
    move-result-object v5

    .line 173
    goto :goto_4

    .line 174
    :cond_6
    move-object v5, v3

    .line 175
    :goto_4
    iget-object v7, p0, Lacgb;->f:Ljava/util/List;

    .line 177
    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 180
    move-result-object v1

    .line 181
    invoke-static {v7, v1}, Lbhrc;->S(Ljava/lang/Iterable;Ljava/lang/Iterable;)Ljava/util/List;

    .line 184
    move-result-object v1

    .line 185
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 188
    move-result v7

    .line 189
    if-ne v2, v7, :cond_7

    .line 191
    move-object v1, v3

    .line 192
    :cond_7
    if-eqz v1, :cond_8

    .line 194
    iget-object v7, p0, Lacgb;->g:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 196
    new-instance v8, Lacfz;

    .line 198
    invoke-direct {v8, v7, v1, v3}, Lacfz;-><init>(Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;Ljava/util/List;Lbhtu;)V

    .line 201
    invoke-static {p1, v3, v6, v8, v4}, Lbidy;->d(Lbifi;Lbhuc;ILbhwu;I)Lbifq;

    .line 204
    move-result-object p1

    .line 205
    goto :goto_5

    .line 206
    :cond_8
    move-object p1, v3

    .line 207
    :goto_5
    new-instance v1, Lbhsr;

    .line 209
    const/16 v4, 0xa

    .line 211
    invoke-direct {v1, v4}, Lbhsr;-><init>(I)V

    .line 214
    if-eqz v5, :cond_9

    .line 216
    iput-object p1, p0, Lacgb;->h:Ljava/lang/Object;

    .line 218
    iput-object v1, p0, Lacgb;->a:Ljava/lang/Object;

    .line 220
    iput-object v1, p0, Lacgb;->b:Ljava/lang/Object;

    .line 222
    iput-object v1, p0, Lacgb;->c:Ljava/lang/Object;

    .line 224
    iput v2, p0, Lacgb;->d:I

    .line 226
    invoke-interface {v5, p0}, Lbifq;->a(Lbhtu;)Ljava/lang/Object;

    .line 229
    move-result-object v2

    .line 230
    if-eq v2, v0, :cond_a

    .line 232
    move-object v5, p1

    .line 233
    move-object v4, v1

    .line 234
    move-object p1, v2

    .line 235
    move-object v2, v4

    .line 236
    :goto_6
    check-cast p1, Ljava/util/Collection;

    .line 238
    invoke-interface {v1, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 241
    move-object v1, v4

    .line 242
    move-object p1, v5

    .line 243
    goto :goto_7

    .line 244
    :cond_9
    move-object v2, v1

    .line 245
    :goto_7
    if-eqz p1, :cond_b

    .line 247
    iput-object v1, p0, Lacgb;->h:Ljava/lang/Object;

    .line 249
    iput-object v2, p0, Lacgb;->a:Ljava/lang/Object;

    .line 251
    iput-object v3, p0, Lacgb;->b:Ljava/lang/Object;

    .line 253
    iput-object v3, p0, Lacgb;->c:Ljava/lang/Object;

    .line 255
    const/4 v3, 0x2

    .line 256
    iput v3, p0, Lacgb;->d:I

    .line 258
    invoke-interface {p1, p0}, Lbifq;->a(Lbhtu;)Ljava/lang/Object;

    .line 261
    move-result-object p1

    .line 262
    if-eq p1, v0, :cond_a

    .line 264
    move-object p0, v1

    .line 265
    move-object v0, v2

    .line 266
    :goto_8
    check-cast p1, Ljava/util/Collection;

    .line 268
    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 271
    move-object v1, p0

    .line 272
    goto :goto_9

    .line 273
    :cond_a
    return-object v0

    .line 274
    :cond_b
    :goto_9
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 277
    check-cast v1, Lbhsr;

    .line 279
    invoke-virtual {v1}, Lbhsr;->f()Ljava/util/List;

    .line 282
    move-result-object p0

    .line 283
    return-object p0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 3

    .line 1
    new-instance v0, Lacgb;

    .line 3
    iget-object v1, p0, Lacgb;->e:Ljava/util/Collection;

    .line 5
    iget-object v2, p0, Lacgb;->f:Ljava/util/List;

    .line 7
    iget-object p0, p0, Lacgb;->g:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 9
    invoke-direct {v0, v1, v2, p0, p2}, Lacgb;-><init>(Ljava/util/Collection;Ljava/util/List;Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;Lbhtu;)V

    .line 12
    iput-object p1, v0, Lacgb;->h:Ljava/lang/Object;

    .line 14
    return-object v0
.end method
