.class public final Labof;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labof;->a:Lbeye;

    .line 6
    iput-object p2, p0, Labof;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 2

    .line 1
    new-instance v0, Laboe;

    .line 3
    iget-object v1, p0, Labof;->a:Lbeye;

    .line 5
    iget-object p0, p0, Labof;->b:Lbeye;

    .line 7
    invoke-direct {v0, v1, p0}, Laboe;-><init>(Lbhpa;Lbhpa;)V

    .line 10
    return-object v0
.end method
