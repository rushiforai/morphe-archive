.class public final Laedv;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbilb;


# instance fields
.field final synthetic a:Lbilb;


# direct methods
.method public constructor <init>(Lbilb;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laedv;->a:Lbilb;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public final gv(Lbilc;Lbhtu;)Ljava/lang/Object;
    .locals 1

    .line 1
    new-instance v0, Laedu;

    .line 3
    invoke-direct {v0, p1}, Laedu;-><init>(Lbilc;)V

    .line 6
    iget-object p0, p0, Laedv;->a:Lbilb;

    .line 8
    invoke-interface {p0, v0, p2}, Lbilb;->gv(Lbilc;Lbhtu;)Ljava/lang/Object;

    .line 11
    move-result-object p0

    .line 12
    sget-object p1, Lbhug;->a:Lbhug;

    .line 14
    if-ne p0, p1, :cond_0

    .line 16
    return-object p0

    .line 17
    :cond_0
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 19
    return-object p0
.end method
