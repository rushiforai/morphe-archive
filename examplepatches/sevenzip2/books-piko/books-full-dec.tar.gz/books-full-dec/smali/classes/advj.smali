.class public final Ladvj;
.super Ladvn;
.source "PG"


# instance fields
.field public final a:Layhy;

.field public final b:Layhy;

.field public final c:Landroid/view/View;

.field public final d:I


# direct methods
.method public constructor <init>(Layhy;Layhy;Landroid/view/View;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ladvn;-><init>()V

    .line 4
    iput-object p1, p0, Ladvj;->a:Layhy;

    .line 6
    iput-object p2, p0, Ladvj;->b:Layhy;

    .line 8
    iput-object p3, p0, Ladvj;->c:Landroid/view/View;

    .line 10
    iput p4, p0, Ladvj;->d:I

    .line 12
    return-void
.end method


# virtual methods
.method public final a()Landroid/view/View;
    .locals 0

    .line 1
    iget-object p0, p0, Ladvj;->c:Landroid/view/View;

    .line 3
    return-object p0
.end method

.method public final b()Layhy;
    .locals 0

    .line 1
    iget-object p0, p0, Ladvj;->a:Layhy;

    .line 3
    return-object p0
.end method

.method public final c()Layhy;
    .locals 0

    .line 1
    iget-object p0, p0, Ladvj;->b:Layhy;

    .line 3
    return-object p0
.end method

.method public final d()I
    .locals 0

    .line 1
    iget p0, p0, Ladvj;->d:I

    .line 3
    return p0
.end method

.method public final e()V
    .locals 0

    .line 1
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_0

    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Ladvn;

    .line 7
    const/4 v2, 0x0

    .line 8
    if-eqz v1, :cond_1

    .line 10
    check-cast p1, Ladvn;

    .line 12
    iget-object v1, p0, Ladvj;->a:Layhy;

    .line 14
    invoke-virtual {p1}, Ladvn;->b()Layhy;

    .line 17
    move-result-object v3

    .line 18
    invoke-virtual {v1, v3}, Layhy;->equals(Ljava/lang/Object;)Z

    .line 21
    move-result v1

    .line 22
    if-eqz v1, :cond_1

    .line 24
    iget-object v1, p0, Ladvj;->b:Layhy;

    .line 26
    invoke-virtual {p1}, Ladvn;->c()Layhy;

    .line 29
    move-result-object v3

    .line 30
    invoke-virtual {v1, v3}, Layhy;->equals(Ljava/lang/Object;)Z

    .line 33
    move-result v1

    .line 34
    if-eqz v1, :cond_1

    .line 36
    iget-object v1, p0, Ladvj;->c:Landroid/view/View;

    .line 38
    invoke-virtual {p1}, Ladvn;->a()Landroid/view/View;

    .line 41
    move-result-object v3

    .line 42
    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 45
    move-result v1

    .line 46
    if-eqz v1, :cond_1

    .line 48
    invoke-virtual {p1}, Ladvn;->e()V

    .line 51
    iget p0, p0, Ladvj;->d:I

    .line 53
    invoke-virtual {p1}, Ladvn;->d()I

    .line 56
    move-result v1

    .line 57
    if-ne p0, v1, :cond_1

    .line 59
    invoke-virtual {p1}, Ladvn;->f()V

    .line 62
    return v0

    .line 63
    :cond_1
    return v2
.end method

.method public final f()V
    .locals 0

    .line 1
    return-void
.end method

.method public final hashCode()I
    .locals 4

    .line 1
    iget-object v0, p0, Ladvj;->a:Layhy;

    .line 3
    invoke-virtual {v0}, Layhy;->hashCode()I

    .line 6
    move-result v0

    .line 7
    const v1, 0xf4243

    .line 10
    xor-int/2addr v0, v1

    .line 11
    mul-int/2addr v0, v1

    .line 12
    iget-object v2, p0, Ladvj;->c:Landroid/view/View;

    .line 14
    const v3, 0x79a31aac

    .line 17
    xor-int/2addr v0, v3

    .line 18
    mul-int/2addr v0, v1

    .line 19
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 22
    move-result v2

    .line 23
    xor-int/2addr v0, v2

    .line 24
    const v2, -0x2aff6277

    .line 27
    mul-int/2addr v0, v2

    .line 28
    iget p0, p0, Ladvj;->d:I

    .line 30
    xor-int/2addr p0, v0

    .line 31
    mul-int/2addr p0, v1

    .line 32
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 4

    .line 1
    iget-object v0, p0, Ladvj;->a:Layhy;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 6
    move-result-object v0

    .line 7
    iget-object v1, p0, Ladvj;->c:Landroid/view/View;

    .line 9
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 12
    move-result-object v1

    .line 13
    iget p0, p0, Ladvj;->d:I

    .line 15
    const/4 v2, 0x1

    .line 16
    if-eq p0, v2, :cond_0

    .line 18
    const-string p0, "BELOW"

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    const-string p0, "ABOVE"

    .line 23
    :goto_0
    new-instance v2, Ljava/lang/StringBuilder;

    .line 25
    const-string v3, "TooltipModel{backgroundColor="

    .line 27
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 30
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    const-string v0, ", scrimColor=Optional.absent(), contentView="

    .line 35
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    const-string v0, ", dismissListener=null, placement="

    .line 43
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    const-string p0, ", readyListener=null}"

    .line 51
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 57
    move-result-object p0

    .line 58
    return-object p0
.end method
