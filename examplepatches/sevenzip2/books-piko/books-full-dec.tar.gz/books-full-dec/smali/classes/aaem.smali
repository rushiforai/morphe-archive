.class public final Laaem;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laaem;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laaem;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final a()Laael;
    .locals 3

    .line 1
    iget-object v0, p0, Laaem;->a:Lbeye;

    .line 3
    check-cast v0, Laace;

    .line 5
    invoke-virtual {v0}, Laace;->a()Laacd;

    .line 8
    move-result-object v0

    .line 9
    iget-object p0, p0, Laaem;->b:Lbeye;

    .line 11
    check-cast p0, Lqgk;

    .line 13
    invoke-virtual {p0}, Lqgk;->a()Ldw;

    .line 16
    move-result-object p0

    .line 17
    invoke-static {}, Laadq;->a()Lalyv;

    .line 20
    move-result-object v1

    .line 21
    new-instance v2, Laael;

    .line 23
    invoke-direct {v2, v0, p0, v1}, Laael;-><init>(Laacd;Ldw;Lalyv;)V

    .line 26
    return-object v2
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Laaem;->a()Laael;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
