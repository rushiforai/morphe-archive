.class public final synthetic Laar;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Labl;


# direct methods
.method public synthetic constructor <init>(Labl;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laar;->a:Labl;

    .line 6
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 1
    iget-object p0, p0, Laar;->a:Labl;

    .line 3
    invoke-virtual {p0}, Labl;->invalidateOptionsMenu()V

    .line 6
    return-void
.end method
