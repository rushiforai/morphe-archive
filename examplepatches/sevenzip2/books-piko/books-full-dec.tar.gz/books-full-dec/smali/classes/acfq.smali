.class public final synthetic Lacfq;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwf;


# instance fields
.field public final synthetic a:Lacft;


# direct methods
.method public synthetic constructor <init>(Lacft;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacfq;->a:Lacft;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Lacfq;->a:Lacft;

    .line 3
    iget-object p0, p0, Lacft;->a:Lbhpa;

    .line 5
    invoke-interface {p0}, Lbhpa;->b()Ljava/lang/Object;

    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lbgso;

    .line 11
    return-object p0
.end method
