.class final Ladz;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Lkcb;

.field public final b:Ljava/util/List;


# direct methods
.method public constructor <init>(Lkcb;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    iput-object p1, p0, Ladz;->a:Lkcb;

    .line 9
    new-instance p1, Ljava/util/ArrayList;

    .line 11
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 14
    iput-object p1, p0, Ladz;->b:Ljava/util/List;

    .line 16
    return-void
.end method
