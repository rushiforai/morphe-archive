.class public interface abstract Lyfe;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract a(Ljava/io/IOException;Ljava/io/File;)Ljava/io/IOException;
.end method
