.class final Lacfz;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:I

.field final synthetic b:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

.field final synthetic c:Ljava/util/List;


# direct methods
.method public constructor <init>(Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;Ljava/util/List;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lacfz;->b:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 3
    iput-object p2, p0, Lacfz;->c:Ljava/util/List;

    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, Lbhuu;-><init>(ILbhtu;)V

    .line 9
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Lacfz;

    .line 13
    invoke-virtual {p0, p1}, Lacfz;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Lacfz;->a:I

    .line 5
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 8
    if-eqz v1, :cond_0

    .line 10
    return-object p1

    .line 11
    :cond_0
    iget-object p1, p0, Lacfz;->b:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 13
    iget-object v1, p0, Lacfz;->c:Ljava/util/List;

    .line 15
    const/4 v2, 0x1

    .line 16
    iput v2, p0, Lacfz;->a:I

    .line 18
    new-instance v2, Lacfr;

    .line 20
    iget-object p1, p1, Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;->e:Lacft;

    .line 22
    const/4 v3, 0x0

    .line 23
    invoke-direct {v2, p1, v1, v3}, Lacfr;-><init>(Lacft;Ljava/util/List;Lbhtu;)V

    .line 26
    iget-object p1, p1, Lacft;->c:Lbifb;

    .line 28
    invoke-static {p1, v2, p0}, Lbidy;->a(Lbhuc;Lbhwu;Lbhtu;)Ljava/lang/Object;

    .line 31
    move-result-object p0

    .line 32
    if-ne p0, v0, :cond_1

    .line 34
    return-object v0

    .line 35
    :cond_1
    return-object p0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 1

    .line 1
    new-instance p1, Lacfz;

    .line 3
    iget-object v0, p0, Lacfz;->b:Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;

    .line 5
    iget-object p0, p0, Lacfz;->c:Ljava/util/List;

    .line 7
    invoke-direct {p1, v0, p0, p2}, Lacfz;-><init>(Lcom/google/android/apps/play/books/ebook/copyquota/CopyQuotaServerSyncWorker;Ljava/util/List;Lbhtu;)V

    .line 10
    return-object p1
.end method
