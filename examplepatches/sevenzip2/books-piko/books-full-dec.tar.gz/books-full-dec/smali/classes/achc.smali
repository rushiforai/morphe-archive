.class public interface abstract Lachc;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract l()Lvef;
.end method

.method public abstract s()Lachq;
.end method
