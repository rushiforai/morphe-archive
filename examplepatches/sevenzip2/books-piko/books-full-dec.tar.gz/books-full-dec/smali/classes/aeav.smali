.class final Laeav;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:Ljava/lang/Object;

.field b:Ljava/lang/Object;

.field c:Ljava/lang/Object;

.field d:I

.field final synthetic e:Laeba;

.field final synthetic f:Laeaq;


# direct methods
.method public constructor <init>(Laeba;Laeaq;Lbhtu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laeav;->e:Laeba;

    .line 3
    iput-object p2, p0, Laeav;->f:Laeaq;

    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, Lbhuu;-><init>(ILbhtu;)V

    .line 9
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    invoke-virtual {p0, p1, p2}, Lbhuo;->c(Ljava/lang/Object;Lbhtu;)Lbhtu;

    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 11
    check-cast p0, Laeav;

    .line 13
    invoke-virtual {p0, p1}, Laeav;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Laeav;->d:I

    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v1, :cond_1

    .line 8
    if-eq v1, v2, :cond_0

    .line 10
    iget-object v0, p0, Laeav;->c:Ljava/lang/Object;

    .line 12
    iget-object v1, p0, Laeav;->b:Ljava/lang/Object;

    .line 14
    iget-object p0, p0, Laeav;->a:Ljava/lang/Object;

    .line 16
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 19
    goto :goto_1

    .line 20
    :cond_0
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 23
    goto :goto_0

    .line 24
    :cond_1
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 27
    iget-object p1, p0, Laeav;->e:Laeba;

    .line 29
    iget-object v1, p0, Laeav;->f:Laeaq;

    .line 31
    invoke-interface {v1}, Laeaq;->b()Ljava/lang/String;

    .line 34
    move-result-object v1

    .line 35
    iput v2, p0, Laeav;->d:I

    .line 37
    invoke-virtual {p1, v1, p0}, Laeba;->m(Ljava/lang/String;Lbhtu;)Ljava/lang/Object;

    .line 40
    move-result-object p1

    .line 41
    if-eq p1, v0, :cond_3

    .line 43
    :goto_0
    check-cast p1, Lcom/google/android/libraries/surveys/SurveyData;

    .line 45
    if-eqz p1, :cond_2

    .line 47
    iget-object v1, p0, Laeav;->f:Laeaq;

    .line 49
    iget-object v2, p0, Laeav;->e:Laeba;

    .line 51
    iput-object v1, p0, Laeav;->a:Ljava/lang/Object;

    .line 53
    iput-object v2, p0, Laeav;->b:Ljava/lang/Object;

    .line 55
    iput-object p1, p0, Laeav;->c:Ljava/lang/Object;

    .line 57
    const/4 v3, 0x2

    .line 58
    iput v3, p0, Laeav;->d:I

    .line 60
    invoke-interface {v1, p0}, Laeaq;->a(Lbhtu;)Ljava/lang/Object;

    .line 63
    move-result-object p0

    .line 64
    if-eq p0, v0, :cond_3

    .line 66
    move-object v0, p1

    .line 67
    move-object p1, p0

    .line 68
    move-object p0, v1

    .line 69
    move-object v1, v2

    .line 70
    :goto_1
    check-cast p1, Ljava/util/List;

    .line 72
    sget-object v2, Laeba;->k:Ladsp;

    .line 74
    check-cast v1, Laeba;

    .line 76
    iget-object v2, v1, Laeba;->o:Ladzn;

    .line 78
    invoke-interface {p0}, Laeaq;->c()Ljava/util/List;

    .line 81
    move-result-object p0

    .line 82
    new-instance v3, Laeau;

    .line 84
    invoke-direct {v3, v1, v0, p1}, Laeau;-><init>(Laeba;Lcom/google/android/libraries/surveys/SurveyData;Ljava/util/List;)V

    .line 87
    invoke-virtual {v2, p0, v3}, Ladzn;->b(Ljava/util/List;Lbhwq;)V

    .line 90
    :cond_2
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 92
    return-object p0

    .line 93
    :cond_3
    return-object v0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 1

    .line 1
    new-instance p1, Laeav;

    .line 3
    iget-object v0, p0, Laeav;->e:Laeba;

    .line 5
    iget-object p0, p0, Laeav;->f:Laeaq;

    .line 7
    invoke-direct {p1, v0, p0, p2}, Laeav;-><init>(Laeba;Laeaq;Lbhtu;)V

    .line 10
    return-object p1
.end method
