.class public final Ladbw;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;

.field private final g:Lbeye;

.field private final h:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladbw;->a:Lbeye;

    .line 6
    iput-object p2, p0, Ladbw;->b:Lbeye;

    .line 8
    iput-object p3, p0, Ladbw;->c:Lbeye;

    .line 10
    iput-object p4, p0, Ladbw;->d:Lbeye;

    .line 12
    iput-object p5, p0, Ladbw;->e:Lbeye;

    .line 14
    iput-object p6, p0, Ladbw;->f:Lbeye;

    .line 16
    iput-object p7, p0, Ladbw;->g:Lbeye;

    .line 18
    iput-object p8, p0, Ladbw;->h:Lbeye;

    .line 20
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 9

    .line 1
    new-instance v0, Ladbv;

    .line 3
    iget-object v1, p0, Ladbw;->a:Lbeye;

    .line 5
    iget-object v2, p0, Ladbw;->b:Lbeye;

    .line 7
    iget-object v3, p0, Ladbw;->c:Lbeye;

    .line 9
    iget-object v4, p0, Ladbw;->d:Lbeye;

    .line 11
    iget-object v5, p0, Ladbw;->e:Lbeye;

    .line 13
    iget-object v6, p0, Ladbw;->f:Lbeye;

    .line 15
    iget-object v7, p0, Ladbw;->g:Lbeye;

    .line 17
    iget-object v8, p0, Ladbw;->h:Lbeye;

    .line 19
    invoke-direct/range {v0 .. v8}, Ladbv;-><init>(Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;)V

    .line 22
    return-object v0
.end method
