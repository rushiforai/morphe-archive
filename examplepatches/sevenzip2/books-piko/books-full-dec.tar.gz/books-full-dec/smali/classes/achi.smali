.class public final synthetic Lachi;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lakuc;


# instance fields
.field public final synthetic a:Lachj;


# direct methods
.method public synthetic constructor <init>(Lachj;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lachi;->a:Lachj;

    .line 6
    return-void
.end method


# virtual methods
.method public final fu(Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, Lakvw;

    .line 3
    iget-object p0, p0, Lachi;->a:Lachj;

    .line 5
    iget-object p0, p0, Lachj;->b:Ljava/util/List;

    .line 7
    invoke-interface {p0}, Ljava/util/List;->clear()V

    .line 10
    return-void
.end method
