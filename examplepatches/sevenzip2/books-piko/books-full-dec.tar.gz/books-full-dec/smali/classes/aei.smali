.class public final Laei;
.super Laeg;
.source "PG"


# virtual methods
.method public final bridge synthetic a(ILandroid/content/Intent;)Ljava/lang/Object;
    .locals 4

    .line 1
    const/4 p0, -0x1

    .line 2
    if-eq p1, p0, :cond_0

    .line 4
    sget-object p0, Lbhrr;->a:Lbhrr;

    .line 6
    return-object p0

    .line 7
    :cond_0
    if-nez p2, :cond_1

    .line 9
    sget-object p0, Lbhrr;->a:Lbhrr;

    .line 11
    return-object p0

    .line 12
    :cond_1
    const-string p0, "androidx.activity.result.contract.extra.PERMISSIONS"

    .line 14
    invoke-virtual {p2, p0}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;

    .line 17
    move-result-object p0

    .line 18
    const-string p1, "androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS"

    .line 20
    invoke-virtual {p2, p1}, Landroid/content/Intent;->getIntArrayExtra(Ljava/lang/String;)[I

    .line 23
    move-result-object p1

    .line 24
    if-eqz p1, :cond_5

    .line 26
    if-nez p0, :cond_2

    .line 28
    goto :goto_2

    .line 29
    :cond_2
    new-instance p2, Ljava/util/ArrayList;

    .line 31
    array-length v0, p1

    .line 32
    invoke-direct {p2, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 35
    const/4 v1, 0x0

    .line 36
    move v2, v1

    .line 37
    :goto_0
    if-ge v2, v0, :cond_4

    .line 39
    aget v3, p1, v2

    .line 41
    if-nez v3, :cond_3

    .line 43
    const/4 v3, 0x1

    .line 44
    goto :goto_1

    .line 45
    :cond_3
    move v3, v1

    .line 46
    :goto_1
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 49
    move-result-object v3

    .line 50
    invoke-interface {p2, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 53
    add-int/lit8 v2, v2, 0x1

    .line 55
    goto :goto_0

    .line 56
    :cond_4
    invoke-static {p0}, Lbhqv;->I([Ljava/lang/Object;)Ljava/util/List;

    .line 59
    move-result-object p0

    .line 60
    invoke-static {p0, p2}, Lbhrc;->ad(Ljava/lang/Iterable;Ljava/lang/Iterable;)Ljava/util/List;

    .line 63
    move-result-object p0

    .line 64
    invoke-static {p0}, Lbhry;->j(Ljava/lang/Iterable;)Ljava/util/Map;

    .line 67
    move-result-object p0

    .line 68
    return-object p0

    .line 69
    :cond_5
    :goto_2
    sget-object p0, Lbhrr;->a:Lbhrr;

    .line 71
    return-object p0
.end method

.method public final bridge synthetic b(Ljava/lang/Object;)Landroid/content/Intent;
    .locals 0

    .line 1
    check-cast p1, [Ljava/lang/String;

    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {p1}, Laeh;->a([Ljava/lang/String;)Landroid/content/Intent;

    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method

.method public final bridge synthetic c(Landroid/content/Context;Ljava/lang/Object;)Laef;
    .locals 4

    .line 1
    check-cast p2, [Ljava/lang/String;

    .line 3
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    array-length p0, p2

    .line 7
    if-nez p0, :cond_0

    .line 9
    new-instance p0, Laef;

    .line 11
    sget-object p1, Lbhrr;->a:Lbhrr;

    .line 13
    invoke-direct {p0, p1}, Laef;-><init>(Ljava/lang/Object;)V

    .line 16
    return-object p0

    .line 17
    :cond_0
    const/4 v0, 0x0

    .line 18
    move v1, v0

    .line 19
    :goto_0
    if-ge v1, p0, :cond_2

    .line 21
    aget-object v2, p2, v1

    .line 23
    invoke-static {p1, v2}, Ljez;->b(Landroid/content/Context;Ljava/lang/String;)I

    .line 26
    move-result v2

    .line 27
    if-nez v2, :cond_1

    .line 29
    add-int/lit8 v1, v1, 0x1

    .line 31
    goto :goto_0

    .line 32
    :cond_1
    const/4 p0, 0x0

    .line 33
    return-object p0

    .line 34
    :cond_2
    array-length p0, p2

    .line 35
    invoke-static {p0}, Lbhry;->b(I)I

    .line 38
    move-result p1

    .line 39
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 41
    const/16 v2, 0x10

    .line 43
    invoke-static {p1, v2}, Lbhzj;->f(II)I

    .line 46
    move-result p1

    .line 47
    invoke-direct {v1, p1}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 50
    :goto_1
    if-ge v0, p0, :cond_3

    .line 52
    aget-object p1, p2, v0

    .line 54
    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 56
    new-instance v3, Lbhpn;

    .line 58
    invoke-direct {v3, p1, v2}, Lbhpn;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 61
    iget-object p1, v3, Lbhpn;->a:Ljava/lang/Object;

    .line 63
    iget-object v2, v3, Lbhpn;->b:Ljava/lang/Object;

    .line 65
    invoke-interface {v1, p1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    add-int/lit8 v0, v0, 0x1

    .line 70
    goto :goto_1

    .line 71
    :cond_3
    new-instance p0, Laef;

    .line 73
    invoke-direct {p0, v1}, Laef;-><init>(Ljava/lang/Object;)V

    .line 76
    return-object p0
.end method
