.class public final Ladzj;
.super Ljava/lang/Object;
.source "PG"


# direct methods
.method public static final a(Lurl;Lbhtu;)Ljava/lang/Object;
    .locals 7

    .line 1
    instance-of v0, p1, Ladzi;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Ladzi;

    .line 8
    iget v1, v0, Ladzi;->b:I

    .line 10
    const/high16 v2, -0x80000000

    .line 12
    and-int v3, v1, v2

    .line 14
    if-eqz v3, :cond_0

    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Ladzi;->b:I

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Ladzi;

    .line 22
    invoke-direct {v0, p1}, Lbhuq;-><init>(Lbhtu;)V

    .line 25
    :goto_0
    iget-object p1, v0, Ladzi;->a:Ljava/lang/Object;

    .line 27
    sget-object v1, Lbhug;->a:Lbhug;

    .line 29
    iget v2, v0, Ladzi;->b:I

    .line 31
    const/4 v3, 0x1

    .line 32
    if-eqz v2, :cond_2

    .line 34
    if-ne v2, v3, :cond_1

    .line 36
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 39
    goto :goto_1

    .line 40
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 42
    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 44
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 47
    throw p0

    .line 48
    :cond_2
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 51
    invoke-interface {p0}, Lurl;->c()Lbilb;

    .line 54
    move-result-object p0

    .line 55
    iput v3, v0, Ladzi;->b:I

    .line 57
    invoke-static {p0, v0}, Lbinz;->a(Lbilb;Lbhtu;)Ljava/lang/Object;

    .line 60
    move-result-object p1

    .line 61
    if-eq p1, v1, :cond_7

    .line 63
    :goto_1
    check-cast p1, Lakur;

    .line 65
    iget-object p0, p1, Lakur;->a:Ljava/lang/Object;

    .line 67
    check-cast p0, Luxb;

    .line 69
    new-instance p1, Ljava/util/LinkedHashSet;

    .line 71
    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 74
    const/4 v0, 0x0

    .line 75
    if-eqz p0, :cond_5

    .line 77
    invoke-virtual {p0}, Luxb;->iterator()Ljava/util/Iterator;

    .line 80
    move-result-object p0

    .line 81
    move v1, v0

    .line 82
    move v2, v1

    .line 83
    :cond_3
    :goto_2
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 86
    move-result v4

    .line 87
    if-eqz v4, :cond_6

    .line 89
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 92
    move-result-object v4

    .line 93
    check-cast v4, Luws;

    .line 95
    invoke-virtual {v4}, Luws;->ag()Z

    .line 98
    move-result v5

    .line 99
    if-nez v5, :cond_3

    .line 101
    invoke-virtual {v4}, Luws;->aj()Z

    .line 104
    move-result v5

    .line 105
    if-eqz v5, :cond_3

    .line 107
    invoke-virtual {v4}, Luws;->U()Z

    .line 110
    move-result v5

    .line 111
    if-eqz v5, :cond_4

    .line 113
    add-int/lit8 v2, v2, 0x1

    .line 115
    goto :goto_3

    .line 116
    :cond_4
    add-int/lit8 v1, v1, 0x1

    .line 118
    :goto_3
    invoke-virtual {v4}, Luws;->l()Luwf;

    .line 121
    move-result-object v4

    .line 122
    if-eqz v4, :cond_3

    .line 124
    check-cast v4, Luus;

    .line 126
    iget-object v4, v4, Luus;->a:Ljava/lang/String;

    .line 128
    invoke-interface {p1, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 131
    goto :goto_2

    .line 132
    :cond_5
    move v1, v0

    .line 133
    move v2, v1

    .line 134
    :cond_6
    new-instance p0, Ladzh;

    .line 136
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 139
    const/4 v4, 0x3

    .line 140
    new-array v4, v4, [Ljkd;

    .line 142
    new-instance v5, Ljkd;

    .line 144
    new-instance v6, Ljava/lang/Integer;

    .line 146
    invoke-direct {v6, v1}, Ljava/lang/Integer;-><init>(I)V

    .line 149
    invoke-interface {p0, v6}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 152
    move-result-object v1

    .line 153
    const-string v6, "ebook_count"

    .line 155
    invoke-direct {v5, v6, v1}, Ljkd;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 158
    aput-object v5, v4, v0

    .line 160
    new-instance v0, Ljkd;

    .line 162
    new-instance v1, Ljava/lang/Integer;

    .line 164
    invoke-direct {v1, v2}, Ljava/lang/Integer;-><init>(I)V

    .line 167
    invoke-interface {p0, v1}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 170
    move-result-object v1

    .line 171
    const-string v2, "abook_count"

    .line 173
    invoke-direct {v0, v2, v1}, Ljkd;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 176
    aput-object v0, v4, v3

    .line 178
    new-instance v0, Ljkd;

    .line 180
    invoke-interface {p1}, Ljava/util/Set;->size()I

    .line 183
    move-result p1

    .line 184
    new-instance v1, Ljava/lang/Integer;

    .line 186
    invoke-direct {v1, p1}, Ljava/lang/Integer;-><init>(I)V

    .line 189
    invoke-interface {p0, v1}, Lbhwq;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 192
    move-result-object p0

    .line 193
    const-string p1, "series_count"

    .line 195
    invoke-direct {v0, p1, p0}, Ljkd;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 198
    const/4 p0, 0x2

    .line 199
    aput-object v0, v4, p0

    .line 201
    invoke-static {v4}, Lbhqv;->c([Ljava/lang/Object;)Ljava/util/List;

    .line 204
    move-result-object p0

    .line 205
    return-object p0

    .line 206
    :cond_7
    return-object v1
.end method
