.class public interface abstract Lalos;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract b()Landroid/os/Bundle;
.end method
