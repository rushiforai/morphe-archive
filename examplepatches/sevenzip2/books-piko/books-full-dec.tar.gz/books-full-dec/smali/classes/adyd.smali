.class final Ladyd;
.super Lbhuu;
.source "PG"

# interfaces
.implements Lbhwu;


# instance fields
.field a:I


# direct methods
.method public constructor <init>(Lbhtu;)V
    .locals 1

    .line 1
    const/4 v0, 0x2

    .line 2
    invoke-direct {p0, v0, p1}, Lbhuu;-><init>(ILbhtu;)V

    .line 5
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbifi;

    .line 3
    check-cast p2, Lbhtu;

    .line 5
    new-instance p0, Ladyd;

    .line 7
    invoke-direct {p0, p2}, Ladyd;-><init>(Lbhtu;)V

    .line 10
    sget-object p1, Lbhqc;->a:Lbhqc;

    .line 12
    invoke-virtual {p0, p1}, Ladyd;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    move-result-object p0

    .line 16
    return-object p0
.end method

.method public final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    sget-object v0, Lbhug;->a:Lbhug;

    .line 3
    iget v1, p0, Ladyd;->a:I

    .line 5
    invoke-static {p1}, Lbhpq;->b(Ljava/lang/Object;)V

    .line 8
    if-eqz v1, :cond_0

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    sget-object p1, Ladyh;->a:Lj$/time/Duration;

    .line 13
    const/4 v1, 0x1

    .line 14
    iput v1, p0, Ladyd;->a:I

    .line 16
    invoke-static {p1, p0}, Lazrf;->a(Lj$/time/Duration;Lbhtu;)Ljava/lang/Object;

    .line 19
    move-result-object p0

    .line 20
    if-ne p0, v0, :cond_1

    .line 22
    return-object v0

    .line 23
    :cond_1
    :goto_0
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 25
    return-object p0
.end method

.method public final c(Ljava/lang/Object;Lbhtu;)Lbhtu;
    .locals 0

    .line 1
    new-instance p0, Ladyd;

    .line 3
    invoke-direct {p0, p2}, Ladyd;-><init>(Lbhtu;)V

    .line 6
    return-object p0
.end method
