.class public final Laaue;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;

.field private final g:Lbeye;

.field private final h:Lbeye;

.field private final i:Lbeye;

.field private final j:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laaue;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laaue;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laaue;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laaue;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laaue;->e:Lbeye;

    .line 14
    iput-object p6, p0, Laaue;->f:Lbeye;

    .line 16
    iput-object p7, p0, Laaue;->g:Lbeye;

    .line 18
    iput-object p8, p0, Laaue;->h:Lbeye;

    .line 20
    iput-object p9, p0, Laaue;->i:Lbeye;

    .line 22
    iput-object p10, p0, Laaue;->j:Lbeye;

    .line 24
    return-void
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 13

    .line 1
    iget-object v0, p0, Laaue;->a:Lbeye;

    .line 3
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    move-object v2, v0

    .line 8
    check-cast v2, Lalnn;

    .line 10
    iget-object v0, p0, Laaue;->b:Lbeye;

    .line 12
    check-cast v0, Lqgk;

    .line 14
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 17
    move-result-object v3

    .line 18
    invoke-static {}, Lzvs;->a()Lalyv;

    .line 21
    move-result-object v4

    .line 22
    iget-object v0, p0, Laaue;->d:Lbeye;

    .line 24
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 27
    move-result-object v0

    .line 28
    move-object v6, v0

    .line 29
    check-cast v6, Laaxf;

    .line 31
    iget-object v0, p0, Laaue;->e:Lbeye;

    .line 33
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 36
    move-result-object v0

    .line 37
    move-object v7, v0

    .line 38
    check-cast v7, Laawv;

    .line 40
    iget-object v0, p0, Laaue;->f:Lbeye;

    .line 42
    check-cast v0, Laavs;

    .line 44
    invoke-virtual {v0}, Laavs;->a()Laavr;

    .line 47
    move-result-object v8

    .line 48
    iget-object v0, p0, Laaue;->g:Lbeye;

    .line 50
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 53
    move-result-object v0

    .line 54
    move-object v9, v0

    .line 55
    check-cast v9, Laawx;

    .line 57
    iget-object v0, p0, Laaue;->i:Lbeye;

    .line 59
    check-cast v0, Laake;

    .line 61
    invoke-virtual {v0}, Laake;->a()Laakd;

    .line 64
    move-result-object v11

    .line 65
    iget-object v0, p0, Laaue;->j:Lbeye;

    .line 67
    check-cast v0, Labvc;

    .line 69
    invoke-virtual {v0}, Labvc;->a()Labvb;

    .line 72
    move-result-object v12

    .line 73
    iget-object v5, p0, Laaue;->c:Lbeye;

    .line 75
    iget-object v10, p0, Laaue;->h:Lbeye;

    .line 77
    new-instance v1, Laaud;

    .line 79
    invoke-direct/range {v1 .. v12}, Laaud;-><init>(Lalnn;Ldw;Lalyv;Lbhpa;Laaxf;Laawv;Laaxn;Laawx;Lbhpa;Laakd;Labvb;)V

    .line 82
    return-object v1
.end method
