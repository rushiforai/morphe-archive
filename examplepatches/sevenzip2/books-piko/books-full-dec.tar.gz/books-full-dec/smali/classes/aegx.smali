.class public final Laegx;
.super Ljava/lang/Object;
.source "PG"


# direct methods
.method public static final a(Landroid/animation/Animator;Lbhtu;)Ljava/lang/Object;
    .locals 2

    .line 1
    new-instance v0, Lbief;

    .line 3
    invoke-static {p1}, Lbhuh;->c(Lbhtu;)Lbhtu;

    .line 6
    move-result-object p1

    .line 7
    const/4 v1, 0x1

    .line 8
    invoke-direct {v0, p1, v1}, Lbief;-><init>(Lbhtu;I)V

    .line 11
    invoke-virtual {v0}, Lbief;->B()V

    .line 14
    new-instance p1, Laegu;

    .line 16
    invoke-direct {p1, p0}, Laegu;-><init>(Landroid/animation/Animator;)V

    .line 19
    invoke-interface {v0, p1}, Lbied;->d(Lbhwq;)V

    .line 22
    new-instance p1, Laegv;

    .line 24
    invoke-direct {p1, v0}, Laegv;-><init>(Lbied;)V

    .line 27
    invoke-virtual {p0, p1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 30
    invoke-virtual {v0}, Lbief;->m()Ljava/lang/Object;

    .line 33
    move-result-object p0

    .line 34
    sget-object p1, Lbhug;->a:Lbhug;

    .line 36
    if-ne p0, p1, :cond_0

    .line 38
    return-object p0

    .line 39
    :cond_0
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 41
    return-object p0
.end method

.method public static final b(Landroid/view/View;Lbhtu;)Ljava/lang/Object;
    .locals 2

    .line 1
    new-instance v0, Lbief;

    .line 3
    invoke-static {p1}, Lbhuh;->c(Lbhtu;)Lbhtu;

    .line 6
    move-result-object p1

    .line 7
    const/4 v1, 0x1

    .line 8
    invoke-direct {v0, p1, v1}, Lbief;-><init>(Lbhtu;I)V

    .line 11
    invoke-virtual {v0}, Lbief;->B()V

    .line 14
    invoke-virtual {p0}, Landroid/view/View;->isLaidOut()Z

    .line 17
    move-result p1

    .line 18
    if-eqz p1, :cond_0

    .line 20
    invoke-virtual {p0}, Landroid/view/View;->isLayoutRequested()Z

    .line 23
    move-result p1

    .line 24
    if-nez p1, :cond_0

    .line 26
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 28
    invoke-interface {v0, p0}, Lbhtu;->w(Ljava/lang/Object;)V

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    new-instance p1, Laegw;

    .line 34
    invoke-direct {p1, v0}, Laegw;-><init>(Lbied;)V

    .line 37
    invoke-virtual {p0, p1}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    .line 40
    :goto_0
    invoke-virtual {v0}, Lbief;->m()Ljava/lang/Object;

    .line 43
    move-result-object p0

    .line 44
    sget-object p1, Lbhug;->a:Lbhug;

    .line 46
    if-ne p0, p1, :cond_1

    .line 48
    return-object p0

    .line 49
    :cond_1
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 51
    return-object p0
.end method

.method public static final c(Landroid/view/View;I)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 8
    move-result-object p0

    .line 9
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    return-object p0
.end method

.method public static final varargs d(Landroid/view/View;I[Ljava/lang/Object;)Ljava/lang/String;
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 4
    move-result-object p0

    .line 5
    const/4 v0, 0x1

    .line 6
    invoke-static {p2, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 9
    move-result-object p2

    .line 10
    invoke-virtual {p0, p1, p2}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 13
    move-result-object p0

    .line 14
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    return-object p0
.end method

.method public static final e(Landroid/view/View;I)Lbhph;
    .locals 1

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    new-instance v0, Laegq;

    .line 6
    invoke-direct {v0, p0, p1}, Laegq;-><init>(Landroid/view/View;I)V

    .line 9
    const/4 p0, 0x3

    .line 10
    invoke-static {p0, v0}, Lbhpi;->a(ILbhwf;)Lbhph;

    .line 13
    move-result-object p0

    .line 14
    return-object p0
.end method

.method public static final f(Landroid/view/Window;)V
    .locals 2

    .line 1
    new-instance v0, Ljpf;

    .line 3
    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 6
    move-result-object v1

    .line 7
    invoke-direct {v0, p0, v1}, Ljpf;-><init>(Landroid/view/Window;Landroid/view/View;)V

    .line 10
    const/16 p0, 0x207

    .line 12
    invoke-virtual {v0, p0}, Ljpf;->a(I)V

    .line 15
    iget-object p0, v0, Ljpf;->a:Ljpe;

    .line 17
    invoke-virtual {p0}, Ljpe;->e()V

    .line 20
    return-void
.end method
