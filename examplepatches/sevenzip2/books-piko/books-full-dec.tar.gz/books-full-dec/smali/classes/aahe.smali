.class public final Laahe;
.super Ljava/lang/Object;
.source "PG"


# static fields
.field public static final a:Laahf;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Laahf;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    sput-object v0, Laahe;->a:Laahf;

    .line 8
    return-void
.end method
