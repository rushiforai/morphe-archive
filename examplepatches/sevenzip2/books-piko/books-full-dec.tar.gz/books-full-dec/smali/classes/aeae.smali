.class final synthetic Laeae;
.super Lbhxo;
.source "PG"

# interfaces
.implements Lbhwq;


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 7

    .line 1
    const-class v3, Ladzj;

    .line 3
    const-string v5, "buildDelightPsd(Lcom/google/android/apps/play/books/catalog/data/MyBooksLoader;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;"

    .line 5
    const/4 v6, 0x1

    .line 6
    const/4 v1, 0x1

    .line 7
    const-string v4, "buildDelightPsd"

    .line 9
    move-object v0, p0

    .line 10
    move-object v2, p1

    .line 11
    invoke-direct/range {v0 .. v6}, Lbhxo;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 14
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Laeae;->e:Ljava/lang/Object;

    .line 3
    check-cast p1, Lbhtu;

    .line 5
    check-cast p0, Lurl;

    .line 7
    invoke-static {p0, p1}, Ladzj;->a(Lurl;Lbhtu;)Ljava/lang/Object;

    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method
