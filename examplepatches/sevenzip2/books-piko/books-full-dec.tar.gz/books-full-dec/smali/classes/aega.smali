.class public final synthetic Laega;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwf;


# instance fields
.field public final synthetic a:Laegc;


# direct methods
.method public synthetic constructor <init>(Laegc;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laega;->a:Laegc;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object p0, p0, Laega;->a:Laegc;

    .line 3
    iget-object p0, p0, Laegc;->b:Landroid/content/Context;

    .line 5
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 8
    move-result-object p0

    .line 9
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    invoke-static {}, Lakxa;->g()Z

    .line 15
    move-result v0

    .line 16
    const/4 v1, 0x0

    .line 17
    const-string v2, "com.google.android.apps.kids.home"

    .line 19
    if-eqz v0, :cond_1

    .line 21
    :try_start_0
    invoke-static {p0, v2}, Lhlq$$ExternalSyntheticApiModelOutline0;->m(Landroid/content/pm/PackageManager;Ljava/lang/String;)Landroid/content/pm/InstallSourceInfo;

    .line 24
    move-result-object p0

    .line 25
    if-nez p0, :cond_0

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    invoke-static {p0}, Lhlq$$ExternalSyntheticApiModelOutline0;->m(Landroid/content/pm/InstallSourceInfo;)Ljava/lang/String;

    .line 31
    move-result-object v1

    .line 32
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 33
    :cond_1
    :try_start_1
    invoke-virtual {p0, v2}, Landroid/content/pm/PackageManager;->getInstallerPackageName(Ljava/lang/String;)Ljava/lang/String;

    .line 36
    move-result-object v1

    .line 37
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :goto_0
    const-string p0, "com.android.vending"

    .line 39
    invoke-static {p0, v1}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 42
    move-result p0

    .line 43
    if-nez p0, :cond_2

    .line 45
    sget-object v0, Laegc;->a:Layxl;

    .line 47
    invoke-virtual {v0}, Layxb;->d()Layxz;

    .line 50
    move-result-object v0

    .line 51
    const/16 v1, 0x38

    .line 53
    const-string v2, "KidsSpaceEligibilityImpl.kt"

    .line 55
    const-string v3, "com/google/android/apps/play/books/kidspaceeligibility/KidsSpaceEligibilityImpl"

    .line 57
    const-string v4, "hasKidsPlayStoreInstalled$<anonymous>"

    .line 59
    invoke-interface {v0, v3, v4, v1, v2}, Layxz;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Layxz;

    .line 62
    move-result-object v0

    .line 63
    check-cast v0, Layxi;

    .line 65
    const-string v1, "Side loaded Kids Space detected"

    .line 67
    invoke-interface {v0, v1}, Layxi;->s(Ljava/lang/String;)V

    .line 70
    :cond_2
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 73
    move-result-object p0

    .line 74
    return-object p0
.end method
