.class public final Laecu;
.super Lalmo;
.source "PG"

# interfaces
.implements Lalot;
.implements Lallw;