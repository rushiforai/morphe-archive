.class public final synthetic Laaw;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwf;


# instance fields
.field public final synthetic a:Labl;


# direct methods
.method public synthetic constructor <init>(Labl;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laaw;->a:Labl;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 1

    .line 1
    new-instance v0, Lmjh;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    iget-object p0, p0, Laaw;->a:Labl;

    .line 8
    invoke-virtual {p0}, Labl;->getNavigationEventDispatcher()Lmjj;

    .line 11
    move-result-object p0

    .line 12
    invoke-virtual {p0, v0}, Lmjj;->a(Lmjq;)V

    .line 15
    return-object v0
.end method
