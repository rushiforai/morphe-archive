.class public final synthetic Lacjw;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lyfe;


# instance fields
.field public final synthetic a:Lacjx;

.field public final synthetic b:Lajut;


# direct methods
.method public synthetic constructor <init>(Lacjx;Lajut;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lacjw;->a:Lacjx;

    .line 6
    iput-object p2, p0, Lacjw;->b:Lajut;

    .line 8
    return-void
.end method


# virtual methods
.method public final a(Ljava/io/IOException;Ljava/io/File;)Ljava/io/IOException;
    .locals 10

    .line 1
    iget-object v0, p0, Lacjw;->b:Lajut;

    .line 3
    iget-object v1, v0, Lajut;->a:Lajzl;

    .line 5
    sget-object v2, Lajzl;->b:Lajzl;

    .line 7
    if-ne v1, v2, :cond_0

    .line 9
    iget-object p0, p0, Lacjw;->a:Lacjx;

    .line 11
    sget-object v2, Lacjx;->a:Layxl;

    .line 13
    invoke-virtual {v2}, Layxb;->d()Layxz;

    .line 16
    move-result-object v3

    .line 17
    const/16 v7, 0x5b

    .line 19
    const-string v8, "VolumeContentStore.java"

    .line 21
    const-string v4, "Error accessing file on external storage"

    .line 23
    const-string v5, "com/google/android/apps/play/books/ebook/data/VolumeContentStore"

    .line 25
    const-string v6, "exceptionDecorator"

    .line 27
    move-object v9, p1

    .line 28
    invoke-static/range {v3 .. v9}, La;->A(Layxz;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;CLjava/lang/String;Ljava/lang/Throwable;)V

    .line 31
    new-instance p1, Lachk;

    .line 33
    invoke-direct {p1, v0}, Lachk;-><init>(Lajut;)V

    .line 36
    iget-object v2, p0, Lacjx;->d:Lalnh;

    .line 38
    invoke-virtual {v2, p1}, Lalnh;->f(Ljava/lang/Object;)V

    .line 41
    iget-object p1, v0, Lajut;->c:Ljava/lang/String;

    .line 43
    invoke-virtual {p0, v0}, Lacjx;->l(Lajut;)I

    .line 46
    move-result v2

    .line 47
    add-int/lit8 v2, v2, 0x1

    .line 49
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 52
    move-result-object v2

    .line 53
    iget-object v3, p0, Lacjx;->e:Ljava/util/Map;

    .line 55
    invoke-interface {v3, p1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    invoke-virtual {p0}, Lacjx;->p()Lajut;

    .line 61
    move-result-object p1

    .line 62
    invoke-virtual {v0, p1}, Lajut;->equals(Ljava/lang/Object;)Z

    .line 65
    move-result p1

    .line 66
    if-eqz p1, :cond_1

    .line 68
    iget-object p0, p0, Lacjx;->f:Lyev;

    .line 70
    invoke-virtual {p0}, Lyev;->b()Lajvv;

    .line 73
    goto :goto_0

    .line 74
    :cond_0
    move-object v9, p1

    .line 75
    :cond_1
    :goto_0
    invoke-virtual {v9}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    .line 78
    move-result-object p0

    .line 79
    invoke-virtual {p2}, Ljava/io/File;->toString()Ljava/lang/String;

    .line 82
    move-result-object p1

    .line 83
    invoke-virtual {p0, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 86
    move-result p1

    .line 87
    if-nez p1, :cond_2

    .line 89
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 92
    move-result-object p1

    .line 93
    new-instance p2, Ljava/lang/StringBuilder;

    .line 95
    const-string v2, "Error finding "

    .line 97
    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 100
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 103
    const-string p1, ": "

    .line 105
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 108
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 111
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 114
    move-result-object p0

    .line 115
    :cond_2
    sget-object p1, Lajzl;->a:Lajzl;

    .line 117
    if-eq v1, p1, :cond_4

    .line 119
    iget-object p1, v0, Lajut;->d:Lajzi;

    .line 121
    iget-boolean p1, p1, Lajzi;->d:Z

    .line 123
    if-eqz p1, :cond_3

    .line 125
    new-instance p1, Lcom/google/android/apps/play/books/database/main/ExternalStorageInconsistentException;

    .line 127
    invoke-direct {p1, p0}, Lcom/google/android/apps/play/books/database/main/ExternalStorageInconsistentException;-><init>(Ljava/lang/String;)V

    .line 130
    goto :goto_1

    .line 131
    :cond_3
    new-instance p1, Lcom/google/android/apps/play/books/database/main/ExternalStorageUnavailableException;

    .line 133
    invoke-direct {p1, p0}, Lcom/google/android/apps/play/books/database/main/ExternalStorageUnavailableException;-><init>(Ljava/lang/String;)V

    .line 136
    :goto_1
    invoke-virtual {p1, v9}, Ljava/io/IOException;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 139
    return-object p1

    .line 140
    :cond_4
    return-object v9
.end method
