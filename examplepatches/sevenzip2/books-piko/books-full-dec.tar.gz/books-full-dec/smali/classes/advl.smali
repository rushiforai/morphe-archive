.class public final synthetic Ladvl;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Landroid/widget/PopupWindow$OnDismissListener;


# instance fields
.field public final synthetic a:Ladvm;

.field public final synthetic b:Ladvw;


# direct methods
.method public synthetic constructor <init>(Ladvm;Ladvw;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladvl;->a:Ladvm;

    .line 6
    iput-object p2, p0, Ladvl;->b:Ladvw;

    .line 8
    return-void
.end method


# virtual methods
.method public final onDismiss()V
    .locals 3

    .line 1
    iget-object v0, p0, Ladvl;->b:Ladvw;

    .line 3
    iget-object v1, v0, Ladvw;->b:Landroid/view/View;

    .line 5
    invoke-virtual {v1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 8
    move-result-object v1

    .line 9
    invoke-virtual {v1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    .line 12
    move-result v2

    .line 13
    if-eqz v2, :cond_0

    .line 15
    iget-object v0, v0, Ladvw;->a:Landroid/view/ViewTreeObserver$OnPreDrawListener;

    .line 17
    invoke-virtual {v1, v0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 20
    :cond_0
    iget-object p0, p0, Ladvl;->a:Ladvm;

    .line 22
    iget-object p0, p0, Ladvm;->a:Landroid/widget/PopupWindow$OnDismissListener;

    .line 24
    invoke-interface {p0}, Landroid/widget/PopupWindow$OnDismissListener;->onDismiss()V

    .line 27
    return-void
.end method
