.class public final synthetic Ladsv;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbhwf;


# instance fields
.field public final synthetic a:Lbifi;

.field public final synthetic b:Lbhwq;

.field public final synthetic c:Ladsu;

.field public final synthetic d:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lbifi;Lbhwq;Ladsu;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ladsv;->a:Lbifi;

    .line 6
    iput-object p2, p0, Ladsv;->b:Lbhwq;

    .line 8
    iput-object p3, p0, Ladsv;->c:Ladsu;

    .line 10
    iput-object p4, p0, Ladsv;->d:Ljava/lang/String;

    .line 12
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 5

    .line 1
    sget-object v0, Ladsx;->a:Ljava/util/List;

    .line 3
    new-instance v0, Ladsw;

    .line 5
    iget-object v1, p0, Ladsv;->b:Lbhwq;

    .line 7
    iget-object v2, p0, Ladsv;->c:Ladsu;

    .line 9
    iget-object v3, p0, Ladsv;->d:Ljava/lang/String;

    .line 11
    const/4 v4, 0x0

    .line 12
    invoke-direct {v0, v1, v2, v3, v4}, Ladsw;-><init>(Lbhwq;Ladsu;Ljava/lang/String;Lbhtu;)V

    .line 15
    iget-object p0, p0, Ladsv;->a:Lbifi;

    .line 17
    const/4 v1, 0x0

    .line 18
    const/4 v2, 0x3

    .line 19
    invoke-static {p0, v4, v1, v0, v2}, Lbidy;->e(Lbifi;Lbhuc;ILbhwu;I)Lbihc;

    .line 22
    sget-object p0, Lbhqc;->a:Lbhqc;

    .line 24
    return-object p0
.end method
