.class public final synthetic Laay;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lkcj;


# instance fields
.field public final synthetic a:Labl;


# direct methods
.method public synthetic constructor <init>(Labl;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laay;->a:Labl;

    .line 6
    return-void
.end method


# virtual methods
.method public final a(Lkcm;Lkby;)V
    .locals 0

    .line 1
    sget-object p1, Lkby;->ON_STOP:Lkby;

    .line 3
    if-ne p2, p1, :cond_0

    .line 5
    iget-object p0, p0, Laay;->a:Labl;

    .line 7
    invoke-virtual {p0}, Labl;->getWindow()Landroid/view/Window;

    .line 10
    move-result-object p0

    .line 11
    if-eqz p0, :cond_0

    .line 13
    invoke-virtual {p0}, Landroid/view/Window;->peekDecorView()Landroid/view/View;

    .line 16
    move-result-object p0

    .line 17
    if-eqz p0, :cond_0

    .line 19
    invoke-virtual {p0}, Landroid/view/View;->cancelPendingInputEvents()V

    .line 22
    :cond_0
    return-void
.end method
