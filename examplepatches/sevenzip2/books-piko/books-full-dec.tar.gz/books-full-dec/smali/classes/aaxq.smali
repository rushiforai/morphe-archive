.class public final Laaxq;
.super Ljava/lang/Object;
.source "PG"