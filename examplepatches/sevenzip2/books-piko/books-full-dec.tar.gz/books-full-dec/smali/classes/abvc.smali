.class public final Labvc;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Labvc;->a:Lbeye;

    .line 6
    iput-object p2, p0, Labvc;->b:Lbeye;

    .line 8
    return-void
.end method


# virtual methods
.method public final a()Labvb;
    .locals 2

    .line 1
    iget-object v0, p0, Labvc;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v0

    .line 9
    iget-object p0, p0, Labvc;->b:Lbeye;

    .line 11
    new-instance v1, Labvb;

    .line 13
    invoke-direct {v1, v0, p0}, Labvb;-><init>(Ldw;Lbhpa;)V

    .line 16
    return-object v1
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Labvc;->a()Labvb;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
