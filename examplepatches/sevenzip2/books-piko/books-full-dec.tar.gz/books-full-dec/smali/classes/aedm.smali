.class abstract Laedm;
.super Lacb;
.source "PG"


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0}, Lacb;-><init>(Z)V

    .line 5
    return-void
.end method


# virtual methods
.method public abstract h()V
.end method
