.class public final Lacjx;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lacjo;


# static fields
.field public static final a:Layxl;


# instance fields
.field public final b:Landroid/content/ContentResolver;

.field public final c:Lajuu;

.field public final d:Lalnh;

.field public final e:Ljava/util/Map;

.field public final f:Lyev;

.field public g:Lajut;

.field private final h:Lakuc;

.field private final i:Ljava/util/Set;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "com/google/android/apps/play/books/ebook/data/VolumeContentStore"

    .line 3
    invoke-static {v0}, Layxl;->i(Ljava/lang/String;)Layxl;

    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Lacjx;->a:Layxl;

    .line 9
    return-void
.end method

.method public constructor <init>(Landroid/content/ContentResolver;Lajuu;Lyev;Lalpu;Lalpu;Lalnh;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Lacjr;

    .line 6
    invoke-direct {v0, p0}, Lacjr;-><init>(Lacjx;)V

    .line 9
    iput-object v0, p0, Lacjx;->h:Lakuc;

    .line 11
    new-instance v1, Ljava/util/HashMap;

    .line 13
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 16
    iput-object v1, p0, Lacjx;->e:Ljava/util/Map;

    .line 18
    new-instance v1, Ljava/util/HashSet;

    .line 20
    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    .line 23
    iput-object v1, p0, Lacjx;->i:Ljava/util/Set;

    .line 25
    iput-object p1, p0, Lacjx;->b:Landroid/content/ContentResolver;

    .line 27
    iput-object p2, p0, Lacjx;->c:Lajuu;

    .line 29
    iput-object p3, p0, Lacjx;->f:Lyev;

    .line 31
    iput-object p6, p0, Lacjx;->d:Lalnh;

    .line 33
    invoke-interface {p4, v0}, Lalpu;->c(Lakuc;)V

    .line 36
    new-instance p1, Lacjs;

    .line 38
    invoke-direct {p1, p0}, Lacjs;-><init>(Lacjx;)V

    .line 41
    invoke-interface {p5, p1}, Lalpu;->c(Lakuc;)V

    .line 44
    return-void
.end method

.method public static j(Ljava/lang/String;Lajvv;)V
    .locals 2

    .line 1
    invoke-interface {p1, p0}, Lajvv;->c(Ljava/lang/String;)Ljava/io/File;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-static {v0, v1}, Lakuz;->h(Ljava/io/File;Ljava/util/Set;)Z

    .line 9
    invoke-interface {p1, p0}, Lajvv;->h(Ljava/lang/String;)Ljava/io/File;

    .line 12
    move-result-object p0

    .line 13
    invoke-static {p0, v1}, Lakuz;->h(Ljava/io/File;Ljava/util/Set;)Z

    .line 16
    return-void
.end method

.method public static final t(Ljava/lang/String;Ljava/lang/String;)Landroid/content/ContentProviderOperation;
    .locals 3

    .line 1
    new-instance v0, Landroid/content/ContentValues;

    .line 3
    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 10
    move-result-object v1

    .line 11
    const-string v2, "structure_status"

    .line 13
    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 16
    invoke-static {p0, p1}, Lyip;->b(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    .line 19
    move-result-object p0

    .line 20
    invoke-static {p0}, Landroid/content/ContentProviderOperation;->newUpdate(Landroid/net/Uri;)Landroid/content/ContentProviderOperation$Builder;

    .line 23
    move-result-object p0

    .line 24
    const-string p1, "1"

    .line 26
    filled-new-array {p1}, [Ljava/lang/String;

    .line 29
    move-result-object p1

    .line 30
    const-string v1, "structure_status=?"

    .line 32
    invoke-virtual {p0, v1, p1}, Landroid/content/ContentProviderOperation$Builder;->withSelection(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/ContentProviderOperation$Builder;

    .line 35
    move-result-object p0

    .line 36
    invoke-virtual {p0, v0}, Landroid/content/ContentProviderOperation$Builder;->withValues(Landroid/content/ContentValues;)Landroid/content/ContentProviderOperation$Builder;

    .line 39
    move-result-object p0

    .line 40
    invoke-virtual {p0}, Landroid/content/ContentProviderOperation$Builder;->build()Landroid/content/ContentProviderOperation;

    .line 43
    move-result-object p0

    .line 44
    return-object p0
.end method

.method public static final u(Ljava/lang/String;Ljava/lang/String;)Landroid/content/ContentProviderOperation;
    .locals 3

    .line 1
    new-instance v0, Landroid/content/ContentValues;

    .line 3
    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 6
    const/4 v1, 0x2

    .line 7
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 10
    move-result-object v1

    .line 11
    const-string v2, "content_status"

    .line 13
    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 16
    invoke-static {p0, p1}, Lyiy;->b(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    .line 19
    move-result-object p0

    .line 20
    invoke-static {p0}, Landroid/content/ContentProviderOperation;->newUpdate(Landroid/net/Uri;)Landroid/content/ContentProviderOperation$Builder;

    .line 23
    move-result-object p0

    .line 24
    const-string p1, "3"

    .line 26
    filled-new-array {p1}, [Ljava/lang/String;

    .line 29
    move-result-object p1

    .line 30
    const-string v1, "content_status=?"

    .line 32
    invoke-virtual {p0, v1, p1}, Landroid/content/ContentProviderOperation$Builder;->withSelection(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/ContentProviderOperation$Builder;

    .line 35
    move-result-object p0

    .line 36
    invoke-virtual {p0, v0}, Landroid/content/ContentProviderOperation$Builder;->withValues(Landroid/content/ContentValues;)Landroid/content/ContentProviderOperation$Builder;

    .line 39
    move-result-object p0

    .line 40
    invoke-virtual {p0}, Landroid/content/ContentProviderOperation$Builder;->build()Landroid/content/ContentProviderOperation;

    .line 43
    move-result-object p0

    .line 44
    return-object p0
.end method


# virtual methods
.method public final a()J
    .locals 2

    .line 1
    invoke-virtual {p0}, Lacjx;->c()Lajvv;

    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0}, Lajvv;->j()Ljava/io/File;

    .line 8
    move-result-object p0

    .line 9
    invoke-static {p0}, Lakuz;->e(Ljava/io/File;)Landroid/os/StatFs;

    .line 12
    move-result-object p0

    .line 13
    invoke-static {p0}, Lakuz;->a(Landroid/os/StatFs;)J

    .line 16
    move-result-wide v0

    .line 17
    return-wide v0
.end method

.method public final b()I
    .locals 1

    .line 1
    iget-object p0, p0, Lacjx;->f:Lyev;

    .line 3
    iget-object v0, p0, Lyev;->a:Lakxb;

    .line 5
    invoke-interface {v0}, Lakxb;->a()V

    .line 8
    iget p0, p0, Lyev;->b:I

    .line 10
    return p0
.end method

.method public final declared-synchronized c()Lajvv;
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, Lacjx;->f:Lyev;

    .line 4
    invoke-virtual {v0}, Lyev;->a()Lajvv;

    .line 7
    move-result-object v0

    .line 8
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    .line 9
    return-object v0

    .line 10
    :catchall_0
    move-exception v0

    .line 11
    :try_start_1
    monitor-exit p0

    .line 12
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public final d(Landroid/accounts/Account;)Ljava/io/File;
    .locals 1

    .line 1
    new-instance v0, Ljava/io/File;

    .line 3
    iget-object p1, p1, Landroid/accounts/Account;->name:Ljava/lang/String;

    .line 5
    invoke-virtual {p0}, Lacjx;->c()Lajvv;

    .line 8
    move-result-object p0

    .line 9
    invoke-interface {p0, p1}, Lajvv;->a(Ljava/lang/String;)Ljava/io/File;

    .line 12
    move-result-object p0

    .line 13
    const-string p1, "localState"

    .line 15
    invoke-direct {v0, p0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 18
    return-object v0
.end method

.method public final e(Ljava/lang/String;)Ljava/io/File;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lacjx;->c()Lajvv;

    .line 4
    move-result-object p0

    .line 5
    sget-object v0, Lyin;->a:Landroid/net/Uri;

    .line 7
    new-instance v0, Ljava/io/File;

    .line 9
    invoke-static {p0}, Lyin;->g(Lajvv;)Ljava/io/File;

    .line 12
    move-result-object p0

    .line 13
    invoke-direct {v0, p0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 16
    return-object v0
.end method

.method public final f(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lacjx;->c()Lajvv;

    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0, p1, p2}, Lajvv;->f(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    .line 8
    move-result-object p0

    .line 9
    new-instance p1, Ljava/io/File;

    .line 11
    const-string p2, "cover.png"

    .line 13
    invoke-direct {p1, p0, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 16
    return-object p1
.end method

.method public final g(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lacjx;->c()Lajvv;

    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0, p1, p2}, Lajvv;->f(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    .line 8
    move-result-object p0

    .line 9
    new-instance p1, Ljava/io/File;

    .line 11
    const-string p2, "cover_thumbnail.png"

    .line 13
    invoke-direct {p1, p0, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 16
    return-object p1
.end method

.method public final h(Ljava/lang/String;Ljava/lang/String;)V
    .locals 7

    .line 1
    :try_start_0
    iget-object p0, p0, Lacjx;->b:Landroid/content/ContentResolver;

    .line 3
    const-string v0, "com.google.android.apps.books"

    .line 5
    invoke-static {p1, p2}, Lacjx;->t(Ljava/lang/String;Ljava/lang/String;)Landroid/content/ContentProviderOperation;

    .line 8
    move-result-object p1

    .line 9
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/content/OperationApplicationException; {:try_start_0 .. :try_end_0} :catch_1

    const/4 p2, 0x1

    .line 10
    :try_start_1
    new-array p2, p2, [Landroid/content/ContentProviderOperation;

    .line 12
    const/4 v1, 0x0

    .line 13
    aput-object p1, p2, v1

    .line 15
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Landroid/content/OperationApplicationException; {:try_start_1 .. :try_end_1} :catch_0

    :try_start_2
    invoke-static {p2}, Laysp;->d([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {p0, v0, p1}, Landroid/content/ContentResolver;->applyBatch(Ljava/lang/String;Ljava/util/ArrayList;)[Landroid/content/ContentProviderResult;

    .line 22
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Landroid/content/OperationApplicationException; {:try_start_2 .. :try_end_2} :catch_1

    return-void

    .line 23
    :catch_0
    move-exception v0

    .line 24
    goto :goto_0

    .line 25
    :catch_1
    move-exception v0

    .line 26
    :goto_0
    move-object p0, v0

    .line 27
    move-object v6, p0

    .line 28
    sget-object p0, Lacjx;->a:Layxl;

    .line 30
    invoke-virtual {p0}, Layxb;->d()Layxz;

    .line 33
    move-result-object v0

    .line 34
    const/16 v4, 0x166

    .line 36
    const-string v5, "VolumeContentStore.java"

    .line 38
    const-string v1, "Error clearing page structure status"

    .line 40
    const-string v2, "com/google/android/apps/play/books/ebook/data/VolumeContentStore"

    .line 42
    const-string v3, "clearPageStructureStatus"

    .line 44
    invoke-static/range {v0 .. v6}, La;->A(Layxz;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;CLjava/lang/String;Ljava/lang/Throwable;)V

    .line 47
    return-void
.end method

.method public final i(Ljava/lang/String;Ljava/lang/String;)V
    .locals 7

    .line 1
    :try_start_0
    iget-object p0, p0, Lacjx;->b:Landroid/content/ContentResolver;

    .line 3
    const-string v0, "com.google.android.apps.books"

    .line 5
    invoke-static {p1, p2}, Lacjx;->u(Ljava/lang/String;Ljava/lang/String;)Landroid/content/ContentProviderOperation;

    .line 8
    move-result-object p1

    .line 9
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/content/OperationApplicationException; {:try_start_0 .. :try_end_0} :catch_1

    const/4 p2, 0x1

    .line 10
    :try_start_1
    new-array p2, p2, [Landroid/content/ContentProviderOperation;

    .line 12
    const/4 v1, 0x0

    .line 13
    aput-object p1, p2, v1

    .line 15
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Landroid/content/OperationApplicationException; {:try_start_1 .. :try_end_1} :catch_0

    :try_start_2
    invoke-static {p2}, Laysp;->d([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {p0, v0, p1}, Landroid/content/ContentResolver;->applyBatch(Ljava/lang/String;Ljava/util/ArrayList;)[Landroid/content/ContentProviderResult;

    .line 22
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Landroid/content/OperationApplicationException; {:try_start_2 .. :try_end_2} :catch_1

    return-void

    .line 23
    :catch_0
    move-exception v0

    .line 24
    goto :goto_0

    .line 25
    :catch_1
    move-exception v0

    .line 26
    :goto_0
    move-object p0, v0

    .line 27
    move-object v6, p0

    .line 28
    sget-object p0, Lacjx;->a:Layxl;

    .line 30
    invoke-virtual {p0}, Layxb;->d()Layxz;

    .line 33
    move-result-object v0

    .line 34
    const/16 v4, 0x134

    .line 36
    const-string v5, "VolumeContentStore.java"

    .line 38
    const-string v1, "Error clearing segment status"

    .line 40
    const-string v2, "com/google/android/apps/play/books/ebook/data/VolumeContentStore"

    .line 42
    const-string v3, "clearSegmentStatus"

    .line 44
    invoke-static/range {v0 .. v6}, La;->A(Layxz;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;CLjava/lang/String;Ljava/lang/Throwable;)V

    .line 47
    return-void
.end method

.method public final k(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    invoke-virtual {p0, p1, p2}, Lacjx;->f(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 8
    invoke-virtual {p0, p1, p2}, Lacjx;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    .line 11
    move-result-object p0

    .line 12
    invoke-virtual {p0}, Ljava/io/File;->delete()Z

    .line 15
    return-void
.end method

.method public final l(Lajut;)I
    .locals 0

    .line 1
    iget-object p0, p0, Lacjx;->e:Ljava/util/Map;

    .line 3
    iget-object p1, p1, Lajut;->c:Ljava/lang/String;

    .line 5
    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Ljava/lang/Integer;

    .line 11
    if-eqz p0, :cond_0

    .line 13
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    .line 16
    move-result p0

    .line 17
    return p0

    .line 18
    :cond_0
    const/4 p0, 0x0

    .line 19
    return p0
.end method

.method public final m(Lajut;Ljava/io/File;Ljava/lang/String;)Lyfg;
    .locals 3

    .line 1
    new-instance v0, Lyfg;

    .line 3
    new-instance v1, Lacjw;

    .line 5
    invoke-direct {v1, p0, p1}, Lacjw;-><init>(Lacjx;Lajut;)V

    .line 8
    new-instance v2, Lacjv;

    .line 10
    invoke-direct {v2, p0, p1, p3}, Lacjv;-><init>(Lacjx;Lajut;Ljava/lang/String;)V

    .line 13
    invoke-virtual {p0, p1}, Lacjx;->o(Lajut;)Lyfj;

    .line 16
    move-result-object p0

    .line 17
    invoke-direct {v0, p2, v1, v2, p0}, Lyfg;-><init>(Ljava/io/File;Lyfe;Lyff;Lyfj;)V

    .line 20
    return-object v0
.end method

.method public final n(Ljava/io/File;)Lyfg;
    .locals 4

    .line 1
    invoke-virtual {p0}, Lacjx;->p()Lajut;

    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Lyfg;

    .line 7
    new-instance v2, Lacjw;

    .line 9
    invoke-direct {v2, p0, v0}, Lacjw;-><init>(Lacjx;Lajut;)V

    .line 12
    new-instance v3, Lacjq;

    .line 14
    invoke-direct {v3, p0}, Lacjq;-><init>(Lacjx;)V

    .line 17
    invoke-virtual {p0, v0}, Lacjx;->o(Lajut;)Lyfj;

    .line 20
    move-result-object p0

    .line 21
    invoke-direct {v1, p1, v2, v3, p0}, Lyfg;-><init>(Ljava/io/File;Lyfe;Lyff;Lyfj;)V

    .line 24
    return-object v1
.end method

.method public final o(Lajut;)Lyfj;
    .locals 2

    .line 1
    invoke-virtual {p0}, Lacjx;->p()Lajut;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    iget-object v1, p1, Lajut;->c:Ljava/lang/String;

    .line 10
    iget-object v0, v0, Lajut;->c:Ljava/lang/String;

    .line 12
    invoke-static {v1, v0}, Lbhxq;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 18
    invoke-virtual {p0}, Lacjx;->b()I

    .line 21
    move-result p1

    .line 22
    new-instance v0, Lacjt;

    .line 24
    invoke-direct {v0, p0, p1}, Lacjt;-><init>(Lacjx;I)V

    .line 27
    return-object v0

    .line 28
    :cond_0
    invoke-virtual {p0, p1}, Lacjx;->l(Lajut;)I

    .line 31
    move-result v0

    .line 32
    new-instance v1, Lacju;

    .line 34
    invoke-direct {v1, p0, v0, p1}, Lacju;-><init>(Lacjx;ILajut;)V

    .line 37
    return-object v1
.end method

.method public final p()Lajut;
    .locals 2

    .line 1
    iget-object v0, p0, Lacjx;->g:Lajut;

    .line 3
    if-nez v0, :cond_1

    .line 5
    iget-object v0, p0, Lacjx;->f:Lyev;

    .line 7
    iget-object v1, v0, Lyev;->a:Lakxb;

    .line 9
    invoke-interface {v1}, Lakxb;->a()V

    .line 12
    invoke-virtual {v0}, Lyev;->a()Lajvv;

    .line 15
    move-result-object v0

    .line 16
    invoke-interface {v0}, Lajvv;->n()Z

    .line 19
    move-result v0

    .line 20
    iget-object v1, p0, Lacjx;->c:Lajuu;

    .line 22
    if-nez v0, :cond_0

    .line 24
    invoke-virtual {p0}, Lacjx;->c()Lajvv;

    .line 27
    move-result-object v0

    .line 28
    invoke-interface {v0}, Lajvv;->j()Ljava/io/File;

    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v1, v0}, Lajuu;->g(Ljava/io/File;)Lajut;

    .line 35
    move-result-object v0

    .line 36
    iput-object v0, p0, Lacjx;->g:Lajut;

    .line 38
    return-object v0

    .line 39
    :cond_0
    invoke-virtual {v1}, Lajuu;->k()Lajut;

    .line 42
    move-result-object v0

    .line 43
    iput-object v0, p0, Lacjx;->g:Lajut;

    .line 45
    :cond_1
    return-object v0
.end method

.method public final q(Lajut;Ljava/lang/String;)Ljava/io/File;
    .locals 3

    .line 1
    iget-object v0, p1, Lajut;->b:Lajvv;

    .line 3
    invoke-interface {v0, p2}, Lajvv;->e(Ljava/lang/String;)Ljava/io/File;

    .line 6
    move-result-object p2

    .line 7
    iget-object v0, p0, Lacjx;->i:Ljava/util/Set;

    .line 9
    invoke-interface {v0, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_1

    .line 15
    const/4 v0, 0x0

    .line 16
    :try_start_0
    invoke-static {p2, v0}, Lakuz;->i(Ljava/io/File;Ljava/util/Set;)Z

    .line 19
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 20
    :catch_0
    move-exception v0

    .line 21
    const/4 v1, 0x6

    .line 22
    const-string v2, "VolumeContentStore"

    .line 24
    invoke-static {v2, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 27
    move-result v1

    .line 28
    if-eqz v1, :cond_0

    .line 30
    const-string v1, "Error cleaning temp directory"

    .line 32
    invoke-static {v2, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 35
    :cond_0
    :goto_0
    iget-object v0, p0, Lacjx;->i:Ljava/util/Set;

    .line 37
    invoke-interface {v0, p2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 40
    :cond_1
    invoke-virtual {p0, p1, p2}, Lacjx;->v(Lajut;Ljava/io/File;)Ljava/io/File;

    .line 43
    move-result-object p0

    .line 44
    return-object p0
.end method

.method public final r(Ljava/lang/String;Ljava/lang/String;Lajut;)V
    .locals 0

    .line 1
    iget-object p0, p3, Lajut;->b:Lajvv;

    .line 3
    :try_start_0
    invoke-static {p0, p1, p2}, Lyin;->d(Lajvv;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    .line 6
    move-result-object p0

    .line 7
    const/4 p1, 0x0

    .line 8
    invoke-static {p0, p1}, Lakuz;->h(Ljava/io/File;Ljava/util/Set;)Z

    .line 11
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 12
    :catch_0
    move-exception p0

    .line 13
    const/4 p1, 0x6

    .line 14
    const-string p2, "VolumeContentStore"

    .line 16
    invoke-static {p2, p1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 19
    move-result p1

    .line 20
    if-eqz p1, :cond_0

    .line 22
    const-string p1, "Error deleting page structure files"

    .line 24
    invoke-static {p2, p1, p0}, Lakvo;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 27
    :cond_0
    return-void
.end method

.method public final s(Ljava/lang/String;Ljava/lang/String;Lajut;)V
    .locals 1

    .line 1
    iget-object p0, p3, Lajut;->b:Lajvv;

    .line 3
    :try_start_0
    invoke-static {p0, p1, p2}, Lyin;->f(Lajvv;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    .line 6
    move-result-object p3

    .line 7
    const/4 v0, 0x0

    .line 8
    invoke-static {p3, v0}, Lakuz;->h(Ljava/io/File;Ljava/util/Set;)Z

    .line 11
    invoke-static {p0, p1, p2}, Lyin;->c(Lajvv;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    .line 14
    move-result-object p0

    .line 15
    invoke-static {p0, v0}, Lakuz;->h(Ljava/io/File;Ljava/util/Set;)Z

    .line 18
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 19
    :catch_0
    move-exception p0

    .line 20
    const/4 p1, 0x6

    .line 21
    const-string p2, "VolumeContentStore"

    .line 23
    invoke-static {p2, p1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 26
    move-result p1

    .line 27
    if-eqz p1, :cond_0

    .line 29
    const-string p1, "Error deleting segment files"

    .line 31
    invoke-static {p2, p1, p0}, Lakvo;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 34
    :cond_0
    return-void
.end method

.method public final v(Lajut;Ljava/io/File;)Ljava/io/File;
    .locals 2

    .line 1
    const-string v0, "content"

    .line 3
    :try_start_0
    invoke-static {p2}, Lakuz;->k(Ljava/io/File;)V

    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-static {v0, v1, p2}, Ljava/io/File;->createTempFile(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    .line 10
    move-result-object p0

    .line 11
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    .line 12
    :catch_0
    move-exception v0

    .line 13
    new-instance v1, Lacjw;

    .line 15
    invoke-direct {v1, p0, p1}, Lacjw;-><init>(Lacjx;Lajut;)V

    .line 18
    invoke-interface {v1, v0, p2}, Lyfe;->a(Ljava/io/IOException;Ljava/io/File;)Ljava/io/IOException;

    .line 21
    move-result-object p0

    .line 22
    throw p0
.end method

.method public final w(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lacjx;->c()Lajvv;

    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0, p1, p2}, Lajvv;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    .line 8
    move-result-object p0

    .line 9
    new-instance p1, Ljava/io/File;

    .line 11
    const-string p2, "image"

    .line 13
    invoke-direct {p1, p0, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 16
    return-object p1
.end method
