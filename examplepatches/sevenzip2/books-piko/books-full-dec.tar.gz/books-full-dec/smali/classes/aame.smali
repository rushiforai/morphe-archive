.class public final Laame;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laame;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laame;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laame;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laame;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laame;->e:Lbeye;

    .line 14
    return-void
.end method


# virtual methods
.method public final a()Laama;
    .locals 7

    .line 1
    iget-object v0, p0, Laame;->a:Lbeye;

    .line 3
    check-cast v0, Lqgk;

    .line 5
    invoke-virtual {v0}, Lqgk;->a()Ldw;

    .line 8
    move-result-object v2

    .line 9
    iget-object v0, p0, Laame;->b:Lbeye;

    .line 11
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 14
    move-result-object v0

    .line 15
    move-object v3, v0

    .line 16
    check-cast v3, Laams;

    .line 18
    iget-object v0, p0, Laame;->c:Lbeye;

    .line 20
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 23
    move-result-object v0

    .line 24
    move-object v4, v0

    .line 25
    check-cast v4, Lalnn;

    .line 27
    iget-object v0, p0, Laame;->d:Lbeye;

    .line 29
    invoke-interface {v0}, Lbeye;->b()Ljava/lang/Object;

    .line 32
    move-result-object v0

    .line 33
    move-object v5, v0

    .line 34
    check-cast v5, Lalnn;

    .line 36
    iget-object p0, p0, Laame;->e:Lbeye;

    .line 38
    check-cast p0, Laamd;

    .line 40
    invoke-virtual {p0}, Laamd;->a()Laamc;

    .line 43
    move-result-object v6

    .line 44
    new-instance v1, Laama;

    .line 46
    invoke-direct/range {v1 .. v6}, Laama;-><init>(Ldw;Laams;Lalnn;Lalnn;Laawb;)V

    .line 49
    return-object v1
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Laame;->a()Laama;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
