.class public interface abstract Laed;
.super Ljava/lang/Object;
.source "PG"


# virtual methods
.method public abstract fS()Laec;
.end method
