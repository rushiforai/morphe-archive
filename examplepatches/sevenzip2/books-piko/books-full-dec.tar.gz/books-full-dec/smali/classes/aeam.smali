.class public final Laeam;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Lbexv;


# instance fields
.field private final a:Lbeye;

.field private final b:Lbeye;

.field private final c:Lbeye;

.field private final d:Lbeye;

.field private final e:Lbeye;

.field private final f:Lbeye;


# direct methods
.method public constructor <init>(Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;Lbeye;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Laeam;->a:Lbeye;

    .line 6
    iput-object p2, p0, Laeam;->b:Lbeye;

    .line 8
    iput-object p3, p0, Laeam;->c:Lbeye;

    .line 10
    iput-object p4, p0, Laeam;->d:Lbeye;

    .line 12
    iput-object p5, p0, Laeam;->e:Lbeye;

    .line 14
    iput-object p6, p0, Laeam;->f:Lbeye;

    .line 16
    return-void
.end method


# virtual methods
.method public final a()Laeal;
    .locals 7

    .line 1
    new-instance v0, Laeal;

    .line 3
    iget-object v1, p0, Laeam;->a:Lbeye;

    .line 5
    iget-object v2, p0, Laeam;->b:Lbeye;

    .line 7
    iget-object v3, p0, Laeam;->c:Lbeye;

    .line 9
    iget-object v4, p0, Laeam;->d:Lbeye;

    .line 11
    iget-object v5, p0, Laeam;->e:Lbeye;

    .line 13
    iget-object v6, p0, Laeam;->f:Lbeye;

    .line 15
    invoke-direct/range {v0 .. v6}, Laeal;-><init>(Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;Lbhpa;)V

    .line 18
    return-object v0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Laeam;->a()Laeal;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
